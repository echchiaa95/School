# v19 — Final runtime stabilization

- Teacher dashboard boot made non-fatal; grade list now uses teacher-authorized RPC.
- Institution location uses a dedicated admin RPC with explicit school scope.
- Driver passenger ordering controls are permanently visible on mobile.
- Notification detail dialog uses Arabic type labels and consistent empty-body text.

# v17 — Runtime follow-up fixes

- Teacher: the schedule card now explicitly loads the teacher-only schedule RPC when opened.
- Teacher: home initialization reports a precise missing-shell error instead of a null DOM failure.
- Guard: incident view is registered in the view map so the «بلاغ مخالفة» card opens instead of navigating to an undefined view.
- Admin: successful institution-location saves update the location card in place, avoiding a secondary full-panel refresh that could surface a generic initialization error.
- Cache version bumped to v23.

# CHANGELOG — smart-school-complete-v1

## Migration جديدة
- `supabase/migrations/phase12_complete_platform.sql` — 16 جدولًا جديدًا (user_permissions, subjects, attendance_records, student_grades, incidents, notifications, notification_reads, buses, transport_routes, route_stops, student_transport, trips, trip_events, fee_payments, expenses, class_schedule) + توسعة schools/classes/academic_years/profiles + ~65 دالة SECURITY DEFINER تغطي: الصلاحيات لكل مستخدم، السنوات/الأقسام/المواد، الحضور، النقاط، السلوك والمخالفات، الإشعارات، النقل المدرسي والرحلات، المالية، الجداول، ملف التلميذ الكامل، لوحة المؤسسة، سجل العمليات، إنشاء/تعديل المؤسسات الكامل، قائمة المستخدمين V2.
- `fn_has_permission` استُبدلت داخليًا (نفس التوقيع) لتقرأ منح `user_permissions` الفعلية — الحارس بلا منح لم يعد قادرًا على إنشاء حسابات.

## ملفات معدّلة
- `modules/permissions.js` — loadMyPermissions يقرأ من قاعدة البيانات (fn_my_permissions) مع fallback محلي؛ admin يُوجَّه إلى director.html؛ السماح لـ admin بفتح وحدة المدير.
- `modules/admin.js` — getGuardPermissions/grantPermission/revokePermission أصبحت RPCs حقيقية.
- `modules/ui.js` — إضافة fmtTime.
- `guard.html` — إضافة «بلاغ مخالفة» (مرخّصة بـ incidents.create) مع بحث عن تلميذ وإرسال فعلي؛ الترخيص الآن من قاعدة البيانات.

## ملفات جديدة
- `modules/ui.js` (سابقًا في هذه المرحلة)، `modules/school.js` — كل أغلفة RPC مع رسائل خطأ عربية.
- `modules/directorConsole.js`, `modules/teacherConsole.js`, `modules/driverConsole.js`, `modules/parentConsole.js`.
- `assets/css/platform.css`.
- `superadmin.html` — إعادة كتابة كاملة (لوحة المنصة، المؤسسات + تفاصيلها + إنشاء كامل، المستخدمون + بحث/فلاتر/تقسيم صفحات + تفاصيل/تعديل/تعطيل/أدوار، سجل العمليات).
- `director.html` — إعادة كتابة كاملة: 16 وحدة (المؤسسة، السنوات والأقسام، المواد، التلاميذ، الأساتذة، الحراس والصلاحيات، السائقون، أولياء الأمور، الحضور، الجدول، النقل، المالية، المخالفات، التقارير CSV/طباعة، الإشعارات، سجل العمليات).
- `teacher.html` — أقسامي، تحضير الحضور (حاضر/غائب/متأخر/مبرر)، إدخال النقاط، الجدول الزمني، الإبلاغ عن مخالفة، الإشعارات.
- `driver.html` — الحافلة، بدء/إنهاء الرحلة، تسجيل صعود/نزول التلاميذ، سجل الرحلات.
- `parent.html` — الأبناء، الحضور مع إحصاءات، النقاط، النقل، الأداءات مع الإجماليات، الإشعارات.
- `admin.html` — تحويل تلقائي إلى وحدة المؤسسة.

## Edge Functions (إعادة نشر مطلوبة)
- `create-platform-user`, `create-staff-account` — upsert للملفات، رسائل خطأ حقيقية، CORS.

## غير منفَّذ (بشفافية)
- رفع شعار المؤسسة إلى Supabase Storage — يُستخدم رابط صورة (logo_url) فقط.
- تصدير PDF — يتم عبر طباعة المتصفح (window.print)؛ التصدير المتاح CSV.
- GPS المباشر للحافلة — اختياري ولم يُفعّل؛ لا يؤثر على أي وظيفة.

---

# v1.1 — PHASE 12.1 PRODUCTION HARDENING

## Migration جديدة (وحيدة)
- `supabase/migrations/phase12_1_hardening.sql`:
  fn_list_permissions_catalog؛ fn_update_class(uuid,jsonb) بمنطق patch
  (غياب المفتاح = لا تغيير / null صريح = إزالة الأستاذ)؛ منع تعطيل السنة
  الحالية (YEAR_IS_CURRENT)؛ تقييد الأستاذ بأقسامه في fn_save_attendance و
  fn_get_class_attendance و fn_add_grade (NOT_YOUR_CLASS) مع التحقق من
  تبعية القسم لمؤسسة التلميذ.

## ملفات معدّلة
- `modules/permissions.js` — حذف fallback الصلاحيات الثابت نهائيًا؛ الفشل = صفر صلاحيات.
- `modules/admin.js` — كتالوج الصلاحيات عبر RPC.
- `modules/superadmin.js` — حذف listAllUsers القديمة؛ fn_list_all_users_v2 فقط.
- `modules/school.js` — updateClass بصيغة jsonb + رسائل خطأ جديدة.
- `modules/directorConsole.js` — نافذة تعديل القسم الكاملة (بدل prompt).

## فحوص ثابتة جديدة
- بناء جملة كل الوحدات والسكربتات المضمّنة: سليم.
- تطابق IDs لكل الصفحات الست: كامل.
- تطابق أسماء RPC (المستخدمة ⊆ المعرفة في migrations): كامل.
- أنماط ممنوعة (TODO/FIXME/alert/نصوص placeholder): صفر.

---

# v1.1.1 — Hotfix: updateClass patch payload

- `modules/school.js`: إصلاح `updateClass` ليرسل `p_data` (jsonb patch) إلى
  `fn_update_class(uuid, jsonb)` بدل المعاملات scalar القديمة
  (p_name/p_level/p_capacity/p_teacher_id/p_is_disabled) التي كانت تستدعي
  الـ signature القديمة — ما جعل تعديل القسم/إزالة الأستاذ يفشلان.
- السلوك المؤكد باختبارات Node فعلية (7/7 PASS):
  teacherId=null → {"teacher_id":null} (إزالة الأستاذ)؛ عدم تغيير الأستاذ →
  لا يُرسل teacher_id إطلاقًا؛ نفس الشيء لبقية الحقول؛ لا null تلقائي.
- `modules/directorConsole.js`: تأكيد أن نافذة تعديل القسم تبني patch صحيحًا
  (بدون تغيير / إزالة / تعيين أستاذ، سعة اختيارية، تعطيل).

## v1.2 — Production fixes (Phase 13)
- **SQL (`phase13_fixes.sql`, additive):** `fn_is_admin_or_guard` يشمل دور `director` (إصلاح رفض تسجيل التلميذ والكتابة عبر RLS للمدير) + إكمال سجلات `guards/teachers/drivers/parents` الناقصة من `user_roles` (INSERT فقط، idempotent).
- **create-platform-user:** ينشئ الآن سجل staff (guards/teachers/drivers/parents) مع الدور — حسابات SuperAdmin تظهر في لوحات المؤسسة.
- **create-staff-account:** أكواد أخطاء واضحة (EMAIL_EXISTS/SCHOOL_ACCESS_DENIED/AUTH_CREATE_FAILED/PROFILE_CREATE_FAILED/ROLE_CREATE_FAILED/STAFF_CREATE_FAILED) + إدراجات idempotent.
- **التنقل:** نظام history داخلي (`armViewHistory`/`pushViewState` في ui.js) — زر Back في الهاتف يرجع للشاشة السابقة داخل التطبيق، بلا صفحات بيضاء وبلا فقدان للجلسة.
- **الأخطاء:** `armErrorBoundary` — بانر عربي مع زر إعادة محاولة بدل الصفحة البيضاء؛ إزالة التحويل الأعمى إلى index.html بعد نجاح المصادقة.


## PHASE 26 — V12 HOTFIX
- إصلاح مخطط Audit الحقيقي (`actor_id`, `old_value`, `new_value`).
- إضافة تخزين شعار المؤسسة من الهاتف في `school-logos`.
- تحسين أخطاء الخريطة ورفع الشعار وQR.

## v16 — Runtime & UX stabilization
- Fixed audit trigger mismatch: audit_logs now receives old_data/new_data and actor_id.
- Added driver passenger ordering with persistent per-bus order and ↑/↓ mobile controls.
- Live map student status now derives from boarded_at/alighted_at, fixing false “لم يصعد”.
- Teacher schedule now resolves the authenticated teacher only, shows lesson times, current/next lesson, and no longer exposes other teachers' lessons.
- Teacher class card uses class_id correctly.
- Attendance roster redesigned with compact student rows and summary counts.
- Parent portal adds student timetable with exact lesson times.
- Guard incident-report dashboard card now opens its report screen.
- Trip-history modal now has explicit close controls, backdrop close, Escape close, and Leaflet cleanup.
- QR renderer now has modern/legacy library fallback and clearer loading logic.


## v18 — Runtime + Incident + Notification stabilization
- Fixed teacher dashboard init crash caused by missing `sc-class` element.
- Passenger reorder controls are visible and mobile-friendly.
- Guard incidents can target any school user and notify school admins.
- Institution location save made robust against audit-trigger failures.
- Notifications open in a consistent detail modal when clicked.
- Added `phase32_runtime_stabilization_plus.sql`.
