// ============================================================================
// modules/photoUpload.js
// Uploads a student photo to Supabase Storage (bucket "student-photos",
// created in phase20_badge_maps_transport_driver.sql) and saves the
// resulting public URL via fn_update_student_photo — never stores base64
// in the database, per instruction.
// ============================================================================

import { supabase } from './supabase.js?v=24';
import { updateStudentPhoto } from './school.js?v=24';

const MAX_BYTES = 5 * 1024 * 1024; // 5MB — plenty for an ID photo, keeps uploads fast on mobile data

/**
 * Render a photo box (existing photo or placeholder) with an "add/change
 * photo" control wired to Storage + fn_update_student_photo.
 * @param {HTMLElement} container
 * @param {{studentId:string, schoolId:string, photoUrl?:string}} p
 * @param {(newUrl:string)=>void} onSaved
 */
export function renderStudentPhotoBox(container, p, onSaved) {
  const inputId = 'photo-input-' + Math.random().toString(36).slice(2, 8);
  container.innerHTML = `
    <div style="text-align:center;">
      <div id="${inputId}-preview" style="width:120px; height:120px; border-radius:50%; margin:0 auto; overflow:hidden; background:#e5e7eb; display:flex; align-items:center; justify-content:center; font-size:40px;">
        ${p.photoUrl ? `<img src="${p.photoUrl}" alt="" style="width:100%; height:100%; object-fit:cover;">` : '👤'}
      </div>
      <input type="file" id="${inputId}" accept="image/*" capture="environment" hidden>
      <button type="button" class="quick-action-btn secondary" id="${inputId}-btn" style="margin-top:8px;">
        ${p.photoUrl ? '🔄 تغيير الصورة' : '📷 إضافة صورة'}
      </button>
      <div id="${inputId}-error" class="empty-state" style="color:#dc2626; display:none; margin-top:6px;"></div>
    </div>`;

  const fileInput = container.querySelector(`#${inputId}`);
  const btn = container.querySelector(`#${inputId}-btn`);
  const preview = container.querySelector(`#${inputId}-preview`);
  const errorBox = container.querySelector(`#${inputId}-error`);

  btn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', async () => {
    const file = fileInput.files?.[0];
    if (!file) return;
    errorBox.style.display = 'none';
    if (!file.type.startsWith('image/')) {
      errorBox.textContent = 'الرجاء اختيار ملف صورة.'; errorBox.style.display = 'block'; return;
    }
    if (file.size > MAX_BYTES) {
      errorBox.textContent = 'حجم الصورة كبير جدًا (الحد 5MB).'; errorBox.style.display = 'block'; return;
    }

    // Instant local preview while uploading.
    const localUrl = URL.createObjectURL(file);
    preview.innerHTML = `<img src="${localUrl}" alt="" style="width:100%; height:100%; object-fit:cover;">`;
    btn.disabled = true;
    btn.textContent = 'جارٍ الرفع...';

    try {
      const ext = (file.name.split('.').pop() || 'jpg').toLowerCase().replace(/[^a-z0-9]/g, '') || 'jpg';
      const path = `${p.schoolId}/${p.studentId}.${ext}`;
      const { error: upErr } = await supabase.storage
        .from('student-photos')
        .upload(path, file, { upsert: true, cacheControl: '3600', contentType: file.type });
      if (upErr) throw upErr;

      const { data: pub } = supabase.storage.from('student-photos').getPublicUrl(path);
      const publicUrl = pub.publicUrl + '?v=' + Date.now(); // cache-bust so "change photo" shows instantly

      const res = await updateStudentPhoto(p.studentId, publicUrl);
      if (!res.ok) throw new Error(res.error);

      btn.textContent = '🔄 تغيير الصورة';
      btn.disabled = false;
      onSaved && onSaved(publicUrl);
    } catch (e) {
      console.error('Photo upload failed:', e);
      errorBox.textContent = 'تعذر رفع الصورة، حاول مرة أخرى.';
      errorBox.style.display = 'block';
      btn.textContent = p.photoUrl ? '🔄 تغيير الصورة' : '📷 إضافة صورة';
      btn.disabled = false;
    }
  });
}
