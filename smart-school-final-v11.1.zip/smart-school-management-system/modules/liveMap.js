// ============================================================================
// modules/liveMap.js
// Admin "live bus tracking" map. Leaflet/OSM (same reasoning as
// mapPicker.js — no Google Maps API key exists in this project). Combines:
//   1) An initial fetch + periodic poll of fn_get_active_bus_locations
//      (always correct even if Realtime is unavailable on this project's
//      Supabase plan/config).
//   2) A Supabase Realtime subscription on bus_last_locations so a marker
//      actually glides to a new point the instant a GPS ping lands,
//      instead of waiting for the next poll.
// If a bus's last ping is older than STALE_MS, its marker is shown as
// stale ("⚠️ آخر تحديث منذ...") rather than silently left in place with
// no indication (item 23: never fake movement, always show staleness).
// ============================================================================

import { supabase } from './supabase.js';
import { getActiveBusLocations } from './school.js';
import { loadLeaflet } from './mapPicker.js';
import { esc, fmtTime } from './ui.js';

const POLL_MS = 12000;
const STALE_MS = 60000; // no ping for 60s+ -> flag as stale, don't just keep a "live" green dot

let map = null;
let markers = {}; // bus_id -> L.marker
let pollTimer = null;
let realtimeChannel = null;

function timeAgoAr(iso) {
  if (!iso) return '—';
  const s = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `منذ ${s} ثانية`;
  const m = Math.floor(s / 60);
  if (m < 60) return `منذ ${m} دقيقة`;
  return `منذ ${Math.floor(m / 60)} ساعة`;
}

function busIcon(stale) {
  return window.L.divIcon({
    html: `<div style="font-size:26px; filter:${stale ? 'grayscale(1) opacity(0.6)' : 'none'};">🚌</div>`,
    className: '', iconSize: [30, 30], iconAnchor: [15, 15],
  });
}

function popupHtml(row, stale) {
  return `<div style="min-width:180px; text-align:right;">
    <strong>${esc(row.driver_name || 'بدون سائق')}</strong><br>
    الحافلة: ${esc(row.bus_code || row.bus_plate || '—')}<br>
    ${row.route_name ? `المسار: ${esc(row.route_name)}<br>` : ''}
    الاتجاه: ${row.direction === 'pickup' ? 'نحو المدرسة' : 'نحو المنزل'}<br>
    ${row.speed != null ? `السرعة: ${Math.round(row.speed * 3.6)} كم/س<br>` : ''}
    بدأت: ${row.trip_started_at ? new Date(row.trip_started_at).toLocaleTimeString('ar') : '—'}<br>
    آخر تحديث: ${row.recorded_at ? timeAgoAr(row.recorded_at) : 'لا يوجد بعد'}
    ${stale ? '<br><span style="color:#dc2626;">⚠️ التحديث متأخر</span>' : ''}
  </div>`;
}

async function refresh() {
  const res = await getActiveBusLocations();
  const rows = res.ok ? res.data || [] : [];
  const container = document.getElementById('live-map-empty');
  if (container) container.hidden = rows.filter((r) => r.latitude != null).length > 0;

  const seen = new Set();
  rows.forEach((row) => {
    if (row.latitude == null || row.longitude == null) return;
    seen.add(row.bus_id);
    const stale = !row.recorded_at || (Date.now() - new Date(row.recorded_at).getTime() > STALE_MS);
    if (markers[row.bus_id]) {
      markers[row.bus_id].setLatLng([row.latitude, row.longitude]);
      markers[row.bus_id].setIcon(busIcon(stale));
      markers[row.bus_id].setPopupContent(popupHtml(row, stale));
    } else {
      markers[row.bus_id] = window.L.marker([row.latitude, row.longitude], { icon: busIcon(stale) })
        .addTo(map).bindPopup(popupHtml(row, stale));
    }
  });
  Object.keys(markers).forEach((busId) => {
    if (!seen.has(busId)) { map.removeLayer(markers[busId]); delete markers[busId]; }
  });
}

export async function renderLiveMap(container) {
  container.innerHTML = `
    <div id="live-map" style="width:100%; height:min(60vh, 420px); border-radius:10px; background:#e5e7eb;"></div>
    <p class="empty-state" id="live-map-empty" style="margin-top:8px;">لا توجد حافلات في رحلة نشطة الآن.</p>`;
  try {
    await loadLeaflet();
  } catch {
    container.innerHTML = '<div class="empty-state">تعذر تحميل الخريطة (تحقق من الاتصال بالإنترنت).</div>';
    return () => {};
  }
  map = window.L.map('live-map').setView([27.15, -13.2], 12);
  window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 19 }).addTo(map);
  setTimeout(() => map.invalidateSize(), 50);

  await refresh();
  pollTimer = setInterval(refresh, POLL_MS);

  // Best-effort Realtime: if this Supabase project doesn't have realtime
  // enabled for this table, the subscription simply never fires and the
  // poll above still keeps things correct — this is a pure enhancement.
  realtimeChannel = supabase
    .channel('bus-locations-live')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'bus_last_locations' }, () => refresh())
    .subscribe();

  return function cleanupLiveMap() {
    if (pollTimer) clearInterval(pollTimer);
    if (realtimeChannel) supabase.removeChannel(realtimeChannel);
    if (map) { map.remove(); map = null; }
    markers = {};
  };
}
