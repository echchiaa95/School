# Phase 103 Changelog

- Added per-run class assignment for bus route runs.
- Admin schedules each successive trip against one class.
- Driver UI removes manual class and direction selectors.
- Driver sees preassigned daily runs and a live roster preview for the selected run.
- Start time is flexible: early and late starts are allowed; actual start timestamp is recorded.
- A driver/bus cannot start a second trip while one is active.
- Lower-sequence runs in the same direction must be completed before later runs.
- Passenger roster is generated from transport assignments and the selected class.
