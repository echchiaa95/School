# Phase 85 — Financial Management Upgrade

## Delivered
- Added tenant-scoped fee plans for the three controlled fee types: school tuition, transport, and registration.
- Added billing periods (monthly, annual, one-time) and effective-date history.
- Added student-specific discounts (fixed amount or percentage), mandatory reasons, and explicit permission `finance.discount` for delegated staff.
- Added server-side fee quote calculation; the payment form now loads the active price and discount when a student and fee type are selected.
- Added audited payment correction RPC. The original `recorded_by` is preserved; the correcting account is stored separately in the immutable-style financial audit trail.
- Added payment correction history with actor email, timestamp, reason, and before/after values.
- Kept the existing `payments` table and its legacy uniqueness behavior; no parallel payments ledger was introduced.

## Database deployment
Run migrations in order after the Phase 84 migrations:
1. `supabase/migrations/phase85_financial_management.sql`

The migration expects the existing Phase 12 platform functions and tables:
`fn_my_primary_school`, `fn_is_school_staff`, `fn_has_permission`, `fn_safe_audit`, `schools`, `students`, `payments`, and `permissions`.

## Permissions
- `finance.discount`: can be delegated to a guard or other staff account through the existing permission management UI.
- `finance.adjust`: can be delegated for correcting existing payment records.
- School admins/directors retain the existing administrative access.

## Safety notes
- Fee plans are school-wide per fee type and effective period in this phase. Class-specific pricing is not yet implemented.
- A discount affects the server-generated quote for new payment entries; it does not silently rewrite historical payment amounts.
- Payment corrections require a reason and preserve before/after values and the correcting account.
- Existing `payments.recorded_by` is not overwritten during correction.
- No live Supabase database was available in this workspace. Apply the SQL to a staging project first and verify the schema and permissions before production.

## Verification
- `node --check` passed for all 30 JavaScript modules.
- Admin HTML duplicate-ID scan passed.
- Added API wrappers were checked against their exports/imports.
- ZIP integrity verified after packaging.
- PostgreSQL execution, RLS integration, and Vite production build remain unverified because no database connection/dependencies were available in this environment.
