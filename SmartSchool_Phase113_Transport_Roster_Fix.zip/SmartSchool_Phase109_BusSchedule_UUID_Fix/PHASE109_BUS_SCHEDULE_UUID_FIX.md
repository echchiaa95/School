# Phase 109 — Bus schedule UUID fix

## Root cause
`fn_list_buses()` returns `bus_id`, but the daily route scheduling form populated the bus selector from `b.id`. This produced an option value of `undefined`, which was sent to `fn_create_bus_route_run_days(p_bus_id uuid, ...)` and caused PostgreSQL error 22P02.

## Changes
- Populate the bus selector from `bus_id` (with `id` compatibility fallback).
- Exclude inactive buses from the scheduling selector.
- Validate bus, route, and class UUIDs before calling the RPC.
- Require a non-empty run name, valid sequence, selected weekdays, and valid departure time.
- Disable the submit button during the request and restore it in `finally`.

## Database
No database migration is required for this specific error. The existing `fn_create_bus_route_run_days` signature matches the client RPC arguments.
