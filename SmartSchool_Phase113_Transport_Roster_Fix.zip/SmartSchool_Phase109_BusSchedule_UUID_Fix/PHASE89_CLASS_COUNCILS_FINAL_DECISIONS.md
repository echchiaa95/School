# Phase 89 — Class Councils and Final Decisions

## Included
- Adds `class_councils` for the class, academic year, assessment period, meeting date/title, and meeting minutes.
- Adds `class_council_decisions` for each student's official council outcome (`PASS`, `REPEAT`, `REVIEW`), final average, notes, and decision audit metadata.
- Adds a secured class-final-results RPC. It calculates weighted averages from the existing `fn_student_subject_final_results` calculation and existing subject coefficients; it does not rewrite grade marks.
- The default recommendation threshold is half of the grading scale: 5/10 for levels whose name contains `ابتدائي` or `primary`, otherwise 10/20. The council can override the recommendation and explicitly record `REVIEW`.
- Adds council creation/update, individual decision update, atomic batch decision save (maximum 500 students), and council detail RPCs.
- Adds an admin workflow under Reports: select class/period, load results, record meeting minutes, choose each decision, and approve all decisions in one database transaction.
- Existing grades, assessments, marks, coefficients, report-card functions, and student data are retained.

## Apply
Run `supabase/migrations/phase89_class_councils_final_decisions.sql` after Phase 88.

## Security
- Council tables have RLS enabled and direct client table grants revoked.
- Reads/writes go through security-definer RPCs with school-scoped authorization.
- Decision writes verify every student belongs to the council's exact school, class, and academic year.
- Batch decision writes are atomic: a validation failure rolls back the entire batch.

## Validation performed
- JavaScript syntax checks across the project's JS modules.
- Admin HTML duplicate-ID check.
- Cross-check of RPC names against frontend wrappers and UI handlers.
- ZIP integrity test.
- No live Supabase migration, SQL execution, or browser end-to-end test was available. Apply to staging first and verify the grade scale for each class before approving official decisions.
