# Phase 104 — Weekly scheduling and route management

## What's included
- Schedule a bus run on every day of the week or any selected subset of weekdays.
- Keep the legacy `weekday` column populated with the first selected weekday for compatibility; `days_of_week` is authoritative for new scheduling.
- Driver run listing, start validation, and passenger roster now use `days_of_week`.
- Admin route list now exposes Edit and Delete actions.
- Route editing updates the route name and ordered stop links, then updates linked classes.
- Route deletion is intentionally blocked when active student transport assignments, scheduled/historical runs, or trip history exist. This avoids breaking transport history.

## Install
1. Back up the database.
2. Apply `supabase/migrations/phase104_weekly_days_route_management.sql` after Phases 101 and 103.
3. Deploy the updated project files.
4. Test on a non-production route first.

## UI behavior
- Select one or more weekdays, or use "كل أيام الأسبوع".
- The run table displays all selected weekdays.
- Route list has Edit and Delete buttons.
- A route with linked transport data cannot be hard-deleted; the UI displays the database error.

## Important
This migration has not been executed against the live Supabase project. Verify the migration against the live schema and test a sample route and multi-day schedule before production use.
