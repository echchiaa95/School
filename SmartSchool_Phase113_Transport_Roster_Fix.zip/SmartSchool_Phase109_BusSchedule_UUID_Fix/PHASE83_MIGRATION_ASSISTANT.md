# Phase 83 — Durable Migration Assistant Foundation

## Delivered

- Added tenant-scoped migration job, row-outcome, and batch-history tables.
- Added SECURITY DEFINER RPCs for job creation, batch outcome persistence, job finalization, cancellation before successful writes, job history, and row-level history.
- RPCs verify authenticated school staff access with the existing `fn_is_school_staff` helper. Browser clients have no direct table grants; all access is mediated by the RPCs.
- Student Excel/CSV import now creates a durable migration job and records each 25-row chunk as `PROCESSING` before calling the existing student-registration RPC, then persists final outcomes.
- If the browser/network stops after student creation but before outcome persistence, the affected row is marked `NEEDS_REVIEW`; it is not automatically retried, avoiding silent duplicate creation.
- Added migration history and row-level outcome review to the Student Import Center.
- Error messages and metadata are length-bounded. Raw source rows and parent/student personal details are not stored in migration logs.

## Database migration required

Apply `supabase/migrations/phase83_institution_migration_assistant.sql` in the Supabase SQL Editor or through the project's normal migration deployment process before using durable migration history.

This workspace does not have a live Supabase database session, so the migration was not applied remotely and RPC/RLS execution was not integration-tested here.

## Safety boundaries

- Cancellation is allowed only when no student row has been successfully imported.
- The system deliberately does not delete successfully imported students as an automatic rollback. Deletion may break later enrollments, badges, attendance, or financial references and requires a separate reviewed recovery procedure.
- `NEEDS_REVIEW` rows require manual reconciliation. The current phase does not automatically re-run uncertain records.
- The existing student registration RPC remains the authority for creating student records and enforcing school/class/year permissions.
- This phase does not yet migrate parent accounts/links, academic results, historic finance, transport, staff, or document archives. Their actual schemas and data invariants must be reviewed before implementing those importers.

## Verification

- `node --check` passed for all JavaScript modules in the project.
- HTML structural parse completed without parser exceptions.
- SQL was statically reviewed against existing helper names and confirmed project schema references; no live PostgreSQL execution was available.
- Full Vite production build was not run because dependencies were unavailable in the workspace and `npm install` did not complete within the execution window.

## Follow-on phase

Phase 84 adds a separate same-platform Smart School JSON backup transfer wizard and safe restore RPCs. It does not turn third-party legacy exports into a full-fidelity migration; source-specific mappings for parent accounts, staff identities, historical results, finance, and archives remain future work.
