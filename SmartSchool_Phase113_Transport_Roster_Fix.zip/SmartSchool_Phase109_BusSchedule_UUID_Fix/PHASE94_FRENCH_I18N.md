# Phase 94 — French language (AR ⇄ FR)

- Added a language switcher (العربية / Français, bottom corner of every page). The choice is saved and shared by all pages and open tabs; switching reloads the page so dates, numbers, maps and JS-built text are always consistent. `<html lang/dir>` flips RTL ⇄ LTR before first paint.
- New `modules/i18n-boot.js` (sync, in `<head>`), `modules/i18n.js` (runtime translator + MutationObserver, also covers alert/confirm/prompt and dynamically rendered content), `modules/i18n-fr.js` (dictionary, ~2,060 entries).
- Dates, times and currency follow the language (`window.ssLoc`), DH replaces د.م.
- Translated: every page and module (login, reset, certificate check, parent, admin, teacher, driver, guard, super-admin, landing, school site, live map, import/migration tools, all RPC errors). ~2,060 dictionary entries; extraction found no remaining Arabic UI text.
- Debug: open any page with `?i18n_debug=1`, then run `copy(JSON.stringify(ssMissing(),null,2))`.

## How it works
Arabic stays the source language. In French mode the translator replaces text nodes, placeholder/title/aria-label/alt attributes, button values and the page title using exact phrases first, then regex patterns, then bounded fragment replacement (short keys never touch long free text, so names and user content stay untouched). Mark any element `data-no-i18n` to exclude it.

## Adding strings
1. Open the page with `?i18n_debug=1` in French mode and use the page.
2. `copy(JSON.stringify(ssMissing(), null, 2))`
3. Add `"عربي": "Français"` pairs to `modules/i18n-fr.js`.

## Not tested
Verified: JS syntax, dictionary coverage of extracted strings, translator logic in Node. Browser-tested (headless Chromium, offline): all 13 pages in French show no remaining Arabic text, dir/lang flip correctly, the switcher persists the choice and reloads other open tabs. Not tested while logged in (admin/parent/teacher data screens) — check tables, sticky headers and maps in LTR on staging.

## Known limits
- Text typed by users or stored in the database (post titles, names, notes) stays as written; short fragments that equal a dictionary phrase may be translated. Add `data-no-i18n` to an element to opt out.
- Strings built by concatenating pieces in JS are translated piece by piece, so French word order may be slightly stilted in a few messages; add a pattern in `PATTERNS` to fix any you notice.
- Messages generated server-side in SQL are translated only if the exact text is in the dictionary (parent document-request notifications are included).
