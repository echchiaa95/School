# V93 Changelog — — Parent Document Requests: fixes + features

- **Fix (critical):** Admin → Reports request inbox never loaded: `listSchoolDocumentRequests` / `updateSchoolDocumentRequest` were not imported in `adminConsole.js`.
- **Fix:** parent portal now shows readable Arabic errors (was raw RPC codes); listeners bound once (no duplicate submissions).
- **New:** parent can download the document when READY/DELIVERED (private bucket, narrow storage policy).
- **New:** parent can cancel an open request; duplicate open requests and >10 open requests are blocked server-side.
- **New:** automatic in-app notification to the parent on each status change.
- **New:** admin picks the archive document from a list with preview (no more pasting a UUID); search by student name, counters, reject allowed from APPROVED.
- Apply `supabase/migrations/phase93_parent_document_requests_hardening.sql` after Phase 92. See `PHASE93_DOCUMENT_REQUESTS_HARDENING.md`.

