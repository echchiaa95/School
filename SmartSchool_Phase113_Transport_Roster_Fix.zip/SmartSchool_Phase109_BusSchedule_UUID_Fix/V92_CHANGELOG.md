# V92 Changelog
- Added parent_document_requests with school, student, parent, request type, purpose, lifecycle, admin response, and archive linkage.
- Added parent RPCs for secure submission and personal request tracking.
- Added school-scoped admin RPCs for request inbox and lifecycle updates.
- Added parent portal request form and status history.
- Added admin Reports inbox, status filter, and review/approve/reject/ready/delivered actions.
- READY requires an active Phase 91 archive document linked to the same student and school.
