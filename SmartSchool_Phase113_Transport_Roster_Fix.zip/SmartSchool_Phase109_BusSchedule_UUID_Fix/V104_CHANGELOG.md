# Phase 104
- Added recurring weekly weekday selection for bus route runs.
- Updated driver schedule, trip start, and roster RPCs to honor all selected weekdays.
- Added route edit and guarded delete actions in the admin transport panel.
- Normalized route stop payloads to JSON objects for create/update RPCs.
