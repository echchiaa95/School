# V90 Changelog

- Added sequential school certificate numbering and immutable issuance snapshots.
- Added secure issue, list, cancellation, and public verification RPCs.
- Added enrollment, success, transfer, and departure certificate workflows.
- Added Admin → Reports certificate register with student search, issue, print, filter, and cancel.
- Added `verify-certificate.html` with privacy-limited public validation.
- Success certificates require an active enrollment and an approved annual `PASS` council decision.
