# V94 Changelog — — French language (AR ⇄ FR)

- Added a language switcher (العربية / Français, bottom corner of every page). The choice is saved and shared by all pages and open tabs; switching reloads the page so dates, numbers, maps and JS-built text are always consistent. `<html lang/dir>` flips RTL ⇄ LTR before first paint.
- New `modules/i18n-boot.js` (sync, in `<head>`), `modules/i18n.js` (runtime translator + MutationObserver, also covers alert/confirm/prompt and dynamically rendered content), `modules/i18n-fr.js` (dictionary, ~2,060 entries).
- Dates, times and currency follow the language (`window.ssLoc`), DH replaces د.م.
- Translated: every page and module (login, reset, certificate check, parent, admin, teacher, driver, guard, super-admin, landing, school site, live map, import/migration tools, all RPC errors). ~2,060 dictionary entries; extraction found no remaining Arabic UI text.
- Fix: landing-page phone mockup text was white on white (invisible in both languages).
- Debug: open any page with `?i18n_debug=1`, then run `copy(JSON.stringify(ssMissing(),null,2))`.

