# V89 Changelog
- Class council minutes and per-student final decisions.
- Weighted class result summary based on existing subject-final-results calculation.
- PASS / REPEAT / REVIEW decisions with council override and notes.
- Atomic batch approval and school/class/year authorization.
- Admin reports UI for council sessions and final decisions.
