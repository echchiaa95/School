# Phase 88 — Annual Student Progression

## Included
- A protected progression ledger records the student's source year/class, destination year/class, promotion/repetition outcome, operator, timestamp, and optional note.
- Candidate listing is scoped to the caller's school and an existing active class enrollment.
- Batch processing moves selected students into destination-year classes, changes the previous enrollment to `COMPLETED`, and inserts a new `ACTIVE` enrollment. Previous enrollment rows are retained.
- Per-student progression history is available through a secured RPC and from the admin annual-progression panel.
- The admin panel supports selecting a source class, destination year, target class per student, and either promotion or repeating the level.
- Batch size is capped at 500 and concurrent processing for the same student is serialized.

## Apply
Run `supabase/migrations/phase88_annual_student_progression.sql` after Phase 87.

## Schema compatibility
The migration uses the project's confirmed columns: `academic_years.label`, `classes.name`, `classes.academic_year_id`, and `student_enrollments(student_id, school_id, class_id, academic_year_id, status)`. It does not rename or delete existing records.

At execution time, the progression RPC inspects the deployed `student_enrollments.status` type and any status CHECK constraint. It selects an available closed value from `COMPLETED`, `INACTIVE`, `CLOSED`, or `TRANSFERRED`. If no supported value exists, it aborts with `NO_SUPPORTED_CLOSED_ENROLLMENT_STATUS` before processing students. For an unconstrained text status column it uses `COMPLETED`.

## Validation performed
- Static source and JavaScript syntax checks.
- ZIP archive integrity check.
- No live Supabase SQL execution or end-to-end browser test was available in this environment.
