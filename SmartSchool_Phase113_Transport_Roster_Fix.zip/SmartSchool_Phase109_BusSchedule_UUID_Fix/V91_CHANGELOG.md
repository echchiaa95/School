# V91 Changelog

- Added a private school archive Storage bucket with staff-only access.
- Added school-scoped document metadata and secure register/list/archive RPCs.
- Added upload validation for type, size, ownership, and object path.
- Added Admin → Reports archive UI for student-linked and general institutional documents.
- Added temporary signed downloads and soft archival with reason.
