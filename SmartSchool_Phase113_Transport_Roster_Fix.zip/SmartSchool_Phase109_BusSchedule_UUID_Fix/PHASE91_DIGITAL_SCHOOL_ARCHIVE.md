# Phase 91 — Digital School Archive

## Included
- Adds a private Supabase Storage bucket named `school-archive` with a 20 MB per-file limit and an allowlist of PDF, JPEG, PNG, WebP, DOC, DOCX, XLS, XLSX, and TXT.
- Adds `school_archive_documents` metadata with school, optional student, optional academic year, optional certificate link, category, title, description, original filename, MIME type, size, storage path, uploader, and lifecycle status.
- Adds secure RPCs:
  - `fn_register_archive_document`: verifies school scope, selected student/year/certificate ownership, allowed category/MIME/size, the exact generated path layout, and that the uploaded object exists.
  - `fn_list_archive_documents`: lists school-scoped metadata with query, student, year, category, status, and limit filters.
  - `fn_archive_document`: archives a document with a required reason; it does not delete the stored file.
- Adds an Admin → Reports archive panel with student lookup, academic-year selection, category, title/description, file upload, search, download, and archive actions.
- Downloads use a short-lived signed URL (120 seconds); files are not publicly readable.
- Supports general institutional documents by leaving the student unselected.

## Storage path
Objects are written under:
`<school_id>/<academic_year_id-or-unassigned>/<student_id-or-general>/<random-file-id>.<extension>`

The database registration RPC validates this structure and confirms the Storage object exists before inserting the metadata row.

## Apply
Apply `supabase/migrations/phase91_digital_school_archive.sql` after Phase 90.

## Security
- `school-archive` is private (`public = false`).
- Storage read/insert/update/delete policies require authenticated school staff and enforce the school ID in the first path segment.
- Metadata table has RLS enabled and direct table grants revoked.
- Metadata reads/writes occur through school-scoped SECURITY DEFINER RPCs.
- Signed download URLs are created only after the authenticated Storage read policy succeeds.
- Archive action is a soft state transition; it does not physically delete the file.

## Validation performed
- JavaScript syntax checks across all project modules.
- Admin HTML duplicate-ID and required UI ID checks.
- Frontend wrapper/RPC wiring checks.
- SQL static checks for RLS, private bucket, size/MIME validation, tenant checks, path checks, and RPC grants.
- ZIP integrity test.
- No live Supabase migration, Storage upload, or browser end-to-end test was available. Apply to staging first and test with two different school accounts to verify tenant isolation.
