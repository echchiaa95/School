# Phase 96 — Professional reports and parent document request UX

## UI changes
- Report outputs open in a dedicated modal instead of being appended at the bottom of the reports page.
- Modal includes global search, date range controls, class scope and person scope controls, and CSV/Excel/PDF actions.
- Attendance report is grouped to one row per student with total marked days, present, absent, late and excused counts. Absence/late counts open a drill-down list.
- Payment journal now includes the fee month parsed from the legacy fee label and the actual payment date.
- Parent document requests are now shown inside the selected child's detail view. The request form only asks for document type and purpose; child identity is inherited from the open child card.

## Database
Run `supabase/migrations/phase96_professional_report_details.sql` in Supabase SQL Editor to enable attendance drill-down dates and record timestamps.

## Timestamp note
`attendance_records.created_at` is the time the attendance row was recorded by the system. It is not necessarily the physical time the student arrived. Accurate arrival times require a separate check-in timestamp captured by the attendance workflow.

## Verification
- `node --check modules/adminConsole.js`
- `node --check modules/parentConsole.js`
- Live Supabase RPC execution and production browser testing remain required.
