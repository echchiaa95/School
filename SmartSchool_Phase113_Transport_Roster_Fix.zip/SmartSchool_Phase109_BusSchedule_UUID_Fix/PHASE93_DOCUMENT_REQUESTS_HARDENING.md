# Phase 93 — Document Requests Hardening

## Deploy order
1. Phase 91 and 92 migrations (already applied)
2. `supabase/migrations/phase93_parent_document_requests_hardening.sql`
3. Deploy the frontend (`modules/*.js`, `admin.html`)

## Security notes
- The parent storage policy only exposes objects linked to the caller's own READY/DELIVERED request, via the SECURITY DEFINER helper `fn_parent_can_read_archive_object`; staff policies are unchanged.
- Download links are signed for 120 seconds (existing helper).
- Notification failures never block a status update (exception-guarded).

## Not tested
Static JS syntax, import/export wiring and SQL structure were checked. No live Supabase run, multi-role test or storage test was done — test on staging with a parent and an admin account first:
1. Parent submits → duplicate blocked → cancel works.
2. Admin: review → approve → ready (pick doc) → parent downloads → delivered.
3. A second parent (not linked) cannot download the file.
