# Phase 100 — Batch fee payments

## Purpose
Adds a single-receipt workflow for paying one or more selected student fee obligations, including partial amounts. The legacy `payments` table and its existing RPCs are unchanged.

## Installation
1. Apply Phase 99 first (`phase99_fee_obligations_ledger.sql`).
2. Run `supabase/migrations/phase100_batch_fee_payments.sql` in Supabase SQL Editor.
3. Deploy the updated frontend files (`admin.html`, `modules/adminConsole.js`, `modules/school.js`).

## Admin workflow
1. Open Finance and select a student in the existing payment student search.
2. Click “عرض مستحقات التلميذ”.
3. Select one or more unpaid/partially-paid monthly or annual obligations.
4. Adjust the amount per selected obligation (partial settlement is supported).
5. Enter payment date, method, receipt number and optional note.
6. Submit once. The server validates each allocation under row locks, records one transaction, allocates it to all selected obligations and updates each obligation status atomically. A printable consolidated receipt opens after success.

## Security and compatibility
- New RPCs are `SECURITY DEFINER` with explicit authentication, school and finance permission checks.
- Direct table access remains revoked; the RPCs are granted to `authenticated` only.
- Existing legacy payment records and `payments_student_id_month_year_key` are not altered.
- The database migration has not been executed against the live Supabase project; apply it there and verify with a test student before production use.
