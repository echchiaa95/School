-- ============================================================================
-- Phase 87: Advanced student attendance (absence reasons, lateness, audit,
-- repeated-absence monitoring). Additive migration; existing attendance data
-- and RPC contracts remain compatible.
-- ============================================================================

alter table public.attendance_records
  add column if not exists excuse_reason text,
  add column if not exists minutes_late integer,
  add column if not exists correction_reason text;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.attendance_records'::regclass
      and conname = 'attendance_records_minutes_late_check'
  ) then
    alter table public.attendance_records
      add constraint attendance_records_minutes_late_check
      check (minutes_late is null or (minutes_late between 1 and 1440));
  end if;
end $$;

create table if not exists public.attendance_change_audit (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  attendance_id uuid not null references public.attendance_records(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  att_date date not null,
  old_values jsonb,
  new_values jsonb not null,
  change_reason text,
  changed_by uuid references public.profiles(id),
  changed_at timestamptz not null default now()
);

create index if not exists idx_attendance_audit_school_date
  on public.attendance_change_audit(school_id, changed_at desc);
create index if not exists idx_attendance_audit_student
  on public.attendance_change_audit(student_id, changed_at desc);

alter table public.attendance_change_audit enable row level security;
revoke all on public.attendance_change_audit from anon, authenticated;

create or replace function public.fn_audit_attendance_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'UPDATE' and (
    old.status is distinct from new.status
    or old.note is distinct from new.note
    or old.excuse_reason is distinct from new.excuse_reason
    or old.minutes_late is distinct from new.minutes_late
  ) then
    insert into public.attendance_change_audit(
      school_id, attendance_id, student_id, class_id, att_date,
      old_values, new_values, change_reason, changed_by
    ) values (
      new.school_id, new.id, new.student_id, new.class_id, new.att_date,
      jsonb_build_object(
        'status', old.status, 'note', old.note,
        'excuse_reason', old.excuse_reason, 'minutes_late', old.minutes_late
      ),
      jsonb_build_object(
        'status', new.status, 'note', new.note,
        'excuse_reason', new.excuse_reason, 'minutes_late', new.minutes_late
      ),
      nullif(trim(new.correction_reason), ''), auth.uid()
    );
  end if;
  return new;
end;
$$;

drop trigger if exists trg_attendance_change_audit on public.attendance_records;
create trigger trg_attendance_change_audit
after update on public.attendance_records
for each row execute function public.fn_audit_attendance_change();

-- Preserve the existing attendance RPC signature and authorization rules.
create or replace function public.fn_save_attendance(
  p_class_id uuid,
  p_date date,
  p_rows jsonb
)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_row jsonb;
  v_count integer := 0;
  v_is_teacher boolean;
  v_status text;
  v_minutes integer;
begin
  select school_id into v_school_id
  from public.classes where id = p_class_id;
  if v_school_id is null then raise exception 'INVALID_CLASS'; end if;

  select exists (
    select 1 from public.teachers t
    where t.school_id = v_school_id
      and t.profile_id = auth.uid()
      and t.deleted_at is null
  ) into v_is_teacher;

  if not (public.fn_is_school_staff(v_school_id)
          or v_is_teacher
          or public.fn_has_permission('attendance.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if p_rows is null or jsonb_typeof(p_rows) <> 'array' then
    raise exception 'INVALID_ROWS';
  end if;

  for v_row in select * from jsonb_array_elements(p_rows)
  loop
    if not exists (
      select 1 from public.student_enrollments se
      where se.student_id = (v_row->>'student_id')::uuid
        and se.class_id = p_class_id
        and se.status = 'ACTIVE'
    ) then
      continue;
    end if;

    v_status := coalesce(v_row->>'status', '');
    if v_status not in ('present', 'absent', 'late', 'excused') then
      continue;
    end if;

    v_minutes := nullif(v_row->>'minutes_late', '')::integer;
    if v_status = 'late' and (v_minutes is null or v_minutes < 1 or v_minutes > 1440) then
      v_minutes := null;
    elsif v_status <> 'late' then
      v_minutes := null;
    end if;

    insert into public.attendance_records(
      school_id, student_id, class_id, att_date, status, note,
      excuse_reason, minutes_late, correction_reason, recorded_by
    ) values (
      v_school_id, (v_row->>'student_id')::uuid, p_class_id,
      coalesce(p_date, current_date), v_status,
      nullif(trim(coalesce(v_row->>'note', '')), ''),
      case when v_status = 'excused'
        then nullif(trim(coalesce(v_row->>'excuse_reason', '')), '') else null end,
      v_minutes,
      nullif(trim(coalesce(v_row->>'correction_reason', '')), ''),
      auth.uid()
    )
    on conflict (student_id, class_id, att_date)
    do update set
      status = excluded.status,
      note = excluded.note,
      excuse_reason = excluded.excuse_reason,
      minutes_late = excluded.minutes_late,
      correction_reason = excluded.correction_reason,
      recorded_by = excluded.recorded_by,
      updated_at = now();

    v_count := v_count + 1;
  end loop;

  perform public.fn_safe_audit(
    v_school_id, 'SAVE_ATTENDANCE', 'attendance_records', p_class_id,
    null, jsonb_build_object('date', coalesce(p_date, current_date), 'count', v_count)
  );
  return v_count;
end;
$$;

revoke all on function public.fn_save_attendance(uuid, date, jsonb) from public;
grant execute on function public.fn_save_attendance(uuid, date, jsonb) to authenticated;

create or replace function public.fn_attendance_absence_alerts(
  p_from date default null,
  p_to date default null,
  p_threshold integer default 3
)
returns table(
  student_id uuid,
  full_name text,
  student_number text,
  class_id uuid,
  class_name text,
  absence_count bigint,
  last_absence date,
  absence_dates date[]
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  v_school_id := public.fn_my_primary_school();
  if v_school_id is null then raise exception 'NO_SCHOOL_CONTEXT'; end if;
  if not (public.fn_is_school_member(v_school_id)
          or public.fn_has_permission('attendance.view', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if coalesce(p_threshold, 0) < 1 or p_threshold > 365 then
    raise exception 'INVALID_ABSENCE_THRESHOLD';
  end if;

  return query
  select
    st.id, st.full_name, st.student_number, c.id, c.name,
    count(*)::bigint, max(ar.att_date), array_agg(ar.att_date order by ar.att_date)
  from public.attendance_records ar
  join public.students st on st.id = ar.student_id
  join public.classes c on c.id = ar.class_id
  where ar.school_id = v_school_id
    and ar.status = 'absent'
    and ar.att_date >= coalesce(p_from, current_date - 30)
    and ar.att_date <= coalesce(p_to, current_date)
  group by st.id, st.full_name, st.student_number, c.id, c.name
  having count(*) >= p_threshold
  order by count(*) desc, max(ar.att_date) desc, st.full_name;
end;
$$;

revoke all on function public.fn_attendance_absence_alerts(date, date, integer) from public;
grant execute on function public.fn_attendance_absence_alerts(date, date, integer) to authenticated;

create or replace function public.fn_attendance_audit_history(
  p_student_id uuid,
  p_from date default null,
  p_to date default null
)
returns table(
  changed_at timestamptz,
  att_date date,
  old_values jsonb,
  new_values jsonb,
  change_reason text,
  changed_by_name text
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select s.school_id into v_school_id
  from public.students s where s.id = p_student_id;
  if v_school_id is null then raise exception 'INVALID_STUDENT'; end if;
  if not (public.fn_is_school_member(v_school_id)
          or public.fn_has_permission('attendance.view', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select a.changed_at, a.att_date, a.old_values, a.new_values,
         a.change_reason, p.full_name
  from public.attendance_change_audit a
  left join public.profiles p on p.id = a.changed_by
  where a.school_id = v_school_id
    and a.student_id = p_student_id
    and (p_from is null or a.att_date >= p_from)
    and (p_to is null or a.att_date <= p_to)
  order by a.changed_at desc
  limit 100;
end;
$$;

revoke all on function public.fn_attendance_audit_history(uuid, date, date) from public;
grant execute on function public.fn_attendance_audit_history(uuid, date, date) to authenticated;
