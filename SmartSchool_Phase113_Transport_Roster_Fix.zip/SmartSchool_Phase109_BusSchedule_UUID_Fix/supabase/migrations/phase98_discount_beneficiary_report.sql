-- Phase 98: transparent discount beneficiary reporting (additive, preserves Phase 85 data).
CREATE OR REPLACE FUNCTION public.fn_report_student_fee_discounts(
  p_from date DEFAULT NULL,
  p_to date DEFAULT NULL,
  p_class_id uuid DEFAULT NULL,
  p_fee_type text DEFAULT NULL,
  p_status text DEFAULT NULL
)
RETURNS TABLE(
  discount_id uuid, student_id uuid, student_name text, student_number text,
  class_id uuid, class_name text, fee_type text, discount_kind text,
  discount_value numeric, list_price numeric, discount_amount numeric,
  discount_percent numeric, final_amount numeric, reason text,
  effective_from date, effective_to date, is_active boolean,
  status_label text, created_at timestamptz
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $function$
DECLARE v_school_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  v_school_id := public.fn_my_primary_school();
  IF v_school_id IS NULL OR NOT (
    public.fn_is_school_staff(v_school_id)
    OR public.fn_has_permission('finance.view',v_school_id)
    OR public.fn_has_permission('reports.view',v_school_id)
  ) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;

  RETURN QUERY
  WITH discount_rows AS (
    SELECT d.id, d.student_id, st.full_name, st.student_number,
           enr.class_id, COALESCE(c.name,'بدون قسم') AS class_name,
           d.fee_type, d.discount_kind, d.discount_value,
           COALESCE(fp.price,0)::numeric AS list_price,
           CASE WHEN d.discount_kind='percent'
                THEN ROUND(COALESCE(fp.price,0)*d.discount_value/100,2)
                ELSE LEAST(COALESCE(fp.price,0),d.discount_value) END AS discount_amount,
           d.reason, d.effective_from, d.effective_to, d.is_active, d.created_at,
           CASE WHEN NOT d.is_active THEN 'ملغى'
                WHEN d.effective_to IS NOT NULL AND d.effective_to < CURRENT_DATE THEN 'منتهٍ'
                WHEN d.effective_from > CURRENT_DATE THEN 'مجدول'
                ELSE 'ساري' END AS status_label
    FROM public.student_fee_discounts d
    JOIN public.students st ON st.id=d.student_id AND st.school_id=v_school_id
    LEFT JOIN LATERAL (
      SELECT se.class_id FROM public.student_enrollments se
      WHERE se.student_id=st.id AND se.school_id=v_school_id AND se.status='ACTIVE'
      ORDER BY se.created_at DESC LIMIT 1
    ) enr ON true
    LEFT JOIN public.classes c ON c.id=enr.class_id
    LEFT JOIN LATERAL (
      SELECT p.price FROM public.school_fee_plans p
      WHERE p.school_id=v_school_id AND p.fee_type=d.fee_type
        AND p.effective_from <= d.effective_from
        AND (p.effective_to IS NULL OR p.effective_to >= d.effective_from)
      ORDER BY p.effective_from DESC LIMIT 1
    ) fp ON true
    WHERE d.school_id=v_school_id
      AND (p_class_id IS NULL OR enr.class_id=p_class_id)
      AND (p_fee_type IS NULL OR d.fee_type=p_fee_type)
      AND d.effective_from >= COALESCE(p_from,DATE '1900-01-01')
      AND d.effective_from <= COALESCE(p_to,CURRENT_DATE + INTERVAL '100 years')::date
  )
  SELECT dr.id,dr.student_id,dr.full_name,dr.student_number,dr.class_id,dr.class_name,
         dr.fee_type,dr.discount_kind,dr.discount_value,dr.list_price,dr.discount_amount,
         CASE WHEN dr.list_price>0 THEN ROUND(dr.discount_amount*100/dr.list_price,2) ELSE 0 END,
         GREATEST(0,dr.list_price-dr.discount_amount),dr.reason,dr.effective_from,dr.effective_to,
         dr.is_active,dr.status_label,dr.created_at
  FROM discount_rows dr
  WHERE p_status IS NULL OR dr.status_label=p_status
  ORDER BY dr.effective_from DESC,dr.full_name;
END;
$function$;
REVOKE ALL ON FUNCTION public.fn_report_student_fee_discounts(date,date,uuid,text,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_report_student_fee_discounts(date,date,uuid,text,text) TO authenticated;
