-- ============================================================================
-- Phase 89: Class councils, final results and official school decisions.
-- Adds council minutes and per-student decisions; keeps grade data untouched.
-- ============================================================================

create table if not exists public.class_councils (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  academic_year_id uuid not null references public.academic_years(id),
  period text not null check (period in ('SEMESTER_1','SEMESTER_2','ANNUAL')),
  meeting_date date not null default current_date,
  meeting_title text,
  minutes text,
  created_by uuid references public.profiles(id),
  updated_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(class_id, academic_year_id, period)
);

create table if not exists public.class_council_decisions (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  council_id uuid not null references public.class_councils(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  decision text not null check (decision in ('PASS','REPEAT','REVIEW')),
  final_average numeric(6,2),
  decision_note text,
  decided_by uuid references public.profiles(id),
  decided_at timestamptz not null default now(),
  unique(council_id, student_id)
);

create index if not exists idx_class_councils_school_year
  on public.class_councils(school_id, academic_year_id, period);
create index if not exists idx_council_decisions_student
  on public.class_council_decisions(student_id, decided_at desc);

alter table public.class_councils enable row level security;
alter table public.class_council_decisions enable row level security;
revoke all on public.class_councils, public.class_council_decisions from anon, authenticated;

insert into public.permissions(permission_key, module, name, description)
values
 ('grades.council.view','grades','عرض مجالس الأقسام','عرض نتائج وقرارات مجالس الأقسام'),
 ('grades.council.manage','grades','تدبير مجالس الأقسام','إنشاء محاضر المجالس واعتماد القرارات')
on conflict (permission_key) do nothing;

create or replace function public.fn_class_final_results(
  p_class_id uuid,
  p_period text
)
returns table(
  student_id uuid,
  student_name text,
  student_number text,
  final_average numeric,
  coefficient_total numeric,
  subject_count bigint,
  recommendation text,
  existing_decision text,
  decision_note text
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_year_id uuid;
  v_level text;
  v_role text;
  v_scale numeric;
  v_council_id uuid;
  v_period_key text;
  v_calc_period text;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  if p_period is null or upper(p_period) not in ('SEMESTER_1','SEMESTER_2','ANNUAL') then
    raise exception 'INVALID_RESULT_PERIOD';
  end if;
  v_period_key := case when upper(p_period) = 'ANNUAL' then 'ANNUAL' else upper(p_period) end;
  v_calc_period := case when v_period_key = 'ANNUAL' then 'annual' else v_period_key end;

  select c.school_id, c.academic_year_id, c.level
    into v_school_id, v_year_id, v_level
  from public.classes c where c.id = p_class_id;
  if v_school_id is null then raise exception 'INVALID_CLASS'; end if;

  v_role := public.fn_resolve_my_role(v_school_id);
  if not (
    public.fn_is_school_staff(v_school_id)
    or public.fn_has_permission('grades.council.view', v_school_id)
    or public.fn_has_permission('grades.council.manage', v_school_id)
  ) then raise exception 'PERMISSION_DENIED'; end if;

  v_scale := case
    when coalesce(v_level,'') ilike '%ابتدائي%'
      or coalesce(v_level,'') ilike '%primary%' then 10
    else 20
  end;

  select cc.id into v_council_id
  from public.class_councils cc
  where cc.class_id = p_class_id
    and cc.academic_year_id = v_year_id
    and cc.period = v_period_key
    and cc.school_id = v_school_id;

  return query
  with roster as (
    select st.id, st.full_name, st.student_number
    from public.student_enrollments se
    join public.students st on st.id = se.student_id and st.deleted_at is null
    where se.class_id = p_class_id
      and se.school_id = v_school_id
      and se.academic_year_id = v_year_id
      and se.status = 'ACTIVE'
  ), aggregates as (
    select
      r.id,
      r.full_name,
      r.student_number,
      round(sum(sr.final_score * sr.coefficient) /
        nullif(sum(sr.coefficient),0), 2) as avg_score,
      round(sum(sr.coefficient), 2) as coeff_sum,
      count(sr.subject_id)::bigint as subjects
    from roster r
    left join lateral public.fn_student_subject_final_results(
      p_class_id, r.id, v_calc_period
    ) sr on true
    group by r.id, r.full_name, r.student_number
  )
  select
    a.id, a.full_name, a.student_number,
    a.avg_score, coalesce(a.coeff_sum,0), coalesce(a.subjects,0),
    case
      when a.avg_score is null then 'NO_GRADES'
      when a.avg_score >= v_scale / 2 then 'PASS'
      else 'REPEAT'
    end,
    d.decision,
    d.decision_note
  from aggregates a
  left join public.class_council_decisions d
    on d.student_id = a.id and d.council_id = v_council_id
  order by a.avg_score desc nulls last, a.full_name;
end;
$$;

revoke all on function public.fn_class_final_results(uuid,text) from public;
grant execute on function public.fn_class_final_results(uuid,text) to authenticated;

create or replace function public.fn_save_class_council(
  p_class_id uuid,
  p_period text,
  p_meeting_date date default null,
  p_meeting_title text default null,
  p_minutes text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_year_id uuid;
  v_id uuid;
  v_period_key text;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  if p_period is null or upper(p_period) not in ('SEMESTER_1','SEMESTER_2','ANNUAL') then
    raise exception 'INVALID_RESULT_PERIOD';
  end if;
  v_period_key := case when upper(p_period) = 'ANNUAL' then 'ANNUAL' else upper(p_period) end;
  select c.school_id, c.academic_year_id into v_school_id, v_year_id
  from public.classes c where c.id = p_class_id;
  if v_school_id is null then raise exception 'INVALID_CLASS'; end if;
  if not (
    public.fn_is_school_staff(v_school_id)
    or public.fn_has_permission('grades.council.manage', v_school_id)
  ) then raise exception 'PERMISSION_DENIED'; end if;

  insert into public.class_councils(
    school_id, class_id, academic_year_id, period,
    meeting_date, meeting_title, minutes, created_by, updated_by
  ) values (
    v_school_id, p_class_id, v_year_id, v_period_key,
    coalesce(p_meeting_date,current_date),
    nullif(trim(coalesce(p_meeting_title,'')), ''),
    nullif(trim(coalesce(p_minutes,'')), ''),
    auth.uid(), auth.uid()
  )
  on conflict (class_id, academic_year_id, period)
  do update set
    meeting_date = excluded.meeting_date,
    meeting_title = excluded.meeting_title,
    minutes = excluded.minutes,
    updated_by = auth.uid(),
    updated_at = now()
  returning id into v_id;
  return v_id;
end;
$$;

revoke all on function public.fn_save_class_council(uuid,text,date,text,text) from public;
grant execute on function public.fn_save_class_council(uuid,text,date,text,text) to authenticated;

create or replace function public.fn_save_class_council_decision(
  p_council_id uuid,
  p_student_id uuid,
  p_decision text,
  p_final_average numeric default null,
  p_decision_note text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_class_id uuid;
  v_year_id uuid;
  v_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  if p_decision not in ('PASS','REPEAT','REVIEW') then
    raise exception 'INVALID_COUNCIL_DECISION';
  end if;
  if p_final_average is not null and (p_final_average < 0 or p_final_average > 20) then
    raise exception 'INVALID_FINAL_AVERAGE';
  end if;

  select cc.school_id, cc.class_id, cc.academic_year_id
    into v_school_id, v_class_id, v_year_id
  from public.class_councils cc where cc.id = p_council_id;
  if v_school_id is null then raise exception 'INVALID_COUNCIL'; end if;
  if not (
    public.fn_is_school_staff(v_school_id)
    or public.fn_has_permission('grades.council.manage', v_school_id)
  ) then raise exception 'PERMISSION_DENIED'; end if;

  if not exists (
    select 1 from public.student_enrollments se
    where se.student_id = p_student_id
      and se.school_id = v_school_id
      and se.class_id = v_class_id
      and se.academic_year_id = v_year_id
      and se.status = 'ACTIVE'
  ) then raise exception 'STUDENT_NOT_IN_COUNCIL_CLASS'; end if;

  insert into public.class_council_decisions(
    school_id, council_id, student_id, decision,
    final_average, decision_note, decided_by, decided_at
  ) values (
    v_school_id, p_council_id, p_student_id, p_decision,
    p_final_average, nullif(trim(coalesce(p_decision_note,'')), ''),
    auth.uid(), now()
  )
  on conflict (council_id, student_id)
  do update set decision = excluded.decision,
    final_average = excluded.final_average,
    decision_note = excluded.decision_note,
    decided_by = auth.uid(),
    decided_at = now()
  returning id into v_id;
  return v_id;
end;
$$;

revoke all on function public.fn_save_class_council_decision(uuid,uuid,text,numeric,text) from public;
grant execute on function public.fn_save_class_council_decision(uuid,uuid,text,numeric,text) to authenticated;


create or replace function public.fn_save_class_council_decisions(
  p_council_id uuid,
  p_items jsonb
)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_class_id uuid;
  v_year_id uuid;
  v_item jsonb;
  v_student_id uuid;
  v_decision text;
  v_average numeric;
  v_saved integer := 0;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select cc.school_id, cc.class_id, cc.academic_year_id
    into v_school_id, v_class_id, v_year_id
  from public.class_councils cc where cc.id = p_council_id;
  if v_school_id is null then raise exception 'INVALID_COUNCIL'; end if;
  if not (
    public.fn_is_school_staff(v_school_id)
    or public.fn_has_permission('grades.council.manage', v_school_id)
  ) then raise exception 'PERMISSION_DENIED'; end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array'
     or jsonb_array_length(p_items) = 0 then
    raise exception 'INVALID_COUNCIL_ITEMS';
  end if;
  if jsonb_array_length(p_items) > 500 then
    raise exception 'COUNCIL_BATCH_TOO_LARGE';
  end if;

  for v_item in select value from jsonb_array_elements(p_items)
  loop
    v_student_id := nullif(v_item->>'student_id','')::uuid;
    v_decision := upper(coalesce(v_item->>'decision',''));
    v_average := nullif(v_item->>'final_average','')::numeric;
    if v_student_id is null or v_decision not in ('PASS','REPEAT','REVIEW') then
      raise exception 'INVALID_COUNCIL_ITEM';
    end if;
    if v_average is not null and (v_average < 0 or v_average > 20) then
      raise exception 'INVALID_FINAL_AVERAGE';
    end if;
    if not exists (
      select 1 from public.student_enrollments se
      where se.student_id = v_student_id
        and se.school_id = v_school_id
        and se.class_id = v_class_id
        and se.academic_year_id = v_year_id
        and se.status = 'ACTIVE'
    ) then raise exception 'STUDENT_NOT_IN_COUNCIL_CLASS'; end if;

    insert into public.class_council_decisions(
      school_id, council_id, student_id, decision,
      final_average, decision_note, decided_by, decided_at
    ) values (
      v_school_id, p_council_id, v_student_id, v_decision,
      v_average, nullif(trim(coalesce(v_item->>'decision_note','')), ''),
      auth.uid(), now()
    )
    on conflict (council_id, student_id)
    do update set decision = excluded.decision,
      final_average = excluded.final_average,
      decision_note = excluded.decision_note,
      decided_by = auth.uid(),
      decided_at = now();
    v_saved := v_saved + 1;
  end loop;
  return v_saved;
end;
$$;

revoke all on function public.fn_save_class_council_decisions(uuid,jsonb) from public;
grant execute on function public.fn_save_class_council_decisions(uuid,jsonb) to authenticated;

create or replace function public.fn_class_council_details(
  p_class_id uuid,
  p_period text
)
returns table(
  council_id uuid,
  meeting_date date,
  meeting_title text,
  minutes text,
  updated_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_year_id uuid;
  v_period_key text;
begin
  v_period_key := case when upper(p_period) = 'ANNUAL' then 'ANNUAL' else upper(p_period) end;
  select c.school_id, c.academic_year_id into v_school_id, v_year_id
  from public.classes c where c.id = p_class_id;
  if v_school_id is null then raise exception 'INVALID_CLASS'; end if;
  if not (
    public.fn_is_school_staff(v_school_id)
    or public.fn_has_permission('grades.council.view', v_school_id)
    or public.fn_has_permission('grades.council.manage', v_school_id)
  ) then
    raise exception 'PERMISSION_DENIED';
  end if;
  return query
  select cc.id, cc.meeting_date, cc.meeting_title, cc.minutes, cc.updated_at
  from public.class_councils cc
  where cc.school_id = v_school_id and cc.class_id = p_class_id
    and cc.academic_year_id = v_year_id and cc.period = v_period_key;
end;
$$;

revoke all on function public.fn_class_council_details(uuid,text) from public;
grant execute on function public.fn_class_council_details(uuid,text) to authenticated;
