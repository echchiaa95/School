-- Phase 96: detailed attendance drill-down for professional reports.
-- Returns date + recorded timestamp for absence/late details. The timestamp
-- is the attendance record creation time, not a biometric arrival time.
CREATE OR REPLACE FUNCTION public.fn_report_student_attendance_detail(
  p_student_number text,
  p_student_name text,
  p_from date DEFAULT NULL,
  p_to date DEFAULT NULL
)
RETURNS TABLE(
  att_date date,
  status text,
  note text,
  created_at timestamptz
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_school_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;

  v_school_id := public.fn_my_primary_school();
  IF v_school_id IS NULL OR NOT (
    public.fn_is_school_staff(v_school_id)
    OR public.fn_has_permission('reports.view', v_school_id)
    OR public.fn_has_permission('attendance.view', v_school_id)
  ) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  RETURN QUERY
  SELECT ar.att_date, ar.status, ar.note, ar.created_at
  FROM public.attendance_records ar
  JOIN public.students st ON st.id = ar.student_id
  WHERE ar.school_id = v_school_id
    AND st.school_id = v_school_id
    AND st.student_number = p_student_number
    AND st.full_name = p_student_name
    AND ar.status IN ('absent', 'late')
    AND ar.att_date BETWEEN COALESCE(p_from, CURRENT_DATE - 30)
                        AND COALESCE(p_to, CURRENT_DATE)
  ORDER BY ar.att_date DESC, ar.created_at DESC
  LIMIT 500;
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_report_student_attendance_detail(text, text, date, date) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_report_student_attendance_detail(text, text, date, date) TO authenticated;

-- Finance report source: exposes the billed month/year, actual payment date,
-- and active class so report filters are applied to authoritative DB fields.
CREATE OR REPLACE FUNCTION public.fn_report_payments(
  p_from date DEFAULT NULL,
  p_to date DEFAULT NULL,
  p_class_id uuid DEFAULT NULL
)
RETURNS TABLE(
  payment_id uuid,
  student_id uuid,
  student_name text,
  student_number text,
  class_name text,
  fee_type text,
  billing_month integer,
  billing_year integer,
  amount_due numeric,
  amount_paid numeric,
  remaining numeric,
  payment_date date,
  method text,
  receipt_no text
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_school_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;
  v_school_id := public.fn_my_primary_school();
  IF v_school_id IS NULL OR NOT (
    public.fn_is_school_staff(v_school_id)
    OR public.fn_has_permission('finance.view', v_school_id)
    OR public.fn_has_permission('reports.view', v_school_id)
  ) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  RETURN QUERY
  SELECT fp.id, st.id, st.full_name, st.student_number,
         COALESCE(c.name, 'بدون قسم'),
         COALESCE(fp.fee_type, 'قسط ' || fp.month || '/' || fp.year),
         fp.month, fp.year, fp.amount_due, fp.amount_paid,
         GREATEST(0, fp.amount_due - fp.amount_paid),
         COALESCE(fp.paid_on, fp.created_at::date), fp.method, fp.receipt_no
  FROM public.payments fp
  JOIN public.students st ON st.id = fp.student_id AND st.school_id = v_school_id
  LEFT JOIN LATERAL (
    SELECT se.class_id
    FROM public.student_enrollments se
    WHERE se.student_id = st.id
      AND se.school_id = v_school_id
      AND se.status = 'ACTIVE'
    LIMIT 1
  ) active_enrollment ON true
  LEFT JOIN public.classes c ON c.id = active_enrollment.class_id
  WHERE (p_class_id IS NULL OR active_enrollment.class_id = p_class_id)
    AND COALESCE(fp.paid_on, fp.created_at::date)
        BETWEEN COALESCE(p_from, CURRENT_DATE - 3650)
            AND COALESCE(p_to, CURRENT_DATE)
  ORDER BY COALESCE(fp.paid_on, fp.created_at::date) DESC, st.full_name;
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_report_payments(date, date, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_report_payments(date, date, uuid) TO authenticated;
