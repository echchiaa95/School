-- Phase 93: Parent document requests — hardening + new features
-- Apply AFTER phase92_parent_document_requests.sql.
--  * duplicate / flood guard on submission
--  * parent can cancel an open request
--  * parent can download the document once READY/DELIVERED (private bucket, narrow policy)
--  * automatic in-app notification to the parent on every status change
begin;

-- 1) Submission: block duplicate open requests and cap open requests per parent.
create or replace function public.fn_submit_parent_document_request(
  p_student_id uuid, p_request_type text, p_purpose text default null,
  p_academic_year_id uuid default null
) returns uuid
language plpgsql security definer set search_path=public
as $$
declare v_school_id uuid; v_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  if not public.fn_is_parent_of(p_student_id) then raise exception 'PERMISSION_DENIED'; end if;
  if p_request_type not in ('ENROLLMENT','TRANSFER','REPORT_CARD','OTHER') then
    raise exception 'INVALID_REQUEST_TYPE';
  end if;
  if p_purpose is not null and length(trim(p_purpose)) > 500 then raise exception 'INVALID_PURPOSE'; end if;
  select school_id into v_school_id from public.students
    where id=p_student_id and deleted_at is null;
  if v_school_id is null then raise exception 'STUDENT_NOT_FOUND'; end if;
  if p_academic_year_id is not null and not exists (
    select 1 from public.academic_years ay where ay.id=p_academic_year_id and ay.school_id=v_school_id
  ) then raise exception 'INVALID_ACADEMIC_YEAR'; end if;

  -- serialize per parent so two quick taps cannot both pass the checks
  perform pg_advisory_xact_lock(hashtext('pdr:' || auth.uid()::text));
  if exists (
    select 1 from public.parent_document_requests r
    where r.parent_user_id=auth.uid() and r.student_id=p_student_id
      and r.request_type=p_request_type
      and r.status in ('SUBMITTED','UNDER_REVIEW','APPROVED','READY')
  ) then raise exception 'DUPLICATE_OPEN_REQUEST'; end if;
  if (select count(*) from public.parent_document_requests r
      where r.parent_user_id=auth.uid()
        and r.status in ('SUBMITTED','UNDER_REVIEW','APPROVED','READY')) >= 10 then
    raise exception 'TOO_MANY_OPEN_REQUESTS';
  end if;

  insert into public.parent_document_requests(
    school_id,student_id,academic_year_id,parent_user_id,request_type,purpose
  ) values (v_school_id,p_student_id,p_academic_year_id,auth.uid(),p_request_type,nullif(trim(p_purpose),''))
  returning id into v_id;
  return v_id;
end $$;

-- 2) Parent cancels own request while it is still open (not yet READY).
create or replace function public.fn_cancel_parent_document_request(p_request_id uuid)
returns boolean
language plpgsql security definer set search_path=public
as $$
declare v_status text;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select status into v_status from public.parent_document_requests
    where id=p_request_id and parent_user_id=auth.uid() for update;
  if not found then raise exception 'REQUEST_NOT_FOUND'; end if;
  if v_status not in ('SUBMITTED','UNDER_REVIEW') then raise exception 'REQUEST_NOT_CANCELLABLE'; end if;
  update public.parent_document_requests
    set status='CANCELLED', updated_at=now() where id=p_request_id;
  return true;
end $$;

-- 3) Parent file lookup (path only; the signed URL is created client-side under the policy below).
create or replace function public.fn_get_parent_document_file(p_request_id uuid)
returns table(storage_path text, file_name text, mime_type text)
language plpgsql stable security definer set search_path=public
as $$
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  return query
    select d.storage_path, d.file_name, d.mime_type
    from public.parent_document_requests r
    join public.school_archive_documents d on d.id=r.archive_document_id
    where r.id=p_request_id and r.parent_user_id=auth.uid()
      and r.status in ('READY','DELIVERED')
      and d.status='ACTIVE' and d.student_id=r.student_id
      and public.fn_is_parent_of(r.student_id);
  if not found then raise exception 'FILE_NOT_AVAILABLE'; end if;
end $$;

-- Storage helper: a parent may read exactly the objects linked to their own READY/DELIVERED requests.
create or replace function public.fn_parent_can_read_archive_object(p_name text)
returns boolean
language sql stable security definer set search_path=public
as $$
  select exists (
    select 1
    from public.parent_document_requests r
    join public.school_archive_documents d on d.id=r.archive_document_id
    where d.storage_path=p_name
      and r.parent_user_id=auth.uid()
      and r.status in ('READY','DELIVERED')
      and d.status='ACTIVE' and d.student_id=r.student_id
      and public.fn_is_parent_of(r.student_id)
  );
$$;

do $$
begin
  if not exists (select 1 from pg_policies where schemaname='storage' and tablename='objects'
                 and policyname='p_school_archive_parent_read') then
    create policy p_school_archive_parent_read on storage.objects
      for select to authenticated
      using (bucket_id='school-archive' and public.fn_parent_can_read_archive_object(name));
  end if;
end $$;

-- 4) Staff update: same rules as Phase 92 + notify the parent (never blocks the update).
create or replace function public.fn_update_school_document_request(
  p_request_id uuid, p_status text, p_response text default null,
  p_archive_document_id uuid default null
) returns boolean
language plpgsql security definer set search_path=public
as $$
declare v_school_id uuid; v_req public.parent_document_requests%rowtype;
        v_notif_id uuid; v_title text; v_body text;
begin
  select ur.school_id into v_school_id from public.user_roles ur
    where ur.profile_id=auth.uid() and ur.role in ('admin','director')
    order by case when ur.role='admin' then 0 else 1 end limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;
  select * into v_req from public.parent_document_requests
    where id=p_request_id and school_id=v_school_id for update;
  if not found then raise exception 'REQUEST_NOT_FOUND'; end if;
  if p_status not in ('UNDER_REVIEW','APPROVED','REJECTED','READY','DELIVERED') then
    raise exception 'INVALID_REQUEST_STATUS';
  end if;
  if p_response is not null and length(trim(p_response)) > 1000 then raise exception 'INVALID_RESPONSE'; end if;
  if v_req.status in ('REJECTED','DELIVERED','CANCELLED') then raise exception 'REQUEST_CLOSED'; end if;
  if p_status='REJECTED' and length(trim(coalesce(p_response,''))) < 3 then
    raise exception 'REJECTION_REASON_REQUIRED';
  end if;
  if p_status='READY' and p_archive_document_id is null and v_req.archive_document_id is null then
    raise exception 'ARCHIVE_DOCUMENT_REQUIRED';
  end if;
  if p_archive_document_id is not null and not exists (
    select 1 from public.school_archive_documents d
    where d.id=p_archive_document_id and d.school_id=v_school_id
      and d.student_id=v_req.student_id and d.status='ACTIVE'
  ) then raise exception 'INVALID_ARCHIVE_DOCUMENT'; end if;
  if p_status='UNDER_REVIEW' and v_req.status not in ('SUBMITTED','UNDER_REVIEW') then raise exception 'INVALID_STATUS_TRANSITION'; end if;
  if p_status='APPROVED' and v_req.status not in ('SUBMITTED','UNDER_REVIEW','APPROVED') then raise exception 'INVALID_STATUS_TRANSITION'; end if;
  if p_status='REJECTED' and v_req.status not in ('SUBMITTED','UNDER_REVIEW','APPROVED') then raise exception 'INVALID_STATUS_TRANSITION'; end if;
  if p_status='READY' and v_req.status not in ('APPROVED','READY') then raise exception 'INVALID_STATUS_TRANSITION'; end if;
  if p_status='DELIVERED' and v_req.status not in ('READY','DELIVERED') then raise exception 'INVALID_STATUS_TRANSITION'; end if;

  update public.parent_document_requests set
    status=p_status, admin_response=coalesce(nullif(trim(p_response),''),admin_response),
    archive_document_id=coalesce(p_archive_document_id,archive_document_id),
    reviewed_by=auth.uid(), reviewed_at=coalesce(reviewed_at,now()),
    fulfilled_at=case when p_status in ('READY','DELIVERED') then coalesce(fulfilled_at,now()) else fulfilled_at end,
    updated_at=now()
  where id=p_request_id;

  begin
    v_title := case p_status
      when 'UNDER_REVIEW' then '📄 طلبكم قيد الدراسة'
      when 'APPROVED'     then '✅ تمت الموافقة على طلب الوثيقة'
      when 'REJECTED'     then '❌ تم رفض طلب الوثيقة'
      when 'READY'        then '📥 وثيقتكم جاهزة'
      else '📦 تم تسليم الوثيقة' end;
    v_body := case p_status
      when 'READY' then 'يمكنكم الآن تنزيل الوثيقة من بوابة أولياء الأمور (قسم طلبات الوثائق).'
      when 'REJECTED' then 'سبب الرفض: ' || coalesce(nullif(trim(p_response),''),'—')
      else 'تم تحديث حالة طلب الوثيقة الخاص بكم. راجعوا بوابة أولياء الأمور لمزيد من التفاصيل.' end;
    insert into public.notifications (school_id, title, body, type, created_by)
      values (v_school_id, v_title, v_body, 'announcement', auth.uid())
      returning id into v_notif_id;
    insert into public.notification_deliveries (notification_id, profile_id)
      values (v_notif_id, v_req.parent_user_id);
  exception when others then
    raise warning 'document request notification failed: %', sqlerrm;
  end;
  return true;
end $$;

revoke all on function public.fn_cancel_parent_document_request(uuid) from public;
revoke all on function public.fn_get_parent_document_file(uuid) from public;
revoke all on function public.fn_parent_can_read_archive_object(text) from public;
grant execute on function public.fn_cancel_parent_document_request(uuid) to authenticated;
grant execute on function public.fn_get_parent_document_file(uuid) to authenticated;
grant execute on function public.fn_parent_can_read_archive_object(text) to authenticated;
-- re-assert grants for the two replaced functions (signatures unchanged)
revoke all on function public.fn_submit_parent_document_request(uuid,text,text,uuid) from public;
revoke all on function public.fn_update_school_document_request(uuid,text,text,uuid) from public;
grant execute on function public.fn_submit_parent_document_request(uuid,text,text,uuid) to authenticated;
grant execute on function public.fn_update_school_document_request(uuid,text,text,uuid) to authenticated;

commit;
