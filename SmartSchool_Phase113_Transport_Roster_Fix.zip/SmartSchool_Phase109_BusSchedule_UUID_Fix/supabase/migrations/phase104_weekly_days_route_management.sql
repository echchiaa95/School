-- ============================================================
-- PHASE 104: MULTI-DAY BUS RUNS + ROUTE EDIT/DELETE
-- Apply after Phase 101 and Phase 103.
-- ============================================================

ALTER TABLE public.bus_route_runs
  ADD COLUMN IF NOT EXISTS days_of_week smallint[];

UPDATE public.bus_route_runs
SET days_of_week = ARRAY[weekday::smallint]
WHERE days_of_week IS NULL OR cardinality(days_of_week)=0;

ALTER TABLE public.bus_route_runs
  ALTER COLUMN days_of_week SET DEFAULT ARRAY[0::smallint],
  ALTER COLUMN days_of_week SET NOT NULL;

ALTER TABLE public.bus_route_runs
  ADD CONSTRAINT bus_route_runs_days_of_week_valid
  CHECK (cardinality(days_of_week) BETWEEN 1 AND 7
     AND days_of_week <@ ARRAY[0,1,2,3,4,5,6]::smallint[])
  NOT VALID;

ALTER TABLE public.bus_route_runs
  VALIDATE CONSTRAINT bus_route_runs_days_of_week_valid;

CREATE INDEX IF NOT EXISTS idx_bus_route_runs_days_gin
ON public.bus_route_runs USING gin(days_of_week);

-- New API: one run can be scheduled on any selected weekdays.
CREATE OR REPLACE FUNCTION public.fn_create_bus_route_run_days(
  p_bus_id uuid,
  p_route_id uuid,
  p_run_name text,
  p_sequence_no integer,
  p_days_of_week smallint[],
  p_direction text,
  p_scheduled_start time,
  p_class_id uuid
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public
AS $$
DECLARE
  v_school uuid;
  v_id uuid;
  v_direction public.trip_direction;
  v_days smallint[];
  v_day smallint;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  SELECT school_id INTO v_school FROM public.buses WHERE id=p_bus_id AND is_active;
  IF v_school IS NULL THEN RAISE EXCEPTION 'INVALID_BUS'; END IF;
  IF NOT (public.fn_is_school_staff(v_school) OR public.fn_has_permission('transport.manage',v_school))
    THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.bus_routes WHERE id=p_route_id AND school_id=v_school AND is_active)
    THEN RAISE EXCEPTION 'INVALID_ROUTE'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.classes WHERE id=p_class_id AND school_id=v_school)
    THEN RAISE EXCEPTION 'INVALID_CLASS'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.bus_route_classes WHERE school_id=v_school AND route_id=p_route_id AND class_id=p_class_id)
    THEN RAISE EXCEPTION 'CLASS_NOT_ASSIGNED_TO_ROUTE'; END IF;
  IF p_sequence_no IS NULL OR p_sequence_no NOT BETWEEN 1 AND 99 THEN RAISE EXCEPTION 'INVALID_RUN_SEQUENCE'; END IF;
  IF NULLIF(BTRIM(p_run_name),'') IS NULL THEN RAISE EXCEPTION 'RUN_NAME_REQUIRED'; END IF;
  IF p_scheduled_start IS NULL THEN RAISE EXCEPTION 'SCHEDULED_TIME_REQUIRED'; END IF;
  SELECT array_agg(DISTINCT d ORDER BY d) INTO v_days
  FROM unnest(COALESCE(p_days_of_week,ARRAY[]::smallint[])) AS d
  WHERE d BETWEEN 0 AND 6;
  IF v_days IS NULL OR cardinality(v_days)=0 OR cardinality(v_days)<>cardinality(p_days_of_week)
    THEN RAISE EXCEPTION 'INVALID_WEEKDAY_SELECTION'; END IF;
  v_direction:=CASE lower(COALESCE(p_direction,'pickup'))
    WHEN 'pickup' THEN 'TO_SCHOOL'::public.trip_direction
    WHEN 'to_school' THEN 'TO_SCHOOL'::public.trip_direction
    WHEN 'dropoff' THEN 'TO_HOME'::public.trip_direction
    WHEN 'to_home' THEN 'TO_HOME'::public.trip_direction
    ELSE NULL END;
  IF v_direction IS NULL THEN RAISE EXCEPTION 'INVALID_DIRECTION'; END IF;

  FOREACH v_day IN ARRAY v_days LOOP
    IF EXISTS (
      SELECT 1 FROM public.bus_route_runs rr
      WHERE rr.bus_id=p_bus_id AND rr.days_of_week @> ARRAY[v_day]
        AND rr.sequence_no=p_sequence_no AND rr.direction=v_direction AND rr.is_active
    ) THEN RAISE EXCEPTION 'RUN_SEQUENCE_ALREADY_USED_FOR_BUS_DAY'; END IF;
  END LOOP;

  INSERT INTO public.bus_route_runs(
    school_id,bus_id,route_id,class_id,run_name,sequence_no,weekday,days_of_week,direction,scheduled_start,created_by
  ) VALUES (
    v_school,p_bus_id,p_route_id,p_class_id,LEFT(BTRIM(p_run_name),100),p_sequence_no,
    v_days[1],v_days,v_direction,p_scheduled_start,auth.uid()
  ) RETURNING id INTO v_id;

  PERFORM public.fn_safe_audit(v_school,'CREATE_BUS_ROUTE_RUN_DAYS','bus_route_runs',v_id,NULL,
    jsonb_build_object('days_of_week',v_days,'class_id',p_class_id,'sequence_no',p_sequence_no));
  RETURN v_id;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_create_bus_route_run_days(uuid,uuid,text,integer,smallint[],text,time,uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_create_bus_route_run_days(uuid,uuid,text,integer,smallint[],text,time,uuid) TO authenticated;

-- Return selected weekdays to the admin UI without changing the legacy RPC.
CREATE OR REPLACE FUNCTION public.fn_list_school_bus_route_runs_days()
RETURNS TABLE(
  run_id uuid,bus_id uuid,bus_label text,route_id uuid,route_name text,
  run_name text,sequence_no integer,weekday integer,days_of_week smallint[],
  direction text,scheduled_start time,is_active boolean,class_id uuid,class_name text
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_school uuid;
BEGIN
  v_school:=public.fn_my_primary_school();
  IF v_school IS NULL THEN RAISE EXCEPTION 'NO_SCHOOL_CONTEXT'; END IF;
  IF NOT (public.fn_is_school_staff(v_school) OR public.fn_has_permission('transport.view',v_school)
      OR public.fn_has_permission('transport.manage',v_school)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  RETURN QUERY
  SELECT rr.id,rr.bus_id,COALESCE(b.code,b.plate_number),rr.route_id,r.name,
    rr.run_name,rr.sequence_no,rr.weekday,rr.days_of_week,
    CASE WHEN rr.direction='TO_SCHOOL'::public.trip_direction THEN 'pickup' ELSE 'dropoff' END,
    rr.scheduled_start,rr.is_active,rr.class_id,c.name::text
  FROM public.bus_route_runs rr
  JOIN public.buses b ON b.id=rr.bus_id
  JOIN public.bus_routes r ON r.id=rr.route_id
  LEFT JOIN public.classes c ON c.id=rr.class_id
  WHERE rr.school_id=v_school
  ORDER BY rr.bus_id,rr.sequence_no,rr.scheduled_start;
END;
$$;
REVOKE ALL ON FUNCTION public.fn_list_school_bus_route_runs_days() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_list_school_bus_route_runs_days() TO authenticated;

-- Update the driver list to match runs on every selected weekday.
DROP FUNCTION IF EXISTS public.fn_list_driver_bus_route_runs();
CREATE FUNCTION public.fn_list_driver_bus_route_runs()
RETURNS TABLE(
  run_id uuid,route_id uuid,route_name text,run_name text,sequence_no integer,
  direction text,scheduled_start time,weekday integer,class_id uuid,class_name text,
  student_count bigint,is_completed boolean,is_next_allowed boolean
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_driver uuid; v_school uuid; v_bus uuid; v_dow integer;
BEGIN
  SELECT d.id,d.school_id INTO v_driver,v_school FROM public.drivers d
  WHERE d.profile_id=auth.uid() AND d.deleted_at IS NULL LIMIT 1;
  IF v_driver IS NULL THEN RAISE EXCEPTION 'NOT_A_DRIVER'; END IF;
  SELECT b.id INTO v_bus FROM public.buses b WHERE b.driver_id=v_driver AND b.is_active LIMIT 1;
  IF v_bus IS NULL THEN RAISE EXCEPTION 'NO_BUS_ASSIGNED'; END IF;
  v_dow:=extract(dow FROM CURRENT_DATE)::integer;
  RETURN QUERY
  SELECT rr.id,rr.route_id,r.name,rr.run_name,rr.sequence_no,
    CASE WHEN rr.direction='TO_SCHOOL'::public.trip_direction THEN 'pickup' ELSE 'dropoff' END,
    rr.scheduled_start,rr.weekday,rr.class_id,c.name::text,
    (SELECT COUNT(*) FROM public.student_transport_assignments sta
      JOIN public.student_enrollments se ON se.student_id=sta.student_id AND se.school_id=v_school
        AND se.status='ACTIVE' AND se.class_id=rr.class_id
      JOIN public.students st ON st.id=sta.student_id AND st.deleted_at IS NULL
      WHERE sta.bus_id=rr.bus_id AND sta.route_id=rr.route_id AND sta.is_active)::bigint,
    EXISTS(SELECT 1 FROM public.bus_trips t WHERE t.route_run_id=rr.id
      AND t.status='COMPLETED'::public.trip_status AND t.starts_at::date=CURRENT_DATE),
    NOT EXISTS(SELECT 1 FROM public.bus_route_runs prev
      WHERE prev.bus_id=rr.bus_id AND prev.is_active AND prev.sequence_no<rr.sequence_no
        AND prev.days_of_week @> ARRAY[v_dow::smallint]
        AND NOT EXISTS(SELECT 1 FROM public.bus_trips pt WHERE pt.route_run_id=prev.id
          AND pt.status='COMPLETED'::public.trip_status AND pt.starts_at::date=CURRENT_DATE))
  FROM public.bus_route_runs rr
  JOIN public.bus_routes r ON r.id=rr.route_id
  LEFT JOIN public.classes c ON c.id=rr.class_id
  WHERE rr.school_id=v_school AND rr.bus_id=v_bus
    AND rr.days_of_week @> ARRAY[v_dow::smallint]
    AND rr.is_active AND rr.class_id IS NOT NULL
  ORDER BY rr.sequence_no,rr.scheduled_start;
END;
$$;
REVOKE ALL ON FUNCTION public.fn_list_driver_bus_route_runs() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_list_driver_bus_route_runs() TO authenticated;

-- Start validation uses selected weekdays, not a single weekday.
CREATE OR REPLACE FUNCTION public.fn_start_scheduled_trip(p_run_id uuid)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_driver uuid; v_school uuid; v_run public.bus_route_runs%ROWTYPE; v_trip uuid; v_count integer;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  SELECT d.id,d.school_id INTO v_driver,v_school FROM public.drivers d
    WHERE d.profile_id=auth.uid() AND d.deleted_at IS NULL LIMIT 1;
  IF v_driver IS NULL THEN RAISE EXCEPTION 'NOT_A_DRIVER'; END IF;
  SELECT rr.* INTO v_run FROM public.bus_route_runs rr JOIN public.buses b ON b.id=rr.bus_id
    WHERE rr.id=p_run_id AND rr.school_id=v_school AND rr.is_active AND rr.class_id IS NOT NULL
      AND b.driver_id=v_driver AND b.is_active FOR UPDATE OF rr;
  IF NOT FOUND THEN RAISE EXCEPTION 'INVALID_SCHEDULED_RUN'; END IF;
  IF NOT (v_run.days_of_week @> ARRAY[extract(dow FROM CURRENT_DATE)::smallint])
    THEN RAISE EXCEPTION 'RUN_NOT_SCHEDULED_TODAY'; END IF;
  IF EXISTS(SELECT 1 FROM public.bus_trips WHERE route_run_id=v_run.id
      AND status='COMPLETED'::public.trip_status AND starts_at::date=CURRENT_DATE)
    THEN RAISE EXCEPTION 'RUN_ALREADY_COMPLETED_TODAY'; END IF;
  IF EXISTS(SELECT 1 FROM public.bus_trips WHERE (driver_id=v_driver OR bus_id=v_run.bus_id)
      AND status='ACTIVE'::public.trip_status) THEN RAISE EXCEPTION 'ACTIVE_TRIP_ALREADY_EXISTS'; END IF;
  IF EXISTS(SELECT 1 FROM public.bus_route_runs prev WHERE prev.bus_id=v_run.bus_id
      AND prev.is_active AND prev.sequence_no<v_run.sequence_no
      AND prev.days_of_week @> ARRAY[extract(dow FROM CURRENT_DATE)::smallint]
      AND NOT EXISTS(SELECT 1 FROM public.bus_trips pt WHERE pt.route_run_id=prev.id
        AND pt.status='COMPLETED'::public.trip_status AND pt.starts_at::date=CURRENT_DATE))
    THEN RAISE EXCEPTION 'PREVIOUS_RUN_NOT_COMPLETED'; END IF;
  SELECT COUNT(*) INTO v_count FROM public.student_transport_assignments sta
    JOIN public.student_enrollments se ON se.student_id=sta.student_id AND se.school_id=v_school
      AND se.status='ACTIVE' AND se.class_id=v_run.class_id
    JOIN public.students st ON st.id=sta.student_id AND st.deleted_at IS NULL
    WHERE sta.bus_id=v_run.bus_id AND sta.route_id=v_run.route_id AND sta.is_active;
  IF v_count=0 THEN RAISE EXCEPTION 'NO_TRANSPORT_STUDENTS_IN_CLASS'; END IF;
  INSERT INTO public.bus_trips(school_id,bus_id,driver_id,route_id,route_run_id,selected_class_id,direction,status,starts_at)
    VALUES(v_school,v_run.bus_id,v_driver,v_run.route_id,v_run.id,v_run.class_id,v_run.direction,'ACTIVE'::public.trip_status,now())
    RETURNING id INTO v_trip;
  INSERT INTO public.bus_trip_students(trip_id,student_id)
    SELECT v_trip,sta.student_id FROM public.student_transport_assignments sta
    JOIN public.student_enrollments se ON se.student_id=sta.student_id AND se.school_id=v_school
      AND se.status='ACTIVE' AND se.class_id=v_run.class_id
    JOIN public.students st ON st.id=sta.student_id AND st.deleted_at IS NULL
    WHERE sta.bus_id=v_run.bus_id AND sta.route_id=v_run.route_id AND sta.is_active
    ON CONFLICT(trip_id,student_id) DO NOTHING;
  PERFORM public.fn_safe_audit(v_school,'START_SEQUENTIAL_CLASS_BUS_TRIP','bus_trips',v_trip,NULL,
    jsonb_build_object('route_run_id',v_run.id,'class_id',v_run.class_id,
      'scheduled_start',v_run.scheduled_start,'actual_start',now(),'days_of_week',v_run.days_of_week));
  BEGIN PERFORM public.fn_notify_trip_started(v_trip);
  EXCEPTION WHEN OTHERS THEN RAISE NOTICE 'Trip notification skipped: %',SQLERRM; END;
  RETURN v_trip;
END;
$$;
REVOKE ALL ON FUNCTION public.fn_start_scheduled_trip(uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_start_scheduled_trip(uuid) TO authenticated;

-- Driver roster accepts any day selected for the run.
CREATE OR REPLACE FUNCTION public.fn_list_driver_run_students(p_run_id uuid)
RETURNS TABLE(
  student_id uuid,full_name text,student_number text,pickup_stop text,dropoff_stop text,
  stop_order integer,stop_latitude double precision,stop_longitude double precision,
  student_latitude double precision,student_longitude double precision,
  boarded_at timestamptz,alighted_at timestamptz
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public AS $$
DECLARE v_driver uuid; v_school uuid; v_bus uuid; v_route uuid; v_class uuid;
BEGIN
  SELECT d.id,d.school_id INTO v_driver,v_school FROM public.drivers d
    WHERE d.profile_id=auth.uid() AND d.deleted_at IS NULL LIMIT 1;
  IF v_driver IS NULL THEN RAISE EXCEPTION 'NOT_A_DRIVER'; END IF;
  SELECT rr.bus_id,rr.route_id,rr.class_id INTO v_bus,v_route,v_class
    FROM public.bus_route_runs rr JOIN public.buses b ON b.id=rr.bus_id
    WHERE rr.id=p_run_id AND rr.school_id=v_school AND rr.is_active
      AND rr.days_of_week @> ARRAY[extract(dow FROM CURRENT_DATE)::smallint]
      AND b.driver_id=v_driver AND b.is_active;
  IF v_bus IS NULL OR v_class IS NULL THEN RAISE EXCEPTION 'INVALID_SCHEDULED_RUN'; END IF;
  RETURN QUERY SELECT sta.student_id,s.full_name,s.student_number,pick.name,dropoff.name,
    brs.sequence_order,pick.latitude,pick.longitude,s.latitude,s.longitude,NULL::timestamptz,NULL::timestamptz
  FROM public.student_transport_assignments sta
  JOIN public.students s ON s.id=sta.student_id AND s.deleted_at IS NULL
  JOIN public.student_enrollments se ON se.student_id=sta.student_id AND se.school_id=v_school
    AND se.status='ACTIVE' AND se.class_id=v_class
  LEFT JOIN public.bus_stops pick ON pick.id=sta.pickup_stop_id
  LEFT JOIN public.bus_stops dropoff ON dropoff.id=sta.dropoff_stop_id
  LEFT JOIN public.bus_route_stops brs ON brs.route_id=sta.route_id AND brs.stop_id=sta.pickup_stop_id
  WHERE sta.bus_id=v_bus AND sta.route_id=v_route AND sta.is_active
  ORDER BY COALESCE(brs.sequence_order,999999),s.full_name;
END;
$$;
REVOKE ALL ON FUNCTION public.fn_list_driver_run_students(uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_list_driver_run_students(uuid) TO authenticated;

-- Route edit: replace route name and ordered stops; retain stop records that may be referenced by assignments.
CREATE OR REPLACE FUNCTION public.fn_update_route(p_route_id uuid,p_name text,p_stops jsonb DEFAULT '[]'::jsonb)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_school uuid; v_stop record; v_stop_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  v_school:=public.fn_my_primary_school();
  IF v_school IS NULL OR NOT (public.fn_is_school_staff(v_school) OR public.fn_has_permission('transport.manage',v_school))
    THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  IF NULLIF(BTRIM(p_name),'') IS NULL THEN RAISE EXCEPTION 'ROUTE_NAME_REQUIRED'; END IF;
  UPDATE public.bus_routes SET name=LEFT(BTRIM(p_name),150)
    WHERE id=p_route_id AND school_id=v_school AND is_active;
  IF NOT FOUND THEN RAISE EXCEPTION 'INVALID_ROUTE'; END IF;
  DELETE FROM public.bus_route_stops WHERE route_id=p_route_id;
  FOR v_stop IN SELECT e.value->>'name' AS stop_name,
      NULLIF(e.value->>'latitude','')::double precision AS lat,
      NULLIF(e.value->>'longitude','')::double precision AS lng,e.ordinality AS seq
    FROM jsonb_array_elements(COALESCE(p_stops,'[]'::jsonb)) WITH ORDINALITY e(value,ordinality)
  LOOP
    IF NULLIF(BTRIM(COALESCE(v_stop.stop_name,'')),'') IS NULL THEN CONTINUE; END IF;
    SELECT id INTO v_stop_id FROM public.bus_stops
      WHERE school_id=v_school AND lower(name)=lower(BTRIM(v_stop.stop_name))
      ORDER BY created_at DESC LIMIT 1;
    IF v_stop_id IS NULL THEN
      INSERT INTO public.bus_stops(school_id,name,latitude,longitude)
      VALUES(v_school,BTRIM(v_stop.stop_name),v_stop.lat,v_stop.lng) RETURNING id INTO v_stop_id;
    END IF;
    INSERT INTO public.bus_route_stops(route_id,stop_id,sequence_order)
      VALUES(p_route_id,v_stop_id,v_stop.seq::integer)
    ON CONFLICT(route_id,stop_id) DO UPDATE SET sequence_order=EXCLUDED.sequence_order;
    v_stop_id:=NULL;
  END LOOP;
  PERFORM public.fn_safe_audit(v_school,'UPDATE_ROUTE','bus_routes',p_route_id,NULL,jsonb_build_object('name',p_name));
  RETURN true;
END;
$$;
REVOKE ALL ON FUNCTION public.fn_update_route(uuid,text,jsonb) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_update_route(uuid,text,jsonb) TO authenticated;

-- Hard delete only when no transport assignments or scheduled/historical trips reference it.
CREATE OR REPLACE FUNCTION public.fn_delete_route(p_route_id uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_school uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  v_school:=public.fn_my_primary_school();
  IF v_school IS NULL OR NOT (public.fn_is_school_staff(v_school) OR public.fn_has_permission('transport.manage',v_school))
    THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  IF EXISTS(SELECT 1 FROM public.student_transport_assignments WHERE route_id=p_route_id AND is_active)
    THEN RAISE EXCEPTION 'ROUTE_HAS_ACTIVE_STUDENT_ASSIGNMENTS'; END IF;
  IF EXISTS(SELECT 1 FROM public.bus_route_runs WHERE route_id=p_route_id)
    THEN RAISE EXCEPTION 'ROUTE_HAS_SCHEDULED_OR_HISTORICAL_RUNS'; END IF;
  IF EXISTS(SELECT 1 FROM public.bus_trips WHERE route_id=p_route_id)
    THEN RAISE EXCEPTION 'ROUTE_HAS_TRIP_HISTORY'; END IF;
  DELETE FROM public.bus_route_classes WHERE route_id=p_route_id;
  DELETE FROM public.bus_route_stops WHERE route_id=p_route_id;
  DELETE FROM public.bus_routes WHERE id=p_route_id AND school_id=v_school;
  IF NOT FOUND THEN RAISE EXCEPTION 'INVALID_ROUTE'; END IF;
  PERFORM public.fn_safe_audit(v_school,'DELETE_ROUTE','bus_routes',p_route_id,NULL,'{}'::jsonb);
  RETURN true;
END;
$$;
REVOKE ALL ON FUNCTION public.fn_delete_route(uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_delete_route(uuid) TO authenticated;
