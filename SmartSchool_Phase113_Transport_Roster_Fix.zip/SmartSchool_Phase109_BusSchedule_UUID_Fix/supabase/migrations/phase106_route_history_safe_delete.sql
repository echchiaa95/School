-- Phase 106: preserve route history instead of failing route deletion.
-- If a route has any student assignment, run, or trip history, archive it
-- by setting is_active=false. Only unreferenced routes are physically deleted.

CREATE OR REPLACE FUNCTION public.fn_delete_route(p_route_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school uuid;
  v_route_name text;
  v_has_history boolean := false;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;

  v_school := public.fn_my_primary_school();

  IF v_school IS NULL
     OR NOT (
       public.fn_is_school_staff(v_school)
       OR public.fn_has_permission('transport.manage', v_school)
     ) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  SELECT r.name
    INTO v_route_name
  FROM public.bus_routes r
  WHERE r.id = p_route_id
    AND r.school_id = v_school
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'INVALID_ROUTE';
  END IF;

  -- Any assignment is historical evidence, even if it is no longer active.
  SELECT
    EXISTS (
      SELECT 1
      FROM public.student_transport_assignments a
      WHERE a.route_id = p_route_id
    )
    OR EXISTS (
      SELECT 1
      FROM public.bus_route_runs rr
      WHERE rr.route_id = p_route_id
    )
    OR EXISTS (
      SELECT 1
      FROM public.bus_trips bt
      WHERE bt.route_id = p_route_id
    )
  INTO v_has_history;

  IF v_has_history THEN
    -- Preserve the route and all references for historical reports.
    UPDATE public.bus_routes
    SET is_active = false
    WHERE id = p_route_id
      AND school_id = v_school;

    UPDATE public.bus_route_runs
    SET is_active = false,
        updated_at = now()
    WHERE route_id = p_route_id
      AND school_id = v_school
      AND is_active = true;

    PERFORM public.fn_safe_audit(
      v_school,
      'ARCHIVE_ROUTE_WITH_HISTORY',
      'bus_routes',
      p_route_id,
      NULL,
      jsonb_build_object(
        'route_name', v_route_name,
        'reason', 'ROUTE_HAS_STUDENT_ASSIGNMENT_HISTORY'
      )
    );

    RETURN true;
  END IF;

  DELETE FROM public.bus_route_classes
  WHERE route_id = p_route_id
    AND school_id = v_school;

  DELETE FROM public.bus_route_stops
  WHERE route_id = p_route_id;

  DELETE FROM public.bus_routes
  WHERE id = p_route_id
    AND school_id = v_school;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'INVALID_ROUTE';
  END IF;

  PERFORM public.fn_safe_audit(
    v_school,
    'DELETE_ROUTE',
    'bus_routes',
    p_route_id,
    NULL,
    jsonb_build_object('route_name', v_route_name)
  );

  RETURN true;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_delete_route(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_delete_route(uuid) TO authenticated;
