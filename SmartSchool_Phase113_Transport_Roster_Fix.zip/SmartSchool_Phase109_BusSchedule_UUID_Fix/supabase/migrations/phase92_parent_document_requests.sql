-- Phase 92: Parent document requests
-- Parents may submit and track requests only for children returned by the
-- trusted parent_students relationship. School staff manage only their school.
begin;

create table if not exists public.parent_document_requests (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  academic_year_id uuid references public.academic_years(id) on delete set null,
  parent_user_id uuid not null references auth.users(id) on delete cascade,
  request_type text not null check (request_type in ('ENROLLMENT','TRANSFER','REPORT_CARD','OTHER')),
  purpose text check (purpose is null or length(purpose) <= 500),
  status text not null default 'SUBMITTED'
    check (status in ('SUBMITTED','UNDER_REVIEW','APPROVED','REJECTED','READY','DELIVERED','CANCELLED')),
  admin_response text check (admin_response is null or length(admin_response) <= 1000),
  archive_document_id uuid references public.school_archive_documents(id) on delete set null,
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  fulfilled_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists parent_doc_req_school_status_date_idx
  on public.parent_document_requests(school_id, status, created_at desc);
create index if not exists parent_doc_req_parent_date_idx
  on public.parent_document_requests(parent_user_id, created_at desc);
create index if not exists parent_doc_req_student_idx
  on public.parent_document_requests(student_id, created_at desc);

alter table public.parent_document_requests enable row level security;
revoke all on public.parent_document_requests from anon, authenticated;

create or replace function public.fn_submit_parent_document_request(
  p_student_id uuid, p_request_type text, p_purpose text default null,
  p_academic_year_id uuid default null
) returns uuid
language plpgsql security definer set search_path=public
as $$
declare v_school_id uuid; v_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  if not public.fn_is_parent_of(p_student_id) then raise exception 'PERMISSION_DENIED'; end if;
  if p_request_type not in ('ENROLLMENT','TRANSFER','REPORT_CARD','OTHER') then
    raise exception 'INVALID_REQUEST_TYPE';
  end if;
  if p_purpose is not null and length(trim(p_purpose)) > 500 then raise exception 'INVALID_PURPOSE'; end if;
  select school_id into v_school_id from public.students
    where id=p_student_id and deleted_at is null;
  if v_school_id is null then raise exception 'STUDENT_NOT_FOUND'; end if;
  if p_academic_year_id is not null and not exists (
    select 1 from public.academic_years ay where ay.id=p_academic_year_id and ay.school_id=v_school_id
  ) then raise exception 'INVALID_ACADEMIC_YEAR'; end if;
  insert into public.parent_document_requests(
    school_id,student_id,academic_year_id,parent_user_id,request_type,purpose
  ) values (v_school_id,p_student_id,p_academic_year_id,auth.uid(),p_request_type,nullif(trim(p_purpose),'')) returning id into v_id;
  return v_id;
end $$;

create or replace function public.fn_list_parent_document_requests()
returns table(
  id uuid, student_name text, request_type text, purpose text, status text,
  admin_response text, archive_document_id uuid, created_at timestamptz, updated_at timestamptz
)
language plpgsql stable security definer set search_path=public
as $$
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  return query
    select r.id, st.full_name, r.request_type, r.purpose, r.status,
      r.admin_response, r.archive_document_id, r.created_at, r.updated_at
    from public.parent_document_requests r
    join public.students st on st.id=r.student_id
    where r.parent_user_id=auth.uid()
    order by r.created_at desc limit 100;
end $$;

create or replace function public.fn_list_school_document_requests(p_status text default null)
returns table(
  id uuid, student_id uuid, student_name text, request_type text, purpose text,
  status text, admin_response text, archive_document_id uuid, created_at timestamptz,
  parent_user_id uuid
)
language plpgsql stable security definer set search_path=public
as $$
declare v_school_id uuid;
begin
  select ur.school_id into v_school_id from public.user_roles ur
    where ur.profile_id=auth.uid() and ur.role in ('admin','director')
    order by case when ur.role='admin' then 0 else 1 end limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;
  return query
    select r.id,r.student_id,st.full_name,r.request_type,r.purpose,r.status,
      r.admin_response,r.archive_document_id,r.created_at,r.parent_user_id
    from public.parent_document_requests r
    join public.students st on st.id=r.student_id
    where r.school_id=v_school_id and (p_status is null or r.status=p_status)
    order by r.created_at desc limit 300;
end $$;

create or replace function public.fn_update_school_document_request(
  p_request_id uuid, p_status text, p_response text default null,
  p_archive_document_id uuid default null
) returns boolean
language plpgsql security definer set search_path=public
as $$
declare v_school_id uuid; v_req public.parent_document_requests%rowtype;
begin
  select ur.school_id into v_school_id from public.user_roles ur
    where ur.profile_id=auth.uid() and ur.role in ('admin','director')
    order by case when ur.role='admin' then 0 else 1 end limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;
  select * into v_req from public.parent_document_requests
    where id=p_request_id and school_id=v_school_id for update;
  if not found then raise exception 'REQUEST_NOT_FOUND'; end if;
  if p_status not in ('UNDER_REVIEW','APPROVED','REJECTED','READY','DELIVERED') then
    raise exception 'INVALID_REQUEST_STATUS';
  end if;
  if p_response is not null and length(trim(p_response)) > 1000 then raise exception 'INVALID_RESPONSE'; end if;
  if v_req.status in ('REJECTED','DELIVERED','CANCELLED') then raise exception 'REQUEST_CLOSED'; end if;
  if p_status='REJECTED' and length(trim(coalesce(p_response,''))) < 3 then
    raise exception 'REJECTION_REASON_REQUIRED';
  end if;
  if p_status='READY' and p_archive_document_id is null and v_req.archive_document_id is null then
    raise exception 'ARCHIVE_DOCUMENT_REQUIRED';
  end if;
  if p_archive_document_id is not null and not exists (
    select 1 from public.school_archive_documents d
    where d.id=p_archive_document_id and d.school_id=v_school_id
      and d.student_id=v_req.student_id and d.status='ACTIVE'
  ) then raise exception 'INVALID_ARCHIVE_DOCUMENT'; end if;
  -- Controlled forward transitions only.
  if p_status='UNDER_REVIEW' and v_req.status not in ('SUBMITTED','UNDER_REVIEW') then raise exception 'INVALID_STATUS_TRANSITION'; end if;
  if p_status='APPROVED' and v_req.status not in ('SUBMITTED','UNDER_REVIEW','APPROVED') then raise exception 'INVALID_STATUS_TRANSITION'; end if;
  if p_status='REJECTED' and v_req.status not in ('SUBMITTED','UNDER_REVIEW','APPROVED') then raise exception 'INVALID_STATUS_TRANSITION'; end if;
  if p_status='READY' and v_req.status not in ('APPROVED','READY') then raise exception 'INVALID_STATUS_TRANSITION'; end if;
  if p_status='DELIVERED' and v_req.status not in ('READY','DELIVERED') then raise exception 'INVALID_STATUS_TRANSITION'; end if;
  update public.parent_document_requests set
    status=p_status, admin_response=coalesce(nullif(trim(p_response),''),admin_response),
    archive_document_id=coalesce(p_archive_document_id,archive_document_id),
    reviewed_by=auth.uid(), reviewed_at=coalesce(reviewed_at,now()),
    fulfilled_at=case when p_status in ('READY','DELIVERED') then coalesce(fulfilled_at,now()) else fulfilled_at end,
    updated_at=now()
  where id=p_request_id;
  return true;
end $$;

revoke all on function public.fn_submit_parent_document_request(uuid,text,text,uuid) from public;
revoke all on function public.fn_list_parent_document_requests() from public;
revoke all on function public.fn_list_school_document_requests(text) from public;
revoke all on function public.fn_update_school_document_request(uuid,text,text,uuid) from public;
grant execute on function public.fn_submit_parent_document_request(uuid,text,text,uuid) to authenticated;
grant execute on function public.fn_list_parent_document_requests() to authenticated;
grant execute on function public.fn_list_school_document_requests(text) to authenticated;
grant execute on function public.fn_update_school_document_request(uuid,text,text,uuid) to authenticated;

commit;
