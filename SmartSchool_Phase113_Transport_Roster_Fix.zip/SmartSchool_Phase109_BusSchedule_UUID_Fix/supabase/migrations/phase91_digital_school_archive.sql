-- Phase 91: Private digital school archive
-- Apply after Phase 90. Files are stored in a private Supabase Storage bucket.
begin;

create table if not exists public.school_archive_documents (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  student_id uuid references public.students(id) on delete set null,
  academic_year_id uuid references public.academic_years(id) on delete set null,
  certificate_id uuid references public.school_certificates(id) on delete set null,
  category text not null check (category in (
    'STUDENT_ID','ENROLLMENT','REPORT_CARD','CERTIFICATE','COUNCIL_MINUTES',
    'MEDICAL_NOTE','TRANSFER','PAYMENT','STAFF','ADMINISTRATIVE','OTHER'
  )),
  title text not null check (length(trim(title)) between 2 and 180),
  description text,
  storage_path text not null unique,
  file_name text not null,
  mime_type text not null,
  file_size bigint not null check (file_size > 0 and file_size <= 20971520),
  status text not null default 'ACTIVE' check (status in ('ACTIVE','ARCHIVED')),
  archive_reason text,
  uploaded_by uuid references auth.users(id) on delete set null,
  uploaded_at timestamptz not null default now(),
  archived_by uuid references auth.users(id) on delete set null,
  archived_at timestamptz
);

create index if not exists school_archive_school_date_idx
  on public.school_archive_documents(school_id, uploaded_at desc);
create index if not exists school_archive_student_idx
  on public.school_archive_documents(student_id, uploaded_at desc);
create index if not exists school_archive_year_category_idx
  on public.school_archive_documents(academic_year_id, category, status);

alter table public.school_archive_documents enable row level security;
revoke all on public.school_archive_documents from anon, authenticated;

-- Private bucket: no public URLs. Access is mediated by staff-only Storage RLS.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'school-archive', 'school-archive', false, 20971520,
  array[
    'application/pdf','image/jpeg','image/png','image/webp',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/plain'
  ]
)
on conflict (id) do update set
  public = false,
  file_size_limit = 20971520,
  allowed_mime_types = excluded.allowed_mime_types;

do $$
begin
  if not exists (select 1 from pg_policies where schemaname='storage' and tablename='objects' and policyname='p_school_archive_staff_read') then
    create policy p_school_archive_staff_read on storage.objects
      for select to authenticated
      using (bucket_id='school-archive' and public.fn_is_school_staff((storage.foldername(name))[1]::uuid));
  end if;
  if not exists (select 1 from pg_policies where schemaname='storage' and tablename='objects' and policyname='p_school_archive_staff_insert') then
    create policy p_school_archive_staff_insert on storage.objects
      for insert to authenticated
      with check (bucket_id='school-archive' and public.fn_is_school_staff((storage.foldername(name))[1]::uuid));
  end if;
  if not exists (select 1 from pg_policies where schemaname='storage' and tablename='objects' and policyname='p_school_archive_staff_update') then
    create policy p_school_archive_staff_update on storage.objects
      for update to authenticated
      using (bucket_id='school-archive' and public.fn_is_school_staff((storage.foldername(name))[1]::uuid))
      with check (bucket_id='school-archive' and public.fn_is_school_staff((storage.foldername(name))[1]::uuid));
  end if;
  if not exists (select 1 from pg_policies where schemaname='storage' and tablename='objects' and policyname='p_school_archive_staff_delete') then
    create policy p_school_archive_staff_delete on storage.objects
      for delete to authenticated
      using (bucket_id='school-archive' and public.fn_is_school_staff((storage.foldername(name))[1]::uuid));
  end if;
end $$;

create or replace function public.fn_register_archive_document(
  p_student_id uuid,
  p_academic_year_id uuid,
  p_certificate_id uuid,
  p_category text,
  p_title text,
  p_description text,
  p_storage_path text,
  p_file_name text,
  p_mime_type text,
  p_file_size bigint
) returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select fn_my_primary_school() into v_school_id;
  if v_school_id is null or not fn_is_school_staff(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;

  if p_category not in (
    'STUDENT_ID','ENROLLMENT','REPORT_CARD','CERTIFICATE','COUNCIL_MINUTES',
    'MEDICAL_NOTE','TRANSFER','PAYMENT','STAFF','ADMINISTRATIVE','OTHER'
  ) then raise exception 'INVALID_ARCHIVE_CATEGORY'; end if;
  if length(trim(coalesce(p_title,''))) not between 2 and 180 then raise exception 'INVALID_ARCHIVE_TITLE'; end if;
  if p_storage_path is null
    or split_part(p_storage_path,'/',1) <> v_school_id::text
    or split_part(p_storage_path,'/',2) <> coalesce(p_academic_year_id::text,'unassigned')
    or split_part(p_storage_path,'/',3) <> coalesce(p_student_id::text,'general')
    or split_part(p_storage_path,'/',4) = ''
    or split_part(p_storage_path,'/',5) <> '' then
    raise exception 'INVALID_ARCHIVE_PATH';
  end if;
  if not exists (
    select 1 from storage.objects o
    where o.bucket_id='school-archive' and o.name=p_storage_path
  ) then raise exception 'ARCHIVE_FILE_NOT_FOUND'; end if;
  if p_file_name is null or length(trim(p_file_name)) = 0 then raise exception 'INVALID_ARCHIVE_FILE'; end if;
  if p_file_size is null or p_file_size <= 0 or p_file_size > 20971520 then raise exception 'INVALID_ARCHIVE_SIZE'; end if;
  if p_mime_type not in (
    'application/pdf','image/jpeg','image/png','image/webp',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/plain'
  ) then raise exception 'INVALID_ARCHIVE_MIME'; end if;

  if p_student_id is not null and not exists (
    select 1 from students s where s.id=p_student_id and s.school_id=v_school_id
  ) then raise exception 'INVALID_STUDENT'; end if;
  if p_academic_year_id is not null and not exists (
    select 1 from academic_years ay where ay.id=p_academic_year_id and ay.school_id=v_school_id
  ) then raise exception 'INVALID_ACADEMIC_YEAR'; end if;
  if p_certificate_id is not null and not exists (
    select 1 from school_certificates c where c.id=p_certificate_id and c.school_id=v_school_id
  ) then raise exception 'INVALID_CERTIFICATE'; end if;

  insert into school_archive_documents(
    school_id, student_id, academic_year_id, certificate_id, category,
    title, description, storage_path, file_name, mime_type, file_size, uploaded_by
  ) values (
    v_school_id, p_student_id, p_academic_year_id, p_certificate_id, p_category,
    trim(p_title), nullif(trim(coalesce(p_description,'')),''), p_storage_path,
    p_file_name, p_mime_type, p_file_size, auth.uid()
  ) returning id into v_id;
  return v_id;
end;
$$;

create or replace function public.fn_list_archive_documents(
  p_query text default null,
  p_student_id uuid default null,
  p_academic_year_id uuid default null,
  p_category text default null,
  p_status text default 'ACTIVE',
  p_limit integer default 100
) returns table (
  id uuid, student_id uuid, academic_year_id uuid, certificate_id uuid,
  category text, title text, description text, storage_path text,
  file_name text, mime_type text, file_size bigint, status text,
  archive_reason text, uploaded_at timestamptz, student_name text,
  student_number text, academic_year_name text
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare v_school_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select fn_my_primary_school() into v_school_id;
  if v_school_id is null or not fn_is_school_staff(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select d.id, d.student_id, d.academic_year_id, d.certificate_id,
    d.category, d.title, d.description, d.storage_path, d.file_name,
    d.mime_type, d.file_size, d.status, d.archive_reason, d.uploaded_at,
    s.full_name, s.student_number, ay.label
  from school_archive_documents d
  left join students s on s.id=d.student_id
  left join academic_years ay on ay.id=d.academic_year_id
  where d.school_id=v_school_id
    and (p_student_id is null or d.student_id=p_student_id)
    and (p_academic_year_id is null or d.academic_year_id=p_academic_year_id)
    and (nullif(trim(coalesce(p_category,'')),'') is null or d.category=p_category)
    and (nullif(trim(coalesce(p_status,'')),'') is null or d.status=p_status)
    and (nullif(trim(coalesce(p_query,'')),'') is null
      or d.title ilike '%'||trim(p_query)||'%'
      or d.file_name ilike '%'||trim(p_query)||'%'
      or coalesce(s.full_name,'') ilike '%'||trim(p_query)||'%'
      or coalesce(s.student_number,'') ilike '%'||trim(p_query)||'%')
  order by d.uploaded_at desc
  limit greatest(1,least(coalesce(p_limit,100),500));
end;
$$;

create or replace function public.fn_archive_document(
  p_document_id uuid,
  p_reason text
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare v_school_id uuid; v_status text;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  if length(trim(coalesce(p_reason,''))) < 3 then raise exception 'ARCHIVE_REASON_REQUIRED'; end if;
  select school_id,status into v_school_id,v_status
  from school_archive_documents where id=p_document_id for update;
  if v_school_id is null then raise exception 'ARCHIVE_DOCUMENT_NOT_FOUND'; end if;
  if not fn_is_school_staff(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;
  if v_status='ARCHIVED' then raise exception 'ARCHIVE_DOCUMENT_ALREADY_ARCHIVED'; end if;
  update school_archive_documents set status='ARCHIVED',archive_reason=trim(p_reason),
    archived_by=auth.uid(),archived_at=now()
  where id=p_document_id;
  return jsonb_build_object('id',p_document_id,'status','ARCHIVED');
end;
$$;

revoke all on function public.fn_register_archive_document(uuid,uuid,uuid,text,text,text,text,text,text,bigint) from public;
revoke all on function public.fn_list_archive_documents(text,uuid,uuid,text,text,integer) from public;
revoke all on function public.fn_archive_document(uuid,text) from public;
grant execute on function public.fn_register_archive_document(uuid,uuid,uuid,text,text,text,text,text,text,bigint) to authenticated;
grant execute on function public.fn_list_archive_documents(text,uuid,uuid,text,text,integer) to authenticated;
grant execute on function public.fn_archive_document(uuid,text) to authenticated;

commit;
