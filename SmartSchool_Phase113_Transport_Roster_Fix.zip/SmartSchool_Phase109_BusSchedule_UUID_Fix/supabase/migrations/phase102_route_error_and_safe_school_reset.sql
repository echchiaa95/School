-- Phase 102: route-name validation support + backup-gated school operational reset.
-- Preserves schools, profiles, auth users, user_roles and school master settings.

CREATE TABLE IF NOT EXISTS public.school_reset_backup_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id uuid NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
  created_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  used_at timestamptz,
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '30 minutes')
);
ALTER TABLE public.school_reset_backup_tickets ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.school_reset_backup_tickets FROM PUBLIC, anon, authenticated;


-- Expand the safe export allowlist so Phase 87-101 operational/financial records
-- are included in the backup that gates reset.
CREATE OR REPLACE FUNCTION public.fn_export_school_backup_safe(p_school_id uuid DEFAULT NULL)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public
AS $$
DECLARE
  v_school_id uuid;
  v_tables text[] := ARRAY[
    'academic_years','classes','students','student_enrollments','subjects',
    'school_period_configs','timetables','timetable_entries','buses','bus_routes',
    'bus_stops','bus_route_stops','bus_route_classes','bus_route_runs',
    'student_transport_assignments','attendance_records','attendance_change_audit',
    'student_grades','payments','expenses','expense_categories','financial_transaction_audit',
    'student_fee_discounts','student_fee_obligations','student_fee_payment_transactions',
    'student_fee_payment_allocations','incidents','guard_checks','staff_attendance',
    'notifications','school_posts','bus_trips','bus_trip_students','bus_trip_locations',
    'bus_last_locations','school_student_number_counters','student_academic_progression',
    'class_councils','class_council_decisions','school_certificates',
    'school_certificate_counters','school_archive_documents','parent_document_requests'
  ];
  v_t text;
  v_rows jsonb;
  v_data jsonb := '{}'::jsonb;
  v_has_school boolean;
  v_has_deleted boolean;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  IF p_school_id IS NOT NULL THEN
    v_school_id := p_school_id;
  ELSIF NOT public.fn_is_superadmin() THEN
    v_school_id := public.fn_my_primary_school();
  END IF;
  IF v_school_id IS NULL OR NOT public.fn_is_school_staff(v_school_id) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;
  IF NOT EXISTS(SELECT 1 FROM public.schools WHERE id=v_school_id) THEN
    RAISE EXCEPTION 'SCHOOL_NOT_FOUND';
  END IF;
  FOREACH v_t IN ARRAY v_tables LOOP
    IF to_regclass('public.'||v_t) IS NULL THEN CONTINUE; END IF;
    SELECT EXISTS(SELECT 1 FROM information_schema.columns
      WHERE table_schema='public' AND table_name=v_t AND column_name='school_id')
      INTO v_has_school;
    IF NOT v_has_school THEN CONTINUE; END IF;
    SELECT EXISTS(SELECT 1 FROM information_schema.columns
      WHERE table_schema='public' AND table_name=v_t AND column_name='deleted_at')
      INTO v_has_deleted;
    EXECUTE format(
      'SELECT COALESCE(jsonb_agg(to_jsonb(t)), ''[]''::jsonb) FROM public.%I t WHERE t.school_id=$1%s',
      v_t,CASE WHEN v_has_deleted THEN ' AND t.deleted_at IS NULL' ELSE '' END
    ) INTO v_rows USING v_school_id;
    v_data := v_data || jsonb_build_object(v_t,v_rows);
  END LOOP;
  PERFORM public.fn_safe_audit(v_school_id,'EXPORT_BACKUP_SAFE','schools',v_school_id,NULL,
    jsonb_build_object('included_tables',v_tables));
  RETURN jsonb_build_object('app','smart-school','backup_version',1,
    'exported_at',now(),'school_id',v_school_id,
    'school',(SELECT to_jsonb(s) FROM public.schools s WHERE s.id=v_school_id),
    'tables',v_data);
END;
$$;
REVOKE ALL ON FUNCTION public.fn_export_school_backup_safe(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_export_school_backup_safe(uuid) TO authenticated;

-- This RPC first creates a complete server-side backup, then issues a short-lived,
-- single-use reset ticket. The ticket is not included in the downloaded JSON file.
CREATE OR REPLACE FUNCTION public.fn_export_school_backup_for_reset(
  p_school_id uuid DEFAULT NULL
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public
AS $$
DECLARE
  v_school uuid;
  v_backup jsonb;
  v_ticket uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  v_school := COALESCE(p_school_id, public.fn_my_primary_school());
  IF v_school IS NULL OR NOT public.fn_is_school_staff(v_school) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;
  v_backup := public.fn_export_school_backup_safe(v_school);
  INSERT INTO public.school_reset_backup_tickets(school_id,created_by)
  VALUES(v_school,auth.uid()) RETURNING id INTO v_ticket;
  RETURN v_backup || jsonb_build_object('_reset_ticket',v_ticket);
END;
$$;
REVOKE ALL ON FUNCTION public.fn_export_school_backup_for_reset(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_export_school_backup_for_reset(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.fn_reset_school_operational_data(
  p_ticket uuid,
  p_confirmation text
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public
AS $$
DECLARE
  v_school uuid;
  v_deleted jsonb := '{}'::jsonb;
  v_table text;
  v_count integer;
  v_order text[] := ARRAY[
    -- child/detail records first
    'student_fee_payment_allocations',
    'bus_trip_students','bus_trip_locations','bus_last_locations',
    'attendance_change_audit','financial_transaction_audit',
    'class_council_decisions','school_archive_documents',
    'parent_document_requests','school_certificates',
    'student_fee_payment_transactions','student_fee_obligations',
    'student_fee_discounts','payments','expenses','expense_categories',
    'attendance_records','student_grades','guard_checks','staff_attendance',
    'student_academic_progression','class_councils',
    'bus_trips','student_transport_assignments','bus_route_runs',
    'bus_route_classes','bus_route_stops','bus_stops','bus_routes','buses',
    'timetable_entries','timetables','school_certificate_counters',
    'school_student_number_counters','student_enrollments','students'
  ];
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  IF p_confirmation IS DISTINCT FROM 'تصفير بيانات المؤسسة' THEN
    RAISE EXCEPTION 'RESET_CONFIRMATION_MISMATCH';
  END IF;
  v_school := public.fn_my_primary_school();
  IF v_school IS NULL OR NOT public.fn_is_school_staff(v_school) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  PERFORM 1
  FROM public.school_reset_backup_tickets t
  WHERE t.id=p_ticket
    AND t.school_id=v_school
    AND t.created_by=auth.uid()
    AND t.used_at IS NULL
    AND t.expires_at>now()
  FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'VALID_BACKUP_REQUIRED_OR_TICKET_EXPIRED'; END IF;

  -- Audit before deletion. The audit trail itself is intentionally retained.
  PERFORM public.fn_safe_audit(
    v_school,'RESET_SCHOOL_OPERATIONAL_DATA','schools',v_school,NULL,
    jsonb_build_object('ticket_id',p_ticket,'tables',v_order)
  );

  FOREACH v_table IN ARRAY v_order LOOP
    IF to_regclass('public.'||v_table) IS NULL THEN CONTINUE; END IF;
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema='public' AND table_name=v_table AND column_name='school_id'
    ) THEN CONTINUE; END IF;
    EXECUTE format('DELETE FROM public.%I WHERE school_id = $1',v_table)
      USING v_school;
    GET DIAGNOSTICS v_count = ROW_COUNT;
    v_deleted := v_deleted || jsonb_build_object(v_table,v_count);
  END LOOP;

  UPDATE public.school_reset_backup_tickets
  SET used_at=now()
  WHERE id=p_ticket;

  RETURN jsonb_build_object(
    'ok',true,
    'school_id',v_school,
    'deleted',v_deleted,
    'preserved',jsonb_build_array('schools','profiles','auth.users','user_roles','school profile settings','audit_logs')
  );
END;
$$;
REVOKE ALL ON FUNCTION public.fn_reset_school_operational_data(uuid,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_reset_school_operational_data(uuid,text) TO authenticated;
