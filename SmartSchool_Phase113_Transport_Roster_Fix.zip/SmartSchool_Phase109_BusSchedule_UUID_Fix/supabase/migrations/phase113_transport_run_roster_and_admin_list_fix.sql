-- PHASE 113: reliable scheduled-run roster, safe transport auto-linking,
-- and consistent admin schedule listing.
-- Apply after Phase 104. Existing student-specific bus/route assignments
-- are respected; students marked uses_transport=true and not assigned yet
-- are linked to the run's bus/route when the driver starts that run.

-- Recreate the admin RPC explicitly so stale return signatures cannot leave
-- the admin page silently showing an empty schedule.
DROP FUNCTION IF EXISTS public.fn_list_school_bus_route_runs_days();
CREATE FUNCTION public.fn_list_school_bus_route_runs_days()
RETURNS TABLE(
  run_id uuid,
  bus_id uuid,
  bus_label text,
  route_id uuid,
  route_name text,
  run_name text,
  sequence_no integer,
  weekday integer,
  days_of_week smallint[],
  direction text,
  scheduled_start time without time zone,
  is_active boolean,
  class_id uuid,
  class_name text
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_school uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  v_school := public.fn_my_primary_school();
  IF v_school IS NULL THEN RAISE EXCEPTION 'NO_SCHOOL_CONTEXT'; END IF;
  IF NOT (
    public.fn_is_school_staff(v_school)
    OR public.fn_has_permission('transport.view',v_school)
    OR public.fn_has_permission('transport.manage',v_school)
  ) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;

  RETURN QUERY
  SELECT rr.id, rr.bus_id,
         COALESCE(b.code,b.plate_number,'حافلة')::text,
         rr.route_id, r.name::text, rr.run_name::text,
         rr.sequence_no::integer, rr.weekday::integer,
         rr.days_of_week,
         CASE WHEN rr.direction='TO_SCHOOL'::public.trip_direction
              THEN 'pickup'::text ELSE 'dropoff'::text END,
         rr.scheduled_start, rr.is_active, rr.class_id, c.name::text
  FROM public.bus_route_runs rr
  JOIN public.buses b ON b.id=rr.bus_id AND b.school_id=v_school
  JOIN public.bus_routes r ON r.id=rr.route_id AND r.school_id=v_school
  LEFT JOIN public.classes c ON c.id=rr.class_id AND c.school_id=v_school
  WHERE rr.school_id=v_school
  ORDER BY rr.bus_id, rr.sequence_no, rr.scheduled_start, rr.created_at;
END;
$$;
REVOKE ALL ON FUNCTION public.fn_list_school_bus_route_runs_days() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_list_school_bus_route_runs_days() TO authenticated;

-- Driver's daily schedule: count students actually eligible for this bus run.
-- Existing active assignment to another bus/route excludes the student.
DROP FUNCTION IF EXISTS public.fn_list_driver_bus_route_runs();
CREATE FUNCTION public.fn_list_driver_bus_route_runs()
RETURNS TABLE(
  run_id uuid, route_id uuid, route_name text, run_name text,
  sequence_no integer, direction text, scheduled_start time without time zone,
  weekday integer, class_id uuid, class_name text, student_count bigint,
  is_completed boolean, is_next_allowed boolean
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_driver uuid; v_school uuid; v_bus uuid; v_dow smallint;
BEGIN
  SELECT d.id,d.school_id INTO v_driver,v_school
  FROM public.drivers d
  WHERE d.profile_id=auth.uid() AND d.deleted_at IS NULL
  LIMIT 1;
  IF v_driver IS NULL THEN RAISE EXCEPTION 'NOT_A_DRIVER'; END IF;

  SELECT b.id INTO v_bus FROM public.buses b
  WHERE b.driver_id=v_driver AND b.school_id=v_school AND b.is_active
  ORDER BY b.created_at,b.id LIMIT 1;
  IF v_bus IS NULL THEN RAISE EXCEPTION 'NO_BUS_ASSIGNED'; END IF;
  v_dow := extract(dow FROM CURRENT_DATE)::smallint;

  RETURN QUERY
  SELECT rr.id,rr.route_id,r.name::text,rr.run_name::text,
         rr.sequence_no::integer,
         CASE WHEN rr.direction='TO_SCHOOL'::public.trip_direction
              THEN 'pickup'::text ELSE 'dropoff'::text END,
         rr.scheduled_start,rr.weekday::integer,rr.class_id,c.name::text,
         (
           SELECT count(*)::bigint
           FROM public.student_enrollments se
           JOIN public.students st ON st.id=se.student_id
             AND st.school_id=v_school AND st.deleted_at IS NULL
           WHERE se.school_id=v_school AND se.class_id=rr.class_id
             AND se.academic_year_id=c.academic_year_id AND se.status='ACTIVE'
             AND (
               EXISTS (
                 SELECT 1 FROM public.student_transport_assignments a
                 WHERE a.student_id=st.id AND a.academic_year_id=se.academic_year_id
                   AND a.is_active AND a.bus_id=rr.bus_id AND a.route_id=rr.route_id
               )
               OR (
                 st.uses_transport IS TRUE
                 AND NOT EXISTS (
                   SELECT 1 FROM public.student_transport_assignments a
                   WHERE a.student_id=st.id AND a.academic_year_id=se.academic_year_id
                     AND a.is_active
                 )
               )
             )
         ),
         EXISTS(SELECT 1 FROM public.bus_trips t
           WHERE t.route_run_id=rr.id AND t.status='COMPLETED'::public.trip_status
             AND t.starts_at::date=CURRENT_DATE),
         NOT EXISTS(
           SELECT 1 FROM public.bus_route_runs prev
           WHERE prev.bus_id=rr.bus_id AND prev.is_active
             AND prev.sequence_no<rr.sequence_no
             AND prev.days_of_week @> ARRAY[v_dow]
             AND NOT EXISTS(SELECT 1 FROM public.bus_trips pt
               WHERE pt.route_run_id=prev.id
                 AND pt.status='COMPLETED'::public.trip_status
                 AND pt.starts_at::date=CURRENT_DATE)
         )
  FROM public.bus_route_runs rr
  JOIN public.bus_routes r ON r.id=rr.route_id
  JOIN public.classes c ON c.id=rr.class_id AND c.school_id=v_school
  WHERE rr.school_id=v_school AND rr.bus_id=v_bus
    AND rr.days_of_week @> ARRAY[v_dow]
    AND rr.is_active AND rr.class_id IS NOT NULL
  ORDER BY rr.sequence_no,rr.scheduled_start;
END;
$$;
REVOKE ALL ON FUNCTION public.fn_list_driver_bus_route_runs() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_list_driver_bus_route_runs() TO authenticated;

-- Preview roster for a scheduled run. The class is the roster scope;
-- only transport-enabled students or students explicitly assigned to this
-- exact bus/route are returned. A conflicting active assignment is excluded.
DROP FUNCTION IF EXISTS public.fn_list_driver_run_students(uuid);
CREATE FUNCTION public.fn_list_driver_run_students(p_run_id uuid)
RETURNS TABLE(
  student_id uuid, full_name text, student_number text,
  pickup_stop text, dropoff_stop text, stop_order integer,
  stop_latitude double precision, stop_longitude double precision,
  student_latitude double precision, student_longitude double precision,
  boarded_at timestamptz, alighted_at timestamptz
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_driver uuid; v_school uuid; v_bus uuid; v_route uuid;
        v_class uuid; v_year uuid;
BEGIN
  SELECT d.id,d.school_id INTO v_driver,v_school
  FROM public.drivers d
  WHERE d.profile_id=auth.uid() AND d.deleted_at IS NULL LIMIT 1;
  IF v_driver IS NULL THEN RAISE EXCEPTION 'NOT_A_DRIVER'; END IF;

  SELECT rr.bus_id,rr.route_id,rr.class_id,c.academic_year_id
  INTO v_bus,v_route,v_class,v_year
  FROM public.bus_route_runs rr
  JOIN public.buses b ON b.id=rr.bus_id AND b.driver_id=v_driver AND b.is_active
  JOIN public.classes c ON c.id=rr.class_id AND c.school_id=v_school
  WHERE rr.id=p_run_id AND rr.school_id=v_school AND rr.is_active
    AND rr.days_of_week @> ARRAY[extract(dow FROM CURRENT_DATE)::smallint];
  IF v_bus IS NULL OR v_class IS NULL THEN RAISE EXCEPTION 'INVALID_SCHEDULED_RUN'; END IF;

  RETURN QUERY
  SELECT st.id,st.full_name::text,st.student_number::text,
         pick.name::text,dropoff.name::text,brs.sequence_order::integer,
         pick.latitude,pick.longitude,st.latitude,st.longitude,
         NULL::timestamptz,NULL::timestamptz
  FROM public.student_enrollments se
  JOIN public.students st ON st.id=se.student_id
    AND st.school_id=v_school AND st.deleted_at IS NULL
  LEFT JOIN public.student_transport_assignments sta
    ON sta.student_id=st.id AND sta.academic_year_id=v_year
   AND sta.is_active AND sta.bus_id=v_bus AND sta.route_id=v_route
  LEFT JOIN public.bus_stops pick ON pick.id=sta.pickup_stop_id
  LEFT JOIN public.bus_stops dropoff ON dropoff.id=sta.dropoff_stop_id
  LEFT JOIN public.bus_route_stops brs
    ON brs.route_id=v_route AND brs.stop_id=sta.pickup_stop_id
  WHERE se.school_id=v_school AND se.class_id=v_class
    AND se.academic_year_id=v_year AND se.status='ACTIVE'
    AND (
      sta.id IS NOT NULL
      OR (
        st.uses_transport IS TRUE
        AND NOT EXISTS(
          SELECT 1 FROM public.student_transport_assignments other
          WHERE other.student_id=st.id AND other.academic_year_id=v_year
            AND other.is_active
        )
      )
    )
  ORDER BY COALESCE(brs.sequence_order,999999),st.full_name;
END;
$$;
REVOKE ALL ON FUNCTION public.fn_list_driver_run_students(uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_list_driver_run_students(uuid) TO authenticated;

-- Starting a run materializes transport assignments for students already
-- marked uses_transport=true, but never overwrites an active assignment to
-- a different bus/route. Then it snapshots the exact roster into the trip.
CREATE OR REPLACE FUNCTION public.fn_start_scheduled_trip(p_run_id uuid)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public
AS $$
DECLARE
  v_driver uuid; v_school uuid; v_run public.bus_route_runs%ROWTYPE;
  v_year uuid; v_trip uuid; v_student_ids uuid[]; v_count integer;
  v_capacity integer;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  SELECT d.id,d.school_id INTO v_driver,v_school
  FROM public.drivers d
  WHERE d.profile_id=auth.uid() AND d.deleted_at IS NULL LIMIT 1;
  IF v_driver IS NULL THEN RAISE EXCEPTION 'NOT_A_DRIVER'; END IF;

  SELECT rr.* INTO v_run
  FROM public.bus_route_runs rr
  JOIN public.buses b ON b.id=rr.bus_id AND b.driver_id=v_driver AND b.is_active
  WHERE rr.id=p_run_id AND rr.school_id=v_school
    AND rr.is_active AND rr.class_id IS NOT NULL
  FOR UPDATE OF rr;
  IF NOT FOUND THEN RAISE EXCEPTION 'INVALID_SCHEDULED_RUN'; END IF;
  IF NOT (v_run.days_of_week @> ARRAY[extract(dow FROM CURRENT_DATE)::smallint])
    THEN RAISE EXCEPTION 'RUN_NOT_SCHEDULED_TODAY'; END IF;
  IF EXISTS(SELECT 1 FROM public.bus_trips t
    WHERE t.route_run_id=v_run.id AND t.status='COMPLETED'::public.trip_status
      AND t.starts_at::date=CURRENT_DATE)
    THEN RAISE EXCEPTION 'RUN_ALREADY_COMPLETED_TODAY'; END IF;
  IF EXISTS(SELECT 1 FROM public.bus_trips t
    WHERE (t.driver_id=v_driver OR t.bus_id=v_run.bus_id)
      AND t.status='ACTIVE'::public.trip_status)
    THEN RAISE EXCEPTION 'ACTIVE_TRIP_ALREADY_EXISTS'; END IF;
  IF EXISTS(SELECT 1 FROM public.bus_route_runs prev
    WHERE prev.bus_id=v_run.bus_id AND prev.is_active
      AND prev.sequence_no<v_run.sequence_no
      AND prev.days_of_week @> ARRAY[extract(dow FROM CURRENT_DATE)::smallint]
      AND NOT EXISTS(SELECT 1 FROM public.bus_trips pt
        WHERE pt.route_run_id=prev.id AND pt.status='COMPLETED'::public.trip_status
          AND pt.starts_at::date=CURRENT_DATE))
    THEN RAISE EXCEPTION 'PREVIOUS_RUN_NOT_COMPLETED'; END IF;

  SELECT c.academic_year_id,b.capacity INTO v_year,v_capacity
  FROM public.classes c CROSS JOIN public.buses b
  WHERE c.id=v_run.class_id AND c.school_id=v_school
    AND b.id=v_run.bus_id AND b.school_id=v_school;
  IF v_year IS NULL THEN RAISE EXCEPTION 'INVALID_RUN_CLASS_YEAR'; END IF;

  SELECT COALESCE(array_agg(se.student_id ORDER BY st.full_name),ARRAY[]::uuid[])
  INTO v_student_ids
  FROM public.student_enrollments se
  JOIN public.students st ON st.id=se.student_id
    AND st.school_id=v_school AND st.deleted_at IS NULL
  WHERE se.school_id=v_school AND se.class_id=v_run.class_id
    AND se.academic_year_id=v_year AND se.status='ACTIVE'
    AND (
      EXISTS(SELECT 1 FROM public.student_transport_assignments a
        WHERE a.student_id=st.id AND a.academic_year_id=v_year
          AND a.is_active AND a.bus_id=v_run.bus_id AND a.route_id=v_run.route_id)
      OR (st.uses_transport IS TRUE AND NOT EXISTS(
        SELECT 1 FROM public.student_transport_assignments a
        WHERE a.student_id=st.id AND a.academic_year_id=v_year AND a.is_active
      ))
    );
  v_count := cardinality(v_student_ids);
  IF v_count=0 THEN
    RAISE EXCEPTION 'NO_TRANSPORT_STUDENTS_IN_CLASS: mark students as uses_transport=true or assign them to this bus and route';
  END IF;
  IF v_capacity IS NOT NULL AND v_count>v_capacity THEN
    RAISE EXCEPTION 'BUS_CAPACITY_EXCEEDED: % students for capacity %',v_count,v_capacity;
  END IF;

  -- Create missing assignment rows only for students opted into transport.
  INSERT INTO public.student_transport_assignments(
    student_id,academic_year_id,route_id,bus_id,starts_on,is_active
  )
  SELECT x.student_id,v_year,v_run.route_id,v_run.bus_id,CURRENT_DATE,true
  FROM unnest(v_student_ids) AS x(student_id)
  JOIN public.students st ON st.id=x.student_id AND st.uses_transport IS TRUE
  WHERE NOT EXISTS(
    SELECT 1 FROM public.student_transport_assignments a
    WHERE a.student_id=x.student_id AND a.academic_year_id=v_year AND a.is_active
  );

  INSERT INTO public.bus_trips(
    school_id,bus_id,driver_id,route_id,route_run_id,
    selected_class_id,direction,status,starts_at
  ) VALUES(
    v_school,v_run.bus_id,v_driver,v_run.route_id,v_run.id,
    v_run.class_id,v_run.direction,'ACTIVE'::public.trip_status,now()
  ) RETURNING id INTO v_trip;

  INSERT INTO public.bus_trip_students(trip_id,student_id)
  SELECT v_trip,x.student_id FROM unnest(v_student_ids) AS x(student_id)
  ON CONFLICT(trip_id,student_id) DO NOTHING;

  PERFORM public.fn_safe_audit(
    v_school,'START_SEQUENTIAL_CLASS_BUS_TRIP','bus_trips',v_trip,NULL,
    jsonb_build_object('route_run_id',v_run.id,'class_id',v_run.class_id,
      'student_count',v_count,'sequence_no',v_run.sequence_no,
      'scheduled_start',v_run.scheduled_start,'actual_start',now(),
      'days_of_week',v_run.days_of_week)
  );
  BEGIN
    PERFORM public.fn_notify_trip_started(v_trip);
  EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Trip notification skipped: %',SQLERRM;
  END;
  RETURN v_trip;
END;
$$;
REVOKE ALL ON FUNCTION public.fn_start_scheduled_trip(uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_start_scheduled_trip(uuid) TO authenticated;
