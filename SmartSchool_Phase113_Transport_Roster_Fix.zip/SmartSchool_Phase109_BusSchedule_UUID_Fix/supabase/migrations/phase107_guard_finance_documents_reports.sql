-- Phase 107: Guard finance documents, obligation selection and cashbox reporting.
-- Additive migration. Does not alter or delete existing financial records.

CREATE TABLE IF NOT EXISTS public.finance_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id uuid NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
  record_type text NOT NULL CHECK (record_type IN ('payment','expense')),
  record_id uuid NOT NULL,
  storage_path text NOT NULL UNIQUE,
  original_name text,
  note text,
  created_by uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_finance_documents_record
  ON public.finance_documents(school_id, record_type, record_id);

ALTER TABLE public.finance_documents ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.finance_documents FROM PUBLIC, anon, authenticated;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('finance-documents','finance-documents',false,5242880,ARRAY['image/jpeg','image/png','image/webp'])
ON CONFLICT (id) DO UPDATE SET
  public=false,
  file_size_limit=5242880,
  allowed_mime_types=ARRAY['image/jpeg','image/png','image/webp'];

DROP POLICY IF EXISTS "finance documents upload by school staff" ON storage.objects;
CREATE POLICY "finance documents upload by school staff"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id='finance-documents'
  AND split_part(name,'/',1) ~* '^[0-9a-f-]{36}$'
  AND public.fn_has_permission('finance.manage', split_part(name,'/',1)::uuid)
);

DROP POLICY IF EXISTS "finance documents read by school staff" ON storage.objects;
CREATE POLICY "finance documents read by school staff"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id='finance-documents'
  AND split_part(name,'/',1) ~* '^[0-9a-f-]{36}$'
  AND (
    public.fn_has_permission('finance.view', split_part(name,'/',1)::uuid)
    OR public.fn_has_permission('finance.manage', split_part(name,'/',1)::uuid)
  )
);

DROP POLICY IF EXISTS "finance documents delete by school staff" ON storage.objects;
CREATE POLICY "finance documents delete by school staff"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id='finance-documents'
  AND split_part(name,'/',1) ~* '^[0-9a-f-]{36}$'
  AND public.fn_has_permission('finance.manage', split_part(name,'/',1)::uuid)
);

CREATE OR REPLACE FUNCTION public.fn_link_finance_document(
  p_record_type text,
  p_record_id uuid,
  p_storage_path text,
  p_original_name text DEFAULT NULL,
  p_note text DEFAULT NULL
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public
AS $$
DECLARE
  v_school uuid;
  v_id uuid;
  v_exists boolean := false;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  IF p_record_type NOT IN ('payment','expense') THEN RAISE EXCEPTION 'INVALID_RECORD_TYPE'; END IF;
  IF p_storage_path IS NULL OR split_part(p_storage_path,'/',1) !~* '^[0-9a-f-]{36}$' THEN
    RAISE EXCEPTION 'INVALID_STORAGE_PATH';
  END IF;

  v_school := split_part(p_storage_path,'/',1)::uuid;
  IF NOT public.fn_has_permission('finance.manage',v_school) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  IF p_record_type='payment' THEN
    SELECT EXISTS(
      SELECT 1 FROM public.student_fee_payment_transactions
      WHERE id=p_record_id AND school_id=v_school
    ) INTO v_exists;
  ELSE
    SELECT EXISTS(
      SELECT 1 FROM public.expenses
      WHERE id=p_record_id AND school_id=v_school
    ) INTO v_exists;
  END IF;

  IF NOT v_exists THEN RAISE EXCEPTION 'FINANCE_RECORD_NOT_FOUND'; END IF;

  INSERT INTO public.finance_documents(
    school_id,record_type,record_id,storage_path,original_name,note,created_by
  ) VALUES (
    v_school,p_record_type,p_record_id,p_storage_path,
    NULLIF(btrim(p_original_name),''),NULLIF(btrim(p_note),''),auth.uid()
  ) RETURNING id INTO v_id;

  RETURN v_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.fn_list_finance_documents(
  p_record_type text,
  p_record_ids uuid[]
) RETURNS TABLE(
  id uuid, record_type text, record_id uuid, storage_path text,
  original_name text, note text, created_at timestamptz
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_school uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  v_school := public.fn_my_primary_school();
  IF NOT (
    public.fn_has_permission('finance.view',v_school)
    OR public.fn_has_permission('finance.manage',v_school)
  ) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;

  RETURN QUERY
  SELECT d.id,d.record_type,d.record_id,d.storage_path,d.original_name,d.note,d.created_at
  FROM public.finance_documents d
  WHERE d.school_id=v_school
    AND d.record_type=p_record_type
    AND d.record_id=ANY(COALESCE(p_record_ids,ARRAY[]::uuid[]))
  ORDER BY d.created_at DESC;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_link_finance_document(text,uuid,text,text,text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.fn_list_finance_documents(text,uuid[]) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_link_finance_document(text,uuid,text,text,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_list_finance_documents(text,uuid[]) TO authenticated;


CREATE OR REPLACE FUNCTION public.fn_list_guard_fee_transactions(p_limit integer DEFAULT 500)
RETURNS TABLE(
  payment_id uuid,
  student_name text,
  payment_date date,
  fee_type text,
  amount_paid numeric,
  amount_due numeric,
  method text,
  receipt_no text,
  notes text
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_school uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  v_school := public.fn_my_primary_school();
  IF NOT (
    public.fn_has_permission('finance.view',v_school)
    OR public.fn_has_permission('finance.manage',v_school)
    OR public.fn_is_school_staff(v_school)
  ) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;

  RETURN QUERY
  SELECT
    tx.id,
    s.full_name::text,
    tx.paid_on,
    string_agg(DISTINCT o.fee_type, '، ' ORDER BY o.fee_type),
    tx.amount,
    NULL::numeric,
    tx.method,
    tx.receipt_no,
    tx.notes
  FROM public.student_fee_payment_transactions tx
  JOIN public.students s ON s.id=tx.student_id AND s.school_id=v_school
  LEFT JOIN public.student_fee_payment_allocations a ON a.transaction_id=tx.id
  LEFT JOIN public.student_fee_obligations o ON o.id=a.obligation_id
  WHERE tx.school_id=v_school
  GROUP BY tx.id,s.full_name,tx.paid_on,tx.amount,tx.method,tx.receipt_no,tx.notes
  ORDER BY tx.paid_on DESC,tx.created_at DESC
  LIMIT GREATEST(1,LEAST(COALESCE(p_limit,500),2000));
END;
$$;

REVOKE ALL ON FUNCTION public.fn_list_guard_fee_transactions(integer) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_list_guard_fee_transactions(integer) TO authenticated;
