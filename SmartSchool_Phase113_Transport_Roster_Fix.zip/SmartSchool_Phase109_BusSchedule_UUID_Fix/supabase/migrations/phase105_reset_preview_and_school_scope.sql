-- Phase 105: server-resolved reset target and mandatory non-destructive preview.
-- This migration does NOT execute a reset and does not delete existing data.

CREATE OR REPLACE FUNCTION public.fn_is_school_staff(p_school_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    EXISTS (
      SELECT 1 FROM public.user_roles
      WHERE profile_id = auth.uid()
        AND role::text = 'superadmin'
    )
    OR EXISTS (
      SELECT 1 FROM public.user_roles
      WHERE profile_id = auth.uid()
        AND school_id = p_school_id
        AND role::text IN ('admin', 'director')
    );
$$;

REVOKE ALL ON FUNCTION public.fn_is_school_staff(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_is_school_staff(uuid) TO authenticated;


-- A reset manager must have exactly one school-bound admin/director role.
-- A school_id supplied by a browser is never used to select the reset target.
CREATE OR REPLACE FUNCTION public.fn_reset_target_school()
RETURNS uuid
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_schools uuid[];
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;

  SELECT array_agg(DISTINCT school_id ORDER BY school_id)
    INTO v_schools
  FROM public.user_roles
  WHERE profile_id = auth.uid()
    AND school_id IS NOT NULL
    AND role::text IN ('admin', 'director');

  IF COALESCE(cardinality(v_schools), 0) = 0 THEN
    RAISE EXCEPTION 'RESET_PERMISSION_DENIED';
  END IF;

  IF cardinality(v_schools) <> 1 THEN
    RAISE EXCEPTION 'RESET_SCHOOL_AMBIGUOUS';
  END IF;

  RETURN v_schools[1];
END;
$$;

REVOKE ALL ON FUNCTION public.fn_reset_target_school() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_reset_target_school() TO authenticated;


-- Non-destructive preview. Counts all operational tables with school_id,
-- while explicitly retaining school identity, user identities, access roles,
-- audit history and master settings.
CREATE OR REPLACE FUNCTION public.fn_preview_school_reset()
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school uuid;
  v_table record;
  v_count bigint;
  v_result jsonb := '{}'::jsonb;
  v_total bigint := 0;
  v_excluded text[] := ARRAY[
    'schools','profiles','user_roles','user_permissions','audit_logs',
    'school_reset_backup_tickets','teachers','drivers','guards','parents',
    'appointment_settings','school_domains','school_period_configs',
    'school_posts','staff_pins','login_qr_tokens','push_subscriptions',
    'pin_login_attempts','tv_screens'
  ];
BEGIN
  v_school := public.fn_reset_target_school();

  FOR v_table IN
    SELECT c.table_name
    FROM information_schema.columns c
    JOIN information_schema.tables t
      ON t.table_schema = c.table_schema
     AND t.table_name = c.table_name
    WHERE c.table_schema = 'public'
      AND c.column_name = 'school_id'
      AND t.table_type = 'BASE TABLE'
      AND NOT (c.table_name = ANY(v_excluded))
    ORDER BY c.table_name
  LOOP
    EXECUTE format(
      'SELECT count(*) FROM public.%I WHERE school_id = $1',
      v_table.table_name
    )
    INTO v_count
    USING v_school;

    v_result := v_result || jsonb_build_object(v_table.table_name, v_count);
    v_total := v_total + v_count;
  END LOOP;

  RETURN jsonb_build_object(
    'ok', true,
    'school_id', v_school,
    'counts_by_table', v_result,
    'total_direct_records', v_total,
    'warning', 'المعاينة تشمل الجداول ذات school_id فقط. الجداول التابعة التي لا تحتوي على school_id تُعالج وفق علاقاتها ومفاتيحها الأجنبية أثناء مرحلة التصفير.'
  );
END;
$$;

REVOKE ALL ON FUNCTION public.fn_preview_school_reset() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_preview_school_reset() TO authenticated;


-- Keep the existing RPC signature for compatibility, but ignore the browser's
-- school_id and resolve the only admin/director school from auth.uid().
CREATE OR REPLACE FUNCTION public.fn_export_school_backup_for_reset(
  p_school_id uuid DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school uuid;
  v_backup jsonb;
  v_ticket uuid;
BEGIN
  v_school := public.fn_reset_target_school();

  IF p_school_id IS NOT NULL AND p_school_id <> v_school THEN
    RAISE EXCEPTION 'RESET_SCHOOL_SCOPE_MISMATCH';
  END IF;

  v_backup := public.fn_export_school_backup_safe(v_school);

  INSERT INTO public.school_reset_backup_tickets(school_id, created_by)
  VALUES (v_school, auth.uid())
  RETURNING id INTO v_ticket;

  RETURN v_backup || jsonb_build_object('_reset_ticket', v_ticket);
END;
$$;

REVOKE ALL ON FUNCTION public.fn_export_school_backup_for_reset(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_export_school_backup_for_reset(uuid) TO authenticated;


-- Recreate the reset RPC with the same public signature and strict school
-- resolution. The existing allowlisted delete order is retained for backward
-- compatibility; dependent-table coverage is explicitly identified as a
-- follow-up requirement and must be verified against the deployed FK catalog.
CREATE OR REPLACE FUNCTION public.fn_reset_school_operational_data(
  p_ticket uuid,
  p_confirmation text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;
  IF p_confirmation IS DISTINCT FROM 'تصفير بيانات المؤسسة' THEN
    RAISE EXCEPTION 'RESET_CONFIRMATION_MISMATCH';
  END IF;
  -- Fail closed: Phase 106 will replace this guard only after every dependent
  -- FK table without school_id has an explicit, verified deletion strategy.
  RAISE EXCEPTION 'RESET_TEMPORARILY_DISABLED_DEPENDENT_FK_AUDIT_REQUIRED';
END;
$$;

REVOKE ALL ON FUNCTION public.fn_reset_school_operational_data(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_reset_school_operational_data(uuid, text) TO authenticated;
