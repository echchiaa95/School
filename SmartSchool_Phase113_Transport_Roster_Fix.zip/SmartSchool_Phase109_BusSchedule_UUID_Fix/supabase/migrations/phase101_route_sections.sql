-- Phase 101: Route-to-section assignment and driver section selection.
CREATE TABLE IF NOT EXISTS public.bus_route_classes (
 school_id uuid NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
 route_id uuid NOT NULL REFERENCES public.bus_routes(id) ON DELETE CASCADE,
 class_id uuid NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
 created_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(route_id,class_id)
);
CREATE INDEX IF NOT EXISTS idx_bus_route_classes_school ON public.bus_route_classes(school_id,route_id);
ALTER TABLE public.bus_route_classes ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.bus_route_classes FROM PUBLIC,anon,authenticated;

ALTER TABLE public.bus_trips ADD COLUMN IF NOT EXISTS selected_class_id uuid REFERENCES public.classes(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_bus_trips_selected_class ON public.bus_trips(selected_class_id,starts_at DESC);

CREATE OR REPLACE FUNCTION public.fn_set_bus_route_classes(p_route_id uuid,p_class_ids uuid[])
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_school uuid; v_id uuid; v_n integer:=0;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
 SELECT school_id INTO v_school FROM public.bus_routes WHERE id=p_route_id AND is_active;
 IF v_school IS NULL THEN RAISE EXCEPTION 'INVALID_ROUTE'; END IF;
 IF NOT (public.fn_is_school_staff(v_school) OR public.fn_has_permission('transport.manage',v_school)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
 IF EXISTS(SELECT 1 FROM unnest(COALESCE(p_class_ids,ARRAY[]::uuid[])) x LEFT JOIN public.classes c ON c.id=x AND c.school_id=v_school WHERE c.id IS NULL) THEN RAISE EXCEPTION 'INVALID_CLASS_SELECTION'; END IF;
 DELETE FROM public.bus_route_classes WHERE route_id=p_route_id;
 FOREACH v_id IN ARRAY COALESCE(p_class_ids,ARRAY[]::uuid[]) LOOP
  INSERT INTO public.bus_route_classes(school_id,route_id,class_id) VALUES(v_school,p_route_id,v_id) ON CONFLICT DO NOTHING;
  v_n:=v_n+1;
 END LOOP;
 PERFORM public.fn_safe_audit(v_school,'SET_BUS_ROUTE_CLASSES','bus_routes',p_route_id,NULL,jsonb_build_object('class_ids',COALESCE(p_class_ids,ARRAY[]::uuid[])));
 RETURN v_n;
END $$;

CREATE OR REPLACE FUNCTION public.fn_list_bus_route_classes(p_route_id uuid)
RETURNS TABLE(class_id uuid,class_name text)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public AS $$
DECLARE v_school uuid;
BEGIN
 SELECT school_id INTO v_school FROM public.bus_routes WHERE id=p_route_id;
 IF v_school IS NULL THEN RAISE EXCEPTION 'INVALID_ROUTE'; END IF;
 IF NOT (public.fn_is_school_member(v_school) OR public.fn_is_school_staff(v_school) OR public.fn_has_permission('transport.view',v_school) OR public.fn_has_permission('transport.manage',v_school)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
 RETURN QUERY SELECT c.id,c.name::text FROM public.bus_route_classes rc JOIN public.classes c ON c.id=rc.class_id WHERE rc.route_id=p_route_id ORDER BY c.name;
END $$;

CREATE OR REPLACE FUNCTION public.fn_list_driver_run_classes(p_run_id uuid)
RETURNS TABLE(class_id uuid,class_name text)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public AS $$
DECLARE v_driver uuid; v_school uuid; v_route uuid;
BEGIN
 SELECT d.id,d.school_id INTO v_driver,v_school FROM public.drivers d WHERE d.profile_id=auth.uid() AND d.deleted_at IS NULL LIMIT 1;
 IF v_driver IS NULL THEN RAISE EXCEPTION 'NOT_A_DRIVER'; END IF;
 SELECT rr.route_id INTO v_route FROM public.bus_route_runs rr JOIN public.buses b ON b.id=rr.bus_id
 WHERE rr.id=p_run_id AND rr.school_id=v_school AND rr.is_active AND b.driver_id=v_driver AND b.is_active;
 IF v_route IS NULL THEN RAISE EXCEPTION 'INVALID_SCHEDULED_RUN'; END IF;
 RETURN QUERY SELECT c.id,c.name::text FROM public.bus_route_classes rc JOIN public.classes c ON c.id=rc.class_id WHERE rc.route_id=v_route ORDER BY c.name;
END $$;

CREATE OR REPLACE FUNCTION public.fn_start_scheduled_trip_for_class(p_run_id uuid,p_class_id uuid)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_driver uuid; v_school uuid; v_run public.bus_route_runs%rowtype; v_trip uuid; v_n integer;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
 SELECT d.id,d.school_id INTO v_driver,v_school FROM public.drivers d WHERE d.profile_id=auth.uid() AND d.deleted_at IS NULL LIMIT 1;
 IF v_driver IS NULL THEN RAISE EXCEPTION 'NOT_A_DRIVER'; END IF;
 SELECT rr.* INTO v_run FROM public.bus_route_runs rr JOIN public.buses b ON b.id=rr.bus_id
 WHERE rr.id=p_run_id AND rr.school_id=v_school AND rr.is_active AND b.driver_id=v_driver AND b.is_active FOR UPDATE OF rr;
 IF NOT FOUND THEN RAISE EXCEPTION 'INVALID_SCHEDULED_RUN'; END IF;
 IF v_run.weekday<>extract(dow FROM current_date)::integer THEN RAISE EXCEPTION 'RUN_NOT_SCHEDULED_TODAY'; END IF;
 IF NOT EXISTS(SELECT 1 FROM public.bus_route_classes WHERE route_id=v_run.route_id AND class_id=p_class_id AND school_id=v_school) THEN RAISE EXCEPTION 'CLASS_NOT_ASSIGNED_TO_ROUTE'; END IF;
 SELECT count(*) INTO v_n FROM public.student_transport_assignments sta
 JOIN public.student_enrollments se ON se.student_id=sta.student_id AND se.school_id=v_school AND se.status='ACTIVE' AND se.class_id=p_class_id
 JOIN public.students st ON st.id=sta.student_id AND st.deleted_at IS NULL
 WHERE sta.bus_id=v_run.bus_id AND sta.route_id=v_run.route_id AND sta.is_active;
 IF v_n=0 THEN RAISE EXCEPTION 'NO_TRANSPORT_STUDENTS_IN_CLASS'; END IF;
 IF EXISTS(SELECT 1 FROM public.bus_trips WHERE driver_id=v_driver AND status='ACTIVE'::public.trip_status) THEN RAISE EXCEPTION 'ACTIVE_TRIP_ALREADY_EXISTS'; END IF;
 INSERT INTO public.bus_trips(school_id,bus_id,driver_id,route_id,route_run_id,selected_class_id,direction,status,starts_at)
 VALUES(v_school,v_run.bus_id,v_driver,v_run.route_id,v_run.id,p_class_id,v_run.direction,'ACTIVE'::public.trip_status,now()) RETURNING id INTO v_trip;
 INSERT INTO public.bus_trip_students(trip_id,student_id)
 SELECT v_trip,sta.student_id FROM public.student_transport_assignments sta
 JOIN public.student_enrollments se ON se.student_id=sta.student_id AND se.school_id=v_school AND se.status='ACTIVE' AND se.class_id=p_class_id
 JOIN public.students st ON st.id=sta.student_id AND st.deleted_at IS NULL
 WHERE sta.bus_id=v_run.bus_id AND sta.route_id=v_run.route_id AND sta.is_active
 ON CONFLICT(trip_id,student_id) DO NOTHING;
 PERFORM public.fn_safe_audit(v_school,'START_SCHEDULED_BUS_TRIP_CLASS','bus_trips',v_trip,NULL,jsonb_build_object('route_run_id',v_run.id,'class_id',p_class_id));
 BEGIN PERFORM public.fn_notify_trip_started(v_trip); EXCEPTION WHEN OTHERS THEN RAISE NOTICE 'Trip notification skipped: %',SQLERRM; END;
 RETURN v_trip;
END $$;

CREATE OR REPLACE FUNCTION public.fn_list_bus_students_ordered(p_bus_id uuid,p_trip_id uuid DEFAULT NULL)
RETURNS TABLE(student_id uuid,full_name text,student_number text,pickup_stop text,dropoff_stop text,stop_order integer,stop_latitude double precision,stop_longitude double precision,student_latitude double precision,student_longitude double precision,boarded_at timestamptz,alighted_at timestamptz)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public AS $$
DECLARE v_school uuid; v_ctx jsonb; v_route uuid; v_class uuid;
BEGIN
 SELECT school_id INTO v_school FROM public.buses WHERE id=p_bus_id;
 IF v_school IS NULL THEN RAISE EXCEPTION 'INVALID_BUS'; END IF;
 v_ctx:=public.fn_driver_context();
 IF NOT (public.fn_is_school_member(v_school) OR (v_ctx IS NOT NULL AND (v_ctx->>'bus_id')::uuid=p_bus_id)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
 IF p_trip_id IS NOT NULL THEN
  SELECT route_id,selected_class_id INTO v_route,v_class FROM public.bus_trips WHERE id=p_trip_id AND bus_id=p_bus_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'INVALID_TRIP'; END IF;
 END IF;
 RETURN QUERY SELECT sta.student_id,s.full_name,s.student_number,pick.name,dropoff.name,brs.sequence_order,pick.latitude,pick.longitude,s.latitude,s.longitude,bts.boarded_at,bts.dropped_at
 FROM public.student_transport_assignments sta JOIN public.students s ON s.id=sta.student_id AND s.deleted_at IS NULL
 LEFT JOIN public.bus_stops pick ON pick.id=sta.pickup_stop_id
 LEFT JOIN public.bus_stops dropoff ON dropoff.id=sta.dropoff_stop_id
 LEFT JOIN public.bus_route_stops brs ON brs.route_id=sta.route_id AND brs.stop_id=sta.pickup_stop_id
 LEFT JOIN public.bus_trip_students bts ON bts.trip_id=p_trip_id AND bts.student_id=sta.student_id
 WHERE sta.bus_id=p_bus_id AND sta.is_active AND (v_route IS NULL OR sta.route_id=v_route)
 AND (v_class IS NULL OR EXISTS(SELECT 1 FROM public.student_enrollments se WHERE se.student_id=sta.student_id AND se.school_id=v_school AND se.status='ACTIVE' AND se.class_id=v_class))
 ORDER BY COALESCE(brs.sequence_order,999999),s.full_name;
END $$;

REVOKE ALL ON FUNCTION public.fn_set_bus_route_classes(uuid,uuid[]) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.fn_list_bus_route_classes(uuid) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.fn_list_driver_run_classes(uuid) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.fn_start_scheduled_trip_for_class(uuid,uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_set_bus_route_classes(uuid,uuid[]) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_list_bus_route_classes(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_list_driver_run_classes(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_start_scheduled_trip_for_class(uuid,uuid) TO authenticated;


-- Scope departure notifications to the section actually selected by the driver.
CREATE OR REPLACE FUNCTION public.fn_notify_trip_started(p_trip_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE
 v_school uuid; v_bus uuid; v_route uuid; v_class uuid;
 v_direction public.trip_direction; v_bus_label text; v_route_label text;
 v_run_label text; v_seq integer; v_title text; v_body text; v_notif uuid;
BEGIN
 SELECT t.school_id,t.bus_id,t.route_id,t.selected_class_id,t.direction,
   COALESCE(b.code,b.plate_number,'الحافلة'),r.name,rr.run_name,rr.sequence_no
 INTO v_school,v_bus,v_route,v_class,v_direction,v_bus_label,v_route_label,v_run_label,v_seq
 FROM public.bus_trips t JOIN public.buses b ON b.id=t.bus_id
 LEFT JOIN public.bus_routes r ON r.id=t.route_id
 LEFT JOIN public.bus_route_runs rr ON rr.id=t.route_run_id
 WHERE t.id=p_trip_id;
 IF v_school IS NULL THEN RETURN; END IF;
 IF NOT EXISTS(
   SELECT 1 FROM public.bus_trips t JOIN public.drivers d ON d.id=t.driver_id
   WHERE t.id=p_trip_id AND (
     d.profile_id=auth.uid() OR public.fn_is_school_staff(t.school_id)
     OR public.fn_has_permission('transport.manage',t.school_id)
   )
 ) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
 v_run_label:=COALESCE(v_run_label,'المسار');
 IF v_seq IS NOT NULL THEN v_run_label:=v_run_label||' (المسار رقم '||v_seq||')'; END IF;
 IF v_direction='TO_SCHOOL'::public.trip_direction THEN
   v_title:='🚌 انطلاق الحافلة — '||v_run_label;
   v_body:='انطلقت حافلة '||v_bus_label||' في '||v_run_label||
     COALESCE(' ('||v_route_label||')','')||' باتجاه المؤسسة. الرجاء الاستعداد عند نقطة الركوب.';
 ELSE
   v_title:='🚌 رحلة العودة — '||v_run_label;
   v_body:='انطلقت حافلة '||v_bus_label||' في '||v_run_label||
     COALESCE(' ('||v_route_label||')','')||' لإرجاع التلاميذ إلى منازلهم.';
 END IF;
 INSERT INTO public.notifications(school_id,title,body,type,created_by)
 VALUES(v_school,v_title,v_body,'transport',auth.uid()) RETURNING id INTO v_notif;
 INSERT INTO public.notification_deliveries(notification_id,profile_id)
 SELECT DISTINCT v_notif,pa.profile_id
 FROM public.student_transport_assignments sta
 JOIN public.student_enrollments se ON se.student_id=sta.student_id
   AND se.school_id=v_school AND se.status='ACTIVE'
 JOIN public.parent_students ps ON ps.student_id=sta.student_id
 JOIN public.parents pa ON pa.id=ps.parent_id AND pa.deleted_at IS NULL
 WHERE sta.bus_id=v_bus AND sta.is_active
   AND (v_route IS NULL OR sta.route_id=v_route)
   AND (v_class IS NULL OR se.class_id=v_class)
 ON CONFLICT DO NOTHING;
END $$;

REVOKE ALL ON FUNCTION public.fn_notify_trip_started(uuid) FROM PUBLIC,anon,authenticated;
