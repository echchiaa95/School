-- Phase 90: Secure school certificate issuance and public verification
-- Apply after phase89_class_councils_final_decisions.sql.
begin;

create table if not exists public.school_certificate_counters (
  school_id uuid not null references public.schools(id) on delete cascade,
  issue_year integer not null,
  last_number bigint not null default 0 check (last_number >= 0),
  primary key (school_id, issue_year)
);

create table if not exists public.school_certificates (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete restrict,
  certificate_type text not null check (certificate_type in ('ENROLLMENT','SUCCESS','TRANSFER','DEPARTURE')),
  certificate_number text not null,
  verification_token uuid not null default gen_random_uuid(),
  issue_date date not null default current_date,
  purpose text,
  snapshot jsonb not null,
  status text not null default 'VALID' check (status in ('VALID','VOID')),
  issued_by uuid references auth.users(id) on delete set null,
  issued_at timestamptz not null default now(),
  voided_at timestamptz,
  void_reason text,
  constraint school_certificates_school_number_uq unique (school_id, certificate_number),
  constraint school_certificates_token_uq unique (verification_token)
);

create index if not exists school_certificates_school_issued_idx
  on public.school_certificates (school_id, issued_at desc);
create index if not exists school_certificates_student_idx
  on public.school_certificates (student_id, issued_at desc);

alter table public.school_certificates enable row level security;
alter table public.school_certificate_counters enable row level security;
revoke all on public.school_certificates from anon, authenticated;
revoke all on public.school_certificate_counters from anon, authenticated;

create or replace function public.fn_issue_school_certificate(
  p_student_id uuid,
  p_certificate_type text,
  p_purpose text default null
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_student record;
  v_class_name text;
  v_year_name text;
  v_school_name text;
  v_decision text;
  v_issue_year integer := extract(year from current_date)::integer;
  v_seq bigint;
  v_number text;
  v_snapshot jsonb;
  v_id uuid;
  v_token uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  if upper(coalesce(p_certificate_type,'')) not in ('ENROLLMENT','SUCCESS','TRANSFER','DEPARTURE') then
    raise exception 'INVALID_CERTIFICATE_TYPE';
  end if;
  select s.* into v_student from students s
  where s.id = p_student_id and s.deleted_at is null;
  if not found then raise exception 'INVALID_STUDENT'; end if;
  v_school_id := v_student.school_id;
  if not fn_is_school_staff(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;

  select c.name, ay.label into v_class_name, v_year_name
  from student_enrollments se
  join classes c on c.id = se.class_id
  left join academic_years ay on ay.id = c.academic_year_id
  where se.student_id = p_student_id and se.status = 'ACTIVE'
  limit 1;
  if v_class_name is null then raise exception 'ACTIVE_ENROLLMENT_REQUIRED'; end if;

  if upper(p_certificate_type) = 'SUCCESS' then
    select d.decision into v_decision
    from student_enrollments se
    join classes cl on cl.id = se.class_id
    join class_councils cc on cc.class_id = cl.id
      and cc.academic_year_id = cl.academic_year_id
      and cc.period = 'ANNUAL'
    join class_council_decisions d on d.council_id = cc.id
      and d.student_id = p_student_id
    where se.student_id = p_student_id and se.status = 'ACTIVE'
    limit 1;
    if coalesce(v_decision,'') <> 'PASS' then
      raise exception 'SUCCESS_DECISION_REQUIRED';
    end if;
  end if;
  select name into v_school_name from schools where id = v_school_id;

  -- Per-school/year serialization prevents duplicate numbers under concurrency.
  perform pg_advisory_xact_lock(hashtext(v_school_id::text), v_issue_year);
  insert into school_certificate_counters(school_id, issue_year, last_number)
  values (v_school_id, v_issue_year, 0)
  on conflict (school_id, issue_year) do nothing;
  update school_certificate_counters
    set last_number = last_number + 1
    where school_id = v_school_id and issue_year = v_issue_year
    returning last_number into v_seq;

  v_number := 'SC-' || v_issue_year::text || '-' || lpad(v_seq::text, 6, '0');
  v_snapshot := jsonb_build_object(
    'school_name', coalesce(v_school_name,''),
    'student_name', coalesce(v_student.full_name,''),
    'student_number', coalesce(v_student.student_number,''),
    'class_name', coalesce(v_class_name,''),
    'academic_year', coalesce(v_year_name,''),
    'certificate_type', upper(p_certificate_type),
    'purpose', nullif(trim(coalesce(p_purpose,'')),''),
    'issue_date', current_date
  );
  insert into school_certificates(
    school_id, student_id, certificate_type, certificate_number,
    purpose, snapshot, issued_by
  ) values (
    v_school_id, p_student_id, upper(p_certificate_type),
    v_number, nullif(trim(coalesce(p_purpose,'')),''), v_snapshot, auth.uid()
  ) returning id, verification_token into v_id, v_token;

  return jsonb_build_object(
    'id', v_id, 'certificate_number', v_number,
    'verification_token', v_token, 'issue_date', current_date,
    'snapshot', v_snapshot, 'status', 'VALID'
  );
end;
$$;

create or replace function public.fn_list_school_certificates(
  p_query text default null,
  p_limit integer default 100
) returns table (
  id uuid, certificate_number text, certificate_type text,
  issue_date date, status text, student_name text, student_number text,
  class_name text, academic_year text, purpose text, verification_token uuid,
  issued_at timestamptz, void_reason text
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare v_school_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select fn_my_primary_school() into v_school_id;
  if v_school_id is null or not fn_is_school_staff(v_school_id) then
    raise exception 'PERMISSION_DENIED';
  end if;
  return query
  select c.id, c.certificate_number, c.certificate_type, c.issue_date,
    c.status, c.snapshot->>'student_name', c.snapshot->>'student_number',
    c.snapshot->>'class_name', c.snapshot->>'academic_year',
    c.purpose, c.verification_token, c.issued_at, c.void_reason
  from school_certificates c
  where c.school_id = v_school_id
    and (nullif(trim(coalesce(p_query,'')),'') is null
      or c.certificate_number ilike '%'||trim(p_query)||'%'
      or coalesce(c.snapshot->>'student_name','') ilike '%'||trim(p_query)||'%'
      or coalesce(c.snapshot->>'student_number','') ilike '%'||trim(p_query)||'%')
  order by c.issued_at desc
  limit greatest(1, least(coalesce(p_limit,100),500));
end;
$$;

create or replace function public.fn_void_school_certificate(
  p_certificate_id uuid,
  p_reason text
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare v_school_id uuid; v_status text;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  if nullif(trim(coalesce(p_reason,'')),'') is null then raise exception 'VOID_REASON_REQUIRED'; end if;
  select school_id, status into v_school_id, v_status
  from school_certificates where id = p_certificate_id for update;
  if v_school_id is null then raise exception 'CERTIFICATE_NOT_FOUND'; end if;
  if not fn_is_school_staff(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;
  if v_status = 'VOID' then raise exception 'CERTIFICATE_ALREADY_VOID'; end if;
  update school_certificates set status='VOID', voided_at=now(),
    void_reason=trim(p_reason) where id=p_certificate_id;
  return jsonb_build_object('id',p_certificate_id,'status','VOID');
end;
$$;

-- Public verification reveals only authenticity status and non-sensitive document metadata.
create or replace function public.fn_verify_school_certificate(p_token uuid)
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select case when c.id is null then
    jsonb_build_object('found',false,'valid',false)
  else
    jsonb_build_object(
      'found',true,
      'valid',c.status='VALID',
      'status',c.status,
      'certificate_number',c.certificate_number,
      'certificate_type',c.certificate_type,
      'issue_date',c.issue_date,
      'school_name',coalesce(c.snapshot->>'school_name','')
    )
  end
  from (select p_token as token) q
  left join school_certificates c on c.verification_token=q.token;
$$;

revoke all on function public.fn_issue_school_certificate(uuid,text,text) from public;
revoke all on function public.fn_list_school_certificates(text,integer) from public;
revoke all on function public.fn_void_school_certificate(uuid,text) from public;
revoke all on function public.fn_verify_school_certificate(uuid) from public;
grant execute on function public.fn_issue_school_certificate(uuid,text,text) to authenticated;
grant execute on function public.fn_list_school_certificates(text,integer) to authenticated;
grant execute on function public.fn_void_school_certificate(uuid,text) to authenticated;
grant execute on function public.fn_verify_school_certificate(uuid) to anon, authenticated;

commit;
