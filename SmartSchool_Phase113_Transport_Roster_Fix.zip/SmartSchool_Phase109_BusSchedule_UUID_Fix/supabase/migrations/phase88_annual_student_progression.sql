-- ============================================================================
-- Phase 88: Academic progression and annual student promotion.
-- Additive migration. Existing students and enrollment history are preserved.
-- ============================================================================

create table if not exists public.student_academic_progression (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  from_academic_year_id uuid not null references public.academic_years(id),
  from_class_id uuid not null references public.classes(id),
  to_academic_year_id uuid not null references public.academic_years(id),
  to_class_id uuid not null references public.classes(id),
  outcome text not null check (outcome in ('PROMOTED', 'REPEATED')),
  notes text,
  processed_by uuid references public.profiles(id),
  processed_at timestamptz not null default now(),
  constraint uq_student_progression_year unique (student_id, to_academic_year_id)
);

create index if not exists idx_student_progression_school_year
  on public.student_academic_progression(school_id, to_academic_year_id);
create index if not exists idx_student_progression_student
  on public.student_academic_progression(student_id, processed_at desc);

alter table public.student_academic_progression enable row level security;
revoke all on public.student_academic_progression from anon, authenticated;

insert into public.permissions(permission_key, module, name, description)
values
 ('students.progression.view', 'students', 'عرض المسار الدراسي', 'عرض انتقالات التلاميذ بين السنوات'),
 ('students.progression.manage', 'students', 'تدبير الترقية السنوية', 'ترقية التلاميذ أو إعادة تسجيلهم')
on conflict (permission_key) do nothing;

create or replace function public.fn_list_promotion_candidates(p_class_id uuid)
returns table(
  student_id uuid,
  full_name text,
  student_number text,
  current_class_id uuid,
  current_class_name text,
  current_academic_year_id uuid,
  current_academic_year_name text
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select c.school_id into v_school_id
  from public.classes c where c.id = p_class_id;
  if v_school_id is null then raise exception 'INVALID_CLASS'; end if;

  if not (
    public.fn_resolve_my_role(v_school_id) in ('admin','director','superadmin')
    or public.fn_has_permission('students.progression.view', v_school_id)
  ) then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select st.id, st.full_name, st.student_number,
         c.id, c.name, ay.id, ay.label
  from public.student_enrollments se
  join public.students st on st.id = se.student_id and st.deleted_at is null
  join public.classes c on c.id = se.class_id
  join public.academic_years ay on ay.id = se.academic_year_id
  where se.class_id = p_class_id
    and se.school_id = v_school_id
    and se.status = 'ACTIVE'
  order by st.full_name;
end;
$$;

revoke all on function public.fn_list_promotion_candidates(uuid) from public;
grant execute on function public.fn_list_promotion_candidates(uuid) to authenticated;

create or replace function public.fn_process_student_progression(
  p_to_academic_year_id uuid,
  p_items jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
  v_item jsonb;
  v_student_id uuid;
  v_target_class_id uuid;
  v_outcome text;
  v_from_year uuid;
  v_from_class uuid;
  v_old_count integer;
  v_done integer := 0;
  v_skipped integer := 0;
  v_status_type text;
  v_status_udt text;
  v_status_check text;
  v_closed_status text;
  v_candidate text;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  v_school_id := public.fn_my_primary_school();
  if v_school_id is null then raise exception 'NO_SCHOOL_CONTEXT'; end if;
  v_role := public.fn_resolve_my_role(v_school_id);
  if not (
    v_role in ('admin','director','superadmin')
    or public.fn_has_permission('students.progression.manage', v_school_id)
  ) then raise exception 'PERMISSION_DENIED'; end if;

  if not exists (
    select 1 from public.academic_years ay
    where ay.id = p_to_academic_year_id and ay.school_id = v_school_id
  ) then raise exception 'INVALID_ACADEMIC_YEAR'; end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array'
     or jsonb_array_length(p_items) < 1 then
    raise exception 'INVALID_PROGRESSION_ITEMS';
  end if;
  if jsonb_array_length(p_items) > 500 then
    raise exception 'PROGRESSION_BATCH_TOO_LARGE';
  end if;

  -- Resolve a valid closed-enrollment value from the deployed schema rather
  -- than assuming the status column is text or that a particular enum label
  -- exists. If a CHECK/enum offers no known closed value, fail safely.
  select data_type, udt_name into v_status_type, v_status_udt
  from information_schema.columns
  where table_schema = 'public'
    and table_name = 'student_enrollments'
    and column_name = 'status';

  if v_status_type is null then
    raise exception 'ENROLLMENT_STATUS_COLUMN_NOT_FOUND';
  elsif v_status_type = 'USER-DEFINED' then
    select e.enumlabel into v_closed_status
    from pg_type t
    join pg_enum e on e.enumtypid = t.oid
    where t.typname = v_status_udt
      and t.typnamespace = 'public'::regnamespace
      and upper(e.enumlabel) in ('COMPLETED','INACTIVE','CLOSED','TRANSFERRED')
    order by case upper(e.enumlabel)
      when 'COMPLETED' then 1 when 'INACTIVE' then 2
      when 'CLOSED' then 3 else 4 end
    limit 1;
  else
    select string_agg(pg_get_constraintdef(c.oid), ' ')
      into v_status_check
    from pg_constraint c
    where c.conrelid = 'public.student_enrollments'::regclass
      and c.contype = 'c'
      and pg_get_constraintdef(c.oid) ilike '%status%';

    if coalesce(v_status_check, '') = '' then
      v_closed_status := 'COMPLETED';
    else
      foreach v_candidate in array array['COMPLETED','completed','INACTIVE','inactive','CLOSED','closed','TRANSFERRED','transferred'] loop
        if position(quote_literal(v_candidate) in v_status_check) > 0 then
          v_closed_status := v_candidate;
          exit;
        end if;
      end loop;
    end if;
  end if;

  if v_closed_status is null then
    raise exception 'NO_SUPPORTED_CLOSED_ENROLLMENT_STATUS';
  end if;

  for v_item in select value from jsonb_array_elements(p_items)
  loop
    v_student_id := nullif(v_item->>'student_id','')::uuid;
    v_target_class_id := nullif(v_item->>'target_class_id','')::uuid;
    v_outcome := upper(coalesce(v_item->>'outcome','PROMOTED'));

    if v_student_id is null or v_target_class_id is null
       or v_outcome not in ('PROMOTED','REPEATED') then
      raise exception 'INVALID_PROGRESSION_ITEM';
    end if;

    -- Serialize concurrent attempts for this student.
    perform pg_advisory_xact_lock(hashtextextended(v_student_id::text, 88));

    if exists (
      select 1 from public.student_academic_progression p
      where p.student_id = v_student_id
        and p.to_academic_year_id = p_to_academic_year_id
    ) then
      raise exception 'STUDENT_ALREADY_PROCESSED_FOR_YEAR';
    end if;

    select se.academic_year_id, se.class_id
      into v_from_year, v_from_class
    from public.student_enrollments se
    join public.students st on st.id = se.student_id
    where se.student_id = v_student_id
      and se.school_id = v_school_id
      and st.school_id = v_school_id
      and se.status = 'ACTIVE'
    for update of se;

    if v_from_year is null then raise exception 'ACTIVE_ENROLLMENT_NOT_FOUND'; end if;
    if v_from_year = p_to_academic_year_id then
      raise exception 'SAME_ACADEMIC_YEAR';
    end if;

    if not exists (
      select 1 from public.classes c
      where c.id = v_target_class_id
        and c.school_id = v_school_id
        and c.academic_year_id = p_to_academic_year_id
    ) then raise exception 'TARGET_CLASS_YEAR_MISMATCH'; end if;

    select count(*) into v_old_count
    from public.student_enrollments se
    where se.student_id = v_student_id
      and se.school_id = v_school_id
      and se.status = 'ACTIVE';
    if v_old_count <> 1 then raise exception 'MULTIPLE_ACTIVE_ENROLLMENTS'; end if;

    -- Retain the old enrollment as history; create a new active enrollment.
    execute format(
      'update public.student_enrollments set status = %L
       where student_id = $1 and school_id = $2 and class_id = $3
         and academic_year_id = $4 and status::text = ''ACTIVE''',
      v_closed_status
    ) using v_student_id, v_school_id, v_from_class, v_from_year;

    insert into public.student_enrollments(
      student_id, school_id, class_id, academic_year_id, status
    ) values (
      v_student_id, v_school_id, v_target_class_id,
      p_to_academic_year_id, 'ACTIVE'
    );

    insert into public.student_academic_progression(
      school_id, student_id, from_academic_year_id, from_class_id,
      to_academic_year_id, to_class_id, outcome, notes, processed_by
    ) values (
      v_school_id, v_student_id, v_from_year, v_from_class,
      p_to_academic_year_id, v_target_class_id, v_outcome,
      nullif(trim(coalesce(v_item->>'notes','')), ''), auth.uid()
    );

    v_done := v_done + 1;
  end loop;

  return jsonb_build_object(
    'processed', v_done,
    'skipped', v_skipped,
    'target_academic_year_id', p_to_academic_year_id
  );
end;
$$;

revoke all on function public.fn_process_student_progression(uuid, jsonb) from public;
grant execute on function public.fn_process_student_progression(uuid, jsonb) to authenticated;

create or replace function public.fn_student_progression_history(p_student_id uuid)
returns table(
  processed_at timestamptz,
  from_year_name text,
  from_class_name text,
  to_year_name text,
  to_class_name text,
  outcome text,
  notes text,
  processed_by_name text
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select st.school_id into v_school_id
  from public.students st where st.id = p_student_id;
  if v_school_id is null then raise exception 'INVALID_STUDENT'; end if;
  if not (
    public.fn_resolve_my_role(v_school_id) in ('admin','director','superadmin')
    or public.fn_has_permission('students.progression.view', v_school_id)
  ) then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select p.processed_at, fy.label, fc.name, ty.label, tc.name,
         p.outcome, p.notes, prof.full_name
  from public.student_academic_progression p
  join public.academic_years fy on fy.id = p.from_academic_year_id
  join public.classes fc on fc.id = p.from_class_id
  join public.academic_years ty on ty.id = p.to_academic_year_id
  join public.classes tc on tc.id = p.to_class_id
  left join public.profiles prof on prof.id = p.processed_by
  where p.student_id = p_student_id and p.school_id = v_school_id
  order by p.processed_at desc;
end;
$$;

revoke all on function public.fn_student_progression_history(uuid) from public;
grant execute on function public.fn_student_progression_history(uuid) to authenticated;
