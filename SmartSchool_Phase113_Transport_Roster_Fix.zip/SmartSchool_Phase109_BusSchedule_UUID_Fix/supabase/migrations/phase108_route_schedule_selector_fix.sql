-- Phase 108: dedicated route source for the daily bus schedule selector
-- Returns every active route belonging to the authenticated user's school.

CREATE OR REPLACE FUNCTION public.fn_list_routes_for_bus_schedule()
RETURNS TABLE (
    route_id uuid,
    route_name text,
    is_active boolean,
    student_count bigint
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
    v_school uuid;
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'NOT_AUTHENTICATED';
    END IF;

    v_school := public.fn_my_primary_school();
    IF v_school IS NULL THEN
        RAISE EXCEPTION 'NO_SCHOOL_CONTEXT';
    END IF;

    IF NOT (
        public.fn_is_school_staff(v_school)
        OR public.fn_has_permission('transport.view', v_school)
        OR public.fn_has_permission('transport.manage', v_school)
    ) THEN
        RAISE EXCEPTION 'PERMISSION_DENIED';
    END IF;

    RETURN QUERY
    SELECT
        r.id,
        r.name::text,
        r.is_active,
        (
            SELECT COUNT(DISTINCT sta.student_id)::bigint
            FROM public.student_transport_assignments sta
            WHERE sta.route_id = r.id
              AND sta.is_active = true
        )
    FROM public.bus_routes r
    WHERE r.school_id = v_school
      AND r.is_active = true
    ORDER BY r.name ASC, r.id ASC;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_list_routes_for_bus_schedule() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_list_routes_for_bus_schedule() TO authenticated;
