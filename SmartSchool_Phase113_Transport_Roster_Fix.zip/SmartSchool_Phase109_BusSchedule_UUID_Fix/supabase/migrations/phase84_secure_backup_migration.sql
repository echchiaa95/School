-- Phase 84: safe same-platform backup restore for Migration Assistant.
-- This replaces the browser-facing restore RPC with an allowlisted,
-- destination-tenant-bound, atomic importer and cross-tenant FK validation.

create or replace function public.fn_import_school_backup_safe(
  p_data jsonb,
  p_school_id uuid default null
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_order text[] := array[
    'academic_years','subjects','classes','students','student_enrollments',
    'school_period_configs','buses','bus_routes','bus_stops','bus_route_stops',
    'student_transport_assignments','timetables','timetable_entries',
    'expense_categories','payments','expenses','school_posts','notifications',
    'attendance_records','student_grades','incidents','guard_checks','staff_attendance',
    'bus_trips','bus_trip_students','bus_trip_locations','bus_last_locations',
    'school_student_number_counters'
  ];
  v_t text;
  v_rows jsonb;
  v_src jsonb;
  v_inserted integer;
  v_results jsonb := '{}'::jsonb;
  v_has_school boolean;
  v_fk record;
  v_cross_tenant boolean;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  if p_school_id is not null and public.fn_is_superadmin() then
    v_school_id := p_school_id;
  elsif p_school_id is not null then
    select ur.school_id into v_school_id from public.user_roles ur
    where ur.profile_id=auth.uid() and ur.school_id=p_school_id
      and ur.role::text in ('admin','director') limit 1;
  else
    select ur.school_id into v_school_id from public.user_roles ur
    where ur.profile_id=auth.uid() and ur.role::text in ('admin','director')
    order by case ur.role::text when 'admin' then 0 else 1 end limit 1;
  end if;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;
  if not exists(select 1 from public.schools where id=v_school_id) then raise exception 'SCHOOL_NOT_FOUND'; end if;
  if p_data is null or jsonb_typeof(p_data)<>'object'
     or coalesce(p_data->>'app','')<>'smart-school'
     or coalesce((p_data->>'backup_version')::integer,0)<>1 then
    raise exception 'INVALID_BACKUP_FILE';
  end if;
  v_src := p_data->'tables';
  if v_src is null or jsonb_typeof(v_src)<>'object' then raise exception 'INVALID_BACKUP_TABLES'; end if;

  -- Each table insert is part of this function's transaction. Any unexpected
  -- schema/FK error aborts the whole restore instead of silently partial-writing.
  foreach v_t in array v_order loop
    v_rows := v_src->v_t;
    if v_rows is null then continue; end if;
    if jsonb_typeof(v_rows)<>'array' then raise exception 'INVALID_TABLE_PAYLOAD: %',v_t; end if;
    if to_regclass('public.'||v_t) is null then continue; end if;
    select exists(select 1 from information_schema.columns
      where table_schema='public' and table_name=v_t and column_name='school_id') into v_has_school;
    if not v_has_school then continue; end if;
    select coalesce(jsonb_agg(r || jsonb_build_object('school_id',v_school_id::text)),'[]'::jsonb)
      into v_rows from jsonb_array_elements(v_rows) r;
    execute format(
      'insert into public.%I select * from jsonb_populate_recordset(null::public.%I,$1) on conflict do nothing',v_t,v_t
    ) using v_rows;
    get diagnostics v_inserted=row_count;
    v_results := v_results || jsonb_build_object(v_t,v_inserted);
  end loop;

  -- Reject any imported row that points to a record owned by another school.
  -- Single-column public FK relationships are checked dynamically from the
  -- PostgreSQL catalog; references to global/auth tables are not rewritten.
  for v_fk in
    select src.relname as src_table, ref.relname as ref_table,
           src_att.attname as src_column, ref_att.attname as ref_column
    from pg_constraint c
    join pg_class src on src.oid=c.conrelid
    join pg_namespace src_ns on src_ns.oid=src.relnamespace
    join pg_class ref on ref.oid=c.confrelid
    join pg_namespace ref_ns on ref_ns.oid=ref.relnamespace
    join unnest(c.conkey) with ordinality src_key(attnum,ord) on true
    join unnest(c.confkey) with ordinality ref_key(attnum,ord) on ref_key.ord=src_key.ord
    join pg_attribute src_att on src_att.attrelid=src.oid and src_att.attnum=src_key.attnum
    join pg_attribute ref_att on ref_att.attrelid=ref.oid and ref_att.attnum=ref_key.attnum
    where c.contype='f' and src_ns.nspname='public' and ref_ns.nspname='public'
      and src.relname=any(v_order) and array_length(c.conkey,1)=1
      and exists(select 1 from information_schema.columns x where x.table_schema='public' and x.table_name=src.relname and x.column_name='school_id')
      and exists(select 1 from information_schema.columns x where x.table_schema='public' and x.table_name=src.relname and x.column_name='id')
      and exists(select 1 from information_schema.columns x where x.table_schema='public' and x.table_name=ref.relname and x.column_name='school_id')
  loop
    execute format(
      'select exists(select 1 from public.%I s join public.%I r on s.%I=r.%I where s.school_id=$1 and r.school_id<>$1 and s.id::text in (select item->>''id'' from jsonb_array_elements($2->%L) as arr(item) where item ? ''id''))',
      v_fk.src_table,v_fk.ref_table,v_fk.src_column,v_fk.ref_column,v_fk.src_table
    ) into v_cross_tenant using v_school_id,v_src;
    if v_cross_tenant then
      raise exception 'CROSS_TENANT_REFERENCE_REJECTED: % -> %',v_fk.src_table,v_fk.ref_table;
    end if;
  end loop;

  perform public.fn_safe_audit(v_school_id,'IMPORT_BACKUP_SAFE','schools',v_school_id,null,
    jsonb_build_object('tables',v_results,'source_school_id',p_data->>'school_id'));
  return jsonb_build_object('ok',true,'school_id',v_school_id,'results',v_results,
    'source_exported_at',p_data->>'exported_at');
end;
$$;

revoke all on function public.fn_import_school_backup_safe(jsonb,uuid) from public;
grant execute on function public.fn_import_school_backup_safe(jsonb,uuid) to authenticated;

-- Exact-school export companion. Prevents an admin linked to multiple schools
-- from accidentally exporting whichever school happens to sort first.
create or replace function public.fn_export_school_backup_safe(p_school_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_tables text[] := array[
    'academic_years','classes','students','student_enrollments',
    'subjects','school_period_configs','timetables','timetable_entries',
    'buses','bus_routes','bus_stops','bus_route_stops','student_transport_assignments',
    'attendance_records','student_grades','payments',
    'expense_categories','expenses','incidents','guard_checks','staff_attendance',
    'notifications','school_posts','bus_trips','bus_trip_students',
    'bus_trip_locations','bus_last_locations','school_student_number_counters'
  ];
  v_t text;
  v_rows jsonb;
  v_data jsonb := '{}'::jsonb;
  v_has_school boolean;
  v_has_deleted boolean;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  if p_school_id is not null then
    v_school_id := p_school_id;
  elsif not public.fn_is_superadmin() then
    v_school_id := public.fn_my_primary_school();
  end if;
  if v_school_id is null or not public.fn_is_school_staff(v_school_id) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if not exists(select 1 from public.schools where id=v_school_id) then raise exception 'SCHOOL_NOT_FOUND'; end if;

  foreach v_t in array v_tables loop
    if to_regclass('public.'||v_t) is null then continue; end if;
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name=v_t and column_name='school_id') into v_has_school;
    if not v_has_school then continue; end if;
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name=v_t and column_name='deleted_at') into v_has_deleted;
    execute format(
      'select coalesce(jsonb_agg(to_jsonb(t)), ''[]''::jsonb) from public.%I t where t.school_id=$1%s',
      v_t,case when v_has_deleted then ' and t.deleted_at is null' else '' end
    ) into v_rows using v_school_id;
    v_data := v_data || jsonb_build_object(v_t,v_rows);
  end loop;

  perform public.fn_safe_audit(v_school_id,'EXPORT_BACKUP_SAFE','schools',v_school_id,null,null);
  return jsonb_build_object('app','smart-school','backup_version',1,'exported_at',now(),
    'school_id',v_school_id,'school',(select to_jsonb(s) from public.schools s where s.id=v_school_id),
    'tables',v_data);
end;
$$;

revoke all on function public.fn_export_school_backup_safe(uuid) from public;
grant execute on function public.fn_export_school_backup_safe(uuid) to authenticated;
