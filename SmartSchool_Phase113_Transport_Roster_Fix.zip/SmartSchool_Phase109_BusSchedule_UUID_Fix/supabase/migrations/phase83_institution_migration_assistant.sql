-- Phase 83: durable, tenant-isolated institution migration tracking.
-- Additive only. Does not import/delete legacy financial, grade, parent or archive data.

create table if not exists public.institution_migration_jobs (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  created_by uuid not null references auth.users(id),
  source_name text not null,
  source_type text not null default 'student_import'
    check (source_type in ('student_import','institution_migration')),
  status text not null default 'CREATED'
    check (status in ('CREATED','RUNNING','COMPLETED','COMPLETED_WITH_ERRORS','CANCELLED','NEEDS_REVIEW')),
  total_rows integer not null default 0 check (total_rows >= 0),
  processed_rows integer not null default 0 check (processed_rows >= 0),
  succeeded_rows integer not null default 0 check (succeeded_rows >= 0),
  failed_rows integer not null default 0 check (failed_rows >= 0),
  skipped_rows integer not null default 0 check (skipped_rows >= 0),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  started_at timestamptz,
  finished_at timestamptz,
  updated_at timestamptz not null default now()
);
create index if not exists idx_institution_migration_jobs_school_created
  on public.institution_migration_jobs(school_id, created_at desc);

create table if not exists public.institution_migration_rows (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.institution_migration_jobs(id) on delete cascade,
  school_id uuid not null references public.schools(id) on delete cascade,
  source_row_number integer not null check (source_row_number > 0),
  row_fingerprint text,
  status text not null default 'PROCESSING'
    check (status in ('PROCESSING','SUCCEEDED','FAILED','SKIPPED','NEEDS_REVIEW')),
  target_student_id uuid references public.students(id) on delete set null,
  error_code text,
  error_message text,
  updated_at timestamptz not null default now(),
  unique(job_id, source_row_number)
);
create index if not exists idx_institution_migration_rows_job_status
  on public.institution_migration_rows(job_id, status);

create table if not exists public.institution_migration_batches (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.institution_migration_jobs(id) on delete cascade,
  school_id uuid not null references public.schools(id) on delete cascade,
  batch_number integer not null check (batch_number > 0),
  attempted_rows integer not null default 0,
  succeeded_rows integer not null default 0,
  failed_rows integer not null default 0,
  skipped_rows integer not null default 0,
  status text not null default 'PROCESSING'
    check (status in ('PROCESSING','COMPLETED','NEEDS_REVIEW')),
  idempotency_key text not null,
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  unique(job_id, batch_number),
  unique(school_id, idempotency_key)
);
create index if not exists idx_institution_migration_batches_job
  on public.institution_migration_batches(job_id, batch_number);

alter table public.institution_migration_jobs enable row level security;
alter table public.institution_migration_rows enable row level security;
alter table public.institution_migration_batches enable row level security;
revoke all on public.institution_migration_jobs from anon, authenticated;
revoke all on public.institution_migration_rows from anon, authenticated;
revoke all on public.institution_migration_batches from anon, authenticated;

create or replace function public.fn_migration_create_job(
  p_school_id uuid, p_source_name text, p_source_type text default 'student_import',
  p_total_rows integer default 0, p_metadata jsonb default '{}'::jsonb
) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  if p_school_id is null or not public.fn_is_school_staff(p_school_id) then raise exception 'PERMISSION_DENIED'; end if;
  if p_source_type not in ('student_import','institution_migration') then raise exception 'INVALID_MIGRATION_SOURCE'; end if;
  if coalesce(p_total_rows,0) < 0 or p_total_rows > 100000 then raise exception 'INVALID_ROW_COUNT'; end if;
  if nullif(btrim(p_source_name),'') is null then raise exception 'SOURCE_NAME_REQUIRED'; end if;
  insert into public.institution_migration_jobs(school_id,created_by,source_name,source_type,total_rows,metadata,started_at)
  values (p_school_id,auth.uid(),left(btrim(p_source_name),255),p_source_type,coalesce(p_total_rows,0),
    case when jsonb_typeof(coalesce(p_metadata,'{}'::jsonb))='object' then coalesce(p_metadata,'{}'::jsonb) else '{}'::jsonb end,now())
  returning id into v_id;
  perform public.fn_safe_audit(p_school_id,'MIGRATION_JOB_CREATED','institution_migration_jobs',v_id,null,
    jsonb_build_object('source_type',p_source_type,'total_rows',p_total_rows));
  return v_id;
end; $$;

create or replace function public.fn_migration_record_batch(
  p_job_id uuid, p_batch_number integer, p_idempotency_key text, p_rows jsonb
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_job public.institution_migration_jobs%rowtype;
  v_row jsonb;
  v_row_number integer;
  v_status text;
  v_batch public.institution_migration_batches%rowtype;
  v_attempted integer := 0;
  v_succeeded integer := 0;
  v_failed integer := 0;
  v_skipped integer := 0;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  if p_batch_number is null or p_batch_number < 1 then raise exception 'INVALID_BATCH_NUMBER'; end if;
  if nullif(btrim(p_idempotency_key),'') is null then raise exception 'IDEMPOTENCY_KEY_REQUIRED'; end if;
  if jsonb_typeof(p_rows) <> 'array' or jsonb_array_length(p_rows) < 1 or jsonb_array_length(p_rows) > 100 then
    raise exception 'INVALID_BATCH_ROWS';
  end if;
  select * into v_job from public.institution_migration_jobs where id=p_job_id for update;
  if not found then raise exception 'MIGRATION_JOB_NOT_FOUND'; end if;
  if not public.fn_is_school_staff(v_job.school_id) then raise exception 'PERMISSION_DENIED'; end if;
  if v_job.status in ('COMPLETED','COMPLETED_WITH_ERRORS','CANCELLED') then raise exception 'MIGRATION_JOB_CLOSED'; end if;

  insert into public.institution_migration_batches(job_id,school_id,batch_number,attempted_rows,status,idempotency_key)
  values(v_job.id,v_job.school_id,p_batch_number,jsonb_array_length(p_rows),'PROCESSING',left(p_idempotency_key,180))
  on conflict(job_id,batch_number) do update set attempted_rows=excluded.attempted_rows
  returning * into v_batch;

  for v_row in select value from jsonb_array_elements(p_rows) loop
    v_row_number := nullif(v_row->>'row_number','')::integer;
    v_status := upper(coalesce(v_row->>'status','PROCESSING'));
    if v_row_number is null or v_row_number < 1 then raise exception 'INVALID_SOURCE_ROW_NUMBER'; end if;
    if v_status not in ('PROCESSING','SUCCEEDED','FAILED','SKIPPED','NEEDS_REVIEW') then raise exception 'INVALID_ROW_STATUS'; end if;
    if nullif(v_row->>'target_student_id','') is not null and not exists (
      select 1 from public.students st where st.id=(v_row->>'target_student_id')::uuid and st.school_id=v_job.school_id
    ) then raise exception 'TARGET_STUDENT_SCHOOL_MISMATCH'; end if;
    insert into public.institution_migration_rows(job_id,school_id,source_row_number,row_fingerprint,status,target_student_id,error_code,error_message,updated_at)
    values(v_job.id,v_job.school_id,v_row_number,nullif(left(coalesce(v_row->>'fingerprint',''),128),''),v_status,
      case when nullif(v_row->>'target_student_id','') is null then null else (v_row->>'target_student_id')::uuid end,
      nullif(left(coalesce(v_row->>'error_code',''),100),''),nullif(left(coalesce(v_row->>'error_message',''),500),''),now())
    on conflict(job_id,source_row_number) do update set
      row_fingerprint=coalesce(excluded.row_fingerprint,institution_migration_rows.row_fingerprint),
      status=case when institution_migration_rows.status='SUCCEEDED' then 'SUCCEEDED' else excluded.status end,
      target_student_id=coalesce(institution_migration_rows.target_student_id,excluded.target_student_id),
      error_code=excluded.error_code,error_message=excluded.error_message,updated_at=now();
  end loop;

  select count(*) filter(where status in ('SUCCEEDED','FAILED','SKIPPED','NEEDS_REVIEW')),
         count(*) filter(where status='SUCCEEDED'),
         count(*) filter(where status in ('FAILED','NEEDS_REVIEW')),
         count(*) filter(where status='SKIPPED')
    into v_attempted,v_succeeded,v_failed,v_skipped
  from public.institution_migration_rows
  where job_id=v_job.id and source_row_number in (select (value->>'row_number')::integer from jsonb_array_elements(p_rows));

  update public.institution_migration_batches set attempted_rows=v_attempted,succeeded_rows=v_succeeded,
    failed_rows=v_failed,skipped_rows=v_skipped,
    status=case when exists(select 1 from public.institution_migration_rows r where r.job_id=v_job.id
      and r.source_row_number in (select (value->>'row_number')::integer from jsonb_array_elements(p_rows))
      and r.status='PROCESSING') then 'PROCESSING' else 'COMPLETED' end,
    completed_at=case when exists(select 1 from public.institution_migration_rows r where r.job_id=v_job.id
      and r.source_row_number in (select (value->>'row_number')::integer from jsonb_array_elements(p_rows))
      and r.status='PROCESSING') then null else now() end
  where id=v_batch.id;

  update public.institution_migration_jobs j set
    processed_rows=(select count(*) from public.institution_migration_rows r where r.job_id=j.id and r.status<>'PROCESSING'),
    succeeded_rows=(select count(*) from public.institution_migration_rows r where r.job_id=j.id and r.status='SUCCEEDED'),
    failed_rows=(select count(*) from public.institution_migration_rows r where r.job_id=j.id and r.status in ('FAILED','NEEDS_REVIEW')),
    skipped_rows=(select count(*) from public.institution_migration_rows r where r.job_id=j.id and r.status='SKIPPED'),
    status='RUNNING',updated_at=now() where j.id=v_job.id;
  return jsonb_build_object('job_id',v_job.id,'batch_number',p_batch_number,'attempted_rows',v_attempted,
    'succeeded_rows',v_succeeded,'failed_rows',v_failed,'skipped_rows',v_skipped);
end; $$;

create or replace function public.fn_migration_finish_job(p_job_id uuid,p_force_review boolean default false)
returns jsonb language plpgsql security definer set search_path=public as $$
declare
  v_job public.institution_migration_jobs%rowtype;
  v_processing integer; v_succeeded integer; v_failed integer; v_skipped integer; v_total integer; v_status text;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select * into v_job from public.institution_migration_jobs where id=p_job_id for update;
  if not found then raise exception 'MIGRATION_JOB_NOT_FOUND'; end if;
  if not public.fn_is_school_staff(v_job.school_id) then raise exception 'PERMISSION_DENIED'; end if;
  if v_job.status in ('COMPLETED','COMPLETED_WITH_ERRORS','CANCELLED') then return jsonb_build_object('job_id',p_job_id,'status',v_job.status); end if;
  if p_force_review then
    update public.institution_migration_rows set status='NEEDS_REVIEW',error_code=coalesce(error_code,'INTERRUPTED'),
      error_message=coalesce(error_message,'انقطعت العملية أثناء معالجة هذا السجل؛ يلزم التحقق قبل إعادة المحاولة.'),updated_at=now()
    where job_id=p_job_id and status='PROCESSING';
  end if;
  select count(*) filter(where status='PROCESSING'),count(*) filter(where status='SUCCEEDED'),
    count(*) filter(where status in ('FAILED','NEEDS_REVIEW')),count(*) filter(where status='SKIPPED'),count(*)
    into v_processing,v_succeeded,v_failed,v_skipped,v_total
  from public.institution_migration_rows where job_id=p_job_id;
  if v_processing>0 or exists(select 1 from public.institution_migration_rows where job_id=p_job_id and status='NEEDS_REVIEW') then
    v_status:='NEEDS_REVIEW';
  elsif v_failed>0 then v_status:='COMPLETED_WITH_ERRORS';
  else v_status:='COMPLETED';
  end if;
  update public.institution_migration_jobs set status=v_status,processed_rows=v_total-v_processing,succeeded_rows=v_succeeded,
    failed_rows=v_failed,skipped_rows=v_skipped,finished_at=now(),updated_at=now() where id=p_job_id;
  perform public.fn_safe_audit(v_job.school_id,'MIGRATION_JOB_FINISHED','institution_migration_jobs',p_job_id,null,
    jsonb_build_object('status',v_status,'succeeded',v_succeeded,'failed',v_failed,'skipped',v_skipped));
  return jsonb_build_object('job_id',p_job_id,'status',v_status,'total_rows',v_job.total_rows,
    'processed_rows',v_total-v_processing,'succeeded_rows',v_succeeded,'failed_rows',v_failed,
    'skipped_rows',v_skipped,'needs_review_rows',v_processing);
end; $$;

create or replace function public.fn_migration_cancel_job(p_job_id uuid)
returns boolean language plpgsql security definer set search_path=public as $$
declare v_job public.institution_migration_jobs%rowtype;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select * into v_job from public.institution_migration_jobs where id=p_job_id for update;
  if not found then raise exception 'MIGRATION_JOB_NOT_FOUND'; end if;
  if not public.fn_is_school_staff(v_job.school_id) then raise exception 'PERMISSION_DENIED'; end if;
  if exists(select 1 from public.institution_migration_rows where job_id=p_job_id and status='SUCCEEDED') then
    raise exception 'ROLLBACK_REQUIRES_REVIEW: imported records are never deleted automatically';
  end if;
  update public.institution_migration_jobs set status='CANCELLED',finished_at=now(),updated_at=now()
    where id=p_job_id and status not in ('COMPLETED','COMPLETED_WITH_ERRORS');
  return true;
end; $$;

create or replace function public.fn_migration_list_jobs(p_school_id uuid,p_limit integer default 20)
returns table(job_id uuid,source_name text,source_type text,status text,total_rows integer,processed_rows integer,
  succeeded_rows integer,failed_rows integer,skipped_rows integer,created_at timestamptz,finished_at timestamptz,created_by uuid)
language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  if p_school_id is null or not public.fn_is_school_staff(p_school_id) then raise exception 'PERMISSION_DENIED'; end if;

  -- Reconcile abandoned in-flight rows when a staff member next opens history.
  -- This is conservative: uncertain rows become NEEDS_REVIEW, never auto-retried.
  update public.institution_migration_rows r
     set status='NEEDS_REVIEW', error_code=coalesce(r.error_code,'INTERRUPTED'),
         error_message=coalesce(r.error_message,'انقطعت العملية أو توقفت الاستجابة؛ يلزم التحقق قبل إعادة المحاولة.'),
         updated_at=now()
   where r.school_id=p_school_id and r.status='PROCESSING'
     and exists(select 1 from public.institution_migration_jobs j
       where j.id=r.job_id and j.status='RUNNING' and j.updated_at < now()-interval '15 minutes');

  update public.institution_migration_jobs j
     set status='NEEDS_REVIEW',
         processed_rows=(select count(*) from public.institution_migration_rows r where r.job_id=j.id and r.status<>'PROCESSING'),
         succeeded_rows=(select count(*) from public.institution_migration_rows r where r.job_id=j.id and r.status='SUCCEEDED'),
         failed_rows=(select count(*) from public.institution_migration_rows r where r.job_id=j.id and r.status in ('FAILED','NEEDS_REVIEW')),
         skipped_rows=(select count(*) from public.institution_migration_rows r where r.job_id=j.id and r.status='SKIPPED'),
         finished_at=coalesce(j.finished_at,now()), updated_at=now()
   where j.school_id=p_school_id and j.status='RUNNING'
     and exists(select 1 from public.institution_migration_rows r where r.job_id=j.id and r.status='NEEDS_REVIEW');

  return query select j.id,j.source_name,j.source_type,j.status,j.total_rows,j.processed_rows,j.succeeded_rows,
    j.failed_rows,j.skipped_rows,j.created_at,j.finished_at,j.created_by from public.institution_migration_jobs j
    where j.school_id=p_school_id order by j.created_at desc limit greatest(1,least(coalesce(p_limit,20),100));
end; $$;

create or replace function public.fn_migration_job_rows(p_job_id uuid)
returns table(source_row_number integer,status text,target_student_id uuid,error_code text,error_message text,updated_at timestamptz)
language plpgsql security definer set search_path=public as $$
declare v_school_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select school_id into v_school_id from public.institution_migration_jobs where id=p_job_id;
  if v_school_id is null then raise exception 'MIGRATION_JOB_NOT_FOUND'; end if;
  if not public.fn_is_school_staff(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;
  return query select r.source_row_number,r.status,r.target_student_id,r.error_code,r.error_message,r.updated_at
    from public.institution_migration_rows r where r.job_id=p_job_id order by r.source_row_number;
end; $$;

revoke all on function public.fn_migration_create_job(uuid,text,text,integer,jsonb) from public;
revoke all on function public.fn_migration_record_batch(uuid,integer,text,jsonb) from public;
revoke all on function public.fn_migration_finish_job(uuid,boolean) from public;
revoke all on function public.fn_migration_cancel_job(uuid) from public;
revoke all on function public.fn_migration_list_jobs(uuid,integer) from public;
revoke all on function public.fn_migration_job_rows(uuid) from public;
grant execute on function public.fn_migration_create_job(uuid,text,text,integer,jsonb) to authenticated;
grant execute on function public.fn_migration_record_batch(uuid,integer,text,jsonb) to authenticated;
grant execute on function public.fn_migration_finish_job(uuid,boolean) to authenticated;
grant execute on function public.fn_migration_cancel_job(uuid) to authenticated;
grant execute on function public.fn_migration_list_jobs(uuid,integer) to authenticated;
grant execute on function public.fn_migration_job_rows(uuid) to authenticated;
