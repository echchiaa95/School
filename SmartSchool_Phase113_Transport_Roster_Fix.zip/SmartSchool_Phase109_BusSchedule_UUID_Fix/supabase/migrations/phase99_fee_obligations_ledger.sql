-- Phase 99: fee obligations ledger. Additive; legacy public.payments remains untouched.
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS uses_transport boolean NOT NULL DEFAULT false;

CREATE TABLE IF NOT EXISTS public.student_fee_obligations (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), school_id uuid NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
 student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
 academic_year_id uuid NOT NULL REFERENCES public.academic_years(id) ON DELETE CASCADE,
 fee_type text NOT NULL CHECK (fee_type IN ('واجب التمدرس','واجب النقل','واجب التسجيل')),
 period_key text NOT NULL, period_start date NOT NULL, period_end date NOT NULL,
 list_amount numeric(12,2) NOT NULL CHECK(list_amount>=0), discount_amount numeric(12,2) NOT NULL DEFAULT 0 CHECK(discount_amount>=0),
 amount_due numeric(12,2) NOT NULL CHECK(amount_due>=0), amount_paid numeric(12,2) NOT NULL DEFAULT 0 CHECK(amount_paid>=0),
 status text NOT NULL DEFAULT 'unpaid' CHECK(status IN ('unpaid','partial','paid','waived')),
 discount_id uuid REFERENCES public.student_fee_discounts(id) ON DELETE SET NULL,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
 CHECK(discount_amount<=list_amount), CHECK(amount_paid<=amount_due),
 UNIQUE(student_id,academic_year_id,fee_type,period_key)
);
CREATE INDEX IF NOT EXISTS idx_fee_obligations_school_year ON public.student_fee_obligations(school_id,academic_year_id,fee_type,status);
CREATE INDEX IF NOT EXISTS idx_fee_obligations_student ON public.student_fee_obligations(student_id,period_start);

CREATE TABLE IF NOT EXISTS public.student_fee_payment_transactions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), school_id uuid NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
 student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
 amount numeric(12,2) NOT NULL CHECK(amount>0), method text, paid_on date NOT NULL DEFAULT CURRENT_DATE,
 receipt_no text, notes text, recorded_by uuid NOT NULL REFERENCES auth.users(id), created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.student_fee_payment_allocations (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), school_id uuid NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
 transaction_id uuid NOT NULL REFERENCES public.student_fee_payment_transactions(id) ON DELETE CASCADE,
 obligation_id uuid NOT NULL REFERENCES public.student_fee_obligations(id) ON DELETE RESTRICT,
 amount numeric(12,2) NOT NULL CHECK(amount>0), created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_fee_tx_school_paid ON public.student_fee_payment_transactions(school_id,paid_on DESC);
CREATE INDEX IF NOT EXISTS idx_fee_alloc_obligation ON public.student_fee_payment_allocations(obligation_id);
ALTER TABLE public.student_fee_obligations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_fee_payment_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_fee_payment_allocations ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.student_fee_obligations,public.student_fee_payment_transactions,public.student_fee_payment_allocations FROM PUBLIC,anon,authenticated;

-- Idempotently generate monthly tuition/transport and annual/lifetime registration dues.
CREATE OR REPLACE FUNCTION public.fn_generate_student_fee_obligations(p_student_id uuid,p_academic_year_id uuid)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_school uuid; v_transport boolean; v_year_start date; v_year_end date; v_enrolled date;
 v_plan record; v_month date; v_start date; v_end date; v_key text; v_disc uuid; v_kind text; v_value numeric; v_discount numeric; v_due numeric; v_count integer:=0;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
 SELECT school_id,uses_transport INTO v_school,v_transport FROM public.students WHERE id=p_student_id AND deleted_at IS NULL;
 IF v_school IS NULL THEN RAISE EXCEPTION 'INVALID_STUDENT'; END IF;
 IF NOT (public.fn_is_school_staff(v_school) OR public.fn_has_permission('finance.manage',v_school) OR public.fn_has_permission('finance.view',v_school)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
 SELECT starts_on,ends_on INTO v_year_start,v_year_end FROM public.academic_years WHERE id=p_academic_year_id AND school_id=v_school;
 IF v_year_start IS NULL OR v_year_end IS NULL THEN RAISE EXCEPTION 'INVALID_ACADEMIC_YEAR'; END IF;
 SELECT min(enrolled_on) INTO v_enrolled FROM public.student_enrollments WHERE student_id=p_student_id AND school_id=v_school AND academic_year_id=p_academic_year_id AND status='ACTIVE';
 IF v_enrolled IS NULL THEN RAISE EXCEPTION 'ACTIVE_ENROLLMENT_REQUIRED'; END IF;
 FOR v_plan IN SELECT * FROM public.school_fee_plans WHERE school_id=v_school AND is_active AND effective_from<=v_year_end AND COALESCE(effective_to,v_year_end)>=GREATEST(v_year_start,v_enrolled) ORDER BY effective_from LOOP
  IF v_plan.fee_type='واجب النقل' AND NOT v_transport THEN CONTINUE; END IF;
  IF v_plan.billing_period='monthly' AND v_plan.fee_type IN ('واجب التمدرس','واجب النقل') THEN
   v_month:=date_trunc('month',GREATEST(v_year_start,v_enrolled))::date;
   WHILE v_month<=v_year_end LOOP
    v_start:=GREATEST(v_month,v_year_start,v_enrolled,v_plan.effective_from);
    v_end:=LEAST((v_month+interval '1 month - 1 day')::date,v_year_end,COALESCE(v_plan.effective_to,v_year_end));
    IF v_start<=v_end THEN
     v_key:=to_char(v_month,'YYYY-MM'); v_disc:=NULL; v_kind:=NULL; v_value:=NULL;
     SELECT id,discount_kind,discount_value INTO v_disc,v_kind,v_value FROM public.student_fee_discounts
      WHERE school_id=v_school AND student_id=p_student_id AND fee_type=v_plan.fee_type AND is_active
       AND effective_from<=v_end AND COALESCE(effective_to,v_end)>=v_start ORDER BY effective_from DESC,created_at DESC LIMIT 1;
     v_discount:=CASE WHEN v_kind='percent' THEN round(v_plan.price*v_value/100,2) WHEN v_kind='amount' THEN least(v_plan.price,v_value) ELSE 0 END;
     v_due:=greatest(0,v_plan.price-v_discount);
     INSERT INTO public.student_fee_obligations(school_id,student_id,academic_year_id,fee_type,period_key,period_start,period_end,list_amount,discount_amount,amount_due,discount_id,status)
      VALUES(v_school,p_student_id,p_academic_year_id,v_plan.fee_type,v_key,v_start,v_end,v_plan.price,v_discount,v_due,v_disc,CASE WHEN v_due=0 THEN 'waived' ELSE 'unpaid' END)
      ON CONFLICT(student_id,academic_year_id,fee_type,period_key) DO NOTHING;
     IF FOUND THEN v_count:=v_count+1; END IF;
    END IF;
    v_month:=(v_month+interval '1 month')::date;
   END LOOP;
  ELSIF v_plan.fee_type='واجب التسجيل' AND v_plan.billing_period IN ('annual','one_time') THEN
   v_key:=CASE WHEN v_plan.billing_period='one_time' THEN 'lifetime' ELSE 'annual' END;
   IF v_key='lifetime' AND EXISTS(SELECT 1 FROM public.student_fee_obligations WHERE student_id=p_student_id AND fee_type='واجب التسجيل' AND period_key='lifetime') THEN CONTINUE; END IF;
   v_disc:=NULL; v_kind:=NULL; v_value:=NULL;
   SELECT id,discount_kind,discount_value INTO v_disc,v_kind,v_value FROM public.student_fee_discounts
    WHERE school_id=v_school AND student_id=p_student_id AND fee_type='واجب التسجيل' AND is_active
     AND effective_from<=v_year_end AND COALESCE(effective_to,v_year_end)>=v_year_start ORDER BY effective_from DESC,created_at DESC LIMIT 1;
   v_discount:=CASE WHEN v_kind='percent' THEN round(v_plan.price*v_value/100,2) WHEN v_kind='amount' THEN least(v_plan.price,v_value) ELSE 0 END;
   v_due:=greatest(0,v_plan.price-v_discount);
   INSERT INTO public.student_fee_obligations(school_id,student_id,academic_year_id,fee_type,period_key,period_start,period_end,list_amount,discount_amount,amount_due,discount_id,status)
    VALUES(v_school,p_student_id,p_academic_year_id,'واجب التسجيل',v_key,v_year_start,v_year_end,v_plan.price,v_discount,v_due,v_disc,CASE WHEN v_due=0 THEN 'waived' ELSE 'unpaid' END)
    ON CONFLICT(student_id,academic_year_id,fee_type,period_key) DO NOTHING;
   IF FOUND THEN v_count:=v_count+1; END IF;
  END IF;
 END LOOP;
 RETURN v_count;
END $$;

CREATE OR REPLACE FUNCTION public.fn_record_fee_obligation_payment(p_obligation_id uuid,p_amount numeric,p_method text DEFAULT NULL,p_paid_on date DEFAULT CURRENT_DATE,p_receipt_no text DEFAULT NULL,p_notes text DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_school uuid; v_student uuid; v_due numeric; v_paid numeric; v_tx uuid;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
 IF p_amount IS NULL OR p_amount<=0 THEN RAISE EXCEPTION 'INVALID_PAYMENT_AMOUNT'; END IF;
 SELECT school_id,student_id,amount_due,amount_paid INTO v_school,v_student,v_due,v_paid FROM public.student_fee_obligations WHERE id=p_obligation_id FOR UPDATE;
 IF v_school IS NULL THEN RAISE EXCEPTION 'OBLIGATION_NOT_FOUND'; END IF;
 IF NOT (public.fn_is_school_staff(v_school) OR public.fn_has_permission('finance.manage',v_school)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
 IF p_amount>v_due-v_paid THEN RAISE EXCEPTION 'PAYMENT_EXCEEDS_REMAINING'; END IF;
 INSERT INTO public.student_fee_payment_transactions(school_id,student_id,amount,method,paid_on,receipt_no,notes,recorded_by)
 VALUES(v_school,v_student,p_amount,NULLIF(btrim(p_method),''),COALESCE(p_paid_on,CURRENT_DATE),NULLIF(btrim(p_receipt_no),''),NULLIF(btrim(p_notes),''),auth.uid()) RETURNING id INTO v_tx;
 INSERT INTO public.student_fee_payment_allocations(school_id,transaction_id,obligation_id,amount) VALUES(v_school,v_tx,p_obligation_id,p_amount);
 UPDATE public.student_fee_obligations SET amount_paid=amount_paid+p_amount,status=CASE WHEN amount_paid+p_amount>=amount_due THEN 'paid' ELSE 'partial' END,updated_at=now() WHERE id=p_obligation_id;
 RETURN v_tx;
END $$;

CREATE OR REPLACE FUNCTION public.fn_report_fee_obligations(p_academic_year_id uuid DEFAULT NULL,p_class_id uuid DEFAULT NULL,p_fee_type text DEFAULT NULL,p_status text DEFAULT NULL,p_from date DEFAULT NULL,p_to date DEFAULT NULL)
RETURNS TABLE(obligation_id uuid,student_id uuid,student_name text,student_number text,class_id uuid,class_name text,fee_type text,period_key text,period_start date,period_end date,list_amount numeric,discount_amount numeric,amount_due numeric,amount_paid numeric,remaining numeric,status text,uses_transport boolean)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public AS $$
DECLARE v_school uuid;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
 v_school:=public.fn_my_primary_school();
 IF v_school IS NULL OR NOT(public.fn_is_school_staff(v_school) OR public.fn_has_permission('finance.view',v_school) OR public.fn_has_permission('reports.view',v_school)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
 RETURN QUERY SELECT o.id,o.student_id,st.full_name,st.student_number,en.class_id,COALESCE(c.name,'بدون قسم'),o.fee_type,o.period_key,o.period_start,o.period_end,o.list_amount,o.discount_amount,o.amount_due,o.amount_paid,greatest(0,o.amount_due-o.amount_paid),o.status,st.uses_transport
 FROM public.student_fee_obligations o JOIN public.students st ON st.id=o.student_id
 LEFT JOIN LATERAL(SELECT se.class_id FROM public.student_enrollments se WHERE se.student_id=st.id AND se.academic_year_id=o.academic_year_id AND se.school_id=v_school ORDER BY se.created_at DESC LIMIT 1) en ON true
 LEFT JOIN public.classes c ON c.id=en.class_id
 WHERE o.school_id=v_school AND (p_academic_year_id IS NULL OR o.academic_year_id=p_academic_year_id) AND (p_class_id IS NULL OR en.class_id=p_class_id)
 AND (p_fee_type IS NULL OR o.fee_type=p_fee_type) AND (p_status IS NULL OR o.status=p_status) AND (p_from IS NULL OR o.period_start>=p_from) AND (p_to IS NULL OR o.period_start<=p_to)
 ORDER BY o.period_start DESC,st.full_name;
END $$;

REVOKE ALL ON FUNCTION public.fn_generate_student_fee_obligations(uuid,uuid) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.fn_record_fee_obligation_payment(uuid,numeric,text,date,text,text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.fn_report_fee_obligations(uuid,uuid,text,text,date,date) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_generate_student_fee_obligations(uuid,uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_record_fee_obligation_payment(uuid,numeric,text,date,text,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_report_fee_obligations(uuid,uuid,text,text,date,date) TO authenticated;

-- Persist the initial transport choice before generating dues for this student.
CREATE OR REPLACE FUNCTION public.fn_set_student_transport_and_generate(p_student_id uuid,p_uses_transport boolean,p_academic_year_id uuid)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_school uuid; v_role text; v_created integer;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
 SELECT school_id INTO v_school FROM public.students WHERE id=p_student_id AND deleted_at IS NULL;
 IF v_school IS NULL THEN RAISE EXCEPTION 'INVALID_STUDENT'; END IF;
 v_role:=public.fn_resolve_my_role(v_school);
 IF NOT (v_role IN ('admin','director') OR public.fn_has_permission('students.create',v_school)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
 UPDATE public.students SET uses_transport=COALESCE(p_uses_transport,false) WHERE id=p_student_id AND school_id=v_school;
 v_created:=public.fn_generate_student_fee_obligations(p_student_id,p_academic_year_id);
 RETURN v_created;
END $$;
REVOKE ALL ON FUNCTION public.fn_set_student_transport_and_generate(uuid,boolean,uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_set_student_transport_and_generate(uuid,boolean,uuid) TO authenticated;
