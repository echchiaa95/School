-- Phase 85: financial fee plans, delegated discounts and audited corrections.
-- Additive extension of the legacy payments table; no parallel ledger and no
-- change to its existing UNIQUE(student_id, month, year) constraint.

create table if not exists public.school_fee_plans (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  fee_type text not null check (fee_type in ('واجب التمدرس','واجب النقل','واجب التسجيل')),
  price numeric(12,2) not null check (price >= 0),
  billing_period text not null default 'monthly'
    check (billing_period in ('monthly','annual','one_time')),
  effective_from date not null default current_date,
  effective_to date,
  is_active boolean not null default true,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (effective_to is null or effective_to >= effective_from)
);
create index if not exists idx_school_fee_plans_lookup
  on public.school_fee_plans(school_id, fee_type, is_active, effective_from desc);

create table if not exists public.student_fee_discounts (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  fee_type text not null check (fee_type in ('واجب التمدرس','واجب النقل','واجب التسجيل')),
  discount_kind text not null check (discount_kind in ('amount','percent')),
  discount_value numeric(12,2) not null check (discount_value > 0),
  reason text not null,
  effective_from date not null default current_date,
  effective_to date,
  is_active boolean not null default true,
  created_by uuid not null references auth.users(id),
  authorized_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  check (effective_to is null or effective_to >= effective_from),
  check (discount_kind <> 'percent' or discount_value <= 100)
);
create index if not exists idx_student_fee_discounts_active
  on public.student_fee_discounts(school_id, student_id, fee_type, is_active, effective_from desc);

create table if not exists public.financial_transaction_audit (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  payment_id uuid not null references public.payments(id) on delete cascade,
  actor_id uuid not null references auth.users(id),
  action text not null check (action in ('CORRECT_PAYMENT','CANCEL_PAYMENT')),
  reason text not null,
  old_values jsonb not null,
  new_values jsonb not null,
  created_at timestamptz not null default now()
);
create index if not exists idx_financial_transaction_audit_payment
  on public.financial_transaction_audit(school_id, payment_id, created_at desc);

alter table public.school_fee_plans enable row level security;
alter table public.student_fee_discounts enable row level security;
alter table public.financial_transaction_audit enable row level security;
revoke all on public.school_fee_plans from anon, authenticated;
revoke all on public.student_fee_discounts from anon, authenticated;
revoke all on public.financial_transaction_audit from anon, authenticated;

create or replace function public.fn_school_fee_plans()
returns table(id uuid, fee_type text, price numeric, billing_period text,
              effective_from date, effective_to date, is_active boolean)
language plpgsql stable security definer set search_path=public
as $$
declare v_school uuid;
begin
  v_school := public.fn_my_primary_school();
  if v_school is null then raise exception 'NO_SCHOOL_CONTEXT'; end if;
  if not (public.fn_is_school_staff(v_school) or public.fn_has_permission('finance.view',v_school)) then
    raise exception 'PERMISSION_DENIED';
  end if;
  return query
    select p.id,p.fee_type,p.price,p.billing_period,p.effective_from,p.effective_to,p.is_active
    from public.school_fee_plans p
    where p.school_id=v_school
    order by p.fee_type,p.effective_from desc;
end $$;

create or replace function public.fn_school_fee_plan_upsert(
  p_fee_type text, p_price numeric, p_billing_period text default 'monthly',
  p_effective_from date default current_date, p_effective_to date default null,
  p_is_active boolean default true
) returns uuid
language plpgsql security definer set search_path=public
as $$
declare v_school uuid; v_id uuid;
begin
  v_school := public.fn_my_primary_school();
  if v_school is null then raise exception 'NO_SCHOOL_CONTEXT'; end if;
  if not (public.fn_is_school_staff(v_school) or public.fn_has_permission('finance.manage',v_school)) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if p_fee_type not in ('واجب التمدرس','واجب النقل','واجب التسجيل') then raise exception 'INVALID_FEE_TYPE'; end if;
  if p_price is null or p_price < 0 then raise exception 'INVALID_FEE_PRICE'; end if;
  if p_billing_period not in ('monthly','annual','one_time') then raise exception 'INVALID_BILLING_PERIOD'; end if;
  if p_effective_to is not null and p_effective_to < p_effective_from then raise exception 'INVALID_EFFECTIVE_PERIOD'; end if;

  -- Close any currently active overlapping plan for this fee type; preserve history.
  update public.school_fee_plans
     set is_active=false, updated_at=now()
   where school_id=v_school and fee_type=p_fee_type and is_active=true
     and effective_from <= coalesce(p_effective_from,current_date)
     and (effective_to is null or effective_to >= coalesce(p_effective_from,current_date));

  insert into public.school_fee_plans(
    school_id,fee_type,price,billing_period,effective_from,effective_to,is_active,created_by
  ) values (
    v_school,p_fee_type,p_price,p_billing_period,coalesce(p_effective_from,current_date),p_effective_to,p_is_active,auth.uid()
  ) returning id into v_id;

  perform public.fn_safe_audit(v_school,'FEE_PLAN_CREATED','school_fee_plans',v_id,null,
    jsonb_build_object('fee_type',p_fee_type,'price',p_price,'billing_period',p_billing_period));
  return v_id;
end $$;

create or replace function public.fn_student_fee_quote(
  p_student_id uuid, p_fee_type text, p_on_date date default current_date
) returns table(list_price numeric, discount_amount numeric, final_amount numeric,
                discount_reason text, billing_period text)
language plpgsql stable security definer set search_path=public
as $$
declare v_school uuid; v_price numeric; v_period text; v_discount numeric:=0; v_reason text;
declare v_kind text; v_value numeric;
begin
  select s.school_id into v_school from public.students s where s.id=p_student_id;
  if v_school is null then raise exception 'INVALID_STUDENT'; end if;
  if not (public.fn_is_school_staff(v_school) or public.fn_has_permission('finance.view',v_school)) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if p_fee_type not in ('واجب التمدرس','واجب النقل','واجب التسجيل') then raise exception 'INVALID_FEE_TYPE'; end if;

  select p.price,p.billing_period into v_price,v_period
  from public.school_fee_plans p
  where p.school_id=v_school and p.fee_type=p_fee_type and p.is_active
    and p.effective_from <= coalesce(p_on_date,current_date)
    and (p.effective_to is null or p.effective_to >= coalesce(p_on_date,current_date))
  order by p.effective_from desc limit 1;

  if v_price is null then
    return query select 0::numeric,0::numeric,0::numeric,null::text,'monthly'::text;
    return;
  end if;

  select d.discount_kind,d.discount_value,d.reason into v_kind,v_value,v_reason
  from public.student_fee_discounts d
  where d.school_id=v_school and d.student_id=p_student_id
    and d.fee_type=p_fee_type and d.is_active
    and d.effective_from <= coalesce(p_on_date,current_date)
    and (d.effective_to is null or d.effective_to >= coalesce(p_on_date,current_date))
  order by d.created_at desc limit 1;

  if v_kind='amount' then v_discount:=least(v_price,v_value);
  elsif v_kind='percent' then v_discount:=round(v_price * v_value / 100,2);
  end if;
  return query select v_price,v_discount,greatest(0,v_price-v_discount),v_reason,coalesce(v_period,'monthly');
end $$;

create or replace function public.fn_student_fee_discount_create(
  p_student_id uuid,p_fee_type text,p_discount_kind text,p_discount_value numeric,
  p_reason text,p_effective_from date default current_date,p_effective_to date default null
) returns uuid
language plpgsql security definer set search_path=public
as $$
declare v_school uuid; v_id uuid;
begin
  select school_id into v_school from public.students where id=p_student_id;
  if v_school is null then raise exception 'INVALID_STUDENT'; end if;
  -- Director/admin by default; a guard can receive the explicit finance.discount permission.
  if not (public.fn_is_school_staff(v_school) or public.fn_has_permission('finance.discount',v_school)) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if p_fee_type not in ('واجب التمدرس','واجب النقل','واجب التسجيل') then raise exception 'INVALID_FEE_TYPE'; end if;
  if p_discount_kind not in ('amount','percent') or p_discount_value is null or p_discount_value <= 0 then
    raise exception 'INVALID_DISCOUNT';
  end if;
  if p_discount_kind='percent' and p_discount_value>100 then raise exception 'INVALID_DISCOUNT_PERCENT'; end if;
  if nullif(btrim(p_reason),'') is null then raise exception 'DISCOUNT_REASON_REQUIRED'; end if;
  if p_effective_to is not null and p_effective_to<p_effective_from then raise exception 'INVALID_EFFECTIVE_PERIOD'; end if;

  update public.student_fee_discounts
     set is_active=false
   where school_id=v_school and student_id=p_student_id and fee_type=p_fee_type
     and is_active=true
     and effective_from <= coalesce(p_effective_from,current_date)
     and (effective_to is null or effective_to >= coalesce(p_effective_from,current_date));

  insert into public.student_fee_discounts(
    school_id,student_id,fee_type,discount_kind,discount_value,reason,
    effective_from,effective_to,created_by,authorized_by
  ) values (
    v_school,p_student_id,p_fee_type,p_discount_kind,p_discount_value,left(btrim(p_reason),500),
    coalesce(p_effective_from,current_date),p_effective_to,auth.uid(),auth.uid()
  ) returning id into v_id;
  perform public.fn_safe_audit(v_school,'STUDENT_FEE_DISCOUNT_CREATED','student_fee_discounts',v_id,null,
    jsonb_build_object('student_id',p_student_id,'fee_type',p_fee_type,'kind',p_discount_kind,
                       'value',p_discount_value,'reason',left(btrim(p_reason),500)));
  return v_id;
end $$;

create or replace function public.fn_payment_correct(
  p_payment_id uuid,p_amount_due numeric,p_amount_paid numeric,p_method text,
  p_reason text
) returns boolean
language plpgsql security definer set search_path=public
as $$
declare v_school uuid; v_old public.payments%rowtype; v_status public.payment_status;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select p.* into v_old
  from public.payments p
  join public.students s on s.id=p.student_id
  where p.id=p_payment_id
  for update of p;
  if not found then raise exception 'PAYMENT_NOT_FOUND'; end if;
  select school_id into v_school from public.students where id=v_old.student_id;
  if not (public.fn_is_school_staff(v_school) or public.fn_has_permission('finance.adjust',v_school)) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if p_amount_due is null or p_amount_due<0 or p_amount_paid is null or p_amount_paid<0 then
    raise exception 'INVALID_PAYMENT_AMOUNT';
  end if;
  if nullif(btrim(p_reason),'') is null then raise exception 'CORRECTION_REASON_REQUIRED'; end if;

  v_status:=case when p_amount_due>0 and p_amount_paid>=p_amount_due then 'PAID'::public.payment_status
                 when p_amount_paid>0 then 'PARTIAL'::public.payment_status
                 else 'UNPAID'::public.payment_status end;

  update public.payments set amount_due=p_amount_due,amount_paid=p_amount_paid,status=v_status,
    method=coalesce(nullif(btrim(coalesce(p_method,'')),''),method)
  where id=p_payment_id;

  insert into public.financial_transaction_audit(
    school_id,payment_id,actor_id,action,reason,old_values,new_values
  ) values (
    v_school,p_payment_id,auth.uid(),'CORRECT_PAYMENT',left(btrim(p_reason),500),
    jsonb_build_object('amount_due',v_old.amount_due,'amount_paid',v_old.amount_paid,
      'method',v_old.method,'status',v_old.status::text,'recorded_by',v_old.recorded_by),
    jsonb_build_object('amount_due',p_amount_due,'amount_paid',p_amount_paid,
      'method',coalesce(nullif(btrim(coalesce(p_method,'')),''),v_old.method),
      'status',v_status::text,'recorded_by',v_old.recorded_by)
  );
  perform public.fn_safe_audit(v_school,'CORRECT_PAYMENT','payments',p_payment_id,
    jsonb_build_object('amount_due',v_old.amount_due,'amount_paid',v_old.amount_paid),
    jsonb_build_object('amount_due',p_amount_due,'amount_paid',p_amount_paid,'reason',left(btrim(p_reason),500)));
  return true;
end $$;

create or replace function public.fn_payment_audit_history(p_payment_id uuid)
returns table(actor_id uuid,actor_email text,action text,reason text,old_values jsonb,new_values jsonb,created_at timestamptz)
language plpgsql stable security definer set search_path=public
as $$
declare v_school uuid;
begin
  select s.school_id into v_school from public.payments p join public.students s on s.id=p.student_id
  where p.id=p_payment_id;
  if v_school is null then raise exception 'PAYMENT_NOT_FOUND'; end if;
  if not (public.fn_is_school_staff(v_school) or public.fn_has_permission('finance.view',v_school)) then
    raise exception 'PERMISSION_DENIED';
  end if;
  return query select a.actor_id,coalesce(u.email,'حساب غير متاح')::text,
                      a.action,a.reason,a.old_values,a.new_values,a.created_at
  from public.financial_transaction_audit a
  left join auth.users u on u.id=a.actor_id
  where a.payment_id=p_payment_id and a.school_id=v_school
  order by a.created_at desc;
end $$;

insert into public.permissions(permission_key,module,name,description)
values
 ('finance.discount','finance','اعتماد الخصومات','السماح باعتماد خصومات التلاميذ مع تسجيل السبب والمنفذ'),
 ('finance.adjust','finance','تصحيح الأداءات','السماح بتصحيح الأداءات مع حفظ القيم السابقة واللاحقة وسبب التعديل')
on conflict (permission_key) do nothing;

revoke all on function public.fn_school_fee_plans() from public;
revoke all on function public.fn_school_fee_plan_upsert(text,numeric,text,date,date,boolean) from public;
revoke all on function public.fn_student_fee_quote(uuid,text,date) from public;
revoke all on function public.fn_student_fee_discount_create(uuid,text,text,numeric,text,date,date) from public;
revoke all on function public.fn_payment_correct(uuid,numeric,numeric,text,text) from public;
revoke all on function public.fn_payment_audit_history(uuid) from public;
grant execute on function public.fn_school_fee_plans() to authenticated;
grant execute on function public.fn_school_fee_plan_upsert(text,numeric,text,date,date,boolean) to authenticated;
grant execute on function public.fn_student_fee_quote(uuid,text,date) to authenticated;
grant execute on function public.fn_student_fee_discount_create(uuid,text,text,numeric,text,date,date) to authenticated;
grant execute on function public.fn_payment_correct(uuid,numeric,numeric,text,text) to authenticated;
grant execute on function public.fn_payment_audit_history(uuid) to authenticated;
