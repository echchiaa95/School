-- Phase 100: one receipt can settle several selected monthly/annual obligations.
-- Additive to Phase 99. Keeps legacy payments untouched.

CREATE OR REPLACE FUNCTION public.fn_list_student_fee_obligations(p_student_id uuid)
RETURNS TABLE(
  obligation_id uuid, fee_type text, period_key text, period_start date,
  list_amount numeric, discount_amount numeric, amount_due numeric,
  amount_paid numeric, remaining numeric, status text
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_school uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  SELECT school_id INTO v_school FROM public.students
  WHERE id=p_student_id AND deleted_at IS NULL;
  IF v_school IS NULL THEN RAISE EXCEPTION 'STUDENT_NOT_FOUND'; END IF;
  IF NOT (public.fn_is_school_staff(v_school)
      OR public.fn_has_permission('finance.view',v_school)
      OR public.fn_has_permission('finance.manage',v_school)) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;
  RETURN QUERY
  SELECT o.id,o.fee_type,o.period_key,o.period_start,o.list_amount,
         o.discount_amount,o.amount_due,o.amount_paid,
         GREATEST(0,o.amount_due-o.amount_paid),o.status
  FROM public.student_fee_obligations o
  WHERE o.student_id=p_student_id AND o.school_id=v_school
  ORDER BY o.period_start DESC,o.fee_type;
END;
$$;

CREATE OR REPLACE FUNCTION public.fn_record_fee_payment_batch(
  p_student_id uuid,
  p_allocations jsonb,
  p_method text DEFAULT NULL,
  p_paid_on date DEFAULT CURRENT_DATE,
  p_receipt_no text DEFAULT NULL,
  p_notes text DEFAULT NULL
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public
AS $$
DECLARE
  v_school uuid;
  v_tx uuid;
  v_item jsonb;
  v_obligation uuid;
  v_amount numeric(12,2);
  v_due numeric(12,2);
  v_paid numeric(12,2);
  v_total numeric(12,2):=0;
  v_student uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  IF jsonb_typeof(p_allocations) <> 'array' OR jsonb_array_length(p_allocations)=0 THEN
    RAISE EXCEPTION 'SELECT_AT_LEAST_ONE_DUE';
  END IF;
  IF (SELECT count(*) FROM jsonb_array_elements(p_allocations)) <>
     (SELECT count(DISTINCT value->>'obligation_id') FROM jsonb_array_elements(p_allocations)) THEN
    RAISE EXCEPTION 'DUPLICATE_OBLIGATION_ALLOCATION';
  END IF;
  SELECT school_id INTO v_school FROM public.students
  WHERE id=p_student_id AND deleted_at IS NULL;
  IF v_school IS NULL THEN RAISE EXCEPTION 'STUDENT_NOT_FOUND'; END IF;
  IF NOT (public.fn_is_school_staff(v_school) OR public.fn_has_permission('finance.manage',v_school)) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  -- Lock all selected obligations before validating and allocating.
  FOR v_item IN SELECT value FROM jsonb_array_elements(p_allocations)
  LOOP
    v_obligation := (v_item->>'obligation_id')::uuid;
    v_amount := (v_item->>'amount')::numeric;
    IF v_amount IS NULL OR v_amount <= 0 THEN RAISE EXCEPTION 'INVALID_ALLOCATION_AMOUNT'; END IF;
    SELECT o.student_id,o.amount_due,o.amount_paid
      INTO v_student,v_due,v_paid
    FROM public.student_fee_obligations o
    WHERE o.id=v_obligation AND o.school_id=v_school
    FOR UPDATE;
    IF v_student IS DISTINCT FROM p_student_id THEN RAISE EXCEPTION 'OBLIGATION_STUDENT_MISMATCH'; END IF;
    IF v_amount > (v_due-v_paid) THEN RAISE EXCEPTION 'PAYMENT_EXCEEDS_REMAINING'; END IF;
    v_total:=v_total+v_amount;
  END LOOP;

  INSERT INTO public.student_fee_payment_transactions(
    school_id,student_id,amount,method,paid_on,receipt_no,notes,recorded_by
  ) VALUES (
    v_school,p_student_id,v_total,NULLIF(BTRIM(p_method),''),COALESCE(p_paid_on,CURRENT_DATE),
    NULLIF(BTRIM(p_receipt_no),''),NULLIF(BTRIM(p_notes),''),auth.uid()
  ) RETURNING id INTO v_tx;

  FOR v_item IN SELECT value FROM jsonb_array_elements(p_allocations)
  LOOP
    v_obligation := (v_item->>'obligation_id')::uuid;
    v_amount := (v_item->>'amount')::numeric;
    INSERT INTO public.student_fee_payment_allocations(school_id,transaction_id,obligation_id,amount)
    VALUES (v_school,v_tx,v_obligation,v_amount);
    UPDATE public.student_fee_obligations
    SET amount_paid=amount_paid+v_amount,
        status=CASE WHEN amount_paid+v_amount >= amount_due THEN 'paid' ELSE 'partial' END,
        updated_at=now()
    WHERE id=v_obligation;
  END LOOP;
  RETURN v_tx;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_list_student_fee_obligations(uuid) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.fn_record_fee_payment_batch(uuid,jsonb,text,date,text,text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_list_student_fee_obligations(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_record_fee_payment_batch(uuid,jsonb,text,date,text,text) TO authenticated;
