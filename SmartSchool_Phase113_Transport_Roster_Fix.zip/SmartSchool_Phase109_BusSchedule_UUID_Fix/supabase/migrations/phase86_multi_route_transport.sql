-- Phase 86: scheduled multi-run transport routes and route-specific parent notices.
-- Existing buses/routes/trips/events remain the canonical records.

create table if not exists public.bus_route_runs (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  bus_id uuid not null references public.buses(id) on delete cascade,
  route_id uuid not null references public.bus_routes(id) on delete restrict,
  run_name text not null,
  sequence_no integer not null check (sequence_no between 1 and 99),
  weekday smallint not null check (weekday between 0 and 6), -- PostgreSQL DOW: Sunday=0
  direction public.trip_direction not null,
  scheduled_start time not null,
  is_active boolean not null default true,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (length(trim(run_name)) > 0)
);
create unique index if not exists uq_bus_route_run_slot
  on public.bus_route_runs(school_id,bus_id,weekday,sequence_no,direction)
  where is_active=true;
create index if not exists idx_bus_route_runs_driver_day
  on public.bus_route_runs(bus_id,weekday,is_active,scheduled_start);

alter table public.bus_trips
  add column if not exists route_run_id uuid references public.bus_route_runs(id) on delete set null;
create index if not exists idx_bus_trips_route_run on public.bus_trips(route_run_id,starts_at desc);
alter table public.bus_route_runs enable row level security;
revoke all on public.bus_route_runs from anon,authenticated;

create or replace function public.fn_create_bus_route_run(
  p_bus_id uuid,p_route_id uuid,p_run_name text,p_sequence_no integer,
  p_weekday integer,p_direction text,p_scheduled_start time
) returns uuid
language plpgsql security definer set search_path=public
as $$
declare v_school uuid; v_id uuid; v_direction public.trip_direction;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select school_id into v_school from public.buses where id=p_bus_id and is_active;
  if v_school is null then raise exception 'INVALID_BUS'; end if;
  if not (public.fn_is_school_staff(v_school) or public.fn_has_permission('transport.manage',v_school)) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if not exists(select 1 from public.bus_routes where id=p_route_id and school_id=v_school and is_active) then
    raise exception 'INVALID_ROUTE';
  end if;
  if p_sequence_no is null or p_sequence_no<1 or p_sequence_no>99 then raise exception 'INVALID_RUN_SEQUENCE'; end if;
  if p_weekday is null or p_weekday<0 or p_weekday>6 then raise exception 'INVALID_WEEKDAY'; end if;
  if nullif(btrim(p_run_name),'') is null then raise exception 'RUN_NAME_REQUIRED'; end if;
  v_direction:=case lower(coalesce(p_direction,'pickup'))
    when 'pickup' then 'TO_SCHOOL'::public.trip_direction
    when 'to_school' then 'TO_SCHOOL'::public.trip_direction
    when 'dropoff' then 'TO_HOME'::public.trip_direction
    when 'to_home' then 'TO_HOME'::public.trip_direction
    else null end;
  if v_direction is null then raise exception 'INVALID_DIRECTION'; end if;
  if p_scheduled_start is null then raise exception 'SCHEDULED_TIME_REQUIRED'; end if;

  insert into public.bus_route_runs(
    school_id,bus_id,route_id,run_name,sequence_no,weekday,direction,scheduled_start,created_by
  ) values (
    v_school,p_bus_id,p_route_id,left(btrim(p_run_name),100),p_sequence_no,p_weekday,
    v_direction,p_scheduled_start,auth.uid()
  ) returning id into v_id;

  perform public.fn_safe_audit(v_school,'CREATE_BUS_ROUTE_RUN','bus_route_runs',v_id,null,
    jsonb_build_object('bus_id',p_bus_id,'route_id',p_route_id,'sequence_no',p_sequence_no,
      'weekday',p_weekday,'direction',v_direction::text,'scheduled_start',p_scheduled_start));
  return v_id;
end $$;

create or replace function public.fn_list_school_bus_route_runs()
returns table(run_id uuid,bus_id uuid,bus_label text,route_id uuid,route_name text,
  run_name text,sequence_no integer,weekday integer,direction text,scheduled_start time,is_active boolean)
language plpgsql stable security definer set search_path=public
as $$
declare v_school uuid;
begin
  v_school:=public.fn_my_primary_school();
  if v_school is null then raise exception 'NO_SCHOOL_CONTEXT'; end if;
  if not (public.fn_is_school_staff(v_school) or public.fn_has_permission('transport.view',v_school)
          or public.fn_has_permission('transport.manage',v_school)) then raise exception 'PERMISSION_DENIED'; end if;
  return query
    select rr.id,rr.bus_id,coalesce(b.code,b.plate_number),rr.route_id,r.name,
      rr.run_name,rr.sequence_no,rr.weekday,
      case when rr.direction='TO_SCHOOL'::public.trip_direction then 'pickup' else 'dropoff' end,
      rr.scheduled_start,rr.is_active
    from public.bus_route_runs rr
    join public.buses b on b.id=rr.bus_id
    join public.bus_routes r on r.id=rr.route_id
    where rr.school_id=v_school
    order by rr.weekday,rr.scheduled_start,rr.sequence_no;
end $$;

create or replace function public.fn_list_driver_bus_route_runs()
returns table(run_id uuid,route_id uuid,route_name text,run_name text,sequence_no integer,
  direction text,scheduled_start time,weekday integer)
language plpgsql stable security definer set search_path=public
as $$
declare v_driver uuid; v_bus uuid; v_dow integer;
begin
  select d.id into v_driver from public.drivers d
  where d.profile_id=auth.uid() and d.deleted_at is null limit 1;
  if v_driver is null then raise exception 'NOT_A_DRIVER'; end if;
  select b.id into v_bus from public.buses b where b.driver_id=v_driver and b.is_active limit 1;
  if v_bus is null then raise exception 'NO_BUS_ASSIGNED'; end if;
  v_dow:=extract(dow from current_date)::integer;
  return query
    select rr.id,rr.route_id,r.name,rr.run_name,rr.sequence_no,
      case when rr.direction='TO_SCHOOL'::public.trip_direction then 'pickup' else 'dropoff' end,
      rr.scheduled_start,rr.weekday
    from public.bus_route_runs rr
    join public.bus_routes r on r.id=rr.route_id
    where rr.bus_id=v_bus and rr.weekday=v_dow and rr.is_active
    order by rr.scheduled_start,rr.sequence_no;
end $$;

create or replace function public.fn_start_scheduled_trip(p_run_id uuid)
returns uuid
language plpgsql security definer set search_path=public
as $$
declare v_driver uuid; v_school uuid; v_bus uuid; v_run public.bus_route_runs%rowtype; v_trip uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select d.id,d.school_id into v_driver,v_school from public.drivers d
  where d.profile_id=auth.uid() and d.deleted_at is null limit 1;
  if v_driver is null then raise exception 'NOT_A_DRIVER'; end if;

  select rr.* into v_run
  from public.bus_route_runs rr
  join public.buses b on b.id=rr.bus_id
  where rr.id=p_run_id and rr.school_id=v_school and rr.is_active
    and b.driver_id=v_driver and b.is_active
  for update of rr;
  if not found then raise exception 'INVALID_SCHEDULED_RUN'; end if;
  if v_run.weekday <> extract(dow from current_date)::integer then raise exception 'RUN_NOT_SCHEDULED_TODAY'; end if;

  update public.bus_trips set status='COMPLETED'::public.trip_status,ends_at=now()
  where driver_id=v_driver and status='ACTIVE'::public.trip_status;

  insert into public.bus_trips(school_id,bus_id,driver_id,route_id,route_run_id,direction,status,starts_at)
  values(v_school,v_run.bus_id,v_driver,v_run.route_id,v_run.id,v_run.direction,'ACTIVE'::public.trip_status,now())
  returning id into v_trip;

  perform public.fn_safe_audit(v_school,'START_SCHEDULED_BUS_TRIP','bus_trips',v_trip,null,
    jsonb_build_object('route_run_id',v_run.id,'route_id',v_run.route_id,'sequence_no',v_run.sequence_no));
  begin
    perform public.fn_notify_trip_started(v_trip);
  exception when others then
    raise notice 'Trip notification skipped: %',sqlerrm;
  end;
  return v_trip;
end $$;

-- Replace the generic departure notice with a route-aware, route-scoped notice.
create or replace function public.fn_notify_trip_started(p_trip_id uuid)
returns void
language plpgsql security definer set search_path=public
as $$
declare
  v_school uuid; v_bus uuid; v_route uuid; v_direction public.trip_direction;
  v_bus_label text; v_route_label text; v_run_label text; v_run_sequence integer; v_title text; v_body text; v_notif uuid;
begin
  select t.school_id,t.bus_id,t.route_id,t.direction,
    coalesce(b.code,b.plate_number,'الحافلة'),r.name,rr.run_name,rr.sequence_no
  into v_school,v_bus,v_route,v_direction,v_bus_label,v_route_label,v_run_label,v_run_sequence
  from public.bus_trips t
  join public.buses b on b.id=t.bus_id
  left join public.bus_routes r on r.id=t.route_id
  left join public.bus_route_runs rr on rr.id=t.route_run_id
  where t.id=p_trip_id;

  if v_school is null then return; end if;
  if not exists (
    select 1 from public.bus_trips t
    join public.drivers d on d.id=t.driver_id
    where t.id=p_trip_id
      and (d.profile_id=auth.uid()
           or public.fn_is_school_staff(t.school_id)
           or public.fn_has_permission('transport.manage',t.school_id))
  ) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if v_run_sequence is not null then
    v_run_label:=coalesce(v_run_label,'الرحلة')||' (المسار رقم '||v_run_sequence||')';
  else
    v_run_label:=coalesce(v_run_label,'المسار');
  end if;
  if v_direction='TO_SCHOOL'::public.trip_direction then
    v_title:='🚌 انطلاق الحافلة — '||coalesce(v_run_label,'');
    v_body:='انطلقت حافلة '||v_bus_label||' في '||v_run_label||
      case when v_route_label is not null then ' ('||v_route_label||')' else '' end||
      ' باتجاه المؤسسة. الرجاء الاستعداد عند نقطة الركوب.';
  else
    v_title:='🚌 رحلة العودة — '||coalesce(v_run_label,'');
    v_body:='انطلقت حافلة '||v_bus_label||' في '||v_run_label||
      case when v_route_label is not null then ' ('||v_route_label||')' else '' end||
      ' لإرجاع التلاميذ إلى منازلهم.';
  end if;

  insert into public.notifications(school_id,title,body,type,created_by)
  values(v_school,v_title,v_body,'transport',auth.uid()) returning id into v_notif;

  insert into public.notification_deliveries(notification_id,profile_id)
  select distinct v_notif,pa.profile_id
  from public.student_transport_assignments sta
  join public.parent_students ps on ps.student_id=sta.student_id
  join public.parents pa on pa.id=ps.parent_id and pa.deleted_at is null
  where sta.bus_id=v_bus and sta.is_active
    and (v_route is null or sta.route_id=v_route)
  on conflict do nothing;
end $$;

-- Route-aware student roster: a driver sees only pupils assigned to this trip's route.
create or replace function public.fn_list_bus_students_ordered(p_bus_id uuid,p_trip_id uuid default null)
returns table(
  student_id uuid,full_name text,student_number text,pickup_stop text,dropoff_stop text,
  stop_order integer,stop_latitude double precision,stop_longitude double precision,
  student_latitude double precision,student_longitude double precision,
  boarded_at timestamptz,alighted_at timestamptz
)
language plpgsql stable security definer set search_path=public
as $$
declare v_school uuid; v_ctx jsonb; v_route uuid;
begin
  select school_id into v_school from public.buses where id=p_bus_id;
  if v_school is null then raise exception 'INVALID_BUS'; end if;
  v_ctx:=public.fn_driver_context();
  if not (public.fn_is_school_member(v_school) or (v_ctx is not null and (v_ctx->>'bus_id')::uuid=p_bus_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if p_trip_id is not null then
    select route_id into v_route from public.bus_trips where id=p_trip_id and bus_id=p_bus_id;
    if not found then raise exception 'INVALID_TRIP'; end if;
  end if;
  return query
  select sta.student_id,s.full_name,s.student_number,bs_pick.name,bs_drop.name,brs.sequence_order,
    bs_pick.latitude,bs_pick.longitude,s.latitude,s.longitude,bts.boarded_at,bts.dropped_at
  from public.student_transport_assignments sta
  join public.students s on s.id=sta.student_id and s.deleted_at is null
  left join public.bus_stops bs_pick on bs_pick.id=sta.pickup_stop_id
  left join public.bus_stops bs_drop on bs_drop.id=sta.dropoff_stop_id
  left join public.bus_route_stops brs on brs.route_id=sta.route_id and brs.stop_id=sta.pickup_stop_id
  left join public.bus_trip_students bts on bts.trip_id=p_trip_id and bts.student_id=sta.student_id
  where sta.bus_id=p_bus_id and sta.is_active
    and (v_route is null or sta.route_id=v_route)
  order by coalesce(brs.sequence_order,999999),s.full_name;
end $$;

-- Include scheduled-run identity in the active-trip payload while preserving
-- the existing JSON fields consumed by the driver UI.
create or replace function public.fn_get_active_trip()
returns jsonb language plpgsql stable security definer set search_path=public
as $$
declare v_driver uuid; v_trip record; v_events jsonb;
begin
  select d.id into v_driver from public.drivers d
  where d.profile_id=auth.uid() and d.deleted_at is null limit 1;
  if v_driver is null then return null; end if;
  select t.id,t.direction,t.status,t.starts_at,t.route_id,
    case when rr.id is not null then rr.run_name||' — '||r.name else r.name end as route_name,
    coalesce(b.code,b.plate_number) as bus_code
  into v_trip
  from public.bus_trips t
  left join public.bus_routes r on r.id=t.route_id
  left join public.bus_route_runs rr on rr.id=t.route_run_id
  join public.buses b on b.id=t.bus_id
  where t.driver_id=v_driver and t.status='ACTIVE'::public.trip_status
  order by t.starts_at desc limit 1;
  if v_trip.id is null then return null; end if;
  select coalesce(jsonb_agg(jsonb_build_object(
    'student_id',be.student_id,
    'event_type',case when be.event_type='BOARD'::public.bus_event_type then 'board' else 'alight' end,
    'created_at',be.created_at) order by be.created_at),'[]'::jsonb)
  into v_events from public.bus_events be where be.trip_id=v_trip.id;
  return jsonb_build_object(
    'trip_id',v_trip.id,
    'direction',case when v_trip.direction='TO_SCHOOL'::public.trip_direction then 'pickup' else 'dropoff' end,
    'started_at',v_trip.starts_at,'route_id',v_trip.route_id,'route_name',v_trip.route_name,
    'bus_code',v_trip.bus_code,'events',v_events);
end $$;

revoke all on function public.fn_create_bus_route_run(uuid,uuid,text,integer,integer,text,time) from public;
revoke all on function public.fn_list_school_bus_route_runs() from public;
revoke all on function public.fn_list_driver_bus_route_runs() from public;
revoke all on function public.fn_start_scheduled_trip(uuid) from public;
grant execute on function public.fn_create_bus_route_run(uuid,uuid,text,integer,integer,text,time) to authenticated;
grant execute on function public.fn_list_school_bus_route_runs() to authenticated;
grant execute on function public.fn_list_driver_bus_route_runs() to authenticated;
grant execute on function public.fn_start_scheduled_trip(uuid) to authenticated;
revoke all on function public.fn_notify_trip_started(uuid) from public,anon,authenticated;
