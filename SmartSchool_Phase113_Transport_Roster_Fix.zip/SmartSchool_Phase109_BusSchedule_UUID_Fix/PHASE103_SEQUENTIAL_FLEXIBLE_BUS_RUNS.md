# Phase 103 — Sequential Flexible Bus Runs

## Goal
A single bus can serve multiple classes in successive trips. Each scheduled run is assigned by the administrator to one class, route, direction, weekday, sequence number across the full bus day and target start time.

## Driver experience
- Driver sees only the runs assigned to their bus for the current weekday.
- The class, direction and passenger roster are preselected from the run.
- Driver chooses the scheduled run card/row; there is no manual class or direction selector.
- Passenger preview changes automatically when the selected run changes.
- A run may start earlier or later than its target time. `starts_at` stores the actual start timestamp.
- The next run becomes startable after the current run is explicitly ended.
- A previous lower-sequence run in the same direction must be completed first.
- The system never auto-completes an active trip just because a later run is selected.

## Administrator
When programming each run, select bus, route, class, weekday, direction, sequence and target time. For three morning pickup trips, use sequence 1, 2 and 3 for the morning pickups, then continue 4, 5 and 6 for later return runs. Sequence numbers are unique across the bus day, regardless of direction.

The selected class must already be linked to the route in `bus_route_classes`.

## Database
Run `supabase/migrations/phase103_sequential_flexible_bus_runs.sql` after Phase 86 and Phase 101. It:
- adds `bus_route_runs.class_id`;
- safely backfills only routes linked to exactly one class;
- adds a class-specific overload of `fn_create_bus_route_run`;
- updates admin and driver run-list RPCs;
- replaces `fn_start_scheduled_trip(uuid)` with a sequential, time-flexible implementation;
- adds `fn_list_driver_run_students(uuid)` for pre-start passenger preview.

Existing 7-argument `fn_create_bus_route_run` and `fn_start_scheduled_trip_for_class` remain for compatibility. The updated interface uses the new class-specific overload and the new one-argument start RPC.

## Existing runs
Runs are automatically assigned a class only if their route has exactly one linked class. For routes with multiple linked classes, the administrator must create a separate run per class (or set `class_id` for existing rows after checking them). Runs with no class are intentionally hidden from the new driver schedule.

## Validation
- JavaScript syntax checked with `node --check` for the modified modules.
- SQL was not executed against the live Supabase database.
- Test with a demo bus and at least two classes: start run 1, end it, then start run 2 after its scheduled time to verify late-start behavior.
