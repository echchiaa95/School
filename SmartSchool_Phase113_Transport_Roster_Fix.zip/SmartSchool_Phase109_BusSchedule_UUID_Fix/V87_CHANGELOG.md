# V87 Changelog
- Advanced student attendance metadata and correction audit.
- Repeated-absence alert/report RPC and admin UI.
- Additive migration; existing student/staff attendance records preserved.
