# Phase 95 — Runtime and UI repairs

- Fixed annual progression markup nesting: it now belongs exclusively to the Academic Years & Classes view.
- Reports: document-request refresh now calls `fn_list_school_document_requests` directly, handles Supabase errors, and is awaited during report-view initialization. This avoids a stale helper-export ReferenceError and unhandled asynchronous rejection.
- Parent portal: added an explicit boot state and a visible retry watchdog instead of an indefinite “checking” label. Authentication and tenant checks remain mandatory; this does not bypass access control.
- Guard finance: payment fee type is now a controlled select, fee quote/discount is retrieved through `fn_student_fee_quote`, amount due follows the approved price when available, and expense categories/validation match the manager console.
- Class creation and editing: level selection now offers Moroccan pre-primary, primary, middle, and secondary levels while preserving legacy custom values during edits.

## Important validation

The source package can be syntax/build checked locally. Live Supabase authentication, RLS, RPC behavior, and role-specific UI must still be verified against the deployed project. No database migration is included in this phase.
