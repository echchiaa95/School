# Phase 87 — Advanced Attendance

## What's included
- Adds `excuse_reason`, `minutes_late`, and `correction_reason` to the existing `attendance_records` table without dropping or recreating existing records.
- Adds `attendance_change_audit` and an update trigger that records old/new attendance values, the actor, and the correction reason.
- Extends the existing `fn_save_attendance(uuid,date,jsonb)` contract so the current teacher/admin attendance screens continue to work, while accepting optional notes, excuse reasons, and late minutes.
- Adds `fn_attendance_absence_alerts` to identify students whose unexcused `absent` records reach a configurable threshold during a date range.
- Adds `fn_attendance_audit_history` for authorized review of attendance changes.
- Admin attendance UI now captures per-student notes/reasons and late minutes and includes a repeated-absence report.

## Apply
Run `supabase/migrations/phase87_advanced_attendance.sql` after Phase 86.

## Important behavior
- `excused` is not counted in repeated-absence alerts; only `status = 'absent'` is counted.
- Late minutes are optional and constrained to 1–1440 when supplied.
- Audit rows are created on updates to attendance status/details, not on first insertion.
- Existing staff attendance (Phase 59) is unchanged.
- The audit table has RLS enabled and no direct client grants; access is through the secured RPC.

## Validation
Static checks are required before deployment. Run the migration in a staging Supabase project first, then test:
1. Save a normal attendance roster.
2. Save an excused absence with a reason.
3. Save a late mark with minutes.
4. Change an existing mark and confirm an audit row is created.
5. Set the repeated-absence threshold and verify only `absent` records are counted.
6. Verify teacher/admin/parent access remains limited by existing school authorization.
