# Phase 113 — Transport roster and scheduled-run visibility fix

## What changed
- Recreated `fn_list_school_bus_route_runs_days()` with the exact columns consumed by the manager UI. This prevents a failed/stale RPC from being silently rendered as an empty schedule.
- Manager UI now displays the actual RPC error instead of claiming no runs were programmed.
- Driver schedule counts and preview roster now include:
  - students with an active assignment to the exact run bus and route; and
  - students marked `students.uses_transport = true` who have no active assignment for the current academic year.
- Starting a scheduled run creates missing student transport assignments for transport-enabled students in the run's class, without overwriting any active assignment to a different bus/route.
- The trip snapshots its student roster into `bus_trip_students`.
- A conflicting assignment to another bus/route is respected; bus capacity is checked before starting.
- Existing weekday-array scheduling and sequential-run rules are retained.

## Apply
Run `supabase/migrations/phase113_transport_run_roster_and_admin_list_fix.sql` in Supabase SQL Editor after the existing Phase 104 migration, then deploy the updated project files.

## Important data rule
Students must either be explicitly assigned to the run's bus/route in the student profile's transport section, or be marked as using school transport (`uses_transport = true`) and have no active assignment to another bus/route. The migration does not automatically place students who are not marked for school transport onto a bus.
