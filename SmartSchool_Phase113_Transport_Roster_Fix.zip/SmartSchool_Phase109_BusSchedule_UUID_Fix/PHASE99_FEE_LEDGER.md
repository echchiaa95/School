# Phase 99 — Fee obligations ledger

This phase adds an independent fee-obligations ledger while preserving the existing `payments` table and its unique constraint for historical compatibility.

## Included
- Separate obligations for monthly tuition and transport, and annual or one-time registration fees.
- Transport preference captured during student registration; transport dues are generated only when the choice is **yes**.
- Discounts are snapshotted into each generated obligation (list amount, discount amount, net amount, discount reference).
- Partial payments with transaction headers and allocations; overpayment is rejected.
- A report RPC with filters for class, fee type, status and date, showing list price, discount, net due, paid and remaining amounts.
- Idempotent generation: running the generator again does not duplicate the same student/year/fee/period obligation.

## Apply
1. Run `supabase/migrations/phase99_fee_obligations_ledger.sql` in Supabase SQL Editor after Phases 85 and 98.
2. Deploy the updated `admin.html`, `modules/adminConsole.js`, and `modules/school.js`.
3. Configure fee plans first. When registering a student, choose whether transport is used. The app then stores that choice and generates that student's obligations for the selected academic year.
4. Existing students are not backfilled automatically. For each existing student/year, an authorized staff member must call `fn_generate_student_fee_obligations(student_uuid, academic_year_uuid)` after verifying their transport preference.

## Important compatibility and scope
- The legacy `public.payments` table is not modified or deleted.
- New ledger tables have RLS enabled and direct client table access revoked; operations are exposed through SECURITY DEFINER RPCs.
- The new obligations report and registration generation are integrated in the admin UI. Recording a payment against a new obligation is currently exposed as RPC `fn_record_fee_obligation_payment`; the legacy payment form still writes to the legacy table until a dedicated UI payment-allocation workflow is added.
- The SQL has not been executed against the user's live Supabase project. Apply it first in a staging project and verify the actual role/permission setup before production use.
