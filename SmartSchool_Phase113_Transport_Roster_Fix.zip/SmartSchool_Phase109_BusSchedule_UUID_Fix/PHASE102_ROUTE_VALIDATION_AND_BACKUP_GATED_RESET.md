# Phase 102 — Route validation and backup-gated school data reset

## Fix: route creation error
The screenshot diagnostic showed `fn_create_route` receiving `p_name: ""` and `p_stops: []`. The route form now trims and validates the route name before calling the RPC, focuses the required field, and shows a clear Arabic validation message. The database-side `ROUTE_NAME_REQUIRED` guard remains unchanged.

## Backup-gated reset
- Backup export now calls `fn_export_school_backup_for_reset`.
- The server creates the backup JSON and issues a short-lived, single-use reset ticket in the same RPC transaction.
- The UI enables the reset confirmation only after a successful backup response/download and explicit checkbox acknowledgement.
- Reset requires typing `تصفير بيانات المؤسسة` and confirming a second dialog.
- SQL reset RPC requires the valid ticket, current authenticated user, matching school and non-expired ticket.
- Reset removes only allowlisted operational rows scoped by `school_id` (students/enrollments, attendance, grades, transport, payments/expenses, fee obligations, archive/certificate/request records, etc.). It preserves `schools`, `profiles`, `auth.users`, `user_roles`, school profile settings and audit logs.
- Export allowlist expanded to include Phase 87–101 operational and finance tables.

## Apply
Run `supabase/migrations/phase102_route_error_and_safe_school_reset.sql` after the existing Phase 84 secure-backup migration and the relevant Phase 85–101 migrations.

## Important
The reset is destructive and cannot be undone except by restoring a compatible backup. The reset function deliberately preserves user login accounts and the school record. Review the allowlist against your deployed schema before production use. Test on a non-production school first.

## Checks performed
- `node --check modules/adminConsole.js`
- `node --check modules/school.js`
- SQL was authored but not executed against the user's live Supabase database.
