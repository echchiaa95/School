// ============================================================================
// modules/i18n.js — Arabic (source language) ⇄ French runtime localisation.
// The UI is authored in Arabic. In French mode this module translates every
// text node / placeholder / title / alert / confirm / prompt, including nodes
// rendered later by JS (MutationObserver). Switching language reloads the page,
// so dates, numbers, maps and all JS-built strings are always consistent.
// Missing translations: open any page with ?i18n_debug=1 then run
//   copy(JSON.stringify(ssMissing(), null, 2))   in the console.
// ============================================================================
import FR, { PATTERNS } from './i18n-fr.js';

const LANG = window.ssLang === 'fr' ? 'fr' : 'ar';
const AR = /[\u0600-\u06FF]/;
const KEY = 'ss_lang';
const missing = new Set();
const debug = (() => { try { return new URLSearchParams(location.search).get('i18n_debug') === '1'; } catch { return false; } })();

export const getLang = () => LANG;
export function setLang(next) {
  if (next !== 'ar' && next !== 'fr') return;
  try { localStorage.setItem(KEY, next); } catch { /* ignore */ }
  location.reload();
}

// ---- translation core -------------------------------------------------------
const esc = (k) => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const keys = Object.keys(FR).sort((a, b) => b.length - a.length);
const BOUND = (list) => list.length
  ? new RegExp('(?<![\\u0600-\\u06FF])(?:' + list.map(esc).join('|') + ')(?![\\u0600-\\u06FF])', 'g')
  : null;
const RE_SHORT = BOUND(keys.filter((k) => k.length >= 3));                       // short texts (<= 40 chars)
const RE_LONG = BOUND(keys.filter((k) => k.length >= 8 || k.includes(' ')));     // long texts
const cache = new Map();

function typography(s) {
  return s.replace(/\s*؟/g, ' ?').replace(/،/g, ',').replace(/؛/g, ';').replace(/…/g, '…');
}

export function t(text) {
  if (LANG !== 'fr' || !text || !AR.test(text)) return text;
  const lead = text.match(/^\s*/)[0], trail = text.match(/\s*$/)[0];
  const core = text.trim();
  if (cache.has(core)) return lead + cache.get(core) + trail;
  let out = FR[core];
  if (out === undefined) {
    for (const [re, rep] of PATTERNS) {
      if (re.test(core)) { out = core.replace(re, rep); break; }
    }
  }
  if (out === undefined) {
    const re = core.length <= 40 ? RE_SHORT : RE_LONG;
    out = re ? core.replace(re, (m) => FR[m]) : core;
    if (out === core) out = undefined;
  }
  if (out !== undefined) out = typography(out);
  if (out === undefined || AR.test(out)) {
    if (debug) missing.add(core);
    if (out === undefined) { cache.set(core, core); return text; }
  }
  cache.set(core, out);
  return lead + out + trail;
}
window.ssT = t;
window.ssMissing = () => [...missing];

// ---- DOM translation (French mode only) ---------------------------------------
const SKIP = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'NOSCRIPT', 'CODE', 'PRE']);
const ATTRS = ['placeholder', 'title', 'aria-label', 'alt', 'data-title', 'data-tip'];
const skipEl = (el) => !el || SKIP.has(el.tagName) || el.closest?.('[data-no-i18n],[contenteditable="true"]');

function doText(node) {
  const v = node.nodeValue;
  if (!v || !AR.test(v) || skipEl(node.parentElement)) return;
  const out = t(v);
  if (out !== v) node.nodeValue = out;
}
function doElement(el) {
  if (!el.getAttribute || el.closest?.('[data-no-i18n]')) return;   // attributes (placeholder…) are safe even on <textarea>/<code>
  for (const a of ATTRS) {
    const v = el.getAttribute(a);
    if (v && AR.test(v)) { const o = t(v); if (o !== v) el.setAttribute(a, o); }
  }
  if (el.tagName === 'INPUT' && /^(button|submit|reset)$/i.test(el.type) && AR.test(el.value)) el.value = t(el.value);
}
function walk(root) {
  if (root.nodeType === 3) { doText(root); return; }
  if (root.nodeType !== 1 && root.nodeType !== 9) return;
  if (root.nodeType === 1) doElement(root);
  const tw = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
  let n;
  while ((n = tw.nextNode())) { n.nodeType === 3 ? doText(n) : doElement(n); }
}

function startFrench() {
  const style = document.createElement('style');
  style.id = 'ss-ltr-overrides';
  style.textContent = `
    html[dir="ltr"] body { text-align: left; }
    html[dir="ltr"] .data-table th, html[dir="ltr"] .data-table td { text-align: left; }
    html[dir="ltr"] .detail-row .v { text-align: right; }
    html[dir="ltr"] .audit-date { text-align: right; }
    html[dir="ltr"] .weekly-schedule th, html[dir="ltr"] .weekly-schedule td { border-left: 0; border-right: 1px solid var(--ss-line, #e5e7eb); }
    html[dir="ltr"] .weekly-schedule tr > *:last-child { border-right: 0; }
    html[dir="ltr"] [style*="text-align:right"], html[dir="ltr"] [style*="text-align: right"] { text-align: left !important; }`;
  document.head.appendChild(style);

  const nativeAlert = window.alert.bind(window), nativeConfirm = window.confirm.bind(window), nativePrompt = window.prompt.bind(window);
  window.alert = (m) => nativeAlert(t(String(m ?? '')));
  window.confirm = (m) => nativeConfirm(t(String(m ?? '')));
  window.prompt = (m, d) => nativePrompt(t(String(m ?? '')), d);

  document.title = t(document.title);
  walk(document);
  new MutationObserver((records) => {
    for (const r of records) {
      if (r.type === 'characterData') doText(r.target);
      else if (r.type === 'attributes') doElement(r.target);
      else r.addedNodes.forEach(walk);
    }
  }).observe(document.documentElement, {
    childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS,
  });
  new MutationObserver(() => { const nt = t(document.title); if (nt !== document.title) document.title = nt; })
    .observe(document.querySelector('title') || document.head, { childList: true, subtree: true, characterData: true });
}

// ---- language switcher ---------------------------------------------------------
function mountSwitcher() {
  const box = document.createElement('div');
  box.id = 'ss-lang-switch';
  box.setAttribute('data-no-i18n', '');
  box.innerHTML = '<button type="button" data-l="ar" lang="ar">العربية</button><button type="button" data-l="fr" lang="fr">Français</button>';
  const style = document.createElement('style');
  style.textContent = `
    #ss-lang-switch{position:fixed;bottom:10px;inset-inline-start:10px;z-index:9997;display:flex;gap:2px;padding:3px;
      background:rgba(255,255,255,.92);border:1px solid #d1d5db;border-radius:999px;box-shadow:0 2px 8px rgba(0,0,0,.12);direction:ltr}
    #ss-lang-switch button{border:0;background:transparent;padding:5px 11px;border-radius:999px;font:600 12px/1 inherit;font-family:inherit;color:#374151;cursor:pointer}
    #ss-lang-switch button[aria-pressed="true"]{background:#1f4fd8;color:#fff}
    @media print{#ss-lang-switch{display:none!important}}`;
  document.head.appendChild(style);
  box.querySelectorAll('button').forEach((b) => {
    b.setAttribute('aria-pressed', String(b.dataset.l === LANG));
    b.addEventListener('click', () => { if (b.dataset.l !== LANG) setLang(b.dataset.l); });
  });
  (document.getElementById('lang-slot') || document.body).appendChild(box);
}

window.addEventListener('storage', (e) => {                 // keep every open tab consistent
  if (e.key === KEY && (e.newValue === 'fr' ? 'fr' : 'ar') !== LANG) location.reload();
});

function boot() { if (LANG === 'fr') startFrench(); mountSwitcher(); }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
else boot();
