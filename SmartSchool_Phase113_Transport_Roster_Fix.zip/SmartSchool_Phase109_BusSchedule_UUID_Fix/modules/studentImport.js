// Student Import Center — additive frontend workflow using the existing
// fn_register_student_auto_number RPC. Authorization and tenant isolation
// remain enforced by the existing server-side registration function/RLS.
import { registerStudent } from './students.js';
import { exportToExcel } from './reportExport.js';
import { createMigrationJob, recordMigrationBatch, finishMigrationJob, renderMigrationHistory } from './institutionMigration.js';

const FIELDS = [
  ['full_name', 'الاسم الكامل', ['الاسم الكامل','الاسم','اسم التلميذ','nom complet','nom et prénom','nom','full name','fullname','student name']],
  ['birth_date', 'تاريخ الميلاد', ['تاريخ الميلاد','تاريخ الازدياد','date de naissance','date naissance','birth date','birth_date']],
  ['gender', 'الجنس', ['الجنس','النوع','sexe','gender']],
  ['massar_number', 'رقم مسار', ['رقم مسار','مسار','massar','massar number','code massar']],
  ['health_status', 'الحالة الصحية', ['الحالة الصحية','ملاحظات صحية','santé','etat de santé','health status']],
  ['class_name', 'القسم', ['القسم','الفصل','classe','class','class name']],
  ['year_name', 'السنة الدراسية', ['السنة الدراسية','السنة','année scolaire','annee scolaire','academic year','year']],
];
const normalize = (s) => String(s ?? '').trim().toLocaleLowerCase('fr').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\s_\-]+/g, ' ');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function parseCSV(text) {
  const first = text.split(/\r?\n/, 1)[0] || '';
  const delimiter = (first.match(/;/g) || []).length > (first.match(/,/g) || []).length ? ';' : ',';
  const rows = []; let row = [], cell = '', quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === '"' && quoted && text[i + 1] === '"') { cell += '"'; i++; }
    else if (c === '"') quoted = !quoted;
    else if (c === delimiter && !quoted) { row.push(cell); cell = ''; }
    else if ((c === '\n' || c === '\r') && !quoted) {
      if (c === '\r' && text[i + 1] === '\n') i++;
      row.push(cell); if (row.some(v => String(v).trim())) rows.push(row);
      row = []; cell = '';
    } else cell += c;
  }
  row.push(cell); if (row.some(v => String(v).trim())) rows.push(row);
  return rows;
}

async function readFile(file) {
  const ext = file.name.toLowerCase().split('.').pop();
  if (ext === 'csv' || ext === 'txt') {
    const text = await file.text();
    return parseCSV(text.replace(/^\uFEFF/, ''));
  }
  if (!['xlsx','xls'].includes(ext)) throw new Error('صيغة الملف غير مدعومة. استخدم XLSX أو XLS أو CSV.');
  if (!window.XLSX) {
    await new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js';
      script.onload = resolve; script.onerror = () => reject(new Error('تعذر تحميل قارئ Excel. تحقق من الاتصال ثم أعد المحاولة.'));
      document.head.appendChild(script);
    });
  }
  const buffer = await file.arrayBuffer();
  const wb = window.XLSX.read(buffer, { type: 'array', cellDates: false });
  const sheetName = wb.SheetNames[0];
  return window.XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { header: 1, defval: '', raw: false });
}

function normalizeDate(value) {
  if (!value) return null;
  const s = String(value).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  let m = s.match(/^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})$/);
  if (m) return `${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`;
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? null : d.toISOString().slice(0,10);
}

export function initStudentImport({ host, schoolId, getClasses, getYears, onImported }) {
  if (!host || host.dataset.importReady) return;
  host.dataset.importReady = '1';
  let sourceRows = [], headers = [], mapping = {}, validated = [], classes = [], years = [];
  host.innerHTML = `
    <div class="panel"><h3 style="margin-top:0">سجل عمليات الاستيراد والترحيل</h3><div id="si-history"><div class="loading-state">جارٍ التحميل...</div></div></div>
    <div class="panel">
      <h3 style="margin-top:0">مركز استيراد وترحيل التلاميذ</h3>
      <p class="time">ارفع ملف المؤسسة بصيغة Excel أو CSV، ثم طابق الأعمدة وراجع البيانات قبل التسجيل. لا تُنشأ حسابات أولياء الأمور تلقائياً في هذه المرحلة.</p>
      <div class="form-grid">
        <div class="full"><label>ملف التلاميذ</label><input id="si-file" type="file" class="search-input" accept=".xlsx,.xls,.csv,.txt"></div>
        <div><label>السنة الدراسية الافتراضية</label><select id="si-year" class="search-input"></select></div>
        <div><label>القسم الافتراضي عند غياب العمود</label><select id="si-class" class="search-input"></select></div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
        <button type="button" class="quick-action-btn" id="si-read">قراءة الملف ومعاينة الأعمدة</button>
        <button type="button" class="quick-action-btn secondary" id="si-template">تنزيل نموذج Excel</button>
      </div>
      <div id="si-status" class="time" style="margin-top:10px" aria-live="polite"></div>
    </div>
    <div class="panel" id="si-mapping-panel" hidden>
      <h3 style="margin-top:0">مطابقة الأعمدة</h3><p class="time">اختر العمود المقابل لكل حقل. الاسم الكامل والسنة والقسم إلزامية (يمكن استخدام الاختيارات الافتراضية).</p>
      <div id="si-mapping" class="form-grid"></div>
      <button type="button" class="quick-action-btn" id="si-validate" style="margin-top:10px;width:100%">التحقق ومعاينة السجلات</button>
    </div>
    <div class="panel" id="si-preview-panel" hidden>
      <h3 style="margin-top:0">نتيجة التحقق</h3><div id="si-stats" class="stats-grid"></div>
      <div class="data-table-wrap" style="margin-top:10px;max-height:360px;overflow:auto"><table class="data-table"><thead id="si-preview-head"></thead><tbody id="si-preview-body"></tbody></table></div>
      <p class="time">يتم استيراد السجلات السليمة فقط. كل تلميذ يُسجّل عبر وظيفة التسجيل الحالية التي تولّد رقمه وتتحقق من صلاحية القسم والسنة والمؤسسة.</p>
      <button type="button" class="quick-action-btn" id="si-import" style="width:100%">بدء استيراد السجلات السليمة</button>
      <div id="si-progress" style="margin-top:10px"></div>
      <div id="si-errors" style="margin-top:10px"></div>
    </div>`;

  const $ = id => host.querySelector('#' + id);
  const setStatus = (s, bad=false) => { $('si-status').textContent = s; $('si-status').style.color = bad ? '#b91c1c' : ''; };
  const fillOptions = async () => {
    classes = await getClasses(); years = await getYears();
    $('si-year').innerHTML = '<option value="">— اختر السنة —</option>' + years.filter(y=>!y.is_disabled).map(y=>`<option value="${esc(y.year_id)}">${esc(y.year_name)}</option>`).join('');
    const current = years.find(y=>y.is_current && !y.is_disabled); if (current) $('si-year').value = current.year_id;
    $('si-class').innerHTML = '<option value="">— بدون افتراضي —</option>' + classes.filter(c=>!c.is_disabled).map(c=>`<option value="${esc(c.class_id)}">${esc(c.class_name)} — ${esc(c.year_name||'')}</option>`).join('');
  };
  fillOptions().catch(e=>setStatus(e.message,true));
  renderMigrationHistory(host.querySelector('#si-history'), schoolId);

  $('si-template').addEventListener('click', async () => {
    const headers = ['الاسم الكامل','تاريخ الميلاد','الجنس','رقم مسار','الحالة الصحية','القسم','السنة الدراسية'];
    const rows = [['محمد العلوي','2015-03-12','male','G123456789','','القسم الأول','2026-2027']];
    try { await exportToExcel('smart-school-student-import-template', { name:'التلاميذ', headers, rows }); }
    catch (e) { setStatus(e.message, true); }
  });

  $('si-read').addEventListener('click', async () => {
    const file = $('si-file').files?.[0];
    if (!file) return setStatus('اختر ملفاً أولاً.', true);
    if (file.size > 15 * 1024 * 1024) return setStatus('حجم الملف يتجاوز 15 ميغابايت.', true);
    try {
      setStatus('جارٍ قراءة الملف...');
      const matrix = await readFile(file);
      if (matrix.length < 2) throw new Error('الملف لا يحتوي على صفوف بيانات كافية.');
      headers = matrix[0].map((h,i)=>String(h || `عمود ${i+1}`).trim());
      sourceRows = matrix.slice(1).filter(r=>r.some(v=>String(v??'').trim()));
      if (sourceRows.length > 10000) throw new Error('الحد الأقصى في الملف الواحد هو 10,000 صف.');
      mapping = {};
      for (const [key,,aliases] of FIELDS) {
        const idx = headers.findIndex(h => aliases.some(a=>normalize(a)===normalize(h)));
        mapping[key] = idx >= 0 ? String(idx) : '';
      }
      $('si-mapping').innerHTML = FIELDS.map(([key,label])=>`<label>${label}<select class="search-input" data-map="${key}"><option value="">— غير محدد —</option>${headers.map((h,i)=>`<option value="${i}" ${mapping[key]===String(i)?'selected':''}>${esc(h)}</option>`).join('')}</select></label>`).join('');
      $('si-mapping-panel').hidden = false; $('si-preview-panel').hidden = true;
      $('si-mapping').querySelectorAll('[data-map]').forEach(s=>s.addEventListener('change',()=>mapping[s.dataset.map]=s.value));
      setStatus(`تمت قراءة ${sourceRows.length} سجل من الملف: ${file.name}`);
    } catch (e) { setStatus(e.message || 'تعذرت قراءة الملف.', true); }
  });

  $('si-validate').addEventListener('click', () => {
    const defaultYear = $('si-year').value, defaultClass = $('si-class').value;
    if (mapping.full_name === '') return setStatus('يجب مطابقة عمود الاسم الكامل.', true);
    validated = []; const seen = new Set();
    sourceRows.forEach((row, index) => {
      const get = key => mapping[key] === '' ? '' : String(row[Number(mapping[key])] ?? '').trim();
      const fullName = get('full_name');
      const birthDate = normalizeDate(get('birth_date'));
      const classRaw = get('class_name'), yearRaw = get('year_name');
      const defaultClassRow = classes.find(c=>c.class_id===defaultClass);
      const year = yearRaw ? years.find(y=>normalize(y.year_name)===normalize(yearRaw)) : (defaultClassRow ? years.find(y=>y.year_id===defaultClassRow.academic_year_id) : years.find(y=>y.year_id===defaultYear));
      const cls = classRaw ? classes.find(c=>normalize(c.class_name)===normalize(classRaw) && (!year || c.academic_year_id===year.year_id)) : defaultClassRow;
      const problems = [];
      if (!fullName) problems.push('الاسم مفقود');
      if (get('birth_date') && !birthDate) problems.push('تاريخ الميلاد غير صالح');
      if (!year) problems.push('السنة الدراسية غير مطابقة');
      if (!cls) problems.push('القسم غير مطابق');
      if (cls && year && cls.academic_year_id !== year.year_id) problems.push('القسم لا يتبع السنة المحددة');
      const duplicateKey = `${normalize(fullName)}|${birthDate||''}`;
      const duplicate = !!fullName && seen.has(duplicateKey);
      if (fullName) seen.add(duplicateKey);
      if (duplicate) problems.push('تكرار محتمل داخل الملف');
      const genderRaw = normalize(get('gender'));
      const gender = ['ذكر','male','m','homme','garcon','garçon'].includes(genderRaw) ? 'male' : ['أنثى','female','f','femme','fille'].includes(genderRaw) ? 'female' : null;
      validated.push({ rowNumber:index+2, fullName, birthDate, gender, massarNumber:get('massar_number')||null, healthStatus:get('health_status')||null, classId:cls?.class_id, academicYearId:year?.year_id, className:cls?.class_name, yearName:year?.year_name, problems, duplicate });
    });
    const ok = validated.filter(r=>!r.problems.length);
    $('si-stats').innerHTML = `<div class="stat-card"><strong>${validated.length}</strong><span>إجمالي السجلات</span></div><div class="stat-card"><strong>${ok.length}</strong><span>صالحة للاستيراد</span></div><div class="stat-card"><strong>${validated.length-ok.length}</strong><span>تحتاج مراجعة</span></div>`;
    $('si-preview-head').innerHTML = '<tr><th>السطر</th><th>الاسم</th><th>القسم</th><th>السنة</th><th>التحقق</th></tr>';
    $('si-preview-body').innerHTML = validated.slice(0,300).map(r=>`<tr><td>${r.rowNumber}</td><td>${esc(r.fullName)}</td><td>${esc(r.className||'—')}</td><td>${esc(r.yearName||'—')}</td><td>${r.problems.length?`<span style="color:#b91c1c">${esc(r.problems.join('، '))}</span>`:'<span style="color:#15803d">سليم</span>'}</td></tr>`).join('') + (validated.length>300?`<tr><td colspan="5">يتم عرض أول 300 سجل فقط.</td></tr>`:'');
    $('si-preview-panel').hidden = false; $('si-import').disabled = ok.length===0;
    $('si-errors').textContent = ''; $('si-progress').textContent = '';
    setStatus(`انتهى التحقق: ${ok.length} صالح، ${validated.length-ok.length} يحتاج مراجعة.`);
  });

  $('si-import').addEventListener('click', async () => {
    const rows = validated.filter(r=>!r.problems.length);
    if (!rows.length) return;
    if (!schoolId) return setStatus('تعذر تحديد المؤسسة الحالية. أعد تسجيل الدخول.', true);
    if (!confirm(`سيتم تسجيل ${rows.length} تلميذاً في المؤسسة. سيتم حفظ سجل العملية لاستكمال المراجعة عند انقطاع الاتصال. هل تريد المتابعة؟`)) return;
    $('si-import').disabled = true;
    $('si-progress').textContent = 'جارٍ إنشاء سجل ترحيل آمن...';
    const errors = []; let done = 0; let jobId = null; let batchNo = 0;
    try {
      jobId = await createMigrationJob({
        schoolId,
        sourceName: $('si-file').files?.[0]?.name || 'student-import',
        totalRows: rows.length,
        metadata: { valid_rows: rows.length, source_rows: validated.length, validation_rejected: validated.length - rows.length, workflow: 'student_import_v1' },
      });
      if (!jobId) throw new Error('لم يتم إنشاء سجل الترحيل في قاعدة البيانات.');
      await renderMigrationHistory(host.querySelector('#si-history'), schoolId);

      // A batch is first durably marked PROCESSING, then its final outcomes
      // are committed. If the browser closes between these calls, the rows
      // remain visibly NEEDS_REVIEW after the job is reconciled; they are
      // never silently re-run and risk duplicate student creation.
      for (let offset=0; offset<rows.length; offset+=25) {
        const chunk = rows.slice(offset, offset+25);
        batchNo++;
        const base = chunk.map(r => ({ row_number:r.rowNumber, status:'PROCESSING' }));
        await recordMigrationBatch({ jobId, batchNumber:batchNo, idempotencyKey:`${jobId}:batch:${batchNo}`, rows:base });
        const outcomes = [];
        for (const r of chunk) {
          let outcome;
          try {
            const result = await registerStudent({ fullName:r.fullName, classId:r.classId, academicYearId:r.academicYearId, birthDate:r.birthDate, gender:r.gender, healthStatus:r.healthStatus, massarNumber:r.massarNumber });
            if (!result.ok) {
              const message = result.error || 'تعذر تسجيل التلميذ';
              errors.push({ row:r.rowNumber, name:r.fullName, error:message });
              outcome = { row_number:r.rowNumber, status:'FAILED', error_code:'STUDENT_REGISTRATION_FAILED', error_message:message };
            } else if (!result.studentId) {
              errors.push({ row:r.rowNumber, name:r.fullName, error:'تمت الاستجابة دون معرف التلميذ؛ يلزم التحقق.' });
              outcome = { row_number:r.rowNumber, status:'NEEDS_REVIEW', error_code:'MISSING_TARGET_ID', error_message:'استجابة التسجيل لا تتضمن معرف التلميذ.' };
            } else {
              outcome = { row_number:r.rowNumber, status:'SUCCEEDED', target_student_id:result.studentId };
            }
          } catch (e) {
            const message = e.message || 'خطأ غير معروف';
            errors.push({ row:r.rowNumber, name:r.fullName, error:message });
            outcome = { row_number:r.rowNumber, status:'FAILED', error_code:'UNEXPECTED_ERROR', error_message:message };
          }
          outcomes.push(outcome);
          done++;
          $('si-progress').innerHTML = `<div style="height:10px;background:#e2e8f0;border-radius:20px;overflow:hidden"><div style="height:100%;width:${Math.round(done/rows.length*100)}%;background:#15803d"></div></div><p class="time">تمت معالجة ${done} من ${rows.length}</p>`;
        }
        // Persist outcomes atomically for the whole chunk before moving on.
        await recordMigrationBatch({ jobId, batchNumber:batchNo, idempotencyKey:`${jobId}:batch:${batchNo}`, rows:outcomes });
        await new Promise(resolve=>setTimeout(resolve,0));
      }
      const finalState = await finishMigrationJob(jobId, false);
      const succeeded = rows.length-errors.length;
      $('si-errors').innerHTML = `<p><strong>اكتملت المعالجة:</strong> ${succeeded} ناجح، ${errors.length} فشل.</p><p class="time">رقم العملية: ${esc(jobId)} — الحالة: ${esc(finalState?.status || 'غير محددة')}</p>` + (errors.length?`<div class="data-table-wrap"><table class="data-table"><thead><tr><th>السطر</th><th>الاسم</th><th>الخطأ</th></tr></thead><tbody>${errors.map(e=>`<tr><td>${e.row}</td><td>${esc(e.name)}</td><td>${esc(e.error)}</td></tr>`).join('')}</tbody></table></div><button type="button" class="quick-action-btn secondary" id="si-error-csv">تنزيل تقرير الأخطاء CSV</button>`:'');
      if (errors.length) $('si-error-csv').addEventListener('click',()=>{
        const csv = ['السطر,الاسم,الخطأ',...errors.map(e=>[e.row,e.name,e.error].map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(','))].join('\r\n');
        const blob = new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='student-import-errors.csv'; a.click(); URL.revokeObjectURL(url);
      });
      $('si-import').textContent = 'انتهى الاستيراد';
      await renderMigrationHistory(host.querySelector('#si-history'), schoolId);
      if (succeeded) onImported?.();
    } catch (e) {
      setStatus(`توقفت العملية: ${e.message}. راجع سجل الترحيل قبل إعادة المحاولة؛ السجلات قيد المعالجة لا يعاد تسجيلها تلقائياً.`, true);
      if (jobId) {
        try { await finishMigrationJob(jobId, true); } catch (finishError) { console.error('Could not finalize interrupted migration job', finishError); }
        await renderMigrationHistory(host.querySelector('#si-history'), schoolId);
      }
      $('si-import').disabled = false;
    }
  });
}
