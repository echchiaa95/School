/* i18n-boot.js — classic (blocking) script, loaded in <head> BEFORE any module.
   Sets <html lang/dir> before first paint (no RTL/LTR flash) and exposes
   window.ssLang / window.ssLoc for locale-aware formatting. */
(function () {
  var KEY = 'ss_lang', lang = 'ar';
  try {
    var q = new URLSearchParams(location.search).get('lang');
    if (q === 'fr' || q === 'ar') { localStorage.setItem(KEY, q); }
    lang = localStorage.getItem(KEY) === 'fr' ? 'fr' : 'ar';
  } catch (e) { /* storage blocked: stay on Arabic */ }
  var root = document.documentElement;
  root.lang = lang;
  root.dir = lang === 'fr' ? 'ltr' : 'rtl';
  root.setAttribute('data-lang', lang);
  window.ssLang = lang;
  // 'ar' -> 'fr', 'ar-MA' -> 'fr-MA', 'ar-MA-u-nu-latn' -> 'fr-MA'
  window.ssLoc = function (tag) {
    tag = tag || 'ar';
    return lang === 'fr' ? tag.replace(/^ar/, 'fr').replace(/-u-nu-latn$/, '') : tag;
  };
})();
