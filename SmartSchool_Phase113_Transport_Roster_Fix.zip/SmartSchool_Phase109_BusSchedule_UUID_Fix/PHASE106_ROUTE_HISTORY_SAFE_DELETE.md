# Phase 106 — Safe route deletion with history preservation

Fixes `ROUTE_HAS_STUDENT_ASSIGNMENT_HISTORY`.

- A route with any student transport assignment, route run, or trip history is not physically deleted.
- Such a route is archived by setting `bus_routes.is_active = false`.
- Active route runs are disabled.
- Existing student assignments and trip history remain intact.
- A route with no references is physically deleted as before.
- Scope is checked against the authenticated user's primary school.
- An audit event is written for both archive and hard-delete paths.

## Apply
Run `supabase/migrations/phase106_route_history_safe_delete.sql` after prior migrations.

The UI confirmation and success text are updated to explain that the operation may archive rather than physically delete the route.
