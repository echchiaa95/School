# Phase 86 — Multi-Run Daily Transportation

## Delivered
- Added recurring route-run schedules per bus, weekday, direction, and sequence number.
- Added route-run administration UI in the transport section.
- Added driver-facing "today's scheduled runs" selection. Selecting a scheduled run starts the exact route and direction configured by management.
- Existing manual route selection remains available for exceptional trips.
- Linked each trip to its scheduled run while preserving the existing `bus_trips` table and existing trip RPCs.
- Updated the driver roster RPC to show only students assigned to the active trip's route.
- Updated trip-start notifications to include the run label/sequence and route name, and to notify parents of students assigned to that route only.
- Hardened the internal notification RPC against direct unauthorized invocation.

## Database deployment
Run after Phase 85:
1. `supabase/migrations/phase86_multi_route_transport.sql`

Requires the existing Phase 12 and Phase 61 transport/notification schema and functions.

## Schedule model
- Weekday uses PostgreSQL day-of-week numbering: Sunday=0 through Saturday=6.
- Each schedule row defines one run for one bus, route, weekday, direction, and sequence number.
- A bus can have multiple runs on the same day; sequence numbers must be unique per bus/day/direction.
- Drivers see the runs configured for the current database weekday.
- The schedule's time is displayed to the driver; the current phase does not block early/late starts based on a time window.

## Verification limits
- JavaScript syntax and UI identifiers are checked locally.
- SQL was not executed against a live/staging Supabase database in this workspace.
- Parent push delivery still depends on the existing notification delivery/push infrastructure and device subscription state.
