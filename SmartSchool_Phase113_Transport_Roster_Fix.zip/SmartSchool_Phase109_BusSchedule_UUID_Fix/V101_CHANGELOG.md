# V101 — Transport route sections
- Added route-to-class mapping.
- Added driver section picker for scheduled runs.
- Scheduled trips snapshot only active transport students enrolled in the selected section.
- Driver roster and departure notifications are scoped to the selected section.
