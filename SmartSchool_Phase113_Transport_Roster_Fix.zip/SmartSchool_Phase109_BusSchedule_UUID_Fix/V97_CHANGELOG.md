# Phase 97 — Parent Portal Polish and School Announcements

## Parent document requests
- Moved the administrative document request section to the bottom of the child details view, after all child tabs and panels.
- Kept the request form limited to document type and purpose, with the existing request history/actions below it.
- Added defensive DOM checks for the request controls to prevent `Cannot read properties of null (reading 'value')` from crashing the parent portal.
- Added `try/catch/finally` around submission so the submit button is always restored and errors are surfaced as a toast.

## Institution announcements
- Added a floating announcements/blog shortcut above the existing appointment shortcut.
- The shortcut resolves the institution from the authenticated parent context (`ctx.schoolId`) and opens `school.html?id=<schoolId>#announcements`.
- Added a stable `announcements` anchor to the public institution website and smooth-scroll behavior when the hash is present.

## Cache/versioning
- Bumped the parent console module URL to `parentConsole.js?v=97.1` to avoid reusing the older script that triggered the reported null-value error.

## Database
- No database migration required.
