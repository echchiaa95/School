# Phase 105 — Reset preview and school-scope hardening

- Adds `fn_preview_school_reset()` for a non-destructive per-school count preview.
- Adds `fn_reset_target_school()`; the reset target is resolved from the authenticated admin/director role and is not accepted from the browser.
- Allows `director` in `fn_is_school_staff`.
- Backup ticket creation resolves the same server-side target school.
- The admin backup screen requires a preview before enabling backup download.
- JavaScript belongs in the application, not Supabase SQL Editor.

## Apply

Run `supabase/migrations/phase105_reset_preview_and_school_scope.sql` after Phase 102 and the existing migrations.

## Safety lock

The destructive reset RPC is deliberately fail-closed with `RESET_TEMPORARILY_DISABLED_DEPENDENT_FK_AUDIT_REQUIRED`. The current Phase 102 allowlist does not cover every dependent table without `school_id`; enabling it could leave orphaned rows or fail on restrictive foreign keys. Phase 105 therefore enables preview and backup only. Phase 106 must add and test the complete FK-aware deletion plan before destructive reset is re-enabled.
