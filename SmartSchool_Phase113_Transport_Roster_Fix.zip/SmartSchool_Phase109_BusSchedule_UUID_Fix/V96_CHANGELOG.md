# V96 — Professional reporting and parent document requests

- Report results now open in a focused modal rather than being appended beneath the reports dashboard.
- Added advanced search, date range, class filter, person-focused search, live row counts and refreshed filtered summaries.
- Attendance report is grouped to one row per student and provides totals for present, absent, late and excused days. Absence/late counts open a detail dialog with date, recorded time and note.
- Payment journal and unpaid list now include student number, class, billed month/year, actual payment date, method and receipt number. Finance data is loaded through a school-scoped report RPC.
- Parent document requests moved into the selected child's profile. The parent only chooses document type and purpose; the child is inherited from the open profile.
- Added SQL migration `phase96_professional_report_details.sql` for secure attendance drill-down and finance reporting.

## Deployment
Run `supabase/migrations/phase96_professional_report_details.sql` in Supabase SQL Editor before using the new attendance drill-down and finance report UI.

## Timestamp accuracy
Attendance detail displays `attendance_records.created_at`, the time the record was created in the system. It must not be represented as the actual physical arrival time unless the attendance capture workflow records that separately.
