# Phase 111 — Fix route-run time validation

## Root cause
`normalizeRouteRunTime()` converts valid input such as `07:45` into PostgreSQL-compatible `07:45:00`, but the submit handler then validated the normalized value using a regex that accepted only `HH:mm`. The validation therefore rejected every correctly normalized value.

## Fix
The validation now accepts the normalized `HH:mm:ss` format. The RPC name, argument names, and database schema are unchanged.

## Tests
- `07:45` → `07:45:00` → accepted
- `08:45` → `08:45:00` → accepted
- Invalid hours/minutes remain rejected by the normalizer.
