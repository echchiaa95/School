# Phase 82 — Student Import Center (Initial Delivery)

## What changed

- Added an `استيراد Excel` action to the existing Students administration view.
- Added a dedicated `student-import` view with guided upload, column mapping, validation, preview, and import.
- Supports `.xlsx`, `.xls`, and `.csv`. CSV parsing is local; Excel parsing uses the SheetJS CDN pattern already used by the existing Excel export module.
- Supports Arabic, French, and English header aliases for student name, birth date, gender, Massar number, health status, class, and academic year.
- Supports default academic year and class selections when a source file omits those columns.
- Validates dates, class/year matching, missing names, and likely duplicates inside the uploaded file.
- Imports valid records sequentially through the existing authenticated `fn_register_student_auto_number` wrapper (`registerStudent`) rather than writing directly to the students table.
- Shows per-row import failures and offers a CSV error report.
- Includes an Excel template download.
- Added fixed fee-type choices (tuition, transport, registration) and predefined expense categories to reduce free-text entry.
- Added financial report actions for payment journal, unpaid balances, and payment summary, with date filtering and Excel/PDF export including summary sheets.

## Important scope and safety notes

This is the first safe import slice, not yet the complete institution migration product.

- Parent/guardian account creation and parent-child linking are intentionally not included. The exported project does not provide enough confirmed schema/API evidence to safely write those relationships in this workflow.
- Financial history, opening balances, grades, transport assignments, staff, and document archives are not imported by this phase.
- Durable server-side migration job history, resumable batches, idempotency records, and rollback require a separately reviewed database migration and RPC implementation.
- Duplicate detection currently detects likely duplicate rows inside the uploaded file. It does not automatically merge with existing database records.
- The existing legacy payments RPC aggregates payment rows by student and month/year. The new reports faithfully summarize that existing data model; fully independent subscription pricing and fee ledgers require a reviewed additive financial schema and migration.
- XLSX/XLS reading and XLSX template export require the SheetJS CDN. CSV reading does not require an external parser.
- Importing is online-only and uses the existing authenticated registration RPC. It does not bypass RLS or trust a browser-supplied school ID.

## Files changed

- `admin.html`
- `modules/adminConsole.js`
- `modules/studentImport.js` (new)
- `modules/adminConsole.js` (financial reports and import wiring)

## Verification

- `node --check modules/studentImport.js` — passed.
- `node --check modules/adminConsole.js` — passed.
- Full Vite build could not be run because dependencies are not installed (`vite: not found`). Dependency installation did not complete within the execution window.
- Supabase RPC execution and RLS behavior were not testable because no live database session is available in this workspace.

## Next phases

1. Confirm live schema for parent relationships, finance, transport, and staff records.
2. Add durable migration jobs, batches, row outcomes, and audit records with tenant-safe RLS.
3. Implement server-side transactional batch import, idempotency, resume, and safe rollback.
4. Add parent/guardian linking and migration of grades, financial history, transport, staff, and archives.
