# V88 Changelog
- Annual promotion and repeat-year workflow.
- School-scoped candidate listing and batch transition RPC.
- Historical enrollment retention and per-student progression ledger.
- Admin UI to map students to destination classes and view progression history.
