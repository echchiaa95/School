# Phase 110 — Bus route run time input normalization

## Fix
- Normalize route-run departure time values from mobile/browser inputs before validation and RPC submission.
- Accept `HH:mm`, `H:mm`, `HH:mm:ss`, and localized Arabic/English AM/PM representations.
- Convert Arabic-Indic and Eastern Arabic-Indic digits to ASCII digits.
- Convert accepted values to PostgreSQL-compatible `HH:mm:ss`.
- Keep the existing RPC `fn_create_bus_route_run_days` and parameter name `p_scheduled_start` unchanged.

## Validation
- `node --check modules/adminConsole.js` passed.
