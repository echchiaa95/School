# Phase 84 — Migration Assistant: Smart School Backup Transfer

## Delivered

- Added a dedicated **مساعد ترحيل المؤسسات** entry in the administrator dashboard.
- Added a guided JSON inspection flow for backups produced by Smart School (`backup_version: 1`).
- The preview shows the included tables and source row counts before any write occurs.
- The migration uses the destination `school_id` selected by the authenticated administrator; source `school_id` values are not trusted.
- Added durable job and table-outcome tracking using the Phase 83 migration RPCs.
- Added a safe export/restore RPC pair. The restore uses an explicit table allowlist, rejects malformed table payloads, binds imported records to the destination school, and aborts the whole transaction on an unexpected table/FK failure.
- Added dynamic validation for single-column public foreign keys where both sides are school-scoped, rejecting references from the destination school to another school's records.
- Updated the backup screen to use the exact-school export/restore RPCs rather than selecting an arbitrary first school when an account is linked to multiple institutions.

## Important scope boundary

This is a same-platform Smart School backup transfer, not a universal importer for unrelated school software. It does not import Supabase Auth accounts or recreate parent/teacher/driver login identities. The current backup allowlist also does not include every possible account/profile/link table. After transfer, account identities and relationships outside the allowlist must be recreated or mapped through a separately authorized workflow.

For an unrelated legacy system, the current Excel importer handles student records only. Financial history, parent links, historical grades, staff identities, and archives require dedicated source-specific mapping and validation before importing; they are not silently guessed.

## Deployment order

1. Apply `supabase/migrations/phase83_institution_migration_assistant.sql`.
2. Apply `supabase/migrations/phase84_secure_backup_migration.sql`.
3. Deploy the updated project files.
4. Sign in as the destination school's admin/director, open **مساعد ترحيل المؤسسات**, inspect the backup, and review the table preview before confirming.

## Safety notes

- Restore inserts missing rows only (`ON CONFLICT DO NOTHING`); it does not overwrite existing rows.
- The operation is transactional: unexpected SQL/FK errors roll back the restore rather than leaving an unnoticed partial import.
- No Auth users or passwords are transferred.
- Successful imports are never deleted automatically as rollback. A rollback that could remove referenced student, payment, attendance, or transport records requires a separate reviewed recovery plan.
- Cross-tenant FK validation covers single-column public FK relationships for source tables with an `id` column and school-scoped referenced tables. Composite/global-account references are outside this validator and must not be assumed migrated.

## Verification status

- JavaScript syntax checks: passed for all modules.
- HTML tag-count sanity checks: passed for the edited admin page and other app pages.
- Live Supabase migration execution, RPC integration, RLS behavior, and cross-tenant adversarial tests: not run in this workspace because no live database session is available.
- Vite production build: not run because dependencies are not installed; the earlier dependency installation attempt did not complete in the available execution window.
