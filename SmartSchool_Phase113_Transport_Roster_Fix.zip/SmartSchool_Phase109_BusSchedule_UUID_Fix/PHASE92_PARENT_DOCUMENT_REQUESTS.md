# Phase 92 — Parent Document Requests

## Purpose
Adds a secure workflow for parents to request school documents and track progress from the existing parent portal.

## Parent workflow
- Select a linked child from the children already returned by `fn_my_children`.
- Submit an enrollment certificate, transfer certificate, report-card copy, or other-document request.
- Add an optional purpose/note.
- View request status and the school's response.

## School workflow
- The Reports view includes a request inbox with status filtering.
- Staff can move requests through review, approval, rejection, ready, and delivered states.
- Rejection requires a reason.
- A request cannot be marked READY unless it is linked to an active archive document belonging to the same school and student.
- The archive file must first be uploaded through Phase 91's private archive workflow.

## Security
- Parent submission checks `fn_is_parent_of(student_id)` server-side; the browser cannot assert a parent identity or school.
- Parent listing is filtered by `auth.uid()`.
- Staff listing and updates derive the school from `user_roles` and permit only `admin` / `director`.
- Direct table access is revoked; all operations use SECURITY DEFINER RPCs with a fixed search path.
- Archive links remain private and are not exposed by the request listing RPC.

## Migration
Apply `supabase/migrations/phase92_parent_document_requests.sql` after Phase 91.

## Validation scope
Static JavaScript syntax, key UI/RPC wiring, SQL policy/grant structure, and ZIP integrity are checked locally. No live Supabase migration, authenticated multi-role test, Storage upload, or browser end-to-end test has been run. Apply the migration to a staging project and test with a parent account and a school admin before production.
