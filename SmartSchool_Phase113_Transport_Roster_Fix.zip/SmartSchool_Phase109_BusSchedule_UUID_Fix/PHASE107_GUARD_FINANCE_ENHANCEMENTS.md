# Phase 107 — Guard General: finance workflow enhancements

## Included
- Selecting a student opens a modal with unpaid/partially paid fee obligations (monthly periods and other fee types).
- The guard selects one or more obligations and enters the received amount; the batch RPC allocates it across selected outstanding balances without exceeding them.
- Payment method supports cash, bank transfer, cheque and other. Receipt/cheque reference and free-text note are saved in the transaction notes/receipt fields.
- Optional cheque/bank transfer proof image upload. Images are resized to a maximum 2200px edge and JPEG-compressed with a quality floor of 0.75-ish, normally preserving legibility while reducing storage size.
- Expense invoice/receipt image upload with the same compression path.
- Finance documents are stored in a private Supabase Storage bucket and metadata is saved in `finance_documents`; signed URLs are shown in recent records.
- Daily, weekly, monthly and custom date-range cashbox report with income, expenses, net balance and printable detail rows.

## Migration
Apply `supabase/migrations/phase107_guard_finance_documents_reports.sql` after the existing Phase 100 migration.

## Permissions
The existing `finance.manage` permission is required to upload/link documents. Viewing document links and reports uses `finance.view` or `finance.manage`. Ensure the guard has the corresponding permissions assigned in the admin panel.

## Notes / validation
- Fee obligations must already have been generated for the student's active academic year; otherwise the modal explains that no unpaid dues were found.
- The report uses up to the latest 500 payment and 500 expense records returned by the existing list RPCs; it is not an unlimited historical ledger export.
- Browser JavaScript syntax checks are included in the delivery validation. A full Vite build and live Supabase integration test were not run in this environment.
