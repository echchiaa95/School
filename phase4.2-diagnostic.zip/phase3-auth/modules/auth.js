// ============================================================================
// modules/auth.js
// Central auth service. Every page imports ONLY from here.
//
// PHASE 3.2: email+password login replaced by PIN login.
// PHASE 3.3: the PIN is no longer used ALONE as the account identifier.
// Login now requires two factors, matching one of:
//   - QR method:     { method: 'qr',     qr_token, pin }
//   - Manual method:  { method: 'manual', user_number, pin }
// The identifier (qr_token / user_number) selects the ACCOUNT; the PIN
// still AUTHENTICATES it. Neither alone creates a session — see
// fn_verify_login in supabase/migrations/phase3_3_qr_manual_login.sql.
//
// The PIN itself is NEVER checked in this file (or anywhere in the
// browser). login() calls the `login-with-pin` Edge Function, which
// verifies method+identifier+pin server-side and returns a one-time
// `token_hash`. The frontend exchanges that for a REAL Supabase session via
// supabase.auth.verifyOtp() — using only the public anon-key client, same
// mechanism as a magic-link login. getSession() / getCurrentUser() /
// requireAuth() are unaffected by any of this.
//
// SECURITY NOTES (unchanged from Phase 3):
// - No role/school_id/user_id is ever trusted from the URL, localStorage,
//   sessionStorage, or client state. Every fact here comes from a live query
//   against `profiles` / `user_roles`, protected by RLS.
// - Real authorization for any data mutation still happens in Postgres RPCs.
// ============================================================================

import { supabase } from './supabase.js';
import { homePageForRole, isRoleAllowedOnPage, pickPrimaryRole } from './permissions.js';

const PIN_REGEX = /^\d{4}$/;

/**
 * Authenticate with two factors: an identifier (QR token or user number)
 * plus a 4-digit PIN. Either alone is rejected server-side.
 *
 * PHASE 3.4: on success, also returns the account's user_number (when the
 * account has one) so the caller can remember this device (see
 * modules/device.js) and skip QR/manual identification next time — the
 * remembered flow simply replays method:'manual' with that cached
 * user_number, reusing this exact function and the exact same server-side
 * checks. Nothing about verification itself changes.
 *
 * @param {'qr'|'manual'} method
 * @param {string} identifier - qr_token for 'qr', user_number for 'manual'
 * @param {string} pin - exactly 4 digits
 * @returns {Promise<{ok: true, userNumber: string|null} | {ok: false, error: string}>}
 */
export async function login(method, identifier, pin) {
  if (method !== 'qr' && method !== 'manual') {
    return { ok: false, error: 'INVALID_METHOD' };
  }
  if (!identifier || typeof identifier !== 'string') {
    return { ok: false, error: 'INVALID_IDENTIFIER' };
  }
  if (!PIN_REGEX.test(pin)) {
    return { ok: false, error: 'INVALID_FORMAT' };
  }

  const body =
    method === 'qr'
      ? { method: 'qr', qr_token: identifier, pin }
      : { method: 'manual', user_number: identifier, pin };

  // TEMPORARY DIAGNOSTIC (per explicit request) — never logs the PIN itself.
  console.log('[AUTH DEBUG] Login transport:', 'Edge Function login-with-pin');
  console.log('[AUTH DEBUG] Method:', method, '| Identifier:', identifier);

  let invokeResult;
  try {
    invokeResult = await supabase.functions.invoke('login-with-pin', { body });
  } catch (err) {
    // TEMPORARY DIAGNOSTIC: the request never got an HTTP response at all
    // (DNS failure, CORS rejection before any response, connection refused,
    // wrong project ref typo, etc.) — distinct from the function responding
    // with an error status, handled below.
    console.error('[AUTH DEBUG] EDGE_FUNCTION_NETWORK_ERROR:', {
      name: err?.name, message: err?.message,
    });
    return { ok: false, error: 'NETWORK_ERROR' };
  }

  const { data, error } = invokeResult;

  if (error) {
    // TEMPORARY DIAGNOSTIC: the request DID reach an HTTP endpoint and got
    // a response — this is a real HTTP-level failure (function missing/not
    // deployed on this project -> 404, function threw -> 500, CORS origin
    // rejected -> a response with no allow-origin header surfaces here too,
    // etc.), NOT a "wrong PIN". Never logs the PIN, a token, or a key.
    const httpStatus = error.status ?? error.context?.status ?? null;
    let contextBodyText = null;
    try {
      // error.context is typically the raw Response object from the
      // Edge Function call; reading its body is best-effort only (it may
      // already be consumed, or absent, depending on the failure mode).
      if (error.context && typeof error.context.text === 'function') {
        contextBodyText = await error.context.text();
      }
    } catch {
      contextBodyText = '(could not read response body)';
    }

    console.error('[AUTH DEBUG] EDGE_FUNCTION_HTTP_ERROR:', {
      name: error.name,
      message: error.message,
      status: error.status ?? null,
      contextStatus: error.context?.status ?? null,
      contextBodyText,
    });
    if (httpStatus === 401 || httpStatus === 403 || httpStatus === 404 || httpStatus === 500) {
      console.error(`[AUTH DEBUG] login-with-pin responded HTTP ${httpStatus} — `
        + (httpStatus === 404
          ? 'function likely not deployed on this Supabase project.'
          : httpStatus === 401 || httpStatus === 403
          ? 'auth/CORS rejection before the function logic ran (check verify_jwt=false and ALLOWED_ORIGINS).'
          : 'the function was reached but threw an internal error — check its server logs.'));
    }
    return { ok: false, error: 'INVALID_CREDENTIALS' };
  }

  if (!data?.token_hash) {
    // TEMPORARY DIAGNOSTIC: the function responded successfully (HTTP 200,
    // no `error`) but didn't return a token_hash — this is the ONLY case
    // that genuinely means "wrong PIN / unknown identifier / disabled /
    // locked / rate-limited", the four cases the Edge Function
    // intentionally can't distinguish from each other by design.
    console.log('[AUTH DEBUG] EDGE_FUNCTION_NO_TOKEN_HASH — function responded OK but returned no token_hash. Response data:', data);
    return { ok: false, error: 'INVALID_CREDENTIALS' };
  }

  const { data: verifyData, error: verifyError } = await supabase.auth.verifyOtp({
    token_hash: data.token_hash,
    type: 'magiclink',
  });

  if (verifyError) {
    // TEMPORARY DIAGNOSTIC: the Edge Function succeeded and returned a
    // token_hash, but exchanging it for a session failed — this points at
    // a mismatch between the `type` used in generateLink() (server side)
    // and the `type` used here in verifyOtp(), or an expired/already-used
    // token_hash. This is NOT a PIN problem.
    console.error('[AUTH DEBUG] VERIFY_OTP_ERROR:', {
      name: verifyError.name, message: verifyError.message, status: verifyError.status ?? null,
    });
    return { ok: false, error: 'INVALID_CREDENTIALS' };
  }
  console.log('[AUTH DEBUG] verifyOtp succeeded, session present:', !!verifyData?.session);

  return { ok: true, userNumber: data.user_number ?? null };
}

/**
 * Sign out and send the user back to the login page.
 */
export async function logout() {
  await supabase.auth.signOut();
  window.location.href = 'index.html';
}

/**
 * Raw Supabase session (has the JWT), or null if not logged in.
 */
export async function getSession() {
  const { data, error } = await supabase.auth.getSession();
  if (error) {
    console.error('getSession error:', error);
    return null;
  }
  return data.session;
}

/**
 * Raw Supabase auth user (id, email, etc.), or null if not logged in.
 */
export async function getCurrentUser() {
  const { data, error } = await supabase.auth.getUser();
  if (error) {
    console.error('getCurrentUser error:', error);
    return null;
  }
  return data.user;
}

/**
 * The current user's row from `profiles`, or null if not logged in, no
 * profile exists, or the account has been disabled.
 */
async function loadCurrentProfile(userId) {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, full_name, phone, avatar_url, is_disabled')
    .eq('id', userId)
    .single();

  if (error) {
    console.error('loadCurrentProfile error:', error);
    return null;
  }
  return data;
}

/**
 * All of the current user's (school_id, role) pairs from `user_roles`.
 */
async function loadUserRoles() {
  const { data, error } = await supabase
    .from('user_roles')
    .select('school_id, role');

  if (error) {
    console.error('loadUserRoles error:', error);
    return [];
  }
  return data || [];
}

/**
 * PHASE 3.2 — single source of truth for "who is logged in and as what".
 * Verifies, in order: session -> user -> profile exists & not disabled ->
 * roles exist -> deterministic primary role (see ROLE_PRIORITY).
 * Used by both redirectToRoleHome() and requireAuth() so the two can never
 * disagree about who the user is.
 *
 * @returns {Promise<{
 *   session: object, user: object, profile: object,
 *   role: string, schoolId: string
 * } | null>} null means "not authenticated" — caller must send to login.
 */
export async function getAuthenticatedContext() {
  const session = await getSession();
  if (!session) return null;

  const user = await getCurrentUser();
  if (!user) return null;

  const profile = await loadCurrentProfile(user.id);
  if (!profile || profile.is_disabled) return null;

  const roles = await loadUserRoles();
  const primary = pickPrimaryRole(roles);
  if (!primary) return null;

  return {
    session,
    user,
    profile,
    role: primary.role,
    schoolId: primary.school_id,
  };
}

/**
 * Send the user to the home page for their role. Call right after a
 * successful login().
 */
export async function redirectToRoleHome() {
  const ctx = await getAuthenticatedContext();
  if (!ctx) {
    console.error('No valid authenticated context after login.');
    await logout();
    return;
  }
  const page = homePageForRole(ctx.role);
  if (!page) {
    console.error('Unknown role, cannot route:', ctx.role);
    await logout();
    return;
  }
  window.location.href = page;
}

/**
 * Page guard: call this at the top of every role-specific page
 * (guard.html, director.html, teacher.html, driver.html, parent.html).
 * Returns the authenticated context on success, or null after already
 * redirecting the user somewhere appropriate (login page, or their real
 * role home if they hit the wrong page).
 */
export async function requireAuth(currentPageFileName) {
  const ctx = await getAuthenticatedContext();
  if (!ctx) {
    window.location.href = 'index.html';
    return null;
  }

  if (!isRoleAllowedOnPage(ctx.role, currentPageFileName)) {
    await redirectToRoleHome();
    return null;
  }

  return ctx;
}

/**
 * Keep the UI in sync if the session changes in another tab (login/logout).
 */
export function onAuthStateChange(callback) {
  return supabase.auth.onAuthStateChange((_event, session) => {
    callback(session);
  });
}
