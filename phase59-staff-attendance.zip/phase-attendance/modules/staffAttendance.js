// ============================================================================
// modules/staffAttendance.js
// حضور الموظفين اليومي — يُستعمل من admin.html و guard.html
// ============================================================================
import { supabase } from './supabase.js';

export async function listSchoolStaff(schoolId) {
  const { data, error } = await supabase.rpc('fn_list_school_staff', { p_school_id: schoolId });
  if (error) throw error;
  return data || [];
}

export async function markStaffAttendance({ profileId, workDate, status, checkInAt = null, checkOutAt = null, notes = null }) {
  const { data, error } = await supabase.rpc('fn_mark_staff_attendance', {
    p_profile_id: profileId,
    p_work_date: workDate,
    p_status: status,
    p_check_in_at: checkInAt,
    p_check_out_at: checkOutAt,
    p_notes: notes,
  });
  if (error) throw error;
  return data;
}

export async function staffCheckIn(profileId, workDate = new Date().toISOString().slice(0, 10)) {
  const { data, error } = await supabase.rpc('fn_staff_check_in', { p_profile_id: profileId, p_work_date: workDate });
  if (error) throw error;
  return data;
}

export async function staffCheckOut(profileId, workDate = new Date().toISOString().slice(0, 10)) {
  const { data, error } = await supabase.rpc('fn_staff_check_out', { p_profile_id: profileId, p_work_date: workDate });
  if (error) throw error;
  return data;
}

export async function getStaffAttendanceReport(profileId, fromDate, toDate) {
  const { data, error } = await supabase.rpc('fn_get_staff_attendance_report', {
    p_profile_id: profileId, p_from: fromDate, p_to: toDate,
  });
  if (error) throw error;
  return data || [];
}

export async function getSchoolAttendanceSummary(schoolId, fromDate, toDate) {
  const { data, error } = await supabase.rpc('fn_get_school_attendance_summary', {
    p_school_id: schoolId, p_from: fromDate, p_to: toDate,
  });
  if (error) throw error;
  return data || [];
}

// ---- عرض جدول الحضور اليومي (يُدرج داخل حاوية موجودة في admin.html/guard.html) ----
export function renderStaffAttendanceTable(containerEl, staffList, todayMap) {
  const rows = staffList.map(s => {
    const rec = todayMap.get(s.profile_id);
    const badge = rec
      ? `<span class="att-badge att-${rec.status.toLowerCase()}">${attLabel(rec.status)}</span>`
      : `<span class="att-badge att-none">لم يُسجَّل</span>`;
    return `
      <tr data-profile="${s.profile_id}">
        <td>${s.full_name} <small class="role-tag">${roleLabel(s.role)} · ${s.employment_type === 'HOURLY' ? 'بالساعة' : 'دوام كامل'}</small></td>
        <td>${badge}</td>
        <td>
          <button class="btn-xs btn-checkin" data-id="${s.profile_id}">دخول</button>
          <button class="btn-xs btn-checkout" data-id="${s.profile_id}">خروج</button>
          <button class="btn-xs btn-absent" data-id="${s.profile_id}">غياب</button>
          <button class="btn-xs btn-report" data-id="${s.profile_id}" data-name="${s.full_name}">التقرير</button>
        </td>
      </tr>`;
  }).join('');

  containerEl.innerHTML = `
    <table class="staff-att-table">
      <thead><tr><th>الموظف</th><th>حالة اليوم</th><th>إجراءات</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
}

function attLabel(status) {
  return { PRESENT: 'حاضر', ABSENT: 'غائب', LATE: 'متأخر', HALF_DAY: 'نصف يوم', LEAVE: 'إجازة' }[status] || status;
}
function roleLabel(role) {
  return { teacher: 'أستاذ', guard: 'حارس', driver: 'سائق' }[role] || role;
}

// ---- عرض تقرير حضور موظف واحد في نافذة/modal ----
export function renderStaffReport(containerEl, staffName, rows) {
  const totalHours = rows.reduce((sum, r) => sum + (Number(r.hours_worked) || 0), 0).toFixed(1);
  const present = rows.filter(r => r.status === 'PRESENT').length;
  const absent = rows.filter(r => r.status === 'ABSENT').length;

  containerEl.innerHTML = `
    <h3>تقرير حضور: ${staffName}</h3>
    <div class="report-stats">
      <span>أيام الحضور: ${present}</span>
      <span>أيام الغياب: ${absent}</span>
      <span>إجمالي الساعات: ${totalHours}</span>
    </div>
    <table class="staff-att-table">
      <thead><tr><th>التاريخ</th><th>الحالة</th><th>دخول</th><th>خروج</th><th>ساعات</th></tr></thead>
      <tbody>
        ${rows.map(r => `
          <tr>
            <td>${r.work_date}</td>
            <td>${attLabel(r.status)}</td>
            <td>${r.check_in_at ? new Date(r.check_in_at).toLocaleTimeString('ar-MA', { hour: '2-digit', minute: '2-digit' }) : '—'}</td>
            <td>${r.check_out_at ? new Date(r.check_out_at).toLocaleTimeString('ar-MA', { hour: '2-digit', minute: '2-digit' }) : '—'}</td>
            <td>${r.hours_worked ?? '—'}</td>
          </tr>`).join('')}
      </tbody>
    </table>`;
}
