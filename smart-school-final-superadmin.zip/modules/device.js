// ============================================================================
// modules/device.js
// PHASE 3.4 — "remember this device" so QR/manual identification is only
// asked once per device, not on every app open.
//
// THIS IS THE ONLY FILE IN THE WHOLE PROJECT THAT TOUCHES localStorage FOR
// AUTH PURPOSES. Keeping it isolated here means an audit of "what's stored
// locally" is a read of this one file, not a grep across the codebase.
//
// WHAT IS STORED (and why it's safe to):
//   { userNumber: "10001" }
// A user_number is the same value the person would otherwise type by hand
// on the manual-login screen — it identifies WHICH account to check the PIN
// against, nothing more. It is NOT a credential: fn_verify_login() still
// requires the correct PIN for that exact account, still runs the same
// disabled/lockout/rate-limit checks, and still never trusts anything the
// client sends as an authorization decision.
//
// WHAT IS NEVER STORED HERE (or anywhere in this project):
//   - the PIN, in any form (plaintext or hashed)
//   - the QR token (explicitly excluded — it must be re-scanned if the
//     device forgets its association, never cached long-term)
//   - the Supabase Service Role Key or any Supabase secret
//   - a Supabase session/JWT (that's Supabase-js's own concern via
//     persistSession, entirely separate from this module)
//   - any value that by itself would grant access
// ============================================================================

const STORAGE_KEY = 'ssms_device_identity';

/**
 * @returns {{userNumber: string} | null} the remembered account for this
 * device, or null if none (or if malformed — treated the same as none).
 */
export function getDeviceIdentity() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed.userNumber !== 'string' || !parsed.userNumber) {
      return null;
    }
    return { userNumber: parsed.userNumber };
  } catch {
    return null;
  }
}

/**
 * Remember this device as belonging to the given user_number. Call after a
 * successful login() — no-ops silently if userNumber is falsy (e.g. a QR
 * login for an account that has no user_number assigned yet; that account
 * simply keeps requiring QR scan every time until one is provisioned).
 */
export function setDeviceIdentity(userNumber) {
  if (!userNumber) return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ userNumber }));
  } catch {
    // localStorage unavailable (private mode, quota, etc.) — degrade
    // gracefully to "always ask for QR/manual", never throw.
  }
}

/**
 * "Utiliser un autre compte" — forgets ONLY this device's local
 * association. Never touches the server: the account, its roles, and its
 * PIN are all untouched. The current Supabase session (if any) is the
 * caller's responsibility to end via logout(), kept as a separate step so
 * this module stays purely about local storage.
 */
export function clearDeviceIdentity() {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}
