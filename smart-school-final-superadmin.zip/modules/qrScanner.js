// ============================================================================
// modules/qrScanner.js
// Thin wrapper around getUserMedia + jsQR (loaded globally via CDN in
// index.html, see window.jsQR). No build step, works on GitHub Pages.
//
// This module only ever DECODES the QR's text content and hands it back —
// it makes no network calls and knows nothing about accounts, PINs, or
// sessions. What the decoded text means is entirely the caller's business
// (modules/auth.js treats it as an opaque qr_token).
// ============================================================================

let activeStream = null;
let rafId = null;

/**
 * Start the back camera and continuously scan frames for a QR code.
 * @param {HTMLVideoElement} videoEl
 * @param {HTMLCanvasElement} canvasEl - offscreen canvas used for decoding
 * @param {(text: string) => void} onDecoded - called once, scanning stops after
 * @param {(reason: 'NO_CAMERA'|'PERMISSION_DENIED'|'UNKNOWN') => void} onError
 */
export async function startQrScanner(videoEl, canvasEl, onDecoded, onError) {
  if (!navigator.mediaDevices?.getUserMedia) {
    onError('NO_CAMERA');
    return;
  }
  if (typeof window.jsQR !== 'function') {
    console.error('jsQR library not loaded');
    onError('UNKNOWN');
    return;
  }

  try {
    activeStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'environment' },
      audio: false,
    });
  } catch (err) {
    console.error('getUserMedia error:', err);
    onError(err?.name === 'NotAllowedError' ? 'PERMISSION_DENIED' : 'NO_CAMERA');
    return;
  }

  videoEl.srcObject = activeStream;
  await videoEl.play();

  const canvasCtx = canvasEl.getContext('2d', { willReadFrequently: true });
  let decoded = false;

  function tick() {
    if (decoded) return;

    if (videoEl.readyState === videoEl.HAVE_ENOUGH_DATA) {
      canvasEl.width = videoEl.videoWidth;
      canvasEl.height = videoEl.videoHeight;
      canvasCtx.drawImage(videoEl, 0, 0, canvasEl.width, canvasEl.height);
      const imageData = canvasCtx.getImageData(0, 0, canvasEl.width, canvasEl.height);
      const result = window.jsQR(imageData.data, imageData.width, imageData.height);

      if (result?.data) {
        decoded = true;
        stopQrScanner();
        onDecoded(result.data);
        return;
      }
    }
    rafId = requestAnimationFrame(tick);
  }

  rafId = requestAnimationFrame(tick);
}

/**
 * Stop the camera and any pending scan loop. Safe to call multiple times.
 */
export function stopQrScanner() {
  if (rafId) {
    cancelAnimationFrame(rafId);
    rafId = null;
  }
  if (activeStream) {
    activeStream.getTracks().forEach((track) => track.stop());
    activeStream = null;
  }
}
