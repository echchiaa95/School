// ============================================================================
// modules/admin.js
// PHASE 4.4 — Admin's Guard management (director.html). Kept as its own
// file, same reasoning as modules/accounts.js: one focused module per
// management domain rather than one growing monolith.
//
// READS go through the existing RLS-protected `supabase` client
// (p_guards_staff / p_profiles_staff_read / p_guard_permissions_staff —
// all from Phase 2/4.2, unchanged, already scoped to the caller's school).
// WRITES go through: the extended create-staff-account Edge Function
// (account creation), and the EXISTING fn_grant_guard_permission /
// fn_revoke_guard_permission RPCs (Phase 4.2) plus the ONE new function
// fn_set_guard_status (Phase 4.4) for enable/disable.
// ============================================================================

import { supabase } from './supabase.js';

/**
 * Guards in the caller's own school (RLS-scoped), each annotated with its
 * current granted-permission count. Two queries total, not one-per-guard.
 */
export async function listGuards(query) {
  const { data: guards, error } = await supabase
    .from('guards')
    .select('id, profile_id, school_id, profiles(full_name, phone, user_number, is_disabled)')
    .order('id');
  if (error) {
    console.error('listGuards error:', error);
    return [];
  }
  const rows = guards || [];

  const profileIds = rows.map((g) => g.profile_id);
  let countByProfile = {};
  if (profileIds.length > 0) {
    const { data: grants } = await supabase
      .from('guard_permissions')
      .select('profile_id')
      .in('profile_id', profileIds);
    (grants || []).forEach((g) => {
      countByProfile[g.profile_id] = (countByProfile[g.profile_id] || 0) + 1;
    });
  }

  let results = rows.map((g) => ({
    guardId: g.id,
    profileId: g.profile_id,
    schoolId: g.school_id,
    fullName: g.profiles?.full_name || '—',
    userNumber: g.profiles?.user_number || '—',
    isDisabled: !!g.profiles?.is_disabled,
    permissionCount: countByProfile[g.profile_id] || 0,
  }));

  const q = (query || '').trim().toLowerCase();
  if (q) {
    results = results.filter((g) =>
      g.fullName.toLowerCase().includes(q) || g.userNumber.toLowerCase().includes(q)
    );
  }
  return results;
}

/** All permission catalog keys, grouped by module — for the checklist UI. */
export async function listAllPermissions() {
  const { data, error } = await supabase
    .from('permissions')
    .select('permission_key, module, name')
    .order('module');
  if (error) {
    console.error('listAllPermissions error:', error);
    return [];
  }
  return data || [];
}

/** The specific permission_keys currently granted to one guard. */
export async function getGuardPermissions(profileId, schoolId) {
  const { data, error } = await supabase
    .from('guard_permissions')
    .select('permissions(permission_key)')
    .eq('profile_id', profileId)
    .eq('school_id', schoolId);
  if (error) {
    console.error('getGuardPermissions error:', error);
    return new Set();
  }
  return new Set((data || []).map((r) => r.permissions?.permission_key).filter(Boolean));
}

/**
 * Create a guard account via the (Phase 4.4-extended) create-staff-account
 * Edge Function. school_id is never sent — derived server-side from the
 * admin's own session, exactly like teacher/driver/parent creation.
 */
export async function createGuardAccount({ fullName, userNumber, pin, phone }) {
  const { data, error } = await supabase.functions.invoke('create-staff-account', {
    body: { accountType: 'guard', fullName, userNumber, pin, phone },
  });
  if (error) {
    let message = 'تعذر إنشاء الحساب';
    try {
      const bodyText = await error.context?.text?.();
      if (bodyText) {
        const parsed = JSON.parse(bodyText);
        if (parsed?.error) message = parsed.error;
      }
    } catch {
      // fall back to the generic message
    }
    return { ok: false, error: message };
  }
  if (!data?.ok) return { ok: false, error: data?.error || 'تعذر إنشاء الحساب' };
  return { ok: true, profileId: data.profileId, userNumber: data.userNumber };
}

/**
 * Enable/disable a guard. Calls the ONE new RPC (fn_set_guard_status,
 * Phase 4.4) — never touches profiles directly (no client-facing UPDATE
 * policy exists on profiles for anyone but the profile's own owner).
 */
export async function setGuardStatus(profileId, isDisabled) {
  const { error } = await supabase.rpc('fn_set_guard_status', {
    p_profile_id: profileId, p_is_disabled: isDisabled,
  });
  if (error) return { ok: false, error: error.message };
  return { ok: true };
}

/** Grant one permission — reuses the existing, unmodified Phase 4.2 RPC. */
export async function grantPermission(profileId, schoolId, permissionKey) {
  const { error } = await supabase.rpc('fn_grant_guard_permission', {
    p_profile_id: profileId, p_school_id: schoolId, p_permission_key: permissionKey,
  });
  if (error) return { ok: false, error: error.message };
  return { ok: true };
}

/** Revoke one permission — reuses the existing, unmodified Phase 4.2 RPC. */
export async function revokePermission(profileId, schoolId, permissionKey) {
  const { error } = await supabase.rpc('fn_revoke_guard_permission', {
    p_profile_id: profileId, p_school_id: schoolId, p_permission_key: permissionKey,
  });
  if (error) return { ok: false, error: error.message };
  return { ok: true };
}
