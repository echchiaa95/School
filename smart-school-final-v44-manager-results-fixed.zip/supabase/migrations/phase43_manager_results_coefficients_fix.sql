-- PHASE 43 — Manager results selectors + simple subject coefficients
-- MUTATING SQL: run once in Supabase SQL Editor.

create or replace function public.fn_set_grade_subject_coefficient(
  p_class_id uuid,
  p_subject_id uuid,
  p_coefficient numeric
)
returns public.grade_subject_coefficients
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_year_id uuid;
  v_row public.grade_subject_coefficients;
begin
  if p_coefficient is null or p_coefficient <= 0 then
    raise exception 'COEFFICIENT_INVALID';
  end if;

  select c.school_id, c.academic_year_id
    into v_school_id, v_year_id
  from public.classes c
  where c.id = p_class_id
    and c.is_disabled = false;

  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;

  if not exists (select 1 from public.subjects s where s.id = p_subject_id) then
    raise exception 'INVALID_SUBJECT';
  end if;

  insert into public.grade_subject_coefficients as gsc
    (school_id, class_id, subject_id, academic_year_id, coefficient, created_by, updated_at)
  values
    (v_school_id, p_class_id, p_subject_id, v_year_id, p_coefficient, auth.uid(), now())
  on conflict (class_id, subject_id, academic_year_id)
  do update set
    coefficient = excluded.coefficient,
    updated_at = now()
  returning gsc.* into v_row;

  return v_row;
end;
$$;

revoke all on function public.fn_set_grade_subject_coefficient(uuid, uuid, numeric) from public;
grant execute on function public.fn_set_grade_subject_coefficient(uuid, uuid, numeric) to authenticated;

-- Explicit aliases avoid the previous ambiguous subject_id reference.
create or replace function public.fn_grade_subject_coefficients(p_class_id uuid)
returns table(subject_id uuid, subject_name text, coefficient numeric)
language sql
stable
security definer
set search_path = public
as $$
  select
    s.id as subject_id,
    s.name as subject_name,
    coalesce(gsc.coefficient, 1)::numeric as coefficient
  from public.subjects as s
  left join public.grade_subject_coefficients as gsc
    on gsc.subject_id = s.id
   and gsc.class_id = p_class_id
  order by s.name;
$$;

revoke all on function public.fn_grade_subject_coefficients(uuid) from public;
grant execute on function public.fn_grade_subject_coefficients(uuid) to authenticated;
