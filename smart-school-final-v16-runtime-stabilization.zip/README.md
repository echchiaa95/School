# Smart School Management System — README

منصة إدارة مدرسية (School Management SaaS) عربية RTL، مبنية على HTML/JS ثابت + Supabase (Auth + Postgres + RLS + Edge Functions).

## النشر

### 1) ملفات الواجهة (Frontend)
ارفع محتويات هذا المجلد كما هو إلى استضافة الملفات الثابتة (الجذر يحتوي `index.html`).

### 2) قاعدة البيانات — ترتيب تنفيذ الـ migrations
نفّذ ملفات `supabase/migrations/` بالترتيب التالي (كلها additive وآمنة لإعادة التنفيذ):

1. `phase3_2_pin_login.sql`
2. `phase3_3_qr_manual_login.sql`
3. `phase3_4_remembered_device.sql`
4. `phase4_guard_checks.sql`
5. `phase4_2_permissions_system.sql`
6. `phase4_2_1_security_hardening.sql`
7. `phase4_4_guard_management.sql`
8. `phase5_2_first_superadmin_seed.sql`
9. `phase8_superadmin.sql`
10. `phase9_superadmin_global.sql`
11. `phase10_academic_structure.sql`
12. `phase11_school_creation.sql`
13. `phase12_complete_platform_v5.sql` ← **المنصة الكاملة (مطابقة لمخطط phase2 الفعلي)**
14. `phase12_1_hardening.sql` ← **تشديد الأمان (صلاحيات، عزل، حماية السنة الحالية)**
15. `phase13_fixes.sql` ← **إصلاحات: شمول دور director في fn_is_admin_or_guard + إكمال سجلات staff الناقصة**

ملاحظة: الدوال الأصلية `fn_register_student` / `fn_issue_badge` / `fn_reissue_badge` / `fn_suspend_badge` وجداول المرحلة الأولى (profiles, user_roles, students, badges…) يفترض أنها موجودة من الإعداد الأولي للمشروع.

### 3) Edge Functions — يجب نشر/إعادة نشر الاثنتين
```
supabase functions deploy create-platform-user
supabase functions deploy create-staff-account
```
كلتاهما تستخدمان service_role داخل الخادم فقط، مع التحقق من JWT المتصل وصلاحياته، وCORS مقيد بالنطاق الإنتاجي.

## الأدوار
superadmin / admin / director / guard / teacher / driver / parent — المصدر الوحيد للصلاحية هو جدول `user_roles` + `user_permissions`، وكل عملية حساسة تمر عبر RPC بنمط SECURITY DEFINER يستخرج المؤسسة من `auth.uid()`.

## نظام الصلاحيات (Phase 12)
- جدول `user_permissions` (profile_id, school_id, permission_key).
- الحارس لا يحصل على أي صلاحية تلقائيًا؛ تُمنح من المدير/الإداري عبر صفحة «الحراس والصلاحيات».
- الإنفاذ حقيقي في PostgreSQL (`fn_has_permission` أصبح يقرأ المنح الفعلية) وليس مجرد إخفاء أزرار.

## الأمان
- لا مفاتيح سرية في الواجهة (anon key فقط).
- الجداول الجديدة RLS مفعّل بدون سياسات متساهلة — الوصول عبر RPC فقط.
- الـ audit لا يسجل كلمات مرور أو أسرارًا.
- تعطيل الحسابات مفضّل على الحذف؛ لا يمكن تعطيل آخر SuperAdmin.


## PHASE 26 — V12 HOTFIX
- إصلاح مخطط Audit الحقيقي (`actor_id`, `old_value`, `new_value`).
- إضافة تخزين شعار المؤسسة من الهاتف في `school-logos`.
- تحسين أخطاء الخريطة ورفع الشعار وQR.
