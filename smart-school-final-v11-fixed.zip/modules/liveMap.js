// ============================================================================
// modules/liveMap.js
// Admin "live bus tracking" map. Leaflet/OSM (same reasoning as
// mapPicker.js — no Google Maps API key exists in this project). Combines:
//   1) An initial fetch + periodic poll of fn_get_active_bus_locations
//      (always correct even if Realtime is unavailable on this project's
//      Supabase plan/config).
//   2) A Supabase Realtime subscription on bus_last_locations so a marker
//      actually glides to a new point the instant a GPS ping lands,
//      instead of waiting for the next poll.
// If a bus's last ping is older than STALE_MS, its marker is shown as
// stale ("⚠️ آخر تحديث منذ...") rather than silently left in place with
// no indication (item 23: never fake movement, always show staleness).
// ============================================================================

import { supabase } from './supabase.js';
import { getActiveBusLocations, getAllBusesStatus, listBusTrips, getTripRouteHistory } from './school.js';
import { loadLeaflet } from './mapPicker.js';
import { esc, fmtTime } from './ui.js';

const POLL_MS = 12000;
const STALE_MS = 75000; // item 1: 60-90s stale threshold, visually obvious

let map = null;
let markers = {}; // bus_id -> L.marker
let pollTimer = null;
let realtimeChannel = null;

function timeAgoAr(iso) {
  if (!iso) return '—';
  const s = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `منذ ${s} ثانية`;
  const m = Math.floor(s / 60);
  if (m < 60) return `منذ ${m} دقيقة`;
  return `منذ ${Math.floor(m / 60)} ساعة`;
}

function busIcon(stale) {
  return window.L.divIcon({
    html: `<div style="font-size:26px; filter:${stale ? 'grayscale(1) opacity(0.6)' : 'none'};">🚌</div>`,
    className: '', iconSize: [30, 30], iconAnchor: [15, 15],
  });
}

function popupHtml(row, stale) {
  const passengers = row.total_students != null ? `${row.boarded_count ?? 0}/${row.total_students}` : '—';
  return `<div style="min-width:190px; text-align:right;">
    <strong>${esc(row.bus_code || row.bus_plate || 'الحافلة')}</strong><br>
    الترقيم: ${esc(row.bus_plate || '—')}<br>
    السائق: ${esc(row.driver_name || 'بدون سائق')}<br>
    الركاب: ${passengers}${row.dropped_count ? ` (نزل: ${row.dropped_count})` : ''}<br>
    الاتجاه: ${row.direction === 'pickup' ? 'نحو المؤسسة' : 'نحو المنزل'}<br>
    ${row.speed != null ? `السرعة: ${Math.round(row.speed * 3.6)} كم/س<br>` : ''}
    آخر تحديث: ${row.recorded_at ? timeAgoAr(row.recorded_at) : 'لا يوجد بعد'}<br>
    GPS: ${stale ? '<span style="color:#dc2626;">⚠️ غير محدَّث</span>' : '<span style="color:#16a34a;">🟢 متصل</span>'}
  </div>`;
}

function statusListHtml(rows) {
  const connected = rows.filter((r) => r.recorded_at && (Date.now() - new Date(r.recorded_at).getTime() <= STALE_MS));
  const disconnected = rows.filter((r) => !connected.includes(r));

  const row = (r, why) => `<div class="detail-row" style="flex-wrap:wrap; gap:6px;">
    <div style="flex:1; min-width:140px;">
      <strong>${esc(r.bus_code || r.bus_plate || 'حافلة')}</strong> <span class="time">${esc(r.bus_plate || '')}</span><br>
      <span class="time">${esc(r.driver_name || 'بدون سائق')}${r.route_name ? ' · ' + esc(r.route_name) : ''}</span>
    </div>
    ${r.direction ? `<span class="badge badge-blue">${r.direction === 'pickup' ? 'نحو المؤسسة' : 'نحو المنزل'}</span>` : ''}
    ${r.total_students != null ? `<span class="badge">${r.boarded_count ?? 0}/${r.total_students} 🧑‍🎓</span>` : ''}
    <span class="time">${why}</span>
    <button type="button" class="quick-action-btn secondary" data-history="${r.bus_id}" data-label="${esc(r.bus_code || r.bus_plate || '')}" style="padding:4px 10px; font-size:.85em;">عرض الرحلة</button>
  </div>`;

  return `
    <p class="section-title" style="margin-top:14px;">🟢 الحافلات المتصلة (${connected.length})</p>
    <div class="panel">${connected.length ? connected.map((r) => row(r, `منذ ${timeAgoAr(r.recorded_at)}`)).join('') : '<div class="empty-state">لا توجد حافلات متصلة حاليًا.</div>'}</div>
    <p class="section-title">⚪ الحافلات غير المتصلة (${disconnected.length})</p>
    <div class="panel">${disconnected.length ? disconnected.map((r) => {
      const why = !r.trip_id ? 'الرحلة لم تبدأ' : (!r.recorded_at ? 'لم يصل أي موقع بعد' : `⚠️ آخر تحديث منذ ${timeAgoAr(r.recorded_at)}`);
      return row(r, why);
    }).join('') : '<div class="empty-state">كل الحافلات النشطة متصلة.</div>'}</div>`;
}

async function refresh() {
  const [activeRes, allRes] = await Promise.all([getActiveBusLocations(), getAllBusesStatus()]);
  const activeRows = activeRes.ok ? activeRes.data || [] : [];
  const container = document.getElementById('live-map-empty');
  if (container) container.hidden = activeRows.filter((r) => r.latitude != null).length > 0;

  const seen = new Set();
  activeRows.forEach((row) => {
    if (row.latitude == null || row.longitude == null) return;
    seen.add(row.bus_id);
    const stale = !row.recorded_at || (Date.now() - new Date(row.recorded_at).getTime() > STALE_MS);
    if (markers[row.bus_id]) {
      markers[row.bus_id].setLatLng([row.latitude, row.longitude]);
      markers[row.bus_id].setIcon(busIcon(stale));
      markers[row.bus_id].setPopupContent(popupHtml(row, stale));
    } else {
      markers[row.bus_id] = window.L.marker([row.latitude, row.longitude], { icon: busIcon(stale) })
        .addTo(map).bindPopup(popupHtml(row, stale));
    }
  });
  Object.keys(markers).forEach((busId) => {
    if (!seen.has(busId)) { map.removeLayer(markers[busId]); delete markers[busId]; }
  });

  // Below-map status lists (item 1): merge the FULL fleet (fn_get_all_buses_status
  // — includes buses with no trip at all right now) with the richer
  // active-trip data (passenger counts, speed) where available.
  const allRows = allRes.ok ? allRes.data || [] : [];
  const byBus = new Map(activeRows.map((r) => [r.bus_id, r]));
  const merged = allRows.map((b) => byBus.get(b.bus_id) || {
    bus_id: b.bus_id, bus_code: b.bus_code, bus_plate: b.bus_plate,
    trip_id: b.trip_id, direction: b.direction, driver_name: b.driver_name,
    recorded_at: b.recorded_at, total_students: null, boarded_count: null,
  });
  const listHost = document.getElementById('live-map-status');
  if (listHost) {
    listHost.innerHTML = statusListHtml(merged);
    listHost.querySelectorAll('[data-history]').forEach((b) => {
      b.addEventListener('click', () => openBusHistoryModal(b.dataset.history, b.dataset.label));
    });
  }
}

// ============================================================================
// Item 3 — bus route history: pick a past trip, replay its recorded GPS
// points as a polyline. Real data only (bus_trip_locations); if a trip has
// zero rows there, shows the exact message you asked for.
// ============================================================================

function fmtDur(startIso, endIso) {
  if (!startIso || !endIso) return '—';
  const mins = Math.round((new Date(endIso) - new Date(startIso)) / 60000);
  return mins < 60 ? `${mins} دقيقة` : `${Math.floor(mins / 60)} س ${mins % 60} د`;
}

export async function openBusHistoryModal(busId, busLabel) {
  const overlay = document.createElement('div');
  overlay.className = 'map-picker-overlay';
  overlay.innerHTML = `
    <div class="map-picker-sheet" style="max-width:560px;">
      <div class="map-picker-header"><strong>عرض الرحلة — ${esc(busLabel || '')}</strong><button type="button" class="icon-btn" id="bh-close">✕</button></div>
      <select id="bh-trip-select" class="search-input" style="width:100%; margin-bottom:8px;"><option>جارٍ التحميل...</option></select>
      <div id="bh-info" class="panel" style="margin-bottom:8px;"></div>
      <div id="bh-map" style="width:100%; height:min(45vh, 320px); border-radius:10px; background:#e5e7eb;"></div>
    </div>`;
  document.body.appendChild(overlay);
  overlay.querySelector('#bh-close').addEventListener('click', () => overlay.remove());

  const tripsRes = await listBusTrips(busId, 30);
  const trips = tripsRes.ok ? tripsRes.data || [] : [];
  const select = overlay.querySelector('#bh-trip-select');
  select.innerHTML = trips.length
    ? trips.map((t) => `<option value="${t.trip_id}">${new Date(t.started_at).toLocaleString('ar')} — ${t.direction === 'pickup' ? 'نحو المؤسسة' : 'نحو المنزل'} (${t.status})</option>`).join('')
    : '<option value="">لا توجد رحلات سابقة لهذه الحافلة.</option>';

  await loadLeaflet();
  const hmap = window.L.map('bh-map').setView([27.15, -13.2], 12);
  window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 19 }).addTo(hmap);
  let polyline = null;

  async function loadSelectedTrip() {
    const tripId = select.value;
    const info = overlay.querySelector('#bh-info');
    if (!tripId) { info.innerHTML = ''; return; }
    const trip = trips.find((t) => t.trip_id === tripId);
    info.innerHTML = `
      <div class="detail-row"><span class="k">التاريخ</span><span class="v">${new Date(trip.started_at).toLocaleDateString('ar')}</span></div>
      <div class="detail-row"><span class="k">البداية</span><span class="v">${new Date(trip.started_at).toLocaleTimeString('ar')}</span></div>
      <div class="detail-row"><span class="k">النهاية</span><span class="v">${trip.ended_at ? new Date(trip.ended_at).toLocaleTimeString('ar') : 'الرحلة جارية'}</span></div>
      <div class="detail-row"><span class="k">المدة</span><span class="v">${fmtDur(trip.started_at, trip.ended_at)}</span></div>
      <div class="detail-row"><span class="k">السائق</span><span class="v">${esc(trip.driver_name || '—')}</span></div>
      <div class="detail-row"><span class="k">الاتجاه</span><span class="v">${trip.direction === 'pickup' ? 'نحو المؤسسة' : 'نحو المنزل'}</span></div>
      <div class="detail-row"><span class="k">عدد الركاب</span><span class="v">${trip.passenger_count ?? 0}</span></div>`;

    const histRes = await getTripRouteHistory(tripId);
    const points = histRes.ok ? histRes.data || [] : [];
    if (polyline) { hmap.removeLayer(polyline); polyline = null; }
    if (!points.length) {
      info.innerHTML += '<p class="empty-state" style="margin-top:8px;">لا توجد بيانات GPS لهذه الرحلة.</p>';
      return;
    }
    const latlngs = points.map((p) => [p.latitude, p.longitude]);
    polyline = window.L.polyline(latlngs, { color: '#2563eb', weight: 4 }).addTo(hmap);
    window.L.circleMarker(latlngs[0], { color: '#16a34a', radius: 7 }).addTo(hmap).bindTooltip('البداية');
    window.L.circleMarker(latlngs[latlngs.length - 1], { color: '#dc2626', radius: 7 }).addTo(hmap).bindTooltip('النهاية');
    hmap.fitBounds(polyline.getBounds(), { padding: [20, 20] });
    setTimeout(() => hmap.invalidateSize(), 50);
  }
  select.addEventListener('change', loadSelectedTrip);
  if (trips.length) loadSelectedTrip();
  setTimeout(() => hmap.invalidateSize(), 60);
}
export async function renderLiveMap(container) {
  container.innerHTML = `
    <div id="live-map" style="width:100%; height:min(60vh, 420px); border-radius:10px; background:#e5e7eb;"></div>
    <p class="empty-state" id="live-map-empty" style="margin-top:8px;">لا توجد حافلات في رحلة نشطة الآن.</p>
    <div id="live-map-status"></div>`;
  try {
    await loadLeaflet();
  } catch {
    container.innerHTML = '<div class="empty-state">تعذر تحميل الخريطة (تحقق من الاتصال بالإنترنت).</div>';
    return () => {};
  }
  map = window.L.map('live-map').setView([27.15, -13.2], 12);
  window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 19 }).addTo(map);
  setTimeout(() => map.invalidateSize(), 50);

  await refresh();
  pollTimer = setInterval(refresh, POLL_MS);

  // Best-effort Realtime: if this Supabase project doesn't have realtime
  // enabled for this table, the subscription simply never fires and the
  // poll above still keeps things correct — this is a pure enhancement.
  realtimeChannel = supabase
    .channel('bus-locations-live')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'bus_last_locations' }, () => refresh())
    .subscribe();

  return function cleanupLiveMap() {
    if (pollTimer) clearInterval(pollTimer);
    if (realtimeChannel) supabase.removeChannel(realtimeChannel);
    if (map) { map.remove(); map = null; }
    markers = {};
  };
}
