# CHANGELOG — smart-school-complete-v1

## Migration جديدة
- `supabase/migrations/phase12_complete_platform.sql` — 16 جدولًا جديدًا (user_permissions, subjects, attendance_records, student_grades, incidents, notifications, notification_reads, buses, transport_routes, route_stops, student_transport, trips, trip_events, fee_payments, expenses, class_schedule) + توسعة schools/classes/academic_years/profiles + ~65 دالة SECURITY DEFINER تغطي: الصلاحيات لكل مستخدم، السنوات/الأقسام/المواد، الحضور، النقاط، السلوك والمخالفات، الإشعارات، النقل المدرسي والرحلات، المالية، الجداول، ملف التلميذ الكامل، لوحة المؤسسة، سجل العمليات، إنشاء/تعديل المؤسسات الكامل، قائمة المستخدمين V2.
- `fn_has_permission` استُبدلت داخليًا (نفس التوقيع) لتقرأ منح `user_permissions` الفعلية — الحارس بلا منح لم يعد قادرًا على إنشاء حسابات.

## ملفات معدّلة
- `modules/permissions.js` — loadMyPermissions يقرأ من قاعدة البيانات (fn_my_permissions) مع fallback محلي؛ admin يُوجَّه إلى director.html؛ السماح لـ admin بفتح وحدة المدير.
- `modules/admin.js` — getGuardPermissions/grantPermission/revokePermission أصبحت RPCs حقيقية.
- `modules/ui.js` — إضافة fmtTime.
- `guard.html` — إضافة «بلاغ مخالفة» (مرخّصة بـ incidents.create) مع بحث عن تلميذ وإرسال فعلي؛ الترخيص الآن من قاعدة البيانات.

## ملفات جديدة
- `modules/ui.js` (سابقًا في هذه المرحلة)، `modules/school.js` — كل أغلفة RPC مع رسائل خطأ عربية.
- `modules/directorConsole.js`, `modules/teacherConsole.js`, `modules/driverConsole.js`, `modules/parentConsole.js`.
- `assets/css/platform.css`.
- `superadmin.html` — إعادة كتابة كاملة (لوحة المنصة، المؤسسات + تفاصيلها + إنشاء كامل، المستخدمون + بحث/فلاتر/تقسيم صفحات + تفاصيل/تعديل/تعطيل/أدوار، سجل العمليات).
- `director.html` — إعادة كتابة كاملة: 16 وحدة (المؤسسة، السنوات والأقسام، المواد، التلاميذ، الأساتذة، الحراس والصلاحيات، السائقون، أولياء الأمور، الحضور، الجدول، النقل، المالية، المخالفات، التقارير CSV/طباعة، الإشعارات، سجل العمليات).
- `teacher.html` — أقسامي، تحضير الحضور (حاضر/غائب/متأخر/مبرر)، إدخال النقاط، الجدول الزمني، الإبلاغ عن مخالفة، الإشعارات.
- `driver.html` — الحافلة، بدء/إنهاء الرحلة، تسجيل صعود/نزول التلاميذ، سجل الرحلات.
- `parent.html` — الأبناء، الحضور مع إحصاءات، النقاط، النقل، الأداءات مع الإجماليات، الإشعارات.
- `admin.html` — تحويل تلقائي إلى وحدة المؤسسة.

## Edge Functions (إعادة نشر مطلوبة)
- `create-platform-user`, `create-staff-account` — upsert للملفات، رسائل خطأ حقيقية، CORS.

## غير منفَّذ (بشفافية)
- رفع شعار المؤسسة إلى Supabase Storage — يُستخدم رابط صورة (logo_url) فقط.
- تصدير PDF — يتم عبر طباعة المتصفح (window.print)؛ التصدير المتاح CSV.
- GPS المباشر للحافلة — اختياري ولم يُفعّل؛ لا يؤثر على أي وظيفة.

---

# v1.1 — PHASE 12.1 PRODUCTION HARDENING

## Migration جديدة (وحيدة)
- `supabase/migrations/phase12_1_hardening.sql`:
  fn_list_permissions_catalog؛ fn_update_class(uuid,jsonb) بمنطق patch
  (غياب المفتاح = لا تغيير / null صريح = إزالة الأستاذ)؛ منع تعطيل السنة
  الحالية (YEAR_IS_CURRENT)؛ تقييد الأستاذ بأقسامه في fn_save_attendance و
  fn_get_class_attendance و fn_add_grade (NOT_YOUR_CLASS) مع التحقق من
  تبعية القسم لمؤسسة التلميذ.

## ملفات معدّلة
- `modules/permissions.js` — حذف fallback الصلاحيات الثابت نهائيًا؛ الفشل = صفر صلاحيات.
- `modules/admin.js` — كتالوج الصلاحيات عبر RPC.
- `modules/superadmin.js` — حذف listAllUsers القديمة؛ fn_list_all_users_v2 فقط.
- `modules/school.js` — updateClass بصيغة jsonb + رسائل خطأ جديدة.
- `modules/directorConsole.js` — نافذة تعديل القسم الكاملة (بدل prompt).

## فحوص ثابتة جديدة
- بناء جملة كل الوحدات والسكربتات المضمّنة: سليم.
- تطابق IDs لكل الصفحات الست: كامل.
- تطابق أسماء RPC (المستخدمة ⊆ المعرفة في migrations): كامل.
- أنماط ممنوعة (TODO/FIXME/alert/نصوص placeholder): صفر.

---

# v1.1.1 — Hotfix: updateClass patch payload

- `modules/school.js`: إصلاح `updateClass` ليرسل `p_data` (jsonb patch) إلى
  `fn_update_class(uuid, jsonb)` بدل المعاملات scalar القديمة
  (p_name/p_level/p_capacity/p_teacher_id/p_is_disabled) التي كانت تستدعي
  الـ signature القديمة — ما جعل تعديل القسم/إزالة الأستاذ يفشلان.
- السلوك المؤكد باختبارات Node فعلية (7/7 PASS):
  teacherId=null → {"teacher_id":null} (إزالة الأستاذ)؛ عدم تغيير الأستاذ →
  لا يُرسل teacher_id إطلاقًا؛ نفس الشيء لبقية الحقول؛ لا null تلقائي.
- `modules/directorConsole.js`: تأكيد أن نافذة تعديل القسم تبني patch صحيحًا
  (بدون تغيير / إزالة / تعيين أستاذ، سعة اختيارية، تعطيل).

## v1.2 — Production fixes (Phase 13)
- **SQL (`phase13_fixes.sql`, additive):** `fn_is_admin_or_guard` يشمل دور `director` (إصلاح رفض تسجيل التلميذ والكتابة عبر RLS للمدير) + إكمال سجلات `guards/teachers/drivers/parents` الناقصة من `user_roles` (INSERT فقط، idempotent).
- **create-platform-user:** ينشئ الآن سجل staff (guards/teachers/drivers/parents) مع الدور — حسابات SuperAdmin تظهر في لوحات المؤسسة.
- **create-staff-account:** أكواد أخطاء واضحة (EMAIL_EXISTS/SCHOOL_ACCESS_DENIED/AUTH_CREATE_FAILED/PROFILE_CREATE_FAILED/ROLE_CREATE_FAILED/STAFF_CREATE_FAILED) + إدراجات idempotent.
- **التنقل:** نظام history داخلي (`armViewHistory`/`pushViewState` في ui.js) — زر Back في الهاتف يرجع للشاشة السابقة داخل التطبيق، بلا صفحات بيضاء وبلا فقدان للجلسة.
- **الأخطاء:** `armErrorBoundary` — بانر عربي مع زر إعادة محاولة بدل الصفحة البيضاء؛ إزالة التحويل الأعمى إلى index.html بعد نجاح المصادقة.


## PHASE 26 — V12 HOTFIX
- إصلاح مخطط Audit الحقيقي (`actor_id`, `old_value`, `new_value`).
- إضافة تخزين شعار المؤسسة من الهاتف في `school-logos`.
- تحسين أخطاء الخريطة ورفع الشعار وQR.
