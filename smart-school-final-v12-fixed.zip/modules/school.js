// ============================================================================
// modules/school.js
// Data access wrappers for the Phase 12 platform RPCs. Every function returns
// { ok, ... } and maps server error codes to clear Arabic messages. Technical
// details stay in console — users see safe, useful messages only.
// ============================================================================

import { supabase } from './supabase.js?v=19';

/** Map known PostgreSQL/RPC error codes to Arabic messages. */
export function mapRpcError(message) {
  const msg = String(message || '');
  const table = [
    ['PERMISSION_DENIED', 'ليس لديك صلاحية لهذه العملية.'],
    ['NOT_AUTHENTICATED', 'يجب تسجيل الدخول.'],
    ['NO_SCHOOL_CONTEXT', 'لا توجد مؤسسة مرتبطة بهذا الحساب.'],
    ['INVALID_SCHOOL', 'المؤسسة غير موجودة.'],
    ['INVALID_ACADEMIC_YEAR', 'السنة الدراسية غير صالحة.'],
    ['INVALID_CLASS', 'القسم غير موجود.'],
    ['INVALID_TEACHER', 'الأستاذ غير موجود في هذه المؤسسة.'],
    ['INVALID_STUDENT', 'التلميذ غير موجود.'],
    ['INVALID_DRIVER', 'السائق غير موجود في هذه المؤسسة.'],
    ['INVALID_BUS', 'الحافلة غير موجودة.'],
    ['INVALID_ROUTE', 'المسار غير موجود.'],
    ['INVALID_TRIP', 'الرحلة غير موجودة.'],
    ['TRIP_NOT_ACTIVE', 'الرحلة ليست نشطة.'],
    ['STUDENT_NOT_ON_BUS', 'التلميذ غير مسجل في هذه الحافلة.'],
    ['STUDENT_NAME_REQUIRED', 'اسم التلميذ مطلوب.'],
    ['INVALID_INCIDENT', 'المخالفة غير موجودة.'],
    ['ACADEMIC_YEAR_EXISTS', 'السنة الدراسية موجودة بالفعل.'],
    ['ACADEMIC_YEAR_SCHOOL_MISMATCH', 'السنة الدراسية لا تتبع مؤسسة القسم.'],
    ['YEAR_NAME_REQUIRED', 'اسم السنة الدراسية مطلوب.'],
    ['CLASS_NAME_REQUIRED', 'اسم القسم مطلوب.'],
    ['SCHOOL_NAME_REQUIRED', 'اسم المؤسسة مطلوب.'],
    ['SUBJECT_NAME_REQUIRED', 'اسم المادة مطلوب.'],
    ['BUS_CODE_REQUIRED', 'رقم الحافلة مطلوب.'],
    ['ROUTE_NAME_REQUIRED', 'اسم المسار مطلوب.'],
    ['FEE_TYPE_REQUIRED', 'نوع الرسوم مطلوب.'],
    ['EXPENSE_CATEGORY_REQUIRED', 'تصنيف المصروف مطلوب.'],
    ['INCIDENT_TITLE_REQUIRED', 'عنوان المخالفة مطلوب.'],
    ['NOTIFICATION_TITLE_REQUIRED', 'عنوان الإشعار مطلوب.'],
    ['INVALID_AMOUNT', 'المبلغ غير صالح.'],
    ['INVALID_SCORE', 'النقطة غير صالحة.'],
    ['GRADE_SUBJECT_REQUIRED', 'اختر المادة أولاً.'],
    ['INVALID_SUBJECT', 'المادة غير موجودة أو غير تابعة لهذه المؤسسة.'],
    ['INVALID_DIRECTION', 'اتجاه الرحلة غير صالح.'],
    ['INVALID_EVENT_TYPE', 'نوع العملية غير صالح.'],
    ['INVALID_ROWS', 'البيانات المرسلة غير صالحة.'],
    ['USER_NOT_IN_SCHOOL', 'المستخدم لا ينتمي إلى هذه المؤسسة.'],
    ['UNKNOWN_PERMISSION', 'صلاحية غير معروفة.'],
    ['CANNOT_DISABLE_LAST_SUPERADMIN', 'لا يمكن تعطيل آخر SuperAdmin.'],
    ['CANNOT_REMOVE_LAST_SUPERADMIN', 'لا يمكن إزالة دور آخر SuperAdmin.'],
    ['NOT_YOUR_CLASS', 'لا يمكنك تنفيذ هذه العملية على قسم لا تدرّسه.'],
    ['YEAR_IS_CURRENT', 'لا يمكن تعطيل السنة الحالية؛ حدد سنة أخرى كحالية أولًا.'],
    ['CLASS_EXISTS', 'القسم موجود بالفعل في هذه السنة.'],
    ['INVALID_CAPACITY', 'سعة القسم غير صالحة.'],
    ['INVALID_PATCH', 'بيانات التعديل غير صالحة.'],
    ['NOT_A_DRIVER', 'هذا الحساب ليس حساب سائق.'],
    ['NO_BUS_ASSIGNED', 'لا توجد حافلة مرتبطة بهذا السائق.'],
    ['students_school_id_student_number_key', 'رقم الطالب مستخدم بالفعل في هذه المؤسسة.'],
    ['DUPLICATE_STUDENT_NUMBER', 'رقم الطالب مستخدم بالفعل في هذه المؤسسة.'],
    ['STUDENT_INSERT_FAILED', 'تعذر حفظ بيانات التلميذ، حاول مرة أخرى.'],
    ['ENROLLMENT_INSERT_FAILED', 'تعذر تسجيل التلميذ في القسم، حاول مرة أخرى.'],
    ['CLASS_NOT_FOUND', 'القسم غير موجود.'],
    ['ACADEMIC_YEAR_NOT_FOUND', 'السنة الدراسية غير موجودة.'],
    ['SCHOOL_NOT_FOUND', 'المؤسسة غير موجودة.'],
    ['INVALID_PARENT', 'ولي الأمر غير صالح.'],
    ['INVALID_TRANSPORT', 'بيانات النقل غير صالحة.'],
    ['duplicate', 'موجود مسبقًا.'],
    ['students.create', 'ليس لديك صلاحية إضافة التلاميذ.'],
    ['TEACHER_ASSIGNMENT_REQUIRED', 'الأستاذ غير مرتبط بهذه المادة أو القسم.'],
    ['SUBJECT_SCHOOL_MISMATCH', 'المادة لا تنتمي إلى هذه المؤسسة.'],
    ['CLASS_SCHOOL_MISMATCH', 'القسم لا ينتمي إلى هذه المؤسسة.'],
    ['DUPLICATE_STUDENT', 'رقم التلميذ مستخدم مسبقًا.'],
    ['PERMISSION_CHECK_FAILED', 'تعذر التحقق من الصلاحية، حاول مرة أخرى.'],
    ['EMAIL_EXISTS', 'البريد الإلكتروني مستخدم بالفعل.'],
    ['SCHOOL_ACCESS_DENIED', 'لا يمكنك الوصول إلى هذه المؤسسة.'],
    ['CLASS_SLOT_TAKEN', 'هذا التوقيت محجوز بالفعل لهذا القسم.'],
    ['TEACHER_SCHEDULE_CONFLICT', 'الأستاذ لديه حصة أخرى في نفس التوقيت.'],
    ['INVALID_LESSON', 'الحصة غير موجودة.'],
    ['INVALID_WEEKDAY', 'اليوم غير صالح.'],
    ['INVALID_PERIOD', 'رقم الحصة غير صالح.'],
    ['SCHEDULE_TEACHER_REQUIRED', 'حدد الأستاذ أولاً.'],
    ['INVALID_LATITUDE', 'خط العرض غير صالح.'],
    ['INVALID_LONGITUDE', 'خط الطول غير صالح.'],
    ['PAYROLL_MONTH_NOT_FOUND', 'يجب إدخال ساعات هذا الشهر أولاً قبل تسجيل دفعة.'],
    ['BADGE_INSERT_FAILED', 'تعذر إصدار البطاقة. تحقق من سجل العمليات/قاعدة البيانات ثم حاول مرة أخرى.'],
    ['BADGE_TOKEN_MISSING', 'البطاقة لا تحتوي على رمز QR رسمي صالح.'],
    ['BADGE_REISSUE_FAILED', 'تعذرت إعادة إصدار البطاقة، حاول مرة أخرى.'],
    ['BADGE_STATUS_UPDATE_FAILED', 'تعذر تحديث حالة البطاقة.'],
    ['INVALID_BADGE', 'البطاقة غير موجودة.'],
    ['STUDENT_NOT_ON_THIS_ROUTE', 'هذا التلميذ غير مسجل في هذا المسار.'],
    ['ALREADY_BOARDED', 'تم تسجيل صعود هذا التلميذ مسبقًا.'],
    ['NOT_BOARDED_YET', 'لم يصعد هذا التلميذ بعد.'],
    ['ALREADY_DROPPED', 'تم تسجيل نزول هذا التلميذ مسبقًا.'],
    ['NO_ACTIVE_TRIP', 'لا توجد رحلة نشطة حاليًا.'],
    ['UNKNOWN_BADGE', 'رمز البطاقة غير معروف.'],
    ['BADGE_NOT_ACTIVE', 'هذه البطاقة غير سارية.'],
    ['NOT_A_DRIVER', 'هذا الحساب ليس حساب سائق.'],
    ['INVALID_BUS', 'الحافلة غير موجودة.'],
    ['INVALID_GUARD', 'الحارس غير موجود.'],
    ['INVALID_DRIVER', 'السائق غير موجود.'],
    ['INVALID_PARENT', 'ولي الأمر غير موجود.'],
    ['TRIP_NOT_ACTIVE', 'الرحلة لم تعد نشطة.'],
    ['INVALID_COORDINATES', 'إحداثيات غير صالحة.'],
    ['INVALID_TRIP', 'الرحلة غير موجودة.'],
    ['TOO_MANY_LESSONS', 'مجموع الحصص يتجاوز 8 حصص/يوم.'],
    ['INVALID_DURATION', 'مدة الحصة غير صالحة.'],
  ];
  for (const [code, ar] of table) {
    if (msg.includes(code)) return ar;
  }
  if (msg.includes('schema cache') || msg.includes('Could not find the function')) {
    return 'خطأ تقني: الوظيفة المطلوبة غير منشورة على القاعدة (يرجى إبلاغ الدعم الفني).';
  }
  if (msg.includes('permission denied') || msg.includes('row-level security')) {
    return 'ليس لديك صلاحية للوصول إلى هذه البيانات.';
  }
  return 'تعذر الاتصال بالخادم أو تنفيذ العملية، حاول مرة أخرى.';
}

async function call(fnName, params) {
  const { data, error } = await supabase.rpc(fnName, params || {});
  if (error) {
    console.error(`${fnName} error:`, error);
    return { ok: false, error: mapRpcError(error.message) };
  }
  return { ok: true, data };
}

// ---- Schools (SuperAdmin / school profile) -------------------------------------
export const createSchoolFull = (name, data) => call('fn_create_school_full', { p_name: name, p_data: data || {} });
export const updateSchool = (schoolId, data) => call('fn_update_school', { p_school_id: schoolId, p_data: data });
export const getSchoolProfile = (schoolId) => call('fn_get_school_profile', { p_school_id: schoolId });
export const listSchoolsFull = () => call('fn_list_schools_full');

// ---- Users ------------------------------------------------------------------
export const listAllUsersV2 = (f) => call('fn_list_all_users_v2', {
  p_query: f?.query || null, p_role: f?.role || null,
  p_school_id: f?.schoolId || null, p_status: f?.status || null,
  p_limit: f?.limit || 25, p_offset: f?.offset || 0,
});
export const updateProfile = (profileId, fullName, phone) =>
  call('fn_update_profile', { p_profile_id: profileId, p_full_name: fullName, p_phone: phone });

// ---- Permissions ------------------------------------------------------------
export const myPermissions = () => call('fn_my_permissions');
export const getUserPermissions = (profileId, schoolId) =>
  call('fn_get_user_permissions', { p_profile_id: profileId, p_school_id: schoolId });
export const grantUserPermission = (profileId, schoolId, key) =>
  call('fn_grant_user_permission', { p_profile_id: profileId, p_school_id: schoolId, p_permission_key: key });
export const revokeUserPermission = (profileId, schoolId, key) =>
  call('fn_revoke_user_permission', { p_profile_id: profileId, p_school_id: schoolId, p_permission_key: key });

// ---- Academic structure -----------------------------------------------------
export const createAcademicYearMy = (name, isCurrent) =>
  call('fn_create_academic_year_my', { p_name: name, p_is_current: !!isCurrent });
export const setCurrentAcademicYear = (yearId) => call('fn_set_current_academic_year', { p_year_id: yearId });
export const updateAcademicYear = (yearId, name, isDisabled) =>
  call('fn_update_academic_year', { p_year_id: yearId, p_name: name ?? null, p_is_disabled: isDisabled ?? null });
export const createClassMy = (yearId, name, level, capacity, teacherId) =>
  call('fn_create_class_my', { p_academic_year_id: yearId, p_name: name, p_level: level || null, p_capacity: capacity || null, p_teacher_id: teacherId || null });
export const updateClass = (classId, fields) =>
  call('fn_update_class', {
    p_class_id: classId,
    p_data: {
      ...(Object.prototype.hasOwnProperty.call(fields || {}, 'name')
        ? { name: fields.name }
        : {}),
      ...(Object.prototype.hasOwnProperty.call(fields || {}, 'level')
        ? { level: fields.level }
        : {}),
      ...(Object.prototype.hasOwnProperty.call(fields || {}, 'capacity')
        ? { capacity: fields.capacity }
        : {}),
      ...(Object.prototype.hasOwnProperty.call(fields || {}, 'teacherId')
        ? { teacher_id: fields.teacherId }
        : {}),
      ...(Object.prototype.hasOwnProperty.call(fields || {}, 'isDisabled')
        ? { is_disabled: fields.isDisabled }
        : {}),
    },
  });
export const listMyClasses = (yearId) => call('fn_list_my_classes', { p_academic_year_id: yearId || null });
export const listMyAcademicYears = () => call('fn_list_my_academic_years');

// ---- Subjects ---------------------------------------------------------------
export const createSubject = (name) => call('fn_create_subject', { p_name: name });
export const listSubjects = () => call('fn_list_subjects');

// ---- Attendance -------------------------------------------------------------
export const saveAttendance = (classId, date, rows) =>
  call('fn_save_attendance', { p_class_id: classId, p_date: date, p_rows: rows });
export const getClassAttendance = (classId, date) =>
  call('fn_get_class_attendance', { p_class_id: classId, p_date: date || null });
export const getStudentAttendance = (studentId, from, to) =>
  call('fn_student_attendance', { p_student_id: studentId, p_from: from || null, p_to: to || null });
export const schoolAttendanceToday = () => call('fn_school_attendance_today');
export const reportAttendance = (from, to, classId) =>
  call('fn_report_attendance', { p_from: from || null, p_to: to || null, p_class_id: classId || null });

// ---- Grades -----------------------------------------------------------------
export const addGrade = (g) => call('fn_add_grade', {
  p_student_id: g.studentId, p_class_id: g.classId || null, p_subject_id: g.subjectId || null,
  p_period: g.period || null, p_grade_type: g.gradeType || null,
  p_score: g.score, p_max_score: g.maxScore || 20, p_note: g.note || null,
});
export const listStudentGrades = (studentId) => call('fn_list_student_grades', { p_student_id: studentId });

// ---- Incidents --------------------------------------------------------------
export const reportIncident = (i) => call('fn_report_incident', {
  p_student_id: i.studentId, p_type: i.type, p_title: i.title,
  p_description: i.description || null, p_place: i.place || null, p_occurred_at: i.occurredAt || null,
});
export const listIncidents = (status, limit, offset) =>
  call('fn_list_incidents', { p_status: status || null, p_limit: limit || 50, p_offset: offset || 0 });
export const updateIncident = (id, status, actionTaken) =>
  call('fn_update_incident', { p_incident_id: id, p_status: status || null, p_action_taken: actionTaken || null });

// ---- Notifications ----------------------------------------------------------
export const sendNotification = (n) => call('fn_send_notification', {
  p_title: n.title, p_body: n.body || null, p_type: n.type || 'announcement',
  p_target_role: n.targetRole || null, p_target_profile_id: n.targetProfileId || null,
  p_student_id: n.studentId || null,
});
export const listMyNotifications = (limit) => call('fn_list_my_notifications', { p_limit: limit || 50 });
export const markNotificationRead = (id) => call('fn_mark_notification_read', { p_notification_id: id });
export const unreadNotificationsCount = () => call('fn_unread_notifications_count');

// ---- Transport --------------------------------------------------------------
export const createBus = (b) => call('fn_create_bus', {
  p_code: b.code, p_plate: b.plate || null, p_capacity: b.capacity || null, p_driver_id: b.driverId || null,
});
export const listBuses = () => call('fn_list_buses');
export const createRoute = (name, stops) => call('fn_create_route', { p_name: name, p_stops: stops || [] });
export const listRoutes = () => call('fn_list_routes');
export const assignStudentTransport = (studentId, t) => call('fn_assign_student_transport', {
  p_student_id: studentId, p_bus_id: t.busId || null, p_route_id: t.routeId || null,
  p_pickup_stop_id: t.pickupStopId || null, p_dropoff_stop_id: t.dropoffStopId || null,
});
export const studentTransportInfo = (studentId) => call('fn_student_transport_info', { p_student_id: studentId });
export const driverContext = () => call('fn_driver_context');
export const startTrip = (routeId, direction) => call('fn_start_trip', { p_route_id: routeId || null, p_direction: direction || 'pickup' });
export const endTrip = (tripId) => call('fn_end_trip', { p_trip_id: tripId });
export const recordTripEvent = (tripId, studentId, eventType) =>
  call('fn_record_trip_event', { p_trip_id: tripId, p_student_id: studentId, p_event_type: eventType });
export const getActiveTrip = () => call('fn_get_active_trip');
export const listBusStudents = (busId, tripId) => call('fn_list_bus_students', { p_bus_id: busId, p_trip_id: tripId || null });
export const getGuardStats = (profileId) => call('fn_get_guard_stats', { p_profile_id: profileId });
export const getDriverStats = (driverId) => call('fn_get_driver_stats', { p_driver_id: driverId });
export const getParentStats = (parentId) => call('fn_get_parent_stats', { p_parent_id: parentId });
export const recordGpsPing = (tripId, lat, lng, accuracy, speed, heading) =>
  call('fn_record_gps_ping', { p_trip_id: tripId, p_latitude: lat, p_longitude: lng, p_accuracy: accuracy ?? null, p_speed: speed ?? null, p_heading: heading ?? null });
export const getActiveBusLocations = () => call('fn_get_active_bus_locations');
export const getAllBusesStatus = () => call('fn_get_all_buses_status');
export const listBusTrips = (busId, limit) => call('fn_list_bus_trips', { p_bus_id: busId, p_limit: limit || 30 });
export const getTripRouteHistory = (tripId) => call('fn_get_trip_route_history', { p_trip_id: tripId });
export const teacherClassRoster = (classId) => call('fn_teacher_class_roster', { p_class_id: classId });
export const getSchoolPeriods = () => call('fn_get_school_periods');
export const setSchoolPeriods = (cfg) => call('fn_set_school_periods', {
  p_morning_start: cfg.morningStart, p_morning_lesson_minutes: cfg.morningLessonMinutes,
  p_afternoon_start: cfg.afternoonStart, p_afternoon_lesson_minutes: cfg.afternoonLessonMinutes,
});
export const updateStudentPhoto = (studentId, photoUrl) => call('fn_update_student_photo', { p_student_id: studentId, p_photo_url: photoUrl });
export const updateSchoolLocation = (latitude, longitude, locationLabel) =>
  call('fn_update_school_location', { p_latitude: latitude, p_longitude: longitude, p_location_label: locationLabel || null });
export const driverLookupBadge = (secureToken) => call('fn_driver_lookup_badge', { p_secure_token: secureToken });
export const listBusStudentsOrdered = (busId, tripId) => call('fn_list_bus_students_ordered', { p_bus_id: busId, p_trip_id: tripId || null });
export const myTrips = (limit) => call('fn_my_trips', { p_limit: limit || 20 });
// ---- PHASE 25 — Live map overview (school + homes + fleet + stops) --------
// SuperAdmin (no fixed school) passes the chosen school id; Admin/Director
// are pinned server-side to their own school (param ignored for them).
export const getMapOverview = (schoolId) =>
  call('fn_get_map_overview', { p_school_id: schoolId || null });

// ---- Finance ----------------------------------------------------------------
export const recordPayment = (p) => call('fn_record_payment', {
  p_student_id: p.studentId, p_fee_type: p.feeType, p_amount_due: p.amountDue || 0,
  p_amount_paid: p.amountPaid || 0, p_payment_date: p.paymentDate || null,
  p_method: p.method || null, p_note: p.note || null,
});
export const listPayments = (studentId, limit) => call('fn_list_payments', { p_student_id: studentId || null, p_limit: limit || 100 });
export const recordExpense = (e) => call('fn_record_expense', {
  p_category: e.category, p_amount: e.amount, p_expense_date: e.expenseDate || null, p_description: e.description || null,
});
export const listExpenses = (limit) => call('fn_list_expenses', { p_limit: limit || 100 });
export const financeSummary = (from, to) => call('fn_finance_summary', { p_from: from || null, p_to: to || null });

// ---- Schedule ---------------------------------------------------------------
export const setClassSchedule = (classId, entries) => call('fn_set_class_schedule', { p_class_id: classId, p_entries: entries });
export const getClassSchedule = (classId) => call('fn_get_class_schedule', { p_class_id: classId });
export const teacherClasses = () => call('fn_teacher_classes');

// ---- Students / parents -----------------------------------------------------
export const getStudentFull = (studentId) => call('fn_get_student_full', { p_student_id: studentId });
export const myChildren = () => call('fn_my_children');
export const childPayments = (studentId) => call('fn_child_payments', { p_student_id: studentId });

// ---- Dashboard / audit ------------------------------------------------------
export const schoolDashboard = () => call('fn_get_school_dashboard');
export const schoolAudit = (limit, offset) => call('fn_get_school_audit', { p_limit: limit || 50, p_offset: offset || 0 });

// ---- PHASE 14 — Teacher academic assignments (server-enforced) ------------
export const assignTeacherSubject = (teacherId, subjectId) =>
  call('fn_assign_teacher_subject', { p_teacher_id: teacherId, p_subject_id: subjectId });
export const removeTeacherSubject = (teacherId, subjectId) =>
  call('fn_remove_teacher_subject', { p_teacher_id: teacherId, p_subject_id: subjectId });
export const listTeacherSubjects = (teacherId) =>
  call('fn_list_teacher_subjects', { p_teacher_id: teacherId });
export const assignTeacherClass = (teacherId, classId) =>
  call('fn_assign_teacher_class', { p_teacher_id: teacherId, p_class_id: classId });
export const removeTeacherClass = (teacherId, classId) =>
  call('fn_remove_teacher_class', { p_teacher_id: teacherId, p_class_id: classId });
export const listTeacherClasses = (teacherId) =>
  call('fn_list_teacher_classes', { p_teacher_id: teacherId });
export const myTeacherSubjects = () => call('fn_my_teacher_subjects');

// ---- PHASE 19 — Teacher / Student profiles, single-lesson CRUD -------------
export const getTeacherFull = (teacherId) => call('fn_get_teacher_full', { p_teacher_id: teacherId });
export const getTeacherSchedule = (teacherId) => call('fn_get_teacher_schedule', { p_teacher_id: teacherId });
export const addLesson = (l) => call('fn_add_lesson', {
  p_class_id: l.classId, p_weekday: l.weekday, p_period: l.period,
  p_subject_id: l.subjectId, p_teacher_id: l.teacherId || null, p_notes: l.notes || null,
});
export const updateLesson = (l) => call('fn_update_lesson', {
  p_entry_id: l.entryId, p_weekday: l.weekday, p_period: l.period,
  p_subject_id: l.subjectId, p_teacher_id: l.teacherId || null, p_notes: l.notes || null,
});
export const deleteLesson = (entryId) => call('fn_delete_lesson', { p_entry_id: entryId });
export const getStudentSchedule = (studentId) => call('fn_get_student_schedule', { p_student_id: studentId });
export const getStudentBadge = (studentId) => call('fn_get_student_badge', { p_student_id: studentId });
export const updateStudentLocation = (l) => call('fn_update_student_location', {
  p_student_id: l.studentId, p_latitude: l.latitude, p_longitude: l.longitude,
  p_address: l.address || null, p_location_label: l.locationLabel || null,
});

// ---- PHASE 18 — Teacher payroll ---------------------------------------------
export const setTeacherRate = (teacherId, hourlyRate) =>
  call('fn_set_teacher_rate', { p_teacher_id: teacherId, p_hourly_rate: hourlyRate });
export const upsertTeacherMonth = (teacherId, periodMonth, hoursWorked, notes) =>
  call('fn_upsert_teacher_month', { p_teacher_id: teacherId, p_period_month: periodMonth, p_hours_worked: hoursWorked, p_notes: notes || null });
export const recordTeacherPayment = (teacherId, periodMonth, amount) =>
  call('fn_record_teacher_payment', { p_teacher_id: teacherId, p_period_month: periodMonth, p_amount: amount });
export const listTeacherPayroll = (teacherId) => call('fn_list_teacher_payroll', { p_teacher_id: teacherId });
