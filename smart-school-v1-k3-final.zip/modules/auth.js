// ============================================================================
// modules/auth.js
// Central authentication and role-routing service.
//
// The browser never trusts a role from the URL, localStorage, sessionStorage,
// remembered-device data, or caller-provided state. The authenticated context
// is always rebuilt from Supabase Auth -> profiles -> user_roles.
// ============================================================================

import { supabase } from './supabase.js';
import { homePageForRole, isRoleAllowedOnPage, pickPrimaryRole } from './permissions.js';

const PIN_REGEX = /^\d{4}$/;
const AUTH_TIMEOUT_MS = 15000;
const LOGIN_PAGE = 'index.html';

function withTimeout(promise, ms, label) {
  let timeoutId;
  const timeout = new Promise((_, reject) => {
    timeoutId = setTimeout(() => reject(new Error(`TIMEOUT: ${label}`)), ms);
  });

  return Promise.race([promise, timeout]).finally(() => clearTimeout(timeoutId));
}

function goTo(page) {
  window.location.replace(page);
}

async function signOutAndGoToLogin() {
  try {
    await withTimeout(supabase.auth.signOut(), AUTH_TIMEOUT_MS, 'signOut');
  } catch (error) {
    console.error('signOut error:', error);
  } finally {
    goTo(LOGIN_PAGE);
  }
}

/**
 * Authenticate with an identifier (QR token or user number) plus a 4-digit PIN.
 * The PIN is verified only by the login-with-pin Edge Function.
 */
export async function login(method, identifier, pin) {
  try {
    if (method !== 'qr' && method !== 'manual') {
      return { ok: false, error: 'INVALID_METHOD' };
    }
    if (!identifier || typeof identifier !== 'string') {
      return { ok: false, error: 'INVALID_IDENTIFIER' };
    }
    if (!PIN_REGEX.test(pin)) {
      return { ok: false, error: 'INVALID_FORMAT' };
    }

    const body = method === 'qr'
      ? { method: 'qr', qr_token: identifier, pin }
      : { method: 'manual', user_number: identifier, pin };

    const { data, error } = await withTimeout(
      supabase.functions.invoke('login-with-pin', { body }),
      AUTH_TIMEOUT_MS,
      'login-with-pin'
    );

    if (error || !data?.token_hash) {
      if (error) console.error('login-with-pin error:', error);
      return { ok: false, error: 'INVALID_CREDENTIALS' };
    }

    const { data: verifyData, error: verifyError } = await withTimeout(
      supabase.auth.verifyOtp({ token_hash: data.token_hash, type: 'magiclink' }),
      AUTH_TIMEOUT_MS,
      'verifyOtp'
    );

    if (verifyError || !verifyData?.session) {
      if (verifyError) console.error('verifyOtp error:', verifyError);
      return { ok: false, error: 'INVALID_CREDENTIALS' };
    }

    return { ok: true, userNumber: data.user_number ?? null };
  } catch (error) {
    console.error('login error:', error);
    return { ok: false, error: 'NETWORK_ERROR' };
  }
}

export async function logout() {
  await signOutAndGoToLogin();
}

export async function getSession() {
  try {
    const { data, error } = await withTimeout(
      supabase.auth.getSession(),
      AUTH_TIMEOUT_MS,
      'getSession'
    );
    if (error) {
      console.error('getSession error:', error);
      return null;
    }
    return data.session ?? null;
  } catch (error) {
    console.error('getSession error:', error);
    return null;
  }
}

export async function getCurrentUser() {
  try {
    const { data, error } = await withTimeout(
      supabase.auth.getUser(),
      AUTH_TIMEOUT_MS,
      'getUser'
    );
    if (error) {
      console.error('getUser error:', error);
      return null;
    }
    return data.user ?? null;
  } catch (error) {
    console.error('getUser error:', error);
    return null;
  }
}

async function loadCurrentProfile(userId) {
  try {
    const { data, error } = await withTimeout(
      supabase
        .from('profiles')
        .select('id, full_name, phone, avatar_url, is_disabled')
        .eq('id', userId)
        .maybeSingle(),
      AUTH_TIMEOUT_MS,
      'loadCurrentProfile'
    );
    if (error) {
      console.error('loadCurrentProfile error:', error);
      return null;
    }
    return data ?? null;
  } catch (error) {
    console.error('loadCurrentProfile error:', error);
    return null;
  }
}

async function loadUserRoles(userId) {
  try {
    const { data, error } = await withTimeout(
      supabase
        .from('user_roles')
        .select('school_id, role')
        .eq('profile_id', userId),
      AUTH_TIMEOUT_MS,
      'loadUserRoles'
    );
    if (error) {
      console.error('loadUserRoles error:', error);
      return [];
    }
    return data ?? [];
  } catch (error) {
    console.error('loadUserRoles error:', error);
    return [];
  }
}

/**
 * Single source of truth for the signed-in identity and primary role.
 * Returns null for every unauthenticated, disabled, or misconfigured state.
 */
export async function getAuthenticatedContext() {
  try {
    const session = await getSession();
    if (!session?.user?.id) return null;

    const user = await getCurrentUser();
    if (!user?.id || user.id !== session.user.id) return null;

    const profile = await loadCurrentProfile(user.id);
    if (!profile || profile.is_disabled) return null;

    const roles = await loadUserRoles(user.id);
    const primary = pickPrimaryRole(roles);
    if (!primary?.role || !primary?.school_id) return null;

    return {
      session,
      user,
      profile,
      role: primary.role,
      schoolId: primary.school_id,
    };
  } catch (error) {
    console.error('getAuthenticatedContext error:', error);
    return null;
  }
}

export async function redirectToRoleHome() {
  try {
    const ctx = await getAuthenticatedContext();
    const page = ctx ? homePageForRole(ctx.role) : null;
    if (!ctx || !page) {
      await signOutAndGoToLogin();
      return;
    }
    goTo(page);
  } catch (error) {
    console.error('redirectToRoleHome error:', error);
    await signOutAndGoToLogin();
  }
}

/**
 * Guard one role-specific page. currentPageFileName is supplied explicitly by
 * the page itself; the URL is never used to derive identity, role, or access.
 */
export async function requireAuth(currentPageFileName) {
  try {
    if (!currentPageFileName || typeof currentPageFileName !== 'string') {
      throw new Error('INVALID_PAGE_GUARD');
    }

    const ctx = await withTimeout(
      getAuthenticatedContext(),
      AUTH_TIMEOUT_MS,
      'requireAuth'
    );

    if (!ctx) {
      await signOutAndGoToLogin();
      return null;
    }

    if (!isRoleAllowedOnPage(ctx.role, currentPageFileName)) {
      const page = homePageForRole(ctx.role);
      if (page && page !== currentPageFileName) {
        goTo(page);
      } else {
        await signOutAndGoToLogin();
      }
      return null;
    }

    return ctx;
  } catch (error) {
    console.error('requireAuth error:', error);
    await signOutAndGoToLogin();
    return null;
  }
}

export function onAuthStateChange(callback) {
  return supabase.auth.onAuthStateChange((_event, session) => {
    callback(session);
  });
}
