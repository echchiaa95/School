// ============================================================================
// modules/superadmin.js
// SuperAdmin platform management RPC wrappers.
// ============================================================================

import {
  supabase
} from './supabase.js';

/**  * Fetch enhanced platform-wide stats with role breakdowns.  * SuperAdmin-only RPC: fn_get_platform_stats_enhanced.  */
export async function getPlatformStatsEnhanced() {
  const {
    data,
    error
  } = await supabase.rpc('fn_get_platform_stats_enhanced');
  if (error) {
    console.error('getPlatformStatsEnhanced error:', error);
    return null;
  }
  return data?.[0] ?? null;
}

/**  * List every school (read-only via supabase.from).  * Falls back to supabase.from('schools') because fn_list_all_schools RPC  * is not available in the current Supabase deployment.  * RLS: p_schools_superadmin_read allows SuperAdmin SELECT.  */
export async function listAllSchools() {
  const {
    data,
    error
  } = await supabase.from('schools').select('id, name').order('name', {
    ascending: true
  });
  if (error) {
    console.error('listAllSchools error:', error);
    return [];
  }
  return (data || []).map((s) => ({
    school_id: s.id,
    school_name: s.name,
    admin_count: 0
  }));
}

/**  * Get detailed stats for one school.  * SuperAdmin-only RPC: fn_get_school_detail.  */
export async function getSchoolDetail(schoolId) {
  const {
    data,
    error
  } = await supabase.rpc('fn_get_school_detail', {
    p_school_id: schoolId
  });
  if (error) {
    console.error('getSchoolDetail error:', error);
    return null;
  }
  return data?.[0] ?? null;
}

/**  * Create a new school — DISABLED.  * The fn_create_school RPC is not deployed in Supabase.  * Returns a clear message so the UI can show it without breaking.  */
export async function createSchool(name) {
  return {
    ok: false,
    error: 'إنشاء المدارس يحتاج RPC مخصصة وسيتم تفعيله لاحقًا.',
  };
}

/**  * List admin/director accounts for a specific school (read-only via supabase.from).  * Falls back to supabase.from('user_roles') because fn_list_school_admins RPC  * is not available in the current Supabase deployment.  * RLS: p_user_roles_superadmin_read allows SuperAdmin SELECT.  */
export async function listSchoolAdmins(schoolId) {
  const {
    data,
    error
  } = await supabase.from('user_roles').select('role, profile_id, profiles(full_name, user_number, is_disabled)').eq('school_id', schoolId).in('role', ['admin', 'director']);
  if (error) {
    console.error('listSchoolAdmins error:', error);
    return [];
  }
  return (data || []).map((r) => ({
    full_name: r.profiles?.full_name || '—',
    user_number: r.profiles?.user_number || '—',
    role: r.role,
    is_disabled: r.profiles?.is_disabled ?? false,
  }));
}

/**  * List all platform users (paginated, searchable).  * SuperAdmin-only RPC: fn_list_all_users.  */
export async function listAllUsers(query, limit, offset) {
  const {
    data,
    error
  } = await supabase.rpc('fn_list_all_users', {
    p_query: query || null,
    p_limit: limit || 50,
    p_offset: offset || 0,
  });
  if (error) {
    console.error('listAllUsers error:', error);
    return [];
  }
  return data || [];
}

/**  * Get full detail for one user across all schools.  * SuperAdmin-only RPC: fn_get_user_detail.  */
export async function getUserDetail(profileId) {
  const {
    data,
    error
  } = await supabase.rpc('fn_get_user_detail', {
    p_profile_id: profileId
  });
  if (error) {
    console.error('getUserDetail error:', error);
    return null;
  }
  return data?.[0] ?? null;
}

/**  * Enable or disable any user account.  * SuperAdmin-only RPC: fn_superadmin_set_profile_status.  * Prevents disabling the last superadmin.  */
export async function setProfileStatus(profileId, isDisabled) {
  const {
    error
  } = await supabase.rpc('fn_superadmin_set_profile_status', {
    p_profile_id: profileId,
    p_is_disabled: isDisabled,
  });
  if (error) {
    console.error('setProfileStatus error:', error);
    return {
      ok: false,
      error: error.message
    };
  }
  return {
    ok: true
  };
}

/**  * List all role assignments for a user.  * SuperAdmin-only RPC: fn_superadmin_list_user_roles.  */
export async function listUserRoles(profileId) {
  const {
    data,
    error
  } = await supabase.rpc('fn_superadmin_list_user_roles', {
    p_profile_id: profileId
  });
  if (error) {
    console.error('listUserRoles error:', error);
    return [];
  }
  return data || [];
}

/**  * Assign a role to a user.  * SuperAdmin-only RPC: fn_superadmin_assign_role.  * Prevents duplicates. Only superadmin can assign superadmin role.  */
export async function assignRole(profileId, schoolId, role) {
  const {
    error
  } = await supabase.rpc('fn_superadmin_assign_role', {
    p_profile_id: profileId,
    p_school_id: schoolId,
    p_role: role,
  });
  if (error) {
    console.error('assignRole error:', error);
    return {
      ok: false,
      error: error.message
    };
  }
  return {
    ok: true
  };
}

/**  * Remove a role from a user.  * SuperAdmin-only RPC: fn_superadmin_remove_role.  * Prevents removing the last superadmin.  */
export async function removeRole(profileId, schoolId, role) {
  const {
    error
  } = await supabase.rpc('fn_superadmin_remove_role', {
    p_profile_id: profileId,
    p_school_id: schoolId,
    p_role: role,
  });
  if (error) {
    console.error('removeRole error:', error);
    return {
      ok: false,
      error: error.message
    };
  }
  return {
    ok: true
  };
}

/**  * Get global audit logs (paginated).  * SuperAdmin-only RPC: fn_superadmin_get_audit_logs.  */
export async function getAuditLogs(limit, offset) {
  const {
    data,
    error
  } = await supabase.rpc('fn_superadmin_get_audit_logs', {
    p_limit: limit || 50,
    p_offset: offset || 0,
  });
  if (error) {
    console.error('getAuditLogs error:', error);
    return [];
  }
  return data || [];
}

/**  * Get total audit log count for pagination.  * SuperAdmin-only RPC: fn_superadmin_get_audit_count.  */
export async function getAuditCount() {
  const {
    data,
    error
  } = await supabase.rpc('fn_superadmin_get_audit_count');
  if (error) {
    console.error('getAuditCount error:', error);
    return 0;
  }
  return data || 0;
}

/**  * Check whether the current user is a superadmin (lightweight client hint).  * The real enforcement is still server-side in every RPC.  */
export async function isSuperadmin() {
  const {
    data,
    error
  } = await supabase.rpc('fn_is_superadmin');
  if (error) {
    console.error('isSuperadmin error:', error);
    return false;
  }
  return !!data;
}
