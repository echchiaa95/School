// ============================================================================
// supabase/functions/login-with-pin/index.ts
// PHASE 3.3: now verifies TWO factors — an identifier (QR token or user
// number) that selects the account, plus the 4-digit PIN that authenticates
// it. Neither alone is accepted; see fn_verify_login for the actual check.
//
// PHASE 3.4: on success, also returns the account's user_number (or null)
// so the frontend can remember this device (modules/device.js) and skip
// QR/manual identification next time. This is the ONLY change from 3.3 —
// the verification logic itself is untouched.
//
// This remains the ONLY place in the whole system that:
//   - touches the raw PIN / QR token / user_number together,
//   - uses SUPABASE_SERVICE_ROLE_KEY.
// Neither ever reaches the browser.
//
// REQUEST BODY (exactly one shape):
//   { method: "qr",     qr_token: "<uuid>", pin: "1234" }
//   { method: "manual", user_number: "<string>", pin: "1234" }
//
// FLOW
//  1. Parse + strictly validate the request shape (reject anything else —
//     extra fields are simply ignored, never used as an authority source).
//  2. Call fn_verify_login(method, identifier, pin, ip) — a SECURITY
//     DEFINER Postgres function (phase3_3_qr_manual_login.sql) that:
//       - throttles by IP AND by identifier (rate limiting),
//       - resolves the account from the QR token or user_number FIRST,
//       - rejects disabled accounts before any session is minted,
//       - compares the PIN via pgcrypto's crypt() against that ONE
//         account's stored hash — never scans other accounts' hashes,
//       - returns a profile_id on full success, nothing on any failure.
//  3. On match, mint a magic-link token for that user and return ONLY the
//     token_hash — the frontend exchanges it for a real session via
//     supabase.auth.verifyOtp(), same as Phase 3.2. This function never
//     issues a session itself.
//
// SECURITY
//  - Every failure path (bad shape, unknown QR, unknown user_number, wrong
//    PIN, disabled, locked, rate-limited, GoTrue error) returns the SAME
//    generic response — the frontend/attacker cannot distinguish any of
//    them from each other. This is intentional and required.
//  - CORS is a real allow-list (ALLOWED_ORIGINS, comma-separated), not "*".
// ============================================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

// Comma-separated allow-list, e.g.:
//   ALLOWED_ORIGINS="https://yourorg.github.io,http://localhost:5500,http://127.0.0.1:5500"
// No origin in the list -> request is still answered (so the generic error
// shape is never itself a tell) but WITHOUT an Access-Control-Allow-Origin
// header, so the browser blocks the response from reaching page JS.
const ALLOWED_ORIGINS = (Deno.env.get('ALLOWED_ORIGINS') || '')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);

const PIN_REGEX = /^\d{4}$/;
const MAX_IDENTIFIER_LEN = 128;

const supabaseAdmin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false },
});

function corsHeaders(origin: string | null) {
  const headers: Record<string, string> = {
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    Vary: 'Origin',
  };
  if (origin && ALLOWED_ORIGINS.includes(origin)) {
    headers['Access-Control-Allow-Origin'] = origin;
  }
  return headers;
}

function jsonResponse(body: unknown, status: number, origin: string | null) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json', ...corsHeaders(origin) },
  });
}

// Single generic failure response — never reveals which reason applied.
function genericFailure(origin: string | null) {
  return jsonResponse({ error: 'INVALID_CREDENTIALS' }, 401, origin);
}

function getClientIp(req: Request): string {
  const forwarded = req.headers.get('x-forwarded-for');
  if (forwarded) return forwarded.split(',')[0].trim();
  return req.headers.get('cf-connecting-ip') || 'unknown';
}

Deno.serve(async (req: Request) => {
  const origin = req.headers.get('origin');

  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders(origin) });
  }
  if (req.method !== 'POST') {
    return jsonResponse({ error: 'METHOD_NOT_ALLOWED' }, 405, origin);
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return jsonResponse({ error: 'INVALID_REQUEST' }, 400, origin);
  }

  const method = typeof body.method === 'string' ? body.method : '';
  const pin = typeof body.pin === 'string' ? body.pin : '';


  if (method !== 'qr' && method !== 'manual') {
    return jsonResponse({ error: 'INVALID_METHOD' }, 400, origin);
  }
  if (!PIN_REGEX.test(pin)) {
    return jsonResponse({ error: 'INVALID_FORMAT' }, 400, origin);
  }

  // Only the field relevant to the declared method is ever read — any
  // other field in the body (including a user_number sent alongside
  // method:"qr", say) is simply never looked at.
  const rawIdentifier =
    method === 'qr'
      ? body.qr_token
      : body.user_number;

  const identifier = typeof rawIdentifier === 'string' ? rawIdentifier.trim() : '';
  if (!identifier || identifier.length > MAX_IDENTIFIER_LEN) {
    return jsonResponse({ error: 'INVALID_IDENTIFIER' }, 400, origin);
  }

  const ip = getClientIp(req);

  const { data, error } = await supabaseAdmin.rpc('fn_verify_login', {
    p_method: method,
    p_identifier: identifier,
    p_pin: pin,
    p_ip: ip,
  });

  if (error) {
    console.error('fn_verify_login error:', error);
    return genericFailure(origin);
  }
  if (!data || data.length === 0) {
    return genericFailure(origin);
  }

  const profileId = data[0].profile_id as string;
  const userNumber = data[0].user_number as string | null; // PHASE 3.4: for device memory only

  // profiles.id === auth.users.id by design (Architecture v1.1 §1).
  const { data: userData, error: userErr } = await supabaseAdmin.auth.admin.getUserById(profileId);
  if (userErr || !userData?.user?.email) {
    console.error('getUserById error or missing email:', userErr);
    return genericFailure(origin);
  }

  const { data: linkData, error: linkErr } = await supabaseAdmin.auth.admin.generateLink({
    type: 'magiclink',
    email: userData.user.email,
  });
  if (linkErr || !linkData?.properties?.hashed_token) {
    console.error('generateLink error:', linkErr);
    return genericFailure(origin);
  }

  return jsonResponse({ token_hash: linkData.properties.hashed_token, user_number: userNumber }, 200, origin);
});
