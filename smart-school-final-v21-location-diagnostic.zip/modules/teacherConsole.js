import { requireAuth, logout } from './auth.js?v=27';
import {
  el, esc, fmtDate, fmtDateTime, toast, statCard,
  loadingHtml, emptyHtml, errorHtml, initPageHeader, showView,
  armViewHistory, armErrorBoundary, showInitError, openNotificationDetails,
} from './ui.js?v=27';
import {
  teacherClasses, getClassAttendance, saveAttendance, addGrade,
  listStudentGradesForTeacher, getClassSchedule, myTeacherSubjects, reportIncident,
  listMyNotifications, markNotificationRead, unreadNotificationsCount,
  getSchoolProfile, teacherClassRoster, getMyTeacherSchedule, isDebug,
} from './school.js?v=27';

// Debug-only logging (SMART_SCHOOL_DEBUG=1): ids only, never tokens/secrets.
const dbg = (...a) => { if (isDebug()) console.log(...a); };

const WEEKDAYS_AR = { 0: 'الأحد', 1: 'الاثنين', 2: 'الثلاثاء', 3: 'الأربعاء', 4: 'الخميس', 5: 'الجمعة', 6: 'السبت' };
const ATT_STATES = [
  ['present', 'حاضر', 'active-present'],
  ['absent', 'غائب', 'active-absent'],
  ['late', 'متأخر', 'active-late'],
  ['excused', 'مبرر', 'active-excused'],
];

let ctx = null;
let classes = [];
let subjects = [];
let roster = []; // current attendance roster: {student_id, full_name, status}
const attendanceMarks = new Map(); // student_id -> status

function classLabel(c) {
  return `${c.name || ''}${c.level ? ' — ' + c.level : ''}${c.year_name ? ' (' + c.year_name + ')' : ''}`;
}

function fillClassSelect(selectEl) {
  if (!selectEl) return;
  selectEl.innerHTML = classes.length
    ? classes.map((c) => `<option value="${c.class_id}">${esc(classLabel(c))}</option>`).join('')
    : '<option value="">لا توجد أقسام مسندة</option>';
}

// ---- Home -------------------------------------------------------------------
async function loadHome() {
  const stats = el('dash-stats');
  const list = el('my-classes');
  if (!stats || !list) throw new Error('TEACHER_HOME_ELEMENTS_MISSING');
  stats.innerHTML = loadingHtml();
  list.innerHTML = '';
  const res = await teacherClasses();
  if (!res.ok) {
    // FIX (Phase 23): a real error here now gets a retry button instead of
    // a dead end — per your instruction, no generic message should be a
    // trap with no way forward.
    stats.innerHTML = errorHtml(res.error);
    list.innerHTML = `<button type="button" class="quick-action-btn secondary" id="home-retry" style="width:100%;">🔄 إعادة المحاولة</button>`;
    el('home-retry')?.addEventListener('click', loadHome);
    return;
  }
  classes = res.data || [];
  const today = new Date().getDay();
  const studentsTotal = classes.reduce((sum, c) => sum + (c.student_count || 0), 0);
  stats.innerHTML = `<div class="stats-grid">${
    statCard(classes.length, 'الأقسام المسندة')
    + statCard(studentsTotal, 'التلاميذ')
    + statCard(WEEKDAYS_AR[today] || '', 'اليوم', 'tone-gold')
  }</div>`;

  if (!classes.length) {
    list.innerHTML = emptyHtml('لا توجد أقسام مسندة إليك حاليًا. تواصل مع إدارة المؤسسة.');
    return;
  }
  list.innerHTML = `<div class="modules-grid">${classes.map((c) => `
    <button type="button" class="module-card" data-open-class="${c.class_id}">
      <span class="module-icon">🏫</span>${esc(classLabel(c))}
      <span class="badge badge-blue">${c.student_count ?? 0} تلميذ</span>
    </button>`).join('')}</div>`;
  list.querySelectorAll('[data-open-class]').forEach((b) => {
    b.addEventListener('click', () => {
      el('att-class').value = b.dataset.openClass;
      showView('attendance');
      loadRoster();
    });
  });

  ['att-class', 'gr-class', 'inc-class'].forEach((id) => fillClassSelect(el(id)));
}

// ---- Attendance -------------------------------------------------------------
function renderRoster() {
  const host = el('att-roster');
  if (!roster.length) {
    host.innerHTML = emptyHtml('لا يوجد تلاميذ في هذا القسم.');
    return;
  }
  const counts = roster.reduce((a, s) => { const st = attendanceMarks.get(s.student_id) || s.status || ''; if (st) a[st] = (a[st]||0)+1; return a; }, {});
  host.innerHTML = `<div class="stats-grid" style="margin-bottom:10px;">${statCard(counts.present||0,'حاضر','tone-green')}${statCard(counts.absent||0,'غائب','tone-red')}${statCard(counts.late||0,'متأخر','tone-gold')}</div><div style="display:grid;gap:7px;">${roster.map((s, i) => {
    const current = attendanceMarks.get(s.student_id) || s.status || '';
    return `<div class="detail-row" style="display:grid;grid-template-columns:minmax(120px,1fr) auto;gap:8px;align-items:center;padding:9px 10px;border:1px solid #e5e7eb;border-radius:12px;">
      <div><strong>${i+1}. ${esc(s.full_name)}</strong><div class="time">#${esc(s.student_number||'—')}</div></div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end;">${ATT_STATES.map(([key, label, cls]) => `<button type="button" class="att-btn ${current === key ? cls : ''}" data-student="${s.student_id}" data-status="${key}">${label}</button>`).join('')}</div>
    </div>`;
  }).join('')}</div>`;
  host.querySelectorAll('.att-btn').forEach((b) => {
    b.addEventListener('click', () => {
      attendanceMarks.set(b.dataset.student, b.dataset.status);
      renderRoster();
    });
  });
}

async function loadRoster() {
  const classId = el('att-class').value;
  const date = el('att-date').value;
  if (!classId) { toast('لا توجد أقسام مسندة إليك حاليًا.', 'error'); return; }
  if (!date) { toast('اختر التاريخ', 'error'); return; }
  el('att-panel').hidden = false;
  el('att-roster').innerHTML = loadingHtml();
  const res = await getClassAttendance(classId, date);
  if (!res.ok) {
    el('att-roster').innerHTML = errorHtml(res.error)
      + `<button type="button" class="quick-action-btn secondary" id="att-retry" style="width:100%; margin-top:8px;">🔄 إعادة المحاولة</button>`;
    el('att-retry')?.addEventListener('click', loadRoster);
    return;
  }
  roster = res.data || [];
  dbg(`[TEACHER ROSTER] loaded ${roster.length} students`);
  attendanceMarks.clear();
  roster.forEach((s) => { if (s.status) attendanceMarks.set(s.student_id, s.status); });
  renderRoster();
}

async function saveRoster() {
  const classId = el('att-class').value;
  const date = el('att-date').value;
  if (!classId || !date) { toast('اختر القسم والتاريخ', 'error'); return; }
  const rows = roster
    .filter((s) => attendanceMarks.has(s.student_id))
    .map((s) => ({ student_id: s.student_id, status: attendanceMarks.get(s.student_id) }));
  if (!rows.length) { toast('لم يتم تحديد أي حالة بعد', 'error'); return; }
  dbg(`[TEACHER ATTENDANCE] saving ${rows.length} marks class=${classId} date=${date}`);
  const res = await saveAttendance(classId, date, rows);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم حفظ الحضور بنجاح', 'success');
  loadRoster();
}

// ---- Grades -----------------------------------------------------------------
async function loadClassStudentsInto(selectEl, classId) {
  selectEl.innerHTML = '<option value="">جارٍ التحميل...</option>';
  if (!classId) { selectEl.innerHTML = '<option value="">اختر القسم أولاً</option>'; return; }
  // FIX (Phase 23): this used to reuse fn_get_class_attendance (a
  // date-scoped attendance query) purely to get a student list, coupling
  // Grades/Incidents to an unrelated feature. Now uses the dedicated,
  // simpler fn_teacher_class_roster.
  const res = await teacherClassRoster(classId);
  if (!res.ok) {
    selectEl.innerHTML = `<option value="">${res.error}</option>`;
    return;
  }
  const students = res.data || [];
  selectEl.innerHTML = students.length
    ? '<option value="">اختر التلميذ</option>' + students.map((s) => `<option value="${s.student_id}">${esc(s.full_name)}</option>`).join('')
    : '<option value="">لا يوجد تلاميذ</option>';
}

async function loadStudentGrades() {
  const studentId = el('gr-student').value;
  const host = el('gr-list');
  if (!studentId) { host.innerHTML = emptyHtml('اختر تلميذًا لعرض نقاطه.'); return; }
  host.innerHTML = loadingHtml();
  const res = await listStudentGradesForTeacher(studentId);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد نقاط مسجلة لهذا التلميذ.'); return; }
  host.innerHTML = `<div class="data-table-wrap"><table class="data-table"><thead><tr>
    <th>المادة</th><th>الفترة</th><th>النوع</th><th>النقطة</th><th>ملاحظة</th><th>التاريخ</th>
  </tr></thead><tbody>${rows.map((g) => `<tr>
    <td>${esc(g.subject_name || '—')}</td><td>${esc(g.period || '—')}</td>
    <td>${esc(g.grade_type || '—')}</td><td>${g.score}/${g.max_score ?? 20}</td>
    <td>${esc(g.note || '—')}</td><td>${fmtDate(g.created_at)}</td>
  </tr>`).join('')}</tbody></table></div>`;
}

async function saveGrade() {
  const studentId = el('gr-student').value;
  const classId = el('gr-class').value || null;
  const subjectId = el('gr-subject').value || null;
  const score = parseFloat(el('gr-score').value);
  if (!studentId) { toast('اختر التلميذ', 'error'); return; }
  if (Number.isNaN(score)) { toast('أدخل نقطة صحيحة', 'error'); return; }
  const res = await addGrade({
    studentId, classId, subjectId,
    period: el('gr-period').value,
    gradeType: el('gr-type').value,
    score,
    maxScore: parseFloat(el('gr-max').value) || 20,
    note: el('gr-note').value.trim() || null,
  });
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم حفظ النقطة بنجاح', 'success');
  el('gr-score').value = '';
  el('gr-note').value = '';
  loadStudentGrades();
}

// ---- Schedule ---------------------------------------------------------------
async function loadSchedule() {
  const host = el('sc-table');
  const currentHost = el('sc-current');
  host.innerHTML = loadingHtml();
  currentHost.innerHTML = '';
  const res = await getMyTeacherSchedule();
  if (!res.ok) {
    host.innerHTML = errorHtml(res.error) + `<button type="button" class="quick-action-btn secondary" id="sc-retry" style="width:100%; margin-top:8px;">🔄 إعادة المحاولة</button>`;
    el('sc-retry')?.addEventListener('click', loadSchedule);
    return;
  }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد حصص مسندة إليك حاليًا.'); return; }
  const now = new Date();
  const jsDay = now.getDay();
  const mins = now.getHours() * 60 + now.getMinutes();
  const dayRows = rows.filter(r => Number(r.weekday) === jsDay);
  const active = dayRows.find(r => {
    const [sh, sm] = String(r.starts_at || '').slice(0,5).split(':').map(Number);
    const [eh, em] = String(r.ends_at || '').slice(0,5).split(':').map(Number);
    return mins >= sh*60+sm && mins < eh*60+em;
  });
  const next = dayRows.find(r => {
    const [sh, sm] = String(r.starts_at || '').slice(0,5).split(':').map(Number);
    return sh*60+sm > mins;
  });
  currentHost.innerHTML = active
    ? `<div class="panel" style="border:1px solid #16a34a55;background:#f0fdf4;"><strong>🟢 حصتك الآن</strong><div style="font-size:1.05em;margin-top:4px;">${esc(active.subject_name)} — ${esc(active.class_name)}</div><div class="time">${esc(String(active.starts_at).slice(0,5))} → ${esc(String(active.ends_at).slice(0,5))}</div></div>`
    : next
      ? `<div class="panel" style="border:1px solid #d4a72c55;background:#fffbeb;"><strong>⏭️ الحصة القادمة</strong><div style="font-size:1.05em;margin-top:4px;">${esc(next.subject_name)} — ${esc(next.class_name)}</div><div class="time">${esc(String(next.starts_at).slice(0,5))} → ${esc(String(next.ends_at).slice(0,5))}</div></div>`
      : `<div class="empty-state">لا توجد حصة جارية أو قادمة اليوم.</div>`;
  host.innerHTML = `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>اليوم</th><th>الوقت</th><th>الحصة</th><th>المادة</th></tr></thead><tbody>${rows.map(r => `<tr class="${Number(r.weekday)===jsDay ? 'today-row':''}"><td>${esc(WEEKDAYS_AR[r.weekday] || r.weekday)}</td><td><strong>${esc(String(r.starts_at||'').slice(0,5))} — ${esc(String(r.ends_at||'').slice(0,5))}</strong></td><td>${esc(r.class_name||'—')}</td><td>${esc(r.subject_name||'—')}</td></tr>`).join('')}</tbody></table></div>`;
}

// ---- Incidents --------------------------------------------------------------
async function saveIncident() {
  const studentId = el('inc-student').value;
  const desc = el('inc-desc').value.trim();
  if (!studentId) { toast('اختر التلميذ', 'error'); return; }
  const res = await reportIncident({
    studentId,
    type: el('inc-type').value,
    title: el('inc-type').value,
    description: desc || null,
    place: el('inc-place').value.trim() || null,
  });
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم إرسال البلاغ إلى الإدارة', 'success');
  el('inc-desc').value = '';
  el('inc-place').value = '';
}

// ---- Notifications ----------------------------------------------------------
async function loadNotifications() {
  const host = el('notif-list');
  host.innerHTML = loadingHtml();
  const res = await listMyNotifications(50);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد إشعارات.'); refreshNotifBadge(); return; }
  host.innerHTML = rows.map((n) => `
    <div class="detail-row" data-notif="${n.id}" style="cursor:pointer; ${n.is_read ? 'opacity:.65;' : 'font-weight:600;'}">
      <div style="flex:1;">
        <div>${esc(n.title)}</div>
        ${n.body ? `<div style="font-size:.85em; color:var(--muted);">${esc(n.body)}</div>` : ''}
      </div>
      <span class="badge badge-blue">${esc(n.type || '')}</span>
      <span style="font-size:.8em; color:var(--muted);">${fmtDateTime(n.created_at)}</span>
    </div>`).join('');
  host.querySelectorAll('[data-notif]').forEach((row) => {
    row.addEventListener('click', async () => {
      await markNotificationRead(row.dataset.notif);
      row.style.opacity = '.65';
      row.style.fontWeight = '400';
      openNotificationDetails(rows.find((n) => (n.id || n.notification_id) === row.dataset.notif));
      refreshNotifBadge();
    });
  });
  refreshNotifBadge();
}

async function refreshNotifBadge() {
  const res = await unreadNotificationsCount();
  const badge = el('notif-count');
  if (!badge) return;
  const count = res.ok ? (res.data || 0) : 0;
  badge.hidden = !count;
  badge.textContent = count;
}

// ---- Init -------------------------------------------------------------------
(async () => {
  try {
    armErrorBoundary();
    ctx = await requireAuth('teacher.html');
    if (!ctx) return;
    armViewHistory('home');
    document.getElementById('app-body').hidden = false;

    // Header/profile lookup is non-fatal: a transient profile RPC failure must
    // never prevent a valid teacher session from opening the dashboard.
    let schoolName = null;
    try {
      const schoolRes = await getSchoolProfile(ctx.schoolId);
      schoolName = schoolRes.ok ? schoolRes.data?.name : null;
    } catch (e) {
      console.warn('teacher school profile lookup failed:', e);
    }
    await initPageHeader(ctx, schoolName, logout);

    const bind = (id, event, fn) => { const node = el(id); if (node) node.addEventListener(event, fn); };
    const dateEl = el('att-date');
    if (dateEl) dateEl.value = new Date().toISOString().slice(0, 10);

    document.querySelectorAll('[data-go]').forEach((b) => {
      b.addEventListener('click', () => {
        showView(b.dataset.go);
        if (b.dataset.go === 'notifications') loadNotifications();
        if (b.dataset.go === 'grades') loadSubjectsInto();
        if (b.dataset.go === 'schedule') loadSchedule();
      });
    });
    document.querySelectorAll('[data-back]').forEach((b) => b.addEventListener('click', () => showView('home')));
    bind('notif-btn', 'click', () => { showView('notifications'); loadNotifications(); });
    bind('att-load', 'click', loadRoster);
    bind('att-save', 'click', saveRoster);
    bind('gr-class', 'change', () => loadClassStudentsInto(el('gr-student'), el('gr-class')?.value));
    bind('gr-student', 'change', loadStudentGrades);
    bind('gr-save', 'click', saveGrade);
    bind('inc-class', 'change', () => loadClassStudentsInto(el('inc-student'), el('inc-class')?.value));
    bind('inc-save', 'click', saveIncident);

    // The shell is already visible; loadHome is isolated so a dashboard data
    // problem cannot turn into a fatal "تعذر تحميل اللوحة" screen.
    try { await loadHome(); }
    catch (e) {
      console.error('teacher home load error:', e);
      const host = el('dash-stats');
      if (host) host.innerHTML = errorHtml(e?.message || 'تعذر تحميل بيانات الأستاذ.');
    }
    refreshNotifBadge();
  } catch (error) {
    console.error('teacher console init error:', error);
    showInitError(error);
  }
})();

async function loadSubjectsInto() {
  if (subjects.length) return;
  // PHASE 14: a teacher only ever sees their ASSIGNED subjects (the server
  // independently enforces the same rule in fn_add_grade). fn_list_subjects
  // returns subject_id/subject_name — the old s.id/s.name keys produced
  // empty option values and server-side GRADE_SUBJECT_REQUIRED failures.
  const res = await myTeacherSubjects();
  if (res.ok) {
    subjects = res.data || [];
    el('gr-subject').innerHTML = subjects.length
      ? subjects.map((s) => `<option value="${s.subject_id}">${esc(s.subject_name)}</option>`).join('')
      : '<option value="">لا توجد مواد مسندة — راجع الإدارة</option>';
  }
}
