// ============================================================================
// modules/mapPicker.js
// A single-screen (modal) tap-to-place-marker location picker.
//
// No Google Maps JavaScript API key exists anywhere in this project
// (checked across every HTML file) — building a "real" Google Maps
// draggable-marker picker would require inventing one, which you asked
// us not to do. Leaflet + OpenStreetMap tiles gives the exact same UX
// (tap the map, a pin drops where you tapped, drag to fine-tune, one
// Save button) with NO key and NO account needed — loaded from a public
// CDN, same pattern already used for the QR library (modules/badgeCard.js).
// "Open in Google Maps" for outside navigation is still offered
// separately wherever a saved location is shown (plain URL, no key).
// ============================================================================

let leafletPromise = null;
export function loadLeaflet() {
  if (window.L) return Promise.resolve();
  if (leafletPromise) return leafletPromise;
  leafletPromise = new Promise((resolve, reject) => {
    const css = document.createElement('link');
    css.rel = 'stylesheet';
    css.href = 'https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css';
    document.head.appendChild(css);
    const s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js';
    s.onload = () => resolve();
    s.onerror = () => reject(new Error('MAP_LIB_LOAD_FAILED'));
    document.head.appendChild(s);
  });
  return leafletPromise;
}

/**
 * Open a full-screen modal with a tap-to-place-marker map.
 * @param {{lat?:number, lng?:number, label?:string, onSave:(r:{lat:number,lng:number,label:string})=>void}} opts
 */
export async function openMapPicker(opts) {
  const overlay = document.createElement('div');
  overlay.className = 'map-picker-overlay';
  overlay.innerHTML = `
    <div class="map-picker-sheet">
      <div class="map-picker-header">
        <strong>حدد الموقع على الخريطة</strong>
        <button type="button" class="icon-btn" id="mp-close">✕</button>
      </div>
      <p class="empty-state" style="margin:4px 0;">اضغط على مكان المنزل لوضع 📍، ثم اسحبه لضبطه بدقة.</p>
      <div id="mp-map" style="width:100%; height:min(50vh, 380px); border-radius:10px; background:#e5e7eb;"></div>
      <input type="text" id="mp-label" class="search-input" placeholder="تسمية اختيارية (مثال: بجانب المسجد)" style="margin-top:10px;" value="${opts.label ? String(opts.label).replace(/"/g, '&quot;') : ''}">
      <div style="display:flex; gap:8px; margin-top:10px;">
        <button type="button" class="quick-action-btn secondary" id="mp-current" style="flex:1;">📍 موقعي الحالي</button>
        <button type="button" class="quick-action-btn secondary" id="mp-cancel" style="flex:1;">إلغاء</button>
        <button type="button" class="quick-action-btn" id="mp-save" style="flex:1;" disabled>حفظ الموقع</button>
      </div>
    </div>`;
  if (!document.getElementById('map-picker-style')) {
    const style = document.createElement('style');
    style.id = 'map-picker-style';
    style.textContent = `
      .map-picker-overlay{position:fixed; inset:0; background:rgba(17,24,39,.55); z-index:2000; display:flex; align-items:flex-end; justify-content:center;}
      .map-picker-sheet{background:#fff; width:100%; max-width:520px; border-radius:16px 16px 0 0; padding:14px; direction:rtl;}
      .map-picker-header{display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;}
      @media (min-width:640px){ .map-picker-overlay{align-items:center;} .map-picker-sheet{border-radius:16px;} }`;
    document.head.appendChild(style);
  }
  document.body.appendChild(overlay);

  const close = () => overlay.remove();
  overlay.querySelector('#mp-close').addEventListener('click', close);
  overlay.querySelector('#mp-current').addEventListener('click', () => {
    const b = overlay.querySelector('#mp-current');
    if (!navigator.geolocation) { b.textContent = 'الموقع غير مدعوم'; return; }
    b.disabled = true; b.textContent = 'جارٍ تحديد الموقع...';
    navigator.geolocation.getCurrentPosition((pos) => {
      setMarker(pos.coords.latitude, pos.coords.longitude);
      map.setView([pos.coords.latitude, pos.coords.longitude], 17);
      b.disabled = false; b.textContent = '📍 موقعي الحالي';
    }, () => {
      b.disabled = false; b.textContent = '📍 موقعي الحالي';
      alert('تعذر الحصول على الموقع. فعّل إذن الموقع ثم حاول مرة أخرى.');
    }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 });
  });
  overlay.querySelector('#mp-cancel').addEventListener('click', close);

  let marker = null;
  let picked = opts.lat != null && opts.lng != null ? { lat: opts.lat, lng: opts.lng } : null;
  const saveBtn = overlay.querySelector('#mp-save');
  saveBtn.disabled = !picked;

  try {
    await loadLeaflet();
  } catch (e) {
    overlay.querySelector('#mp-map').innerHTML = '<div class="empty-state">تعذر تحميل الخريطة. تحقق من الإنترنت ثم أغلق النافذة وحاول مرة أخرى.</div>';
    return;
  }

  const startLat = picked?.lat ?? 27.15; // Laâyoune-ish default; irrelevant once the user taps
  const startLng = picked?.lng ?? -13.2;
  const map = window.L.map('mp-map').setView([startLat, startLng], picked ? 15 : 6);
  window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap',
    maxZoom: 19,
  }).addTo(map);

  function setMarker(lat, lng) {
    picked = { lat, lng };
    if (marker) { marker.setLatLng([lat, lng]); }
    else {
      marker = window.L.marker([lat, lng], { draggable: true }).addTo(map);
      marker.on('dragend', () => { const p = marker.getLatLng(); picked = { lat: p.lat, lng: p.lng }; });
    }
    saveBtn.disabled = false;
  }
  if (picked) setMarker(picked.lat, picked.lng);
  map.on('click', (e) => setMarker(e.latlng.lat, e.latlng.lng));
  setTimeout(() => map.invalidateSize(), 50);

  saveBtn.addEventListener('click', async () => {
    if (!picked) return;
    if (!validPick(picked.lat, picked.lng)) {
      alert('الإحداثيات غير صالحة. اختر نقطة صحيحة على الخريطة.');
      return;
    }
    saveBtn.disabled = true;
    saveBtn.textContent = 'جارٍ الحفظ...';
    try {
      const result = await opts.onSave({ lat: picked.lat, lng: picked.lng, label: overlay.querySelector('#mp-label').value.trim() });
      if (result && result.ok === false) {
        // The caller (admin/student console) already showed the classified
        // error toast — re-alerting here would duplicate the message.
        saveBtn.disabled = false;
        saveBtn.textContent = 'حفظ الموقع';
        return;
      }
      close();
    } catch (e) {
      console.error('map picker save failed:', e);
      alert(e?.message || 'تعذر حفظ الموقع. حاول مرة أخرى.');
      saveBtn.disabled = false;
      saveBtn.textContent = 'حفظ الموقع';
    }
  });
}
