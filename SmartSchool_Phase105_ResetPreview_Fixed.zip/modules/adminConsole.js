// ============================================================================
// modules/adminConsole.js — full school console (Phase 15: ADMIN = DIRECTOR).
// Powers admin.html — the ONLY administrative dashboard of the school.
// Every view reads/writes through RLS-scoped queries or SECURITY DEFINER
// RPCs — never a client-asserted school_id.
// ============================================================================

import { requireAuth, logout } from './auth.js';
import { supabase } from './supabase.js';
import {
  el, esc, fmtDate, fmtDateTime, fmtMoney, toast, confirmDialog, showView,
  initPageHeader, statCard, roleAr, loadingHtml, emptyHtml, errorHtml, downloadCSV, attStatusAr,
  armViewHistory, showInitError, openNotificationDetails, phoneActions,
} from './ui.js';
import { renderAppointmentManagement } from './appointments.js';
import { exportToExcel, printReport } from './reportExport.js';
import { printReceipt } from './receiptPrint.js';
import { buildWeeklyTimetable, printWeeklyTimetable, downloadWeeklyTimetablePdf, periodTimeRange } from './scheduleGrid.js';
import { initErrorMonitor } from './errorMonitor.js';
import { mountInstallPrompt } from './installPrompt.js';
import { initOffline } from './offline.js';
import {
  schoolDashboard, getSchoolProfile, updateSchool, updateSchoolLocation,
  getGuardStats,
  listMyAcademicYears, createAcademicYearMy, setCurrentAcademicYear, updateAcademicYear,
  listPromotionCandidates, processStudentProgression, studentProgressionHistory,
  listMyClasses, createClassMy, updateClass,
  classFinalResults, saveClassCouncil, saveClassCouncilDecisions, classCouncilDetails,
  issueSchoolCertificate, listSchoolCertificates, voidSchoolCertificate,
  uploadSchoolArchiveDocument, listSchoolArchiveDocuments, archiveSchoolDocument, createArchiveDocumentLink,
  updateSchoolDocumentRequest,
  listSubjects, createSubject,
  saveAttendance, getClassAttendance, getStudentAttendance, schoolAttendanceToday, reportAttendance, attendanceAbsenceAlerts, attendanceAuditHistory,
  listSchoolStaff, staffCheckIn, staffCheckOut, markStaffAttendance, getStaffAttendanceReport,
  addGrade, listStudentGrades,
  reportIncident, listIncidents, updateIncident,
  sendNotification, listMyNotifications, markNotificationRead, unreadNotificationsCount,
  deleteMyNotification, uploadNotificationImage,
  createBus, listBuses, createRoute, updateRoute, deleteRoute, listRoutes, createBusRouteRun, listSchoolBusRouteRuns, setBusRouteClasses, listBusRouteClasses, assignStudentTransport, studentTransportInfo,
  recordPayment, listPayments, recordExpense, listExpenses, financeSummary,
  listSchoolFeePlans, upsertSchoolFeePlan, getStudentFeeQuote, createStudentFeeDiscount, correctPayment, getPaymentAuditHistory, reportStudentFeeDiscounts, setStudentTransportAndGenerate, reportFeeObligations, listStudentFeeObligations, recordFeePaymentBatch,
  setClassSchedule, getClassSchedule, addLesson, updateLesson, deleteLesson,
  getSchoolPeriods, setSchoolPeriods,
  getStudentFull, getUserPermissions, grantUserPermission, revokeUserPermission,
  updateStudentProfile, listAccountsLastSeen, markStaffAttendanceHours, getSchoolAttendanceSummary,
  listSchoolPosts, saveSchoolPost, deleteSchoolPost,
  previewSchoolReset, exportSchoolBackup, importSchoolBackup, resetSchoolData,
  assignTeacherSubject, removeTeacherSubject, listTeacherSubjects,
  assignTeacherClass, removeTeacherClass, listTeacherClasses,
  getTeacherFull, getTeacherSchedule, getStudentSchedule, getStudentBadge,
  updateStudentLocation, adminSaveSchoolLocation, setTeacherRate, upsertTeacherMonth, recordTeacherPayment, listTeacherPayroll,
  schoolAudit, mapRpcError, isDebug,
} from './school.js';

// Debug-only logging (SMART_SCHOOL_DEBUG=1): coordinates/ids only, never secrets.
const dbg = (...a) => { if (isDebug()) console.log(...a); };
import { searchStudents, registerStudent, filterStudents, issueBadge, reissueBadge, suspendBadge } from './students.js';
import { renderBadgeCard } from './badgeCard.js';
import { openMapPicker } from './mapPicker.js';
import { renderStudentPhotoBox } from './photoUpload.js';
import { initStudentImport } from './studentImport.js';
import { renderInstitutionMigrationAssistant } from './institutionMigration.js';
import { renderLiveMap } from './liveMap.js';
import { listTeachers, listDrivers, listParents, createStaffAccount } from './accounts.js';
import { listGuards, createGuardAccount, listAllPermissions, setGuardStatus } from './admin.js';

let ctx = null;
let schoolId = null;
let schoolProfileCache = null;
async function getCachedSchoolProfile() {
  if (schoolProfileCache) return schoolProfileCache;
  const res = await getSchoolProfile(schoolId);
  schoolProfileCache = res.ok ? (res.data || {}) : {};
  return schoolProfileCache;
}
let cache = { years: null, classes: null, teachers: null, drivers: null, subjects: null, buses: null, routes: null };
let currentStaffType = 'teacher';
let currentGuard = null;
let currentStudentId = null;
let selectedLinks = [];      // parent-student links for staff-add form
let pickedStudent = null;    // student picked for payment/incident forms\nlet pickedDiscountStudent = null;
let auditOffset = 0;
let currentCouncilId = null;
let currentCouncilRows = [];
let editingRouteId = null;
const PAGE_SIZE = 30;

// ===== INIT =====
window.__ADMIN_BOOTED = true;
(async () => {
  try {
    initErrorMonitor('admin.html');
    mountInstallPrompt();
    ctx = await requireAuth('admin.html');
    if (!ctx) return;
    initOffline();
    schoolId = ctx.schoolId;
    const profile = await getSchoolProfile(schoolId);
    initPageHeader(ctx, profile.ok && profile.data ? profile.data.name : null, logout);
    el('app-body').hidden = false;
    armViewHistory('home');
    showView('home');
    try {
      await loadDashboard();
    } catch (error) {
      console.error('admin dashboard load error:', error);
      const host = el('dash-stats');
      if (host) host.innerHTML = `<div class="panel"><p class="empty-state">تعذر تحميل لوحة المؤشرات. ${esc(error?.message || 'خطأ غير معروف')}</p></div>`;
    }
    try { await refreshNotifCount(); } catch (error) { console.error('notification count error:', error); }
  } catch (error) {
    console.error('admin init error:', error);
    // Never kick back to the login page on a transient post-auth failure:
    // the session is valid — surface the real error inside the dashboard.
    showInitError(error);
  }
})();

// ===== NAV =====
document.querySelectorAll('[data-go]').forEach((b) => b.addEventListener('click', () => openModule(b.dataset.go)));
document.querySelectorAll('[data-back]').forEach((b) => b.addEventListener('click', () => {
  if (liveMapCleanup) { liveMapCleanup(); liveMapCleanup = null; }
  showView(b.dataset.back);
  if (b.dataset.back === 'home') loadDashboard();
  if (b.dataset.back === 'students') loadStudents();
  if (b.dataset.back === 'incidents') loadIncidentsView();
  if (b.dataset.back === 'guards') loadGuards();
}));

let liveMapCleanup = null;
function openModule(name) {
  if (liveMapCleanup) { liveMapCleanup(); liveMapCleanup = null; }
  showView(name);
  const loaders = {
    institution: loadInstitution, academic: loadAcademic, subjects: loadSubjects,
    students: loadStudents, 'student-import': loadStudentImportView, teachers: () => loadStaffList('teachers'),
    drivers: () => loadStaffList('drivers'), parents: () => loadStaffList('parents'),
    guards: loadGuards, attendance: loadAttendanceView, schedule: loadScheduleView,
    transport: loadTransport, finance: loadFinance, incidents: loadIncidentsView,
    reports: loadReportsView, notifications: loadNotificationsView, audit: loadAuditView,
    website: loadWebsiteView,
    'migration-assistant': loadMigrationAssistant,
    backup: loadBackupView,
    appointments: () => renderAppointmentManagement(el('appointments-panel'), { canManageSettings: true }),
    'live-tracking': async () => { liveMapCleanup = await renderLiveMap(el('live-map-host'), schoolId); },
  };
  const task = loaders[name]?.();
  if (task && typeof task.catch === 'function') {
    task.catch((error) => {
      console.error(`module load failed: ${name}`, error);
      const host = document.querySelector(`[data-view="${name}"] .panel`);
      if (host) host.innerHTML = errorHtml('تعذر تحميل هذه الصفحة. أعد المحاولة، وإذا تكرر الخطأ أرسل تفاصيله للدعم.');
    });
  }
}

async function refreshNotifCount() {
  const res = await unreadNotificationsCount();
  if (res.ok && res.data > 0) {
    el('notif-count').hidden = false;
    el('notif-count').textContent = res.data;
  }
}
el('notif-btn').addEventListener('click', () => openModule('notifications'));

// ===== DASHBOARD =====
async function loadDashboard() {
  const host = el('dash-stats');
  host.innerHTML = loadingHtml();
  const res = await schoolDashboard();
  if (!res.ok) { host.innerHTML = emptyHtml(res.error); return; }
  const d = res.data || {};
  const att = d.attendance_today || {};
  host.innerHTML = '<div class="stats-grid">'
    + statCard(d.students ?? 0, 'التلاميذ')
    + statCard(att.present ?? 0, 'حاضرون اليوم', 'tone-green')
    + statCard((att.absent ?? 0) + (att.late ?? 0), 'غياب/تأخر اليوم', 'tone-red')
    + statCard(d.teachers ?? 0, 'الأساتذة')
    + statCard(d.guards ?? 0, 'الحراس')
    + statCard(d.drivers ?? 0, 'السائقون')
    + statCard(d.parents ?? 0, 'أولياء الأمور')
    + statCard(d.classes ?? 0, 'الأقسام')
    + statCard(d.buses ?? 0, 'الحافلات')
    + statCard(fmtMoney(d.payments_month), 'أداءات الشهر', 'tone-green')
    + statCard(fmtMoney(d.expenses_month), 'مصاريف الشهر', 'tone-red')
    + statCard(d.open_incidents ?? 0, 'مخالفات مفتوحة', 'tone-gold')
    + '</div>';
}

// §30-31: normalize the school website client-side (the schools trigger in
// phase25 is the authoritative guard). example.ma → https://example.ma;
// dangerous schemes (javascript:/data:/vbscript:/file:) are rejected.
function normalizeWebsite(input) {
  let v = String(input || '').trim();
  if (!v) return '';
  if (/^(javascript|data|vbscript|file):/i.test(v)) { toast('رابط غير آمن مرفوض.', 'error'); return null; }
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(v)) v = 'https://' + v;
  try { new URL(v); return v; } catch { toast('صيغة الرابط غير صالحة.', 'error'); return null; }
}

// ===== INSTITUTION =====
async function loadInstitution() {
  const body = el('institution-body');
  body.innerHTML = loadingHtml();
  const res = await getSchoolProfile(schoolId);
  if (!res.ok) { body.innerHTML = emptyHtml(res.error); return; }
  const s = res.data;
  const row = (k, v) => `<div class="detail-row"><span class="k">${k}</span><span class="v">${esc(v || '—')}</span></div>`;
  body.innerHTML = '<div class="panel">'
    + (s.logo_url ? `<div style="text-align:center; margin-bottom:10px;"><img src="${esc(s.logo_url)}" alt="الشعار" style="max-height:80px; border-radius:10px;"></div>` : '')
    + row('الاسم', s.name) + row('الاسم القانوني', s.legal_name) + row('النوع', s.school_type)
    + row('العنوان', s.address) + row('المدينة', s.city) + row('الجهة', s.region)
    + row('الهاتف', s.phone) + row('البريد', s.email)
    + (s.website ? `<div class="detail-row"><span class="k">الموقع</span><span class="v"><a href="${esc(s.website)}" target="_blank" rel="noopener">🔗 ${esc(s.website)}</a></span></div>` : row('الموقع', null))
    + row('المدير', s.director_name) + row('ICE', s.ice) + row('معلومات إضافية', s.notes)
    + '</div>';
  el('in-name').value = s.name || ''; el('in-legal').value = s.legal_name || '';
  el('in-type').value = s.school_type || ''; el('in-city').value = s.city || '';
  el('in-region').value = s.region || ''; el('in-address').value = s.address || '';
  el('in-phone').value = s.phone || ''; el('in-email').value = s.email || '';
  el('in-website').value = s.website || ''; el('in-ice').value = s.ice || '';
  el('in-logo').value = s.logo_url || ''; el('in-notes').value = s.notes || '';
  renderSchoolLocation(s);
  renderPeriodsConfig();
}

async function uploadSchoolLogo(file) {
  if (!file) return;
  const status = el('in-logo-status');
  if (!file.type.startsWith('image/')) { status.textContent = 'الرجاء اختيار صورة.'; return; }
  if (file.size > 5 * 1024 * 1024) { status.textContent = 'حجم الشعار يجب ألا يتجاوز 5MB.'; return; }
  const btn = el('in-logo-upload');
  btn.disabled = true; status.textContent = 'جارٍ رفع الشعار...';
  try {
    const ext = (file.name.split('.').pop() || 'png').toLowerCase().replace(/[^a-z0-9]/g, '') || 'png';
    const path = `${schoolId}/logo.${ext}`;
    const { error } = await supabase.storage.from('school-logos').upload(path, file, {
      upsert: true, cacheControl: '3600', contentType: file.type,
    });
    if (error) throw error;
    const { data } = supabase.storage.from('school-logos').getPublicUrl(path);
    const url = `${data.publicUrl}?v=${Date.now()}`;
    el('in-logo').value = url;
    const save = await updateSchool(schoolId, { logo_url: url });
    if (!save.ok) throw new Error(save.error);
    status.textContent = 'تم رفع الشعار وحفظه بنجاح.';
    await loadInstitution();
  } catch (e) {
    console.error('school logo upload failed:', e);
    status.textContent = 'تعذر رفع الشعار. تأكد من نشر Phase26 ثم حاول مرة أخرى.';
  } finally { btn.disabled = false; }
}

async function renderPeriodsConfig() {
  const host = el('periods-panel');
  host.innerHTML = loadingHtml();
  const res = await getSchoolPeriods();
  const cfg = res.ok ? res.data : {};
  host.innerHTML = `
    <div class="form-grid">
      <div><label>🌅 بداية الصباح</label><input type="time" id="pc-m-start" class="search-input" value="${(cfg.morning_start || '08:00').slice(0, 5)}"></div>
      <div><label>مدة حصة الصباح (دقيقة)</label><input type="number" id="pc-m-min" class="search-input" min="15" step="5" value="${cfg.morning_lesson_minutes ?? 60}"></div>
      <div><label>☀️ بداية الزوال</label><input type="time" id="pc-a-start" class="search-input" value="${(cfg.afternoon_start || '14:00').slice(0, 5)}"></div>
      <div><label>مدة حصة الزوال (دقيقة)</label><input type="number" id="pc-a-min" class="search-input" min="15" step="5" value="${cfg.afternoon_lesson_minutes ?? 60}"></div>
    </div>
    <p class="empty-state" style="margin-top:6px;">النظام ثابت: 4 حصص صباحًا + 4 حصص زوالًا = 8 حصص/يوم. سيُحسب توقيت كل حصة تلقائيًا من هذا الإعداد.</p>
    <button type="button" class="quick-action-btn" id="pc-save" style="width:100%; margin-top:6px;">حفظ توقيت الحصص</button>`;
  el('pc-save').addEventListener('click', async () => {
    const payload = {
      morningStart: el('pc-m-start').value, morningLessonMinutes: Number(el('pc-m-min').value),
      afternoonStart: el('pc-a-start').value, afternoonLessonMinutes: Number(el('pc-a-min').value),
    };
    const r = await setSchoolPeriods(payload);
    if (!r.ok) { toast(r.error, 'error'); return; }
    toast('تم حفظ توقيت الحصص.', 'success');
    schoolPeriodsCache = null;
  });
}

function renderSchoolLocation(s) {
  const host = el('school-location-panel');
  const hasLoc = s.latitude != null && s.longitude != null;
  host.innerHTML = hasLoc
    ? `<iframe src="https://maps.google.com/maps?q=${s.latitude},${s.longitude}&z=15&output=embed" style="width:100%; height:160px; border:0; border-radius:8px;" loading="lazy"></iframe>
       <button type="button" class="quick-action-btn secondary" id="school-loc-btn" style="width:100%; margin-top:8px;">📍 تغيير موقع المؤسسة</button>`
    : `${emptyHtml('لم يُحدَّد موقع المؤسسة بعد — هذا هو نقطة البداية/النهاية الافتراضية للنقل المدرسي.')}<button type="button" class="quick-action-btn" id="school-loc-btn" style="width:100%;">📍 تحديد موقع المؤسسة</button>`;
  el('school-loc-btn').addEventListener('click', () => {
    openMapPicker({
      lat: s.latitude, lng: s.longitude, label: s.location_label,
      onSave: async ({ lat, lng, label }) => {
        dbg(`[INSTITUTION LOCATION] saving lat=${lat} lng=${lng}`);
        const res = await adminSaveSchoolLocation(schoolId, lat, lng, label || null);
        if (!res.ok) {
          dbg('[INSTITUTION LOCATION ERROR]', res.error, res.kind || '');
          toast(res.error, 'error');
          return res;
        }
        dbg('[INSTITUTION LOCATION] saved, reloading institution');
        toast('تم حفظ موقع المؤسسة.', 'success');
        // Do not re-run the whole institution panel after a successful save.
        // That secondary refresh was able to turn a successful RPC into a
        // generic global error if an unrelated panel failed during refresh.
        // Update the local location card immediately instead.
        s.latitude = lat;
        s.longitude = lng;
        s.location_label = label || s.location_label || null;
        renderSchoolLocation(s);
        return res;
      },
    });
  });
}

el('institution-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    name: el('in-name').value, legal_name: el('in-legal').value, school_type: el('in-type').value,
    city: el('in-city').value, region: el('in-region').value, address: el('in-address').value,
    phone: el('in-phone').value, email: el('in-email').value,
    website: normalizeWebsite(el('in-website').value),
    ice: el('in-ice').value, logo_url: el('in-logo').value, notes: el('in-notes').value,
  };
  if (payload.website === null) return; // رابط غير آمن/غير صالح — لا يُرسل أصلًا (§31)
  const res = await updateSchool(schoolId, payload);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم حفظ بيانات المؤسسة.', 'success');
  loadInstitution();
});

const logoFile = el('in-logo-file');
el('in-logo-upload').addEventListener('click', () => logoFile.click());
logoFile.addEventListener('change', () => uploadSchoolLogo(logoFile.files?.[0]));
el('in-logo-clear').addEventListener('click', () => { el('in-logo').value = ''; el('in-logo-status').textContent = 'سيُحذف الشعار عند الضغط على حفظ.'; });

// ===== ACADEMIC YEARS & CLASSES =====
async function refreshYearsClasses() {
  const [y, c] = await Promise.all([listMyAcademicYears(), listMyClasses(null)]);
  cache.years = y.ok ? y.data || [] : [];
  cache.classes = c.ok ? c.data || [] : [];
  return { years: cache.years, classes: cache.classes };
}


function setupProgressionPanel(years, classes) {
  const source = el('pg-source-class');
  const targetYear = el('pg-target-year');
  const candidatesHost = el('pg-candidates');
  const processBtn = el('pg-process');
  if (!source || !targetYear || !candidatesHost || !processBtn) return;

  const activeClasses = (classes || []).filter((c) => !c.is_disabled);
  source.innerHTML = activeClasses.map((c) =>
    `<option value="${c.class_id}">${esc(c.class_name)} — ${esc(c.year_name || '')}</option>`
  ).join('');
  targetYear.innerHTML = (years || []).filter((y) => !y.is_disabled).map((y) =>
    `<option value="${y.year_id}">${esc(y.year_name)}${y.is_current ? ' (الحالية)' : ''}</option>`
  ).join('');
  candidatesHost.innerHTML = emptyHtml('اختر القسم الحالي والسنة المستهدفة ثم اعرض التلاميذ.');
  processBtn.hidden = true;

  const renderCandidates = async () => {
    const sourceId = source.value;
    const targetYearId = targetYear.value;
    const sourceClass = activeClasses.find((c) => String(c.class_id) === String(sourceId));
    if (!sourceId || !targetYearId) {
      candidatesHost.innerHTML = emptyHtml('تأكد من إنشاء قسم وسنة دراسية مستهدفة.');
      processBtn.hidden = true;
      return;
    }
    if (String(sourceClass?.year_id) === String(targetYearId)) {
      candidatesHost.innerHTML = emptyHtml('يجب اختيار سنة دراسية مختلفة عن السنة الحالية للتلميذ.');
      processBtn.hidden = true;
      return;
    }
    candidatesHost.innerHTML = loadingHtml();
    const [res] = await Promise.all([listPromotionCandidates(sourceId)]);
    if (!res.ok) {
      candidatesHost.innerHTML = emptyHtml(mapRpcError(res.error));
      processBtn.hidden = true;
      return;
    }
    const students = res.data || [];
    const targets = activeClasses.filter((c) => String(c.academic_year_id) === String(targetYearId));
    if (!students.length) {
      candidatesHost.innerHTML = emptyHtml('لا يوجد تلاميذ مسجلون حالياً في هذا القسم.');
      processBtn.hidden = true;
      return;
    }
    if (!targets.length) {
      candidatesHost.innerHTML = emptyHtml('لا توجد أقسام في السنة المستهدفة. أنشئ الأقسام أولاً.');
      processBtn.hidden = true;
      return;
    }
    candidatesHost.innerHTML = `<div class="time" style="margin-bottom:8px;">عدد التلاميذ: ${students.length}. أزل التحديد عن أي تلميذ لا تريد نقله الآن.</div>`
      + students.map((st) => `
        <div class="history-item" style="align-items:flex-start;gap:8px;flex-wrap:wrap;">
          <label style="display:flex;align-items:center;gap:8px;min-width:190px;flex:1;">
            <input type="checkbox" data-pg-student="${st.student_id}" checked>
            <span><strong>${esc(st.full_name)}</strong><span class="time" style="display:block">#${esc(st.student_number || '—')}</span></span>
          </label>
          <select class="search-input" style="min-width:150px;flex:1" data-pg-target="${st.student_id}">
            ${targets.map((c) => `<option value="${c.class_id}">${esc(c.class_name)} — ${esc(c.level || '')}</option>`).join('')}
          </select>
          <select class="search-input" style="min-width:125px;flex:0.7" data-pg-outcome="${st.student_id}">
            <option value="PROMOTED">ترقية</option>
            <option value="REPEATED">إعادة المستوى</option>
          </select>
          <button type="button" class="att-btn" data-pg-history="${st.student_id}">المسار الدراسي</button>
          <div id="pg-history-${st.student_id}" style="width:100%;"></div>
        </div>`).join('');
    candidatesHost.querySelectorAll('[data-pg-history]').forEach((button) => {
      button.addEventListener('click', async () => {
        const host = candidatesHost.querySelector(`#pg-history-${button.dataset.pgHistory}`);
        if (!host) return;
        host.innerHTML = loadingHtml();
        const history = await studentProgressionHistory(button.dataset.pgHistory);
        if (!history.ok) { host.innerHTML = emptyHtml(mapRpcError(history.error)); return; }
        const rows = history.data || [];
        host.innerHTML = rows.length ? rows.map((item) => `
          <div class="time">${esc(item.from_year_name || '')} / ${esc(item.from_class_name || '')}
            ← ${esc(item.to_year_name || '')} / ${esc(item.to_class_name || '')}
            · ${item.outcome === 'REPEATED' ? 'إعادة مستوى' : 'ترقية'}
            · ${esc(item.processed_at || '')}</div>`).join('') : emptyHtml('لا يوجد سجل انتقالات سابق.');
      });
    });
    processBtn.hidden = false;
    processBtn.onclick = async () => {
      const items = students.filter((st) =>
        candidatesHost.querySelector(`[data-pg-student="${st.student_id}"]`)?.checked
      ).map((st) => ({
        student_id: st.student_id,
        target_class_id: candidatesHost.querySelector(`[data-pg-target="${st.student_id}"]`)?.value,
        outcome: candidatesHost.querySelector(`[data-pg-outcome="${st.student_id}"]`)?.value || 'PROMOTED'
      }));
      if (!items.length) { toast('حدد تلميذاً واحداً على الأقل.', 'error'); return; }
      const targetName = years.find((y) => String(y.year_id) === String(targetYearId))?.year_name || '';
      const ok = await confirmDialog(`سيتم نقل ${items.length} تلميذاً إلى السنة ${targetName}. ستبقى تسجيلاتهم السابقة محفوظة كسجل تاريخي. هل تريد المتابعة؟`);
      if (!ok) return;
      processBtn.disabled = true;
      const result = await processStudentProgression(targetYearId, items);
      processBtn.disabled = false;
      if (!result.ok) { toast(mapRpcError(result.error), 'error'); return; }
      const count = result.data?.processed ?? items.length;
      toast(`تمت معالجة ${count} تلميذاً بنجاح.`, 'success');
      candidatesHost.innerHTML = emptyHtml('اكتملت العملية. يمكنك اختيار قسم آخر.');
      processBtn.hidden = true;
      loadAcademic();
    };
  };
  el('pg-load-candidates').onclick = renderCandidates;
  source.onchange = () => { candidatesHost.innerHTML = emptyHtml('اضغط عرض تلاميذ القسم لتحديث القائمة.'); processBtn.hidden = true; };
  targetYear.onchange = () => { candidatesHost.innerHTML = emptyHtml('اضغط عرض تلاميذ القسم لتحديث القائمة.'); processBtn.hidden = true; };
}

async function loadAcademic() {
  el('years-panel').innerHTML = loadingHtml();
  el('classes-panel').innerHTML = loadingHtml();
  const { years, classes } = await refreshYearsClasses();
  setupProgressionPanel(years, classes);

  // Years
  el('years-panel').innerHTML = years.length
    ? years.map((y) => `<div class="history-item">
        <div><strong>${esc(y.year_name)}</strong>
          ${y.is_current ? '<span class="badge badge-green">الحالية</span>' : ''}
          ${y.is_disabled ? '<span class="badge badge-red">معطلة</span>' : ''}
          <span class="time">${y.class_count} قسمًا</span></div>
        <div style="display:flex; gap:6px;">
          ${!y.is_current && !y.is_disabled ? `<button type="button" class="att-btn" data-set-current="${y.year_id}">تعيين كحالية</button>` : ''}
          <button type="button" class="att-btn" data-rename-year="${y.year_id}" data-year-name="${esc(y.year_name)}">تعديل</button>
          <button type="button" class="att-btn" data-toggle-year="${y.year_id}" data-year-disabled="${y.is_disabled}">${y.is_disabled ? 'تفعيل' : 'تعطيل'}</button>
        </div>
      </div>`).join('')
    : emptyHtml('لا توجد سنوات دراسية. أنشئ السنة الأولى أدناه.');

  el('years-panel').querySelectorAll('[data-set-current]').forEach((b) => b.addEventListener('click', async () => {
    const res = await setCurrentAcademicYear(b.dataset.setCurrent);
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast('تم تعيين السنة الحالية.', 'success');
    loadAcademic();
  }));
  el('years-panel').querySelectorAll('[data-rename-year]').forEach((b) => b.addEventListener('click', async () => {
    const name = prompt('اسم السنة الدراسية:', b.dataset.yearName);
    if (name === null) return;
    const res = await updateAcademicYear(b.dataset.renameYear, name, null);
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast('تم التعديل.', 'success');
    loadAcademic();
  }));
  el('years-panel').querySelectorAll('[data-toggle-year]').forEach((b) => b.addEventListener('click', async () => {
    const disabling = b.dataset.yearDisabled !== 'true';
    const ok = await confirmDialog(disabling ? 'تعطيل هذه السنة؟ (لا يمكن تعطيل السنة الحالية)' : 'تفعيل هذه السنة؟');
    if (!ok) return;
    const res = await updateAcademicYear(b.dataset.toggleYear, null, disabling);
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast('تم.', 'success');
    loadAcademic();
  }));

  // Classes
  el('no-years-hint').hidden = years.length > 0;
  el('add-class-form').style.display = years.length ? '' : 'none';
  el('cl-year').innerHTML = years.filter((y) => !y.is_disabled).map((y) => `<option value="${y.year_id}">${esc(y.year_name)}${y.is_current ? ' (الحالية)' : ''}</option>`).join('');

  el('classes-panel').innerHTML = classes.length
    ? '<div class="data-table-wrap"><table class="data-table"><thead><tr><th>القسم</th><th>المستوى</th><th>السنة</th><th>الأستاذ</th><th>تلاميذ</th><th>إجراءات</th></tr></thead><tbody>'
      + classes.map((c) => `<tr>
          <td><button type="button" class="back-link class-open-btn" data-open-class-schedule="${c.class_id}" style="font-weight:800; padding:0;">${esc(c.class_name)}</button>${c.is_disabled ? ' <span class="badge badge-red">معطل</span>' : ''}</td>
          <td>${esc(c.level || '—')}</td><td>${esc(c.year_name || '—')}</td>
          <td>${esc(c.teacher_name || '—')}</td><td>${c.student_count}/${c.capacity ?? '—'}</td>
          <td><button type="button" class="att-btn" data-edit-class="${c.class_id}">تعديل</button></td>
        </tr>`).join('')
      + '</tbody></table></div>'
    : emptyHtml(years.length ? 'لا توجد أقسام بعد.' : 'أنشئ سنة دراسية أولاً.');

  el('classes-panel').querySelectorAll('[data-edit-class]').forEach((b) => b.addEventListener('click', () => editClassDialog(b.dataset.editClass)));
  el('classes-panel').querySelectorAll('[data-open-class-schedule]').forEach((b) => b.addEventListener('click', () => renderAcademicClassSchedule(b.dataset.openClassSchedule)));
  const classScheduleHost = el('academic-class-schedule');
  if (classScheduleHost) classScheduleHost.innerHTML = emptyHtml('اضغط على اسم القسم لعرض جدوله الزمني هنا.');

  // Teacher select for class form
  const teachers = await ensureTeachers();
  el('cl-teacher').innerHTML = '<option value="">—</option>' + teachers.map((t) => `<option value="${t.id}">${esc(t.profiles?.full_name || '—')}</option>`).join('');
}

async function renderAcademicClassSchedule(classId) {
  const host = el('academic-class-schedule');
  if (!host) return;
  const c = cache.classes.find((x) => x.class_id === classId);
  if (!c) { host.innerHTML = emptyHtml('القسم غير موجود.'); return; }
  host.innerHTML = loadingHtml('جارٍ تحميل جدول القسم...');
  const res = await getClassSchedule(classId);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  host.innerHTML = '<div class="schedule-toolbar"><div><strong>الجدول الزمني للقسم</strong><span class="schedule-subtitle">' + esc(c.class_name) + ' — ' + esc(c.year_name || '') + '</span></div>'
    + '<div class="schedule-actions"><button type="button" class="quick-action-btn secondary" id="ac-schedule-print">🖨️ طباعة</button><button type="button" class="quick-action-btn" id="ac-schedule-pdf">⬇️ تحميل PDF</button></div></div>'
    + buildWeeklyTimetable(rows, c.class_name, schoolPeriodsCache);
  host.querySelector('#ac-schedule-print')?.addEventListener('click', async () => printWeeklyTimetable(rows, c.class_name, await getCachedSchoolProfile(), schoolPeriodsCache));
  host.querySelector('#ac-schedule-pdf')?.addEventListener('click', async () => downloadWeeklyTimetablePdf(rows, c.class_name, await getCachedSchoolProfile(), schoolPeriodsCache));
  host.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function editClassDialog(classId) {
  const c = cache.classes.find((x) => x.class_id === classId);
  if (!c) return;
  const teachers = await ensureTeachers();

  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal-card" role="dialog" aria-modal="true" style="max-width:480px;">
      <p style="margin:0 0 12px; font-weight:700;">تعديل القسم: ${esc(c.class_name)}</p>
      <div class="form-grid">
        <label>الاسم<input type="text" id="ec-name" class="search-input" value="${esc(c.class_name)}"></label>
        <label>المستوى الدراسي<select id="ec-level" class="search-input">
          <option value="">غير محدد</option>
          ${['التعليم الأولي','المستوى الأول أولي','المستوى الثاني أولي','الأولى ابتدائي','الثانية ابتدائي','الثالثة ابتدائي','الرابعة ابتدائي','الخامسة ابتدائي','السادسة ابتدائي','الأولى إعدادي','الثانية إعدادي','الثالثة إعدادي','الجذع المشترك','الأولى بكالوريا','الثانية بكالوريا'].map(level => `<option value="${esc(level)}" ${c.level === level ? 'selected' : ''}>${esc(level)}</option>`).join('')}
          ${c.level && !['التعليم الأولي','المستوى الأول أولي','المستوى الثاني أولي','الأولى ابتدائي','الثانية ابتدائي','الثالثة ابتدائي','الرابعة ابتدائي','الخامسة ابتدائي','السادسة ابتدائي','الأولى إعدادي','الثانية إعدادي','الثالثة إعدادي','الجذع المشترك','الأولى بكالوريا','الثانية بكالوريا'].includes(c.level) ? `<option value="${esc(c.level)}" selected>${esc(c.level)} (قيمة سابقة)</option>` : ''}
        </select></label>
        <label>السعة<input type="number" id="ec-capacity" class="search-input" min="1" value="${c.capacity ?? ''}"></label>
        <label>الأستاذ
          <select id="ec-teacher" class="search-input">
            <option value="__keep__">— بدون تغيير —</option>
            <option value="">بدون أستاذ (إزالة)</option>
            ${teachers.map((t) => `<option value="${t.id}" ${t.id === c.teacher_id ? 'selected' : ''}>${esc(t.profiles?.full_name || '—')}</option>`).join('')}
          </select>
        </label>
      </div>
      <label style="display:flex; gap:8px; align-items:center; margin-top:10px;">
        <input type="checkbox" id="ec-disabled" ${c.is_disabled ? 'checked' : ''}> تعطيل القسم
      </label>
      <div style="display:flex; gap:8px; margin-top:14px;">
        <button type="button" class="quick-action-btn" id="ec-save" style="flex:1;">حفظ</button>
        <button type="button" class="back-link" id="ec-cancel" style="flex:1; text-align:center;">إلغاء</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);

  const close = () => overlay.remove();
  overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
  overlay.querySelector('#ec-cancel').addEventListener('click', close);
  overlay.querySelector('#ec-save').addEventListener('click', async () => {
    const patch = {
      name: overlay.querySelector('#ec-name').value.trim(),
      level: overlay.querySelector('#ec-level').value.trim(),
      isDisabled: overlay.querySelector('#ec-disabled').checked,
    };
    const cap = overlay.querySelector('#ec-capacity').value;
    if (cap !== '') patch.capacity = parseInt(cap, 10);
    const teacherSel = overlay.querySelector('#ec-teacher').value;
    if (teacherSel !== '__keep__') patch.teacherId = teacherSel === '' ? null : teacherSel;

    const res = await updateClass(classId, patch);
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast('تم تعديل القسم.', 'success');
    close();
    loadAcademic();
  });
}

el('add-year-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = el('add-year-submit');
  btn.disabled = true;
  const res = await createAcademicYearMy(el('ay-name').value, el('ay-current').checked);
  btn.disabled = false;
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم إنشاء السنة الدراسية.', 'success');
  el('ay-name').value = '';
  el('ay-current').checked = false;
  loadAcademic();
});

el('add-class-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = el('add-class-submit');
  btn.disabled = true;
  const res = await createClassMy(
    el('cl-year').value, el('cl-name').value, el('cl-level').value,
    el('cl-capacity').value ? Number(el('cl-capacity').value) : null,
    el('cl-teacher').value || null,
  );
  btn.disabled = false;
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم إنشاء القسم.', 'success');
  el('cl-name').value = ''; el('cl-level').value = ''; el('cl-capacity').value = '';
  loadAcademic();
});

// ===== SUBJECTS =====
async function loadSubjects() {
  const panel = el('subjects-panel');
  panel.innerHTML = loadingHtml();
  const res = await listSubjects();
  cache.subjects = res.ok ? res.data || [] : [];
  panel.innerHTML = res.ok
    ? (cache.subjects.length
      ? cache.subjects.map((s) => `<div class="history-item"><span>${esc(s.subject_name)}</span><button type="button" class="quick-action-btn secondary" data-coeff-subject="${s.subject_id}">معاملات الأقسام</button></div>`).join('')
      : emptyHtml('لا توجد مواد بعد.'))
    : emptyHtml(res.error);
  panel.querySelectorAll('[data-coeff-subject]').forEach((b) => b.addEventListener('click', () => openSubjectCoefficients(b.dataset.coeffSubject)));
}

el('add-subject-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const res = await createSubject(el('sb-name').value);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تمت إضافة المادة.', 'success');
  el('sb-name').value = '';
  loadSubjects();
});

async function openSubjectCoefficients(subjectId) {
  const classes = await ensureClasses();
  const subject = (cache.subjects || []).find(s => String(s.subject_id) === String(subjectId));
  const values = [];
  for (const c of (classes || [])) {
    const r = await supabase.rpc('fn_grade_subject_coefficients', { p_class_id: c.class_id || c.id });
    const row = (r.data || []).find(x => String(x.subject_id) === String(subjectId));
    values.push({ classId: c.class_id || c.id, className: c.class_name || c.name || c.level || 'قسم', coefficient: row?.coefficient ?? 1 });
  }
  const html = values.map(v => `<label style="display:block;margin:8px 0">${esc(v.className)}<input class="search-input" type="number" min="0.001" step="0.001" data-coeff-class="${v.classId}" value="${v.coefficient}"></label>`).join('');
  const panel = el('subjects-panel');
  panel.innerHTML = `<h3>${esc(subject?.subject_name || 'المادة')}</h3>${html}<button class="quick-action-btn" id="save-subject-coeffs">حفظ المعاملات</button>`;
  el('save-subject-coeffs').onclick = async () => {
    for (const input of panel.querySelectorAll('[data-coeff-class]')) {
      const r = await supabase.rpc('fn_upsert_grade_subject_coefficient', { p_class_id: input.dataset.coeffClass, p_subject_id: subjectId, p_coefficient: Number(input.value) });
      if (r.error) { toast(r.error.message || 'تعذر حفظ المعامل', 'error'); return; }
    }
    toast('تم حفظ معاملات المادة حسب الأقسام.', 'success'); loadSubjects();
  };
}

async function ensureTeachers() {
  if (!cache.teachers) cache.teachers = await listTeachers('');
  return cache.teachers;
}
async function ensureDrivers() {
  if (!cache.drivers) cache.drivers = await listDrivers('');
  return cache.drivers;
}
async function ensureSubjects() {
  if (!cache.subjects) { const r = await listSubjects(); cache.subjects = r.ok ? r.data || [] : []; }
  return cache.subjects;
}
async function ensureClasses() {
  if (!cache.classes) await refreshYearsClasses();
  return cache.classes;
}

// ===== STUDENTS =====
let studentImportInitialized = false;
async function loadMigrationAssistant() {
  renderInstitutionMigrationAssistant(el('institution-migration-host'), schoolId, () => {
    toast('تم تحديث سجل ترحيل المؤسسة.', 'success');
  });
}

async function loadStudentImportView() {
  await refreshYearsClasses();
  if (!studentImportInitialized) {
    initStudentImport({
      host: el('student-import-host'),
      schoolId,
      getClasses: async () => cache.classes || [],
      getYears: async () => cache.years || [],
      onImported: () => { toast('تم تحديث قائمة التلاميذ بعد الاستيراد.', 'success'); loadStudents(); },
    });
    studentImportInitialized = true;
  }
}

async function loadStudents() {
  const panel = el('students-panel');
  panel.innerHTML = loadingHtml();
  const classes = await ensureClasses();
  el('students-class').innerHTML = '<option value="">كل الأقسام</option>'
    + classes.map((c) => `<option value="${c.class_id}">${esc(c.class_name)} — ${esc(c.year_name || '')}</option>`).join('');

  const results = await filterStudents({
    query: el('students-search').value,
    classId: el('students-class').value || null,
    limit: 100,
  });
  panel.innerHTML = results.length
    ? results.map((r) => `<div class="history-item" data-student-id="${r.studentId}" style="cursor:pointer;">
        <div><strong>${esc(r.student?.fullName || '—')}</strong> <span class="time">#${esc(r.student?.studentNumber || '—')}</span></div>
        <div class="time">${esc(r.student?.className || 'بدون قسم')} ${r.resultType === 'AUTHORIZED' ? '<span class="badge badge-green">نشط</span>' : '<span class="badge badge-red">غير نشط</span>'}</div>
      </div>`).join('')
    : emptyHtml('لا يوجد تلاميذ مطابقون.');
  panel.querySelectorAll('[data-student-id]').forEach((it) => it.addEventListener('click', () => openStudentDetail(it.dataset.studentId)));
}
el('btn-import-students').addEventListener('click', () => openModule('student-import'));
el('students-search').addEventListener('input', loadStudents);
el('students-class').addEventListener('change', loadStudents);

el('btn-add-student').addEventListener('click', async () => {
  const { years, classes } = await refreshYearsClasses();
  if (!years.length) { toast('يجب إنشاء سنة دراسية أولاً.', 'error'); openModule('academic'); return; }
  el('st-year').innerHTML = years.filter((y) => !y.is_disabled).map((y) => `<option value="${y.year_id}">${esc(y.year_name)}</option>`).join('');
  const fillClasses = () => {
    const yid = el('st-year').value;
    el('st-class').innerHTML = classes.filter((c) => c.academic_year_id === yid && !c.is_disabled)
      .map((c) => `<option value="${c.class_id}">${esc(c.class_name)}</option>`).join('');
  };
  el('st-year').onchange = fillClasses;
  fillClasses();
  showView('student-add');
});

el('add-student-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = el('add-student-error');
  errEl.hidden = true;
  const btn = el('add-student-submit');
  if (!el('st-class').value) { errEl.hidden = false; errEl.textContent = 'اختر القسم (أنشئ قسمًا أولاً).'; return; }
  btn.disabled = true;
  const res = await registerStudent({
    fullName: el('st-name').value.trim(),
    classId: el('st-class').value,
    academicYearId: el('st-year').value,
    birthDate: el('st-birth').value || null,
    gender: el('st-gender').value || null,
    healthStatus: el('st-health').value.trim() || null,
    massarNumber: el('st-massar').value.trim() || null,
  });
  btn.disabled = false;
  if (!res.ok) { errEl.hidden = false; errEl.textContent = res.error; return; }
  const feeSetup = await setStudentTransportAndGenerate(res.studentId, el('st-transport').value === 'yes', el('st-year').value);
  if (!feeSetup.ok) { console.error('[FEE GENERATION]', feeSetup.error); toast('تم تسجيل التلميذ، لكن تعذر إعداد مستحقاته تلقائياً. راجع إعدادات الرسوم أو الصلاحيات.', 'warning'); }
  toast(`تم تسجيل التلميذ بنجاح. رقم التلميذ: ${res.studentNumber || 'تم توليده تلقائيًا'}`, 'success');
  e.target.reset();
  showView('students');
  loadStudents();
});

async function openStudentDetail(studentId) {
  currentStudentId = studentId;
  showView('student-detail');
  const body = el('student-detail-body');
  body.innerHTML = loadingHtml();
  const res = await getStudentFull(studentId);
  if (!res.ok || !res.data) { body.innerHTML = emptyHtml(res.error || 'تعذر تحميل ملف التلميذ.'); return; }
  const s = res.data;
  const att = s.attendance_30d || {};
  const row = (k, v) => `<div class="detail-row"><span class="k">${k}</span><span class="v">${esc(v ?? '—')}</span></div>`;

  body.innerHTML = `
    <div id="sd-photo-box" class="panel"></div>
    <div class="panel">
      ${row('الاسم', s.full_name)}${row('رقم التلميذ', s.student_number)}
      ${row('رقم مسار', s.massar_number)}${row('الحالة الصحية', s.health_status)}
      ${row('القسم', s.class_name)}${row('المستوى', s.level)}${row('السنة', s.year_name)}
      ${row('تاريخ الميلاد', fmtDate(s.birth_date))}${row('البطاقة', BADGE_STATUS_AR[s.badge_status] || (s.badge_status || 'بدون بطاقة'))}
      ${row('الحالة', s.is_active ? 'نشط' : 'محذوف')}
      <button type="button" class="quick-action-btn secondary" id="sd-edit-btn" style="width:100%; margin-top:10px;">✏️ تعديل ملف التلميذ</button>
    </div>
    <div class="panel" id="sd-edit-panel" hidden>
      <p class="section-title" style="margin-top:0;">تعديل الملف</p>
      <form id="sd-edit-form" novalidate>
        <div class="form-grid">
          <div><label>الاسم الكامل</label><input type="text" id="sde-name" class="search-input" value="${esc(s.full_name || '')}"></div>
          <div><label>تاريخ الميلاد</label><input type="date" id="sde-birth" class="search-input" value="${esc(s.birth_date || '')}"></div>
          <div><label>الجنس</label><select id="sde-gender" class="search-input">
            <option value="">—</option>
            <option value="male" ${s.gender === 'male' ? 'selected' : ''}>ذكر</option>
            <option value="female" ${s.gender === 'female' ? 'selected' : ''}>أنثى</option>
          </select></div>
          <div><label>رقم مسار (Massar)</label><input type="text" id="sde-massar" class="search-input" value="${esc(s.massar_number || '')}" dir="ltr" style="text-align:right;"></div>
          <div><label>الحالة الصحية</label><input type="text" id="sde-health" class="search-input" value="${esc(s.health_status || '')}" placeholder="سليم / حساسية / مرض مزمن..."></div>
        </div>
        <button type="submit" class="quick-action-btn" id="sde-submit" style="width:100%; margin-top:10px;">حفظ التعديلات</button>
      </form>
    </div>
    <p class="section-title">الحضور (آخر 30 يومًا)</p>
    <div class="stats-grid">
      ${statCard(att.present ?? 0, 'حاضر', 'tone-green')}${statCard(att.absent ?? 0, 'غائب', 'tone-red')}
      ${statCard(att.late ?? 0, 'متأخر', 'tone-gold')}${statCard(att.excused ?? 0, 'مبرر')}
    </div>
    <div id="sd-att-list"></div>
    <p class="section-title">النقط</p>
    <div id="sd-grades"></div>
    <div class="panel">
      <p class="section-title" style="margin-top:0;">إضافة نقطة</p>
      <form id="sd-grade-form" novalidate>
        <div class="form-grid">
          <div><label>المادة</label><select id="gd-subject" class="search-input"><option value="">—</option></select></div>
          <div><label>الفترة</label><input type="text" id="gd-period" class="search-input" placeholder="الأسدوس الأول"></div>
          <div><label>نوع التقييم</label><input type="text" id="gd-type" class="search-input" placeholder="فرض / امتحان"></div>
          <div><label>النقطة *</label><input type="number" id="gd-score" class="search-input" min="0" step="0.25" required></div>
        </div>
        <button type="submit" class="quick-action-btn" style="width:100%; margin-top:10px;">حفظ النقطة</button>
      </form>
    </div>
    <p class="section-title">أولياء الأمور</p>
    <div class="panel">${(s.parents || []).length ? s.parents.map((p) => `<div class="history-item"><span>${esc(p.name)}</span><span class="time">${esc(p.phone || '')} ${esc(p.relationship || '')}</span><span style="display:inline-flex; gap:4px;">${phoneActions(p.phone)}</span></div>`).join('') : emptyHtml('لا يوجد ولي أمر مرتبط.')}</div>
    <p class="section-title">النقل المدرسي</p>
    <div class="panel" id="sd-transport"></div>
    <p class="section-title">المخالفات المفتوحة: ${s.open_incidents ?? 0}</p>`;

  renderStudentPhotoBox(el('sd-photo-box'), { studentId, schoolId, photoUrl: s.photo_url }, () => openStudentDetail(studentId));

  // ✏️ Edit profile (Phase 75)
  el('sd-edit-btn').addEventListener('click', () => {
    const p = el('sd-edit-panel');
    p.hidden = !p.hidden;
    if (!p.hidden) p.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  });
  el('sd-edit-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = el('sde-submit');
    btn.disabled = true;
    const res2 = await updateStudentProfile(studentId, {
      p_full_name: el('sde-name').value.trim() || null,
      p_birth_date: el('sde-birth').value || null,
      p_gender: el('sde-gender').value || null,
      p_health_status: el('sde-health').value,
      p_massar_number: el('sde-massar').value,
    });
    btn.disabled = false;
    if (!res2.ok) { toast(mapRpcError(res2.error), 'error'); return; }
    toast('تم حفظ التعديلات بنجاح.', 'success');
    openStudentDetail(studentId);
  });

  // Attendance history
  const attRes = await getStudentAttendance(studentId, null, null);
  el('sd-att-list').innerHTML = attRes.ok && attRes.data.length
    ? '<div class="panel">' + attRes.data.slice(0, 15).map((a) => `<div class="detail-row"><span class="k">${fmtDate(a.att_date)} — ${esc(a.class_name || '')}</span><span class="v">${attStatusAr(a.status)}</span></div>`).join('') + '</div>'
    : emptyHtml('لا توجد سجلات حضور.');

  // Grades
  const grRes = await listStudentGrades(studentId);
  el('sd-grades').innerHTML = grRes.ok && grRes.data.length
    ? '<div class="panel">' + grRes.data.map((g) => `<div class="detail-row"><span class="k">${esc(g.subject_name || '—')} — ${esc(g.period || '')} ${esc(g.grade_type || '')}</span><span class="v">${g.score}/${g.max_score}</span></div>`).join('') + '</div>'
    : emptyHtml('لا توجد نقط بعد.');

  const subjects = await ensureSubjects();
  el('gd-subject').innerHTML = '<option value="">—</option>' + subjects.map((su) => `<option value="${su.subject_id}">${esc(su.subject_name)}</option>`).join('');
  el('sd-grade-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const res2 = await addGrade({
      studentId, subjectId: el('gd-subject').value || null, period: el('gd-period').value,
      gradeType: el('gd-type').value, score: Number(el('gd-score').value),
    });
    if (!res2.ok) { toast(res2.error, 'error'); return; }
    toast('تم حفظ النقطة.', 'success');
    openStudentDetail(studentId);
  });

  // Transport
  renderStudentTransport(s);
  // Schedule (Phase 19 — derived from class timetable, never a per-student copy)
  renderStudentSchedule(studentId);
  // Home location (Google Maps coordinates)
  renderStudentLocation(s);
  // ID badge / QR (Phase 17/18/19 real fix)
  renderStudentBadgeSection(s);
}

async function renderStudentSchedule(studentId) {
  const host = el('sd-schedule');
  host.innerHTML = loadingHtml();
  const res = await getStudentSchedule(studentId);
  const rows = res.ok ? res.data || [] : [];
  el('sd-schedule-summary').textContent = rows.length ? `${rows.length} حصة/أسبوع` : '';
  host.innerHTML = rows.length
    ? '<div class="data-table-wrap"><table class="data-table"><thead><tr><th>اليوم</th><th>الحصة</th><th>المادة</th><th>الأستاذ</th></tr></thead><tbody>'
      + rows.map((r) => `<tr><td>${WEEKDAYS_AR[r.weekday] || r.weekday}</td><td>${r.period}</td><td>${esc(r.subject_name || '—')}</td><td>${esc(r.teacher_name || '—')}</td></tr>`).join('')
      + '</tbody></table></div>'
    : emptyHtml('لا يوجد جدول دراسي (لم يُسند التلميذ إلى قسم له حصص بعد).');
}

// Google Maps location — SIMPLIFIED (Phase 20): one tap on an in-app map,
// no manual lat/lng typing. See modules/mapPicker.js for why Leaflet/OSM is
// used instead of the Google Maps JS API (no API key exists in this
// project, and inventing one was explicitly ruled out).
function mapEmbedUrl(lat, lng) {
  return `https://maps.google.com/maps?q=${lat},${lng}&z=16&output=embed`;
}
function renderStudentLocation(s) {
  const host = el('sd-location');
  const hasLoc = s.latitude != null && s.longitude != null;
  host.innerHTML = `
    ${hasLoc
      ? `<iframe src="${mapEmbedUrl(s.latitude, s.longitude)}" style="width:100%; height:180px; border:0; border-radius:8px;" loading="lazy"></iframe>
         <div style="display:flex; gap:8px; margin-top:8px;">
           <button type="button" class="quick-action-btn secondary" id="loc-change-btn" style="flex:1;">📍 تغيير الموقع</button>
           <a href="https://www.google.com/maps?q=${s.latitude},${s.longitude}" target="_blank" rel="noopener" class="quick-action-btn secondary" style="flex:1; text-align:center; text-decoration:none;">🧭 فتح في Google Maps</a>
         </div>`
      : `${emptyHtml('لم يُحدَّد موقع السكن بعد.')}<button type="button" class="quick-action-btn" id="loc-change-btn" style="width:100%;">📍 تحديد موقع السكن</button>`}
  `;
  el('loc-change-btn').addEventListener('click', () => {
    openMapPicker({
      lat: s.latitude, lng: s.longitude, label: s.location_label,
      onSave: async ({ lat, lng, label }) => {
        const res = await updateStudentLocation({ studentId: currentStudentId, latitude: lat, longitude: lng, locationLabel: label || null });
        if (!res.ok) { toast(res.error, 'error'); return; }
        toast('تم حفظ الموقع.', 'success');
        openStudentDetail(currentStudentId);
      },
    });
  });
}

const BADGE_STATUS_AR = { ACTIVE: 'سارية', SUSPENDED: 'موقوفة', LOST: 'مفقودة', EXPIRED: 'منتهية', REPLACED: 'مستبدلة' };

async function renderStudentBadgeSection(s) {
  const actionsHost = el('sd-badge-actions');
  const cardHost = el('sd-badge-card');
  cardHost.innerHTML = '';
  const badgeRes = await getStudentBadge(s.student_id);
  const badge = badgeRes.ok && badgeRes.data && badgeRes.data.length ? badgeRes.data[0] : null;
  if (!badgeRes.ok) {
    cardHost.innerHTML = emptyHtml(badgeRes.error || 'تعذر تحميل بيانات البطاقة.');
  } else if (!badge) {
    cardHost.innerHTML = emptyHtml('لم تُصدر بطاقة لهذا التلميذ بعد. بعد الإصدار ستظهر البطاقة هنا مع QR وأزرار التحميل والطباعة.');
  }

  actionsHost.innerHTML = `
    <p class="empty-state" id="sd-badge-error" hidden style="color:#dc2626;"></p>
    <div class="quick-actions" id="sd-badge-buttons"></div>`;
  const buttons = [];
  if (badge && badge.status === 'ACTIVE') {
    buttons.push('<button type="button" class="quick-action-btn secondary" id="sd-badge-reissue">🔄 إعادة إصدار</button>');
    buttons.push('<button type="button" class="quick-action-btn secondary" id="sd-badge-suspend">🚫 تعليق البطاقة</button>');
  } else {
    buttons.push('<button type="button" class="quick-action-btn" id="sd-badge-issue" style="grid-column:1 / -1;">🆔 إصدار بطاقة</button>');
  }
  el('sd-badge-buttons').innerHTML = buttons.join('');

  async function run(fn) {
    el('sd-badge-error').hidden = true;
    el('sd-badge-buttons').querySelectorAll('button').forEach((b) => (b.disabled = true));
    const res = await fn();
    if (!res.ok) {
      el('sd-badge-error').hidden = false;
      el('sd-badge-error').textContent = res.error;
      el('sd-badge-buttons').querySelectorAll('button').forEach((b) => (b.disabled = false));
      return;
    }
    toast('تم بنجاح.', 'success');
    openStudentDetail(s.student_id);
  }
  if (badge && badge.status === 'ACTIVE') {
    el('sd-badge-reissue').addEventListener('click', () => run(() => reissueBadge(s.student_id, 'إعادة إصدار من طرف الإدارة')));
    el('sd-badge-suspend').addEventListener('click', () => run(() => suspendBadge(badge.id, 'SUSPENDED', 'تعليق من طرف الإدارة')));
  } else {
    el('sd-badge-issue').addEventListener('click', () => run(() => issueBadge(s.student_id)));
  }

  if (badge && badge.status === 'ACTIVE') {
    const schoolRes = await getSchoolProfile(schoolId);
    await renderBadgeCard(cardHost, {
      full_name: s.full_name, student_number: s.student_number, class_name: s.class_name,
      year_name: s.year_name, photo_url: s.photo_url,
      school_name: schoolRes.ok ? schoolRes.data?.name : '',
      school_logo_url: schoolRes.ok ? schoolRes.data?.logo_url : null,
    }, badge);
  }
}

async function renderStudentTransport(s) {
  const host = el('sd-transport');
  const t = s.transport;
  const [busesRes, routesRes] = await Promise.all([listBuses(), listRoutes()]);
  const buses = busesRes.ok ? busesRes.data || [] : [];
  const routes = routesRes.ok ? routesRes.data || [] : [];

  host.innerHTML = `
    ${t ? `<div class="detail-row"><span class="k">الحافلة</span><span class="v">${esc(t.bus_code || '—')} (${esc(t.bus_plate || '')})</span></div>
      <div class="detail-row"><span class="k">المسار</span><span class="v">${esc(t.route_name || '—')}</span></div>
      <div class="detail-row"><span class="k">محطة الصعود</span><span class="v">${esc(t.pickup_stop || '—')}</span></div>
      <div class="detail-row"><span class="k">محطة النزول</span><span class="v">${esc(t.dropoff_stop || '—')}</span></div>
      <div class="detail-row"><span class="k">السائق</span><span class="v">${esc(t.driver_name || '—')}</span></div>`
    : emptyHtml('غير مسجل في النقل المدرسي.')}
    <form id="sd-transport-form" novalidate style="margin-top:10px;">
      <div class="form-grid">
        <div><label>الحافلة</label><select id="tr-bus" class="search-input"><option value="">—</option>
          ${buses.map((b) => `<option value="${b.bus_id}">${esc(b.code)}</option>`).join('')}</select></div>
        <div><label>المسار</label><select id="tr-route" class="search-input"><option value="">—</option>
          ${routes.map((r) => `<option value="${r.route_id}">${esc(r.route_name)}</option>`).join('')}</select></div>
        <div><label>محطة الصعود</label><select id="tr-pickup" class="search-input"><option value="">—</option></select></div>
        <div><label>محطة النزول</label><select id="tr-dropoff" class="search-input"><option value="">—</option></select></div>
      </div>
      <button type="submit" class="quick-action-btn" style="width:100%; margin-top:10px;">حفظ النقل</button>
    </form>`;

  const fillStops = () => {
    const r = routes.find((x) => x.route_id === el('tr-route').value);
    const stops = r ? (Array.isArray(r.stops) ? r.stops : []) : [];
    const opts = '<option value="">—</option>' + stops.map((st) => `<option value="${st.stop_id}">${esc(st.name)}</option>`).join('');
    el('tr-pickup').innerHTML = opts;
    el('tr-dropoff').innerHTML = opts;
  };
  el('tr-route').addEventListener('change', fillStops);
  fillStops();

  el('sd-transport-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const res = await assignStudentTransport(currentStudentId, {
      busId: el('tr-bus').value || null, routeId: el('tr-route').value || null,
      pickupStopId: el('tr-pickup').value || null, dropoffStopId: el('tr-dropoff').value || null,
    });
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast('تم حفظ النقل.', 'success');
    openStudentDetail(currentStudentId);
  });
}

// ===== STAFF LISTS (teachers / drivers / parents) =====
const STAFF_CONF = {
  teachers: { label: 'أستاذ', type: 'teacher', list: listTeachers, panel: 'teachers-panel', search: 'teachers-search', extra: 'رقم الموظف' },
  drivers: { label: 'سائق', type: 'driver', list: listDrivers, panel: 'drivers-panel', search: 'drivers-search', extra: 'رقم رخصة القيادة' },
  parents: { label: 'ولي أمر', type: 'parent', list: listParents, panel: 'parents-panel', search: 'parents-search', extra: null },
};

function lastSeenAr(iso) {
  if (!iso) return 'لم يدخل بعد';
  const s = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 180) return '🟢 متصل الآن';
  if (s < 3600) return `منذ ${Math.floor(s / 60)} دقيقة`;
  if (s < 86400) return `منذ ${Math.floor(s / 3600)} ساعة`;
  return `منذ ${Math.floor(s / 86400)} يوم`;
}

async function loadStaffList(kind) {
  const conf = STAFF_CONF[kind];
  const panel = el(conf.panel);
  panel.innerHTML = loadingHtml();
  const [rows, lsRes] = await Promise.all([
    conf.list(el(conf.search).value),
    listAccountsLastSeen(schoolId),
  ]);
  const lsMap = {};
  if (lsRes.ok) (lsRes.data || []).forEach((a) => { lsMap[a.profile_id] = a.last_seen_at; });
  panel.innerHTML = rows.length
    ? rows.map((r, i) => `<div class="history-item" data-acc-idx="${i}" style="cursor:pointer;">
        <div><strong>${esc(r.profiles?.full_name || '—')}</strong> <span class="time">${esc(r.profiles?.user_number || '')}</span></div>
        <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
          <span class="time">${esc(r.profiles?.phone || '')}</span>
          <span class="badge ${lsMap[r.profile_id] && (Date.now() - new Date(lsMap[r.profile_id]).getTime() < 180000) ? 'badge-green' : ''}" style="font-size:.78em;">🕐 ${lastSeenAr(lsMap[r.profile_id])}</span>
        </div>
      </div>`).join('')
    : emptyHtml('لا توجد نتائج.');
  panel.querySelectorAll('[data-acc-idx]').forEach((it) => it.addEventListener('click', () => {
    const r = rows[Number(it.dataset.accIdx)];
    if (kind === 'teachers') { openTeacherDetail(r.id); return; }
    // modal بسيط: تفاصيل الحساب + آخر ظهور
    const overlay = document.createElement('div');
    overlay.className = 'map-picker-overlay';
    overlay.innerHTML = `<div class="map-picker-sheet" style="max-width:380px;">
      <div class="map-picker-header"><strong>👤 ${esc(r.profiles?.full_name || '—')}</strong><button type="button" class="icon-btn" id="acc-close">✕</button></div>
      <div class="panel">
        <div class="detail-row"><span class="k">الدور</span><span class="v">${conf.label}</span></div>
        <div class="detail-row"><span class="k">رقم المستخدم</span><span class="v">${esc(r.profiles?.user_number || '—')}</span></div>
        <div class="detail-row"><span class="k">الهاتف</span><span class="v">${esc(r.profiles?.phone || '—')}</span></div>
        <div class="detail-row"><span class="k">آخر ظهور في التطبيق</span><span class="v"><strong>${lastSeenAr(lsMap[r.profile_id])}</strong></span></div>
      </div></div>`;
    document.body.appendChild(overlay);
    const close = () => overlay.remove();
    overlay.querySelector('#acc-close').addEventListener('click', close);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
  }));
}
['teachers', 'drivers', 'parents'].forEach((kind) => {
  el(STAFF_CONF[kind].search).addEventListener('input', () => loadStaffList(kind));
});

// ===== STAFF ADD (teacher/driver/parent/guard) =====
function openStaffAdd(type) {
  currentStaffType = type;
  selectedLinks = [];
  const labels = { teacher: 'إضافة أستاذ', driver: 'إضافة سائق', parent: 'إضافة ولي أمر', guard: 'إضافة حارس' };
  el('staff-add-title').textContent = labels[type];
  el('staff-add-error').hidden = true;
  el('staff-add-form').reset();
  el('sf-children-selected').innerHTML = '';
  el('sf-child-results').innerHTML = '';

  const extra = el('sf-extra-1');
  if (type === 'teacher') { extra.hidden = false; el('sf-extra-1-label').textContent = 'رقم الموظف'; }
  else if (type === 'driver') { extra.hidden = false; el('sf-extra-1-label').textContent = 'رقم رخصة القيادة'; }
  else extra.hidden = true;

  el('sf-children-wrap').hidden = type !== 'parent';

  const backTargets = { teacher: 'teachers', driver: 'drivers', parent: 'parents', guard: 'guards' };
  el('staff-add-back').dataset.back = backTargets[type];
  showView('staff-add');
}
el('btn-add-teacher').addEventListener('click', () => openStaffAdd('teacher'));
el('btn-add-driver').addEventListener('click', () => openStaffAdd('driver'));
el('btn-add-parent').addEventListener('click', () => openStaffAdd('parent'));
el('btn-add-guard').addEventListener('click', () => openStaffAdd('guard'));

// parent-children picker
let childSearchTimer = null;
el('sf-child-search').addEventListener('input', () => {
  clearTimeout(childSearchTimer);
  childSearchTimer = setTimeout(async () => {
    const q = el('sf-child-search').value;
    const host = el('sf-child-results');
    if (!q.trim()) { host.innerHTML = ''; return; }
    const rows = await searchStudents(q);
    host.innerHTML = rows.map((s) => `<div class="search-result-item" data-pick-child="${s.id}" data-child-name="${esc(s.full_name)}">
      ${esc(s.full_name)} <span class="time">#${esc(s.student_number || '')}</span></div>`).join('');
    host.querySelectorAll('[data-pick-child]').forEach((it) => it.addEventListener('click', () => {
      if (selectedLinks.some((l) => l.studentId === it.dataset.pickChild)) return;
      selectedLinks.push({ studentId: it.dataset.pickChild, relationship: 'ولي' });
      renderSelectedChildren();
    }));
  }, 300);
});
function renderSelectedChildren() {
  el('sf-children-selected').innerHTML = selectedLinks.map((l, i) =>
    `<span class="badge badge-blue">${esc(l.name || 'تلميذ')} <a href="#" data-unlink="${i}" style="color:#991b1b;">×</a></span>`).join(' ');
  el('sf-children-selected').querySelectorAll('[data-unlink]').forEach((a) => a.addEventListener('click', (e) => {
    e.preventDefault();
    selectedLinks.splice(Number(a.dataset.unlink), 1);
    renderSelectedChildren();
  }));
}
// keep names for display
el('sf-child-results').addEventListener('click', (e) => {
  const it = e.target.closest('[data-pick-child]');
  if (it) {
    const last = selectedLinks[selectedLinks.length - 1];
    if (last && last.studentId === it.dataset.pickChild) last.name = it.dataset.childName;
    renderSelectedChildren();
  }
});

el('staff-add-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = el('staff-add-error');
  errEl.hidden = true;
  const btn = el('staff-add-submit');
  btn.disabled = true;
  try {
    const base = {
      fullName: el('sf-name').value.trim(),
      email: el('sf-email').value.trim(),
      password: el('sf-password').value,
      phone: el('sf-phone').value.trim() || undefined,
    };
    let result;
    if (currentStaffType === 'guard') {
      result = await createGuardAccount(base);
    } else {
      result = await createStaffAccount({
        ...base,
        accountType: currentStaffType,
        employeeNumber: currentStaffType === 'teacher' ? el('sf-extra-1-input').value.trim() || undefined : undefined,
        licenseNumber: currentStaffType === 'driver' ? el('sf-extra-1-input').value.trim() || undefined : undefined,
        parentStudentLinks: currentStaffType === 'parent' ? selectedLinks.map(({ studentId, relationship }) => ({ studentId, relationship })) : undefined,
      });
    }
    if (!result.ok) { errEl.hidden = false; errEl.textContent = result.error; return; }
    toast('تم إنشاء الحساب بنجاح.', 'success');
    cache.teachers = null; cache.drivers = null;
    showView({ teacher: 'teachers', driver: 'drivers', parent: 'parents', guard: 'guards' }[currentStaffType]);
    if (currentStaffType === 'guard') loadGuards(); else loadStaffList(currentStaffType + 's');
  } finally {
    btn.disabled = false;
  }
});

// ===== GUARDS + PERMISSIONS =====
async function loadGuards() {
  const panel = el('guards-panel');
  panel.innerHTML = loadingHtml();
  const rows = await listGuards(el('guards-search').value);
  panel.innerHTML = rows.length
    ? rows.map((g) => `<div class="history-item" data-guard-idx="${rows.indexOf(g)}" style="cursor:pointer;">
        <div><strong>${esc(g.fullName)}</strong> <span class="time">${esc(g.userNumber)}</span></div>
        <div>${g.isDisabled ? '<span class="badge badge-red">معطل</span>' : '<span class="badge badge-green">نشط</span>'}</div>
      </div>`).join('')
    : emptyHtml('لا يوجد حراس.');
  panel.querySelectorAll('[data-guard-idx]').forEach((it) => it.addEventListener('click', () => openGuardDetail(rows[Number(it.dataset.guardIdx)])));
}
el('guards-search').addEventListener('input', loadGuards);

async function openGuardDetail(guard) {
  currentGuard = guard;
  showView('guard-detail');
  el('guard-detail-title').textContent = guard.fullName;
  el('guard-detail-body').innerHTML = `<div class="panel">
    <div class="detail-row"><span class="k">الاسم</span><span class="v">${esc(guard.fullName)}</span></div>
    <div class="detail-row"><span class="k">البريد</span><span class="v">${esc(guard.userNumber)}</span></div>
    <div class="detail-row"><span class="k">الحالة</span><span class="v">${guard.isDisabled ? 'معطل' : 'نشط'}</span></div>
    <button type="button" class="quick-action-btn" id="gd-toggle" style="width:100%; margin-top:10px; ${guard.isDisabled ? '' : 'background:#b91c1c;'}">
      ${guard.isDisabled ? 'إعادة تفعيل' : 'تعطيل الحساب'}</button>
  </div>
  <p class="section-title" style="margin-top:12px;">إحصائيات</p>
  <div class="stats-grid" id="guard-stats"><div class="loading-state">جارٍ التحميل...</div></div>`;
  getGuardStats(guard.profileId).then((res) => {
    const st = res.ok ? res.data || {} : {};
    el('guard-stats').innerHTML = statCard(st.badges_issued ?? 0, 'بطاقات صادرة')
      + statCard(st.badges_reissued ?? 0, 'إعادة إصدار')
      + statCard(st.badges_suspended ?? 0, 'بطاقات معلّقة')
      + statCard(st.students_registered ?? 0, 'تلاميذ مسجَّلون');
  });
  el('gd-toggle').addEventListener('click', async () => {
    const target = !guard.isDisabled;
    const ok = await confirmDialog(target ? 'تعطيل هذا الحارس؟' : 'إعادة تفعيل هذا الحارس؟');
    if (!ok) return;
    const res = await setGuardStatus(guard.profileId, target);
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast('تم.', 'success');
    guard.isDisabled = target;
    openGuardDetail(guard);
  });

  // Permissions matrix
  const panel = el('guard-perms-panel');
  panel.innerHTML = loadingHtml();
  const [catalog, grantedRes] = await Promise.all([
    listAllPermissions(),
    getUserPermissions(guard.profileId, guard.schoolId),
  ]);
  const granted = grantedRes.ok ? new Set(grantedRes.data || []) : new Set();
  const byModule = {};
  (catalog || []).forEach((p) => { (byModule[p.module] = byModule[p.module] || []).push(p); });

  panel.innerHTML = Object.entries(byModule).map(([mod, perms]) => `
    <div class="perm-module">${esc(mod)}</div>
    <div class="perm-grid">${perms.map((p) => `
      <label class="perm-item"><input type="checkbox" data-perm="${esc(p.permission_key)}" ${granted.has(p.permission_key) ? 'checked' : ''}>
      ${esc(p.name)}</label>`).join('')}</div>`).join('');

  const updateCount = () => {
    const n = panel.querySelectorAll('[data-perm]:checked').length;
    el('perm-count').textContent = n + ' صلاحية';
  };
  updateCount();

  panel.querySelectorAll('[data-perm]').forEach((cb) => cb.addEventListener('change', async () => {
    cb.disabled = true;
    const res = cb.checked
      ? await grantUserPermission(guard.profileId, guard.schoolId, cb.dataset.perm)
      : await revokeUserPermission(guard.profileId, guard.schoolId, cb.dataset.perm);
    cb.disabled = false;
    if (!res.ok) { cb.checked = !cb.checked; toast(mapRpcError(res.error), 'error'); return; }
    toast(cb.checked ? 'تم منح الصلاحية.' : 'تم إلغاء الصلاحية.', 'success');
    updateCount();
  }));
}

// ===== ATTENDANCE =====
async function loadAttendanceView() {
  const host = el('att-today');
  host.innerHTML = loadingHtml();
  const res = await schoolAttendanceToday();
  const t = res.ok && res.data?.length ? res.data[0] : {};
  host.innerHTML = '<div class="stats-grid">'
    + statCard(t.present ?? 0, 'حاضر', 'tone-green') + statCard(t.absent ?? 0, 'غائب', 'tone-red')
    + statCard(t.late ?? 0, 'متأخر', 'tone-gold') + statCard(t.excused ?? 0, 'مبرر')
    + statCard(t.total_marked ?? 0, 'إجمالي المسجلين') + '</div>';

  const classes = await ensureClasses();
  el('att-class').innerHTML = '<option value="__staff__">👥 الموظفون (حضور الطاقم)</option>'
    + classes.filter((c) => !c.is_disabled).map((c) => `<option value="${c.class_id}">${esc(c.class_name)} — ${esc(c.year_name || '')}</option>`).join('');
  el('att-date').value = new Date().toISOString().slice(0, 10);
  el('att-roster').hidden = true;
}

el('att-load').addEventListener('click', async () => {
  const classId = el('att-class').value;
  const date = el('att-date').value;
  const host = el('att-roster');
  if (!classId) { toast('اختر القسم.', 'error'); return; }

  // === فرع الموظفين (Phase 59) ===
  if (classId === '__staff__') {
    host.hidden = false;
    host.innerHTML = loadingHtml();
    const staffRes = await listSchoolStaff(schoolId);
    if (!staffRes.ok) { host.innerHTML = emptyHtml(mapRpcError(staffRes.error)); return; }
    const staff = staffRes.data || [];
    if (!staff.length) { host.innerHTML = emptyHtml('لا يوجد موظفون.'); return; }

    const roleAr = { teacher: 'أستاذ', guard: 'حارس', driver: 'سائق' };
    host.innerHTML = staff.map((s) => `
      <div class="history-item" style="align-items:flex-start; flex-direction:column; gap:6px;">
        <div><strong>${esc(s.full_name)}</strong> <span class="time">${roleAr[s.role] || s.role} · ${s.employment_type === 'HOURLY' ? 'بالساعة' : 'دوام كامل'}</span></div>
        <div style="display:flex; gap:6px; flex-wrap:wrap;">
          <button type="button" class="quick-action-btn" data-staff-in="${s.profile_id}">دخول</button>
          <button type="button" class="quick-action-btn" data-staff-out="${s.profile_id}">خروج</button>
          <button type="button" class="quick-action-btn" data-staff-absent="${s.profile_id}">غياب</button>
          <button type="button" class="quick-action-btn" data-staff-report="${s.profile_id}" data-name="${esc(s.full_name)}">التقرير</button>
        </div>
      </div>`).join('');

    host.querySelectorAll('[data-staff-in]').forEach((b) => b.addEventListener('click', async () => {
      const r = await staffCheckIn(b.dataset.staffIn, date);
      toast(r.ok ? 'تم تسجيل الدخول.' : mapRpcError(r.error), r.ok ? 'success' : 'error');
    }));
    host.querySelectorAll('[data-staff-out]').forEach((b) => b.addEventListener('click', async () => {
      const r = await staffCheckOut(b.dataset.staffOut, date);
      toast(r.ok ? 'تم تسجيل الخروج.' : mapRpcError(r.error), r.ok ? 'success' : 'error');
    }));
    host.querySelectorAll('[data-staff-absent]').forEach((b) => b.addEventListener('click', async () => {
      const r = await markStaffAttendance(b.dataset.staffAbsent, date, 'ABSENT');
      toast(r.ok ? 'تم تسجيل الغياب.' : mapRpcError(r.error), r.ok ? 'success' : 'error');
    }));
    host.querySelectorAll('[data-staff-report]').forEach((b) => b.addEventListener('click', async () => {
      const from = new Date(); from.setMonth(from.getMonth() - 1);
      const r = await getStaffAttendanceReport(b.dataset.staffReport, from.toISOString().slice(0, 10), date);
      if (!r.ok) { toast(mapRpcError(r.error), 'error'); return; }
      const rows = r.data || [];
      alert(`تقرير ${b.dataset.name}:\n` + (rows.length ? rows.map((x) => `${x.work_date} — ${x.status} — ${x.hours_worked ?? '—'}س`).join('\n') : 'لا توجد سجلات.'));
    }));
    return;
  }
  // === نهاية فرع الموظفين ===

  host.hidden = false;
  host.innerHTML = loadingHtml();
  const res = await getClassAttendance(classId, date);
  if (!res.ok) { host.innerHTML = emptyHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا يوجد تلاميذ في هذا القسم.'); return; }

  const state = {};
  rows.forEach((r) => { state[r.student_id] = r.status || 'present'; });

  const render = () => {
    host.innerHTML = rows.map((r) => `
      <div class="history-item" style="align-items:flex-start; flex-direction:column; gap:6px;">
        <div><strong>${esc(r.full_name)}</strong> <span class="time">#${esc(r.student_number || '')}</span></div>
        <div style="display:flex; gap:6px; flex-wrap:wrap;">
          ${['present', 'absent', 'late', 'excused'].map((st) => `<button type="button" class="att-btn ${state[r.student_id] === st ? 'active-' + st : ''}" data-st="${r.student_id}" data-val="${st}">${attStatusAr(st)}</button>`).join('')}
        </div>
        <div style="display:flex; gap:6px; flex-wrap:wrap; width:100%;">
          <input class="search-input" style="flex:1; min-width:150px;" data-note="${r.student_id}" placeholder="ملاحظة / سبب الغياب المبرر" value="${esc(r.note || '')}">
          <input class="search-input" style="width:110px;" type="number" min="1" max="1440" data-late="${r.student_id}" placeholder="دقائق التأخر">
        </div>
      </div>`).join('')
      + '<button type="button" class="quick-action-btn" id="att-save" style="width:100%; margin-top:10px;">حفظ الحضور</button>';
    host.querySelectorAll('[data-st]').forEach((b) => b.addEventListener('click', () => { state[b.dataset.st] = b.dataset.val; render(); }));
    el('att-save').addEventListener('click', async () => {
      const payload = Object.entries(state).map(([student_id, status]) => ({
        student_id, status,
        note: host.querySelector(`[data-note="${student_id}"]`)?.value || null,
        excuse_reason: status === 'excused' ? (host.querySelector(`[data-note="${student_id}"]`)?.value || null) : null,
        minutes_late: status === 'late' ? (host.querySelector(`[data-late="${student_id}"]`)?.value || null) : null
      }));
      const res2 = await saveAttendance(classId, date, payload);
      if (!res2.ok) { toast(res2.error, 'error'); return; }
      toast(`تم حفظ حضور ${res2.data} تلميذًا.`, 'success');
      loadAttendanceView();
    });
  };
  render();
});


// Phase 87: repeated-absence monitoring.
el('att-alert-run').addEventListener('click', async () => {
  const host = el('att-alert-results');
  const threshold = Number(el('att-alert-threshold').value || 3);
  if (!Number.isInteger(threshold) || threshold < 1 || threshold > 365) {
    toast('حدد عتبة صحيحة بين 1 و365.', 'error'); return;
  }
  host.innerHTML = loadingHtml();
  const res = await attendanceAbsenceAlerts(
    el('att-alert-from').value || null,
    el('att-alert-to').value || null,
    threshold
  );
  if (!res.ok) { host.innerHTML = emptyHtml(mapRpcError(res.error)); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد حالات بلغت حد الغياب المحدد.'); return; }
  host.innerHTML = `<div class="time" style="margin-bottom:8px;">عدد الحالات: ${rows.length}</div>` + rows.map((r) => `
    <div class="history-item" style="align-items:flex-start; flex-direction:column; gap:4px;">
      <strong>${esc(r.full_name)}</strong>
      <span class="time">#${esc(r.student_number || '—')} · ${esc(r.class_name || '—')}</span>
      <span>عدد أيام الغياب: <strong>${r.absence_count}</strong> · آخر غياب: ${esc(r.last_absence || '—')}</span>
      <span class="time">التواريخ: ${(r.absence_dates || []).map(esc).join('، ')}</span>
    </div>`).join('');
});

// ===== SCHEDULE =====
const WEEKDAYS_AR = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
let schoolPeriodsCache = null;
let scheduleSchoolProfile = null;
let scEditingEntryId = null; // V24: kept in this module scope; all callers use the same v30 module cache key

async function loadScheduleView() {
  const classes = await ensureClasses();
  el('sc-class').innerHTML = '<option value="">— اختر القسم —</option>'
    + classes.filter((c) => !c.is_disabled).map((c) => `<option value="${c.class_id}">${esc(c.class_name)} — ${esc(c.year_name || '')}</option>`).join('');
  el('sc-panel').innerHTML = emptyHtml('اختر القسم لعرض الجدول الأسبوعي.');
  el('sc-add-panel').hidden = true;
  const subjects = await ensureSubjects();
  el('sc-subject').innerHTML = '<option value="">— اختر المادة —</option>' + subjects.map((s) => `<option value="${s.subject_id}">${esc(s.subject_name)}</option>`).join('');
  const teachers = await ensureTeachers();
  el('sc-teacher').innerHTML = '<option value="">— اختر الأستاذ —</option>' + teachers.map((t) => `<option value="${t.id}">${esc(t.profiles?.full_name || '—')}</option>`).join('');
  // §28: after picking a SUBJECT, the teacher dropdown shows only teachers
  // actually assigned to that subject (fn_add_lesson stays the final
  // server-side authority — TEACHER_ASSIGNMENT_REQUIRED).
  const teacherSubjects = {};
  await Promise.all(teachers.map(async (t) => {
    const r = await listTeacherSubjects(t.id);
    teacherSubjects[t.id] = (r.ok ? r.data || [] : []).map((x) => x.subject_id);
  }));
  el('sc-subject').addEventListener('change', () => {
    const sid = el('sc-subject').value;
    const sel = el('sc-teacher');
    const prev = sel.value;
    sel.innerHTML = '<option value="">— اختر الأستاذ —</option>' + teachers
      .filter((t) => !sid || (teacherSubjects[t.id] || []).includes(sid))
      .map((t) => `<option value="${t.id}">${esc(t.profiles?.full_name || '—')}</option>`).join('');
    if ([...sel.options].some((o) => o.value === prev)) sel.value = prev;
  });
  const [periodsRes, profileRes] = await Promise.all([getSchoolPeriods(), getSchoolProfile(schoolId)]);
  schoolPeriodsCache = periodsRes.ok ? periodsRes.data : null;
  scheduleSchoolProfile = profileRes.ok ? profileRes.data : null;
  await fillPeriodOptions();
}

// ===== SIMPLE 4+4 WEEKLY TIMETABLE (منطق الشبكة الآن في modules/scheduleGrid.js) =====
// Phase 23 — the admin no longer types lesson time; it is computed from 4+4.
function addMinutes(hhmm, minutes) {
  const parts = hhmm.slice(0, 5).split(':').map(Number);
  const total = parts[0] * 60 + parts[1] + minutes;
  return String(Math.floor((total % 1440) / 60)).padStart(2, '0') + ':' + String(total % 60).padStart(2, '0');
}
async function fillPeriodOptions() {
  if (!schoolPeriodsCache) {
    const res = await getSchoolPeriods();
    schoolPeriodsCache = res.ok ? res.data : null;
  }
  const cfg = schoolPeriodsCache || {};
  const opts = [];
  for (let i = 1; i <= 8; i++) {
    const t = periodTimeRange(i, cfg);
    opts.push('<option value="' + i + '">' + (i <= 4 ? '🌅' : '☀️') + ' الحصة ' + i + ' (' + t.start + '–' + t.end + ')</option>');
  }
  el('sc-period').innerHTML = opts.join('');
}

function resetScheduleForm() {
  scEditingEntryId = null;
  el('sc-add-form').reset();
  const btn = el('sc-add-form').querySelector('button[type="submit"]');
  if (btn) btn.textContent = 'إضافة الحصة';
}

async function renderClassSchedule() {
  const classId = el('sc-class').value;
  if (!classId) { el('sc-panel').innerHTML = emptyHtml('اختر القسم لعرض الجدول الأسبوعي.'); el('sc-add-panel').hidden = true; return; }
  el('sc-add-panel').hidden = false;
  if (!schoolPeriodsCache) { const pr = await getSchoolPeriods(); schoolPeriodsCache = pr.ok ? pr.data : null; }
  const res = await getClassSchedule(classId);
  if (!res.ok) { el('sc-panel').innerHTML = emptyHtml(res.error); return; }
  const rows = res.data || [];
  const selected = el('sc-class').selectedOptions[0];
  const className = selected ? selected.textContent : '';
  el('sc-panel').innerHTML = buildWeeklyTimetable(rows, className, schoolPeriodsCache);

  el('sc-panel').querySelectorAll('[data-add-lesson]').forEach((b) => b.addEventListener('click', () => {
    resetScheduleForm();
    el('sc-weekday').value = b.dataset.weekday;
    el('sc-period').value = b.dataset.period;
    el('sc-add-form').querySelector('button[type="submit"]').textContent = 'إضافة الحصة';
    el('sc-add-form').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }));

  const editButtons = el('sc-panel').querySelectorAll('[data-edit-lesson]');
  editButtons.forEach((b) => b.addEventListener('click', () => {
    scEditingEntryId = b.dataset.editLesson;
    el('sc-weekday').value = b.dataset.weekday;
    el('sc-period').value = b.dataset.period;
    el('sc-subject').value = b.dataset.subject;
    el('sc-teacher').value = b.dataset.teacher;
    el('sc-add-form').querySelector('button[type="submit"]').textContent = 'تحديث الحصة';
    el('sc-add-form').scrollIntoView({ behavior: 'smooth' });
  }));
  el('sc-panel').querySelectorAll('[data-del-lesson]').forEach((b) => b.addEventListener('click', async () => {
    const ok = await confirmDialog('حذف هذه الحصة؟');
    if (!ok) return;
    const res2 = await deleteLesson(b.dataset.delLesson);
    if (!res2.ok) { toast(res2.error, 'error'); return; }
    toast('تم حذف الحصة.', 'success');
    if (scEditingEntryId === b.dataset.delLesson) resetScheduleForm();
    renderClassSchedule();
  }));
  el('sc-print')?.addEventListener('click', () => printWeeklyTimetable(rows, className, scheduleSchoolProfile, schoolPeriodsCache));
  el('sc-pdf')?.addEventListener('click', async () => {
    const res = await downloadWeeklyTimetablePdf(rows, className, scheduleSchoolProfile, schoolPeriodsCache);
    toast(res.ok ? 'تم تحميل ملف PDF.' : (res.fellBackToPrint ? 'تعذر إنشاء PDF مباشرة؛ فُتحت نسخة الطباعة لحفظها كـ PDF.' : 'تعذر إنشاء الملف.'), res.ok ? 'success' : 'info');
  });
}

el('sc-class')?.addEventListener('change', () => { resetScheduleForm(); renderClassSchedule(); });

// PHASE 19 FIX: this used to call setClassSchedule(classId, [oneEntry]),
// which REPLACES the whole class timetable and silently deleted every
// other lesson already saved for this class. Now uses single-row
// fn_add_lesson / fn_update_lesson (server-side conflict checks included).
el('sc-add-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const classId = el('sc-class').value;
  if (!classId) { toast('اختر القسم أولاً.', 'error'); return; }
  const payload = {
    classId, weekday: Number(el('sc-weekday').value), period: Number(el('sc-period').value),
    subjectId: el('sc-subject').value || null, teacherId: el('sc-teacher').value || null,
  };
  const res = scEditingEntryId
    ? await updateLesson({ entryId: scEditingEntryId, ...payload })
    : await addLesson(payload);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast(scEditingEntryId ? 'تم تحديث الحصة.' : 'تمت إضافة الحصة.', 'success');
  resetScheduleForm();
  renderClassSchedule();
});

// ===== TRANSPORT =====
async function loadTransport() {
  const bp = el('buses-panel');
  const rp = el('routes-panel');
  bp.innerHTML = loadingHtml();
  rp.innerHTML = loadingHtml();
  const [busesRes, routesRes, drivers, runsRes] = await Promise.all([listBuses(), listRoutes(), ensureDrivers(), listSchoolBusRouteRuns(), ensureClasses()]).then(x => x);
  cache.buses = busesRes.ok ? busesRes.data || [] : [];
  cache.routes = routesRes.ok ? routesRes.data || [] : [];
  cache.routeRuns = runsRes.ok ? runsRes.data || [] : [];
  const routeClassesSelect = el('rt-classes');
  if (routeClassesSelect) {
    if (!cache.classes) await ensureClasses();
    routeClassesSelect.innerHTML = (cache.classes || []).map(c =>
      `<option value="${esc(c.class_id)}">${esc(c.class_name || c.name || 'قسم')}</option>`
    ).join('');
  }


  bp.innerHTML = cache.buses.length
    ? cache.buses.map((b) => `<div class="history-item">
        <div><strong>${esc(b.code)}</strong> <span class="time">${esc(b.plate || '')}</span></div>
        <div class="time">${esc(b.driver_name || 'بدون سائق')} · ${b.student_count} تلميذًا ${b.is_active ? '' : '· <span class="badge badge-red">موقوفة</span>'}</div>
      </div>`).join('')
    : emptyHtml('لا توجد حافلات.');

  rp.innerHTML = cache.routes.length
    ? cache.routes.map((r) => {
      const stops = Array.isArray(r.stops) ? r.stops : [];
      return `<div class="history-item" style="flex-direction:column; align-items:stretch; gap:8px;">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;">
          <div><strong>${esc(r.route_name)}</strong> <span class="time">${Number(r.student_count)||0} تلميذًا</span></div>
          <div style="display:flex;gap:6px;">
            <button type="button" class="quick-action-btn secondary" data-edit-route="${esc(r.route_id)}">تعديل</button>
            <button type="button" class="quick-action-btn" style="background:#991b1b;" data-delete-route="${esc(r.route_id)}">حذف</button>
          </div>
        </div>
        <div class="time">${stops.map((s) => esc(s.name)).join(' ← ') || 'بدون محطات'}</div>
      </div>`;
    }).join('')
    : emptyHtml('لا توجد مسارات.');
  rp.querySelectorAll('[data-edit-route]').forEach((btn) => btn.addEventListener('click', async () => {
    const route = cache.routes.find(r => String(r.route_id) === btn.dataset.editRoute);
    if (!route) return;
    editingRouteId = route.route_id;
    el('rt-name').value = route.route_name || '';
    el('rt-stops').value = (route.stops || []).map(s => s.name || '').filter(Boolean).join('\n');
    const linked = await listBusRouteClasses(route.route_id);
    const selected = new Set((linked.ok ? linked.data || [] : []).map(c => String(c.class_id)));
    [...(el('rt-classes')?.options || [])].forEach(o => { o.selected = selected.has(o.value); });
    const submit = el('add-route-form')?.querySelector('button[type="submit"]');
    if (submit) submit.textContent = 'حفظ تعديلات المسار';
    el('add-route-form')?.scrollIntoView({behavior:'smooth',block:'center'});
  }));
  rp.querySelectorAll('[data-delete-route]').forEach((btn) => btn.addEventListener('click', async () => {
    const ok = await confirmDialog('هل تريد حذف هذا المسار؟ لا يمكن حذفه إذا كانت له رحلات أو تسجيلات نقل مرتبطة.');
    if (!ok) return;
    const result = await deleteRoute(btn.dataset.deleteRoute);
    if (!result.ok) { toast(result.error || 'تعذر حذف المسار لأنه مرتبط ببيانات نقل.', 'error'); return; }
    toast('تم حذف المسار.', 'success');
    if (editingRouteId === btn.dataset.deleteRoute) resetRouteForm();
    await loadTransport();
  }));

  el('bus-driver').innerHTML = '<option value="">—</option>' + drivers.map((d) => `<option value="${d.id}">${esc(d.profiles?.full_name || '—')}</option>`).join('');
  const runBus = el('route-run-bus');
  const runRoute = el('route-run-route');
  if (runBus) runBus.innerHTML = '<option value="">اختر الحافلة</option>' + cache.buses.map(b => `<option value="${b.id}">${esc(b.code || b.plate || 'حافلة')}</option>`).join('');
  if (runRoute) runRoute.innerHTML = '<option value="">اختر المسار</option>' + cache.routes.filter(r => r.is_active !== false).map(r => `<option value="${r.route_id}">${esc(r.route_name)}</option>`).join('');
  const runClass = el('route-run-class');
  if (runClass) {
    runClass.innerHTML = '<option value="">اختر المسار أولاً</option>';
    if (runRoute) runRoute.onchange = async () => {
      const routeId = runRoute.value;
      if (!routeId) {
        runClass.innerHTML = '<option value="">اختر المسار أولاً</option>';
        return;
      }
      runClass.innerHTML = '<option value="">جارٍ تحميل أقسام المسار...</option>';
      const linked = await listBusRouteClasses(routeId);
      if (!linked.ok) {
        runClass.innerHTML = '<option value="">تعذر تحميل الأقسام</option>';
        toast(linked.error, 'error');
        return;
      }
      const rows = linked.data || [];
      runClass.innerHTML = '<option value="">اختر القسم</option>' + rows.map(c =>
        `<option value="${esc(c.class_id)}">${esc(c.class_name)}</option>`
      ).join('');
      if (!rows.length) toast('اربط الأقسام بالمسار أولاً من إعدادات المسارات.', 'error');
    };
  }
  const runHost = el('route-runs-panel');
  if (runHost) {
    const days = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
    runHost.innerHTML = cache.routeRuns?.length
      ? '<div class="data-table-wrap"><table class="data-table"><thead><tr><th>الحافلة</th><th>الرحلة</th><th>المسار</th><th>القسم</th><th>اليوم</th><th>الوقت المستهدف</th><th>الاتجاه</th></tr></thead><tbody>'
        + cache.routeRuns.map(r => `<tr><td>${esc(r.bus_label)}</td><td>${esc(r.run_name)} (#${r.sequence_no})</td><td>${esc(r.route_name)}</td><td>${esc(r.class_name || '—')}</td><td>${(Array.isArray(r.days_of_week) && r.days_of_week.length ? r.days_of_week : [r.weekday]).map(d => days[Number(d)] || '—').join('، ')}</td><td>${esc(String(r.scheduled_start || '').slice(0,5))}</td><td>${r.direction === 'pickup' ? 'ذهاب إلى المؤسسة' : 'عودة إلى المنزل'}</td></tr>`).join('')
        + '</tbody></table></div>'
      : emptyHtml('لم تتم برمجة رحلات متعددة بعد.');
  }
}

el('add-bus-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const res = await createBus({
    code: el('bus-code').value, plate: el('bus-plate').value,
    capacity: el('bus-capacity').value ? Number(el('bus-capacity').value) : null,
    driverId: el('bus-driver').value || null,
  });
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم حفظ الحافلة.', 'success');
  e.target.reset();
  loadTransport();
});

function resetRouteForm() {
  editingRouteId = null;
  el('add-route-form')?.reset();
  const submit = el('add-route-form')?.querySelector('button[type="submit"]');
  if (submit) submit.textContent = 'حفظ المسار';
  [...(el('rt-classes')?.options || [])].forEach(o => { o.selected = false; });
}

el('add-route-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const routeName = String(el('rt-name')?.value || '').trim();
  if (!routeName) {
    el('rt-name')?.focus();
    toast('يرجى إدخال اسم المسار قبل الحفظ.', 'error');
    return;
  }
  const stops = String(el('rt-stops')?.value || '').split('\n').map((s) => s.trim()).filter(Boolean);
  const res = editingRouteId
    ? await updateRoute(editingRouteId, routeName, stops.map(name => ({name})))
    : await createRoute(routeName, stops);
  if (!res.ok) { toast(res.error, 'error'); return; }
  const routeId = editingRouteId || res.data;
  const selectedClasses = [...(el('rt-classes')?.selectedOptions || [])].map(o => o.value);
  const classRes = await setBusRouteClasses(routeId, selectedClasses);
  if (!classRes.ok) { toast('تم حفظ المسار لكن تعذر تحديث الأقسام: ' + classRes.error, 'error'); return; }
  toast(editingRouteId ? 'تم تحديث المسار وأقسامه.' : 'تم حفظ المسار وربط أقسامه.', 'success');
  resetRouteForm();
  loadTransport();
});

el('route-run-all-days')?.addEventListener('change', (e) => {
  document.querySelectorAll('input[name="route-run-days"]').forEach((box) => {
    box.checked = e.target.checked;
  });
});
document.querySelectorAll('input[name="route-run-days"]').forEach((box) => {
  box.addEventListener('change', () => {
    const all = [...document.querySelectorAll('input[name="route-run-days"]')];
    const allToggle = el('route-run-all-days');
    if (allToggle) allToggle.checked = all.length > 0 && all.every(x => x.checked);
  });
});

el('add-route-run-form')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const selectedDays = [...document.querySelectorAll('input[name=\"route-run-days\"]:checked')];
  if (!el('route-run-bus').value || !el('route-run-route').value || !el('route-run-class').value || !selectedDays.length) {
    toast('اختر الحافلة والمسار والقسم ويوماً واحداً على الأقل قبل برمجة الرحلة.', 'error');
    return;
  }
  const res = await createBusRouteRun({
    busId:el('route-run-bus').value, routeId:el('route-run-route').value,
    classId:el('route-run-class').value,
    runName:el('route-run-name').value, sequenceNo:Number(el('route-run-sequence').value),
    daysOfWeek:[...(document.querySelectorAll('input[name=\"route-run-days\"]:checked'))].map(x => Number(x.value)), direction:el('route-run-direction').value,
    scheduledStart:el('route-run-time').value,
  });
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تمت برمجة رحلة القسم بنجاح.', 'success');
  e.target.reset();
  document.querySelectorAll('input[name=\"route-run-days\"]').forEach(x => { x.checked = false; });
  loadTransport();
});

// ===== RECEIPTS =====
function extractReceiptNo(rows) {
  const hit = rows.find(([k]) => /رقم الوصل|مرجع العملية/.test(k));
  return hit ? String(hit[1] || '') : '';
}

async function openReceiptWindow(title, rows, filename = 'receipt') {
  const profile = await getCachedSchoolProfile();
  printReceipt({
    schoolName: profile.name, logoUrl: profile.logo_url,
    title, receiptNo: extractReceiptNo(rows), rows,
    footerNote: 'وصل صادر عن نظام Smart School.',
  });
}
function paymentReceiptRows(p) {
  return [['التلميذ', p.student_name], ['نوع الأداء', p.fee_type], ['المبلغ المستحق', fmtMoney(p.amount_due)], ['المبلغ المؤدى', fmtMoney(p.amount_paid)], ['التاريخ', fmtDate(p.payment_date)], ['طريقة الأداء', p.method || '—'], ['رقم الوصل', p.receipt_no || '—'], ['الحالة', p.status === 'PAID' ? 'مدفوع بالكامل' : p.status === 'PARTIAL' ? 'أداء جزئي' : p.status || '—']];
}

// ===== FINANCE =====
async function loadFinance() {
  const sum = el('finance-summary');
  sum.innerHTML = loadingHtml();
  const res = await financeSummary(null, null);
  const f = res.ok && res.data?.length ? res.data[0] : {};
  sum.innerHTML = '<div class="stats-grid">'
    + statCard(fmtMoney(f.total_due), 'مستحق') + statCard(fmtMoney(f.total_paid), 'مؤدى', 'tone-green')
    + statCard(fmtMoney((f.total_due || 0) - (f.total_paid || 0)), 'متبقٍ', 'tone-gold')
    + statCard(fmtMoney(f.total_expenses), 'مصاريف', 'tone-red')
    + statCard(fmtMoney(f.net), 'الصافي') + '</div>';

  loadPaymentsList();
  loadExpensesList();
  loadFeePlans();
}

async function loadFeePlans() {
  const host = el('fee-plans-panel');
  if (!host) return;
  host.innerHTML = loadingHtml();
  const res = await listSchoolFeePlans();
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  host.innerHTML = rows.length
    ? '<div class="data-table-wrap"><table class="data-table"><thead><tr><th>نوع الرسوم</th><th>السعر</th><th>الدورية</th><th>بداية التطبيق</th><th>الحالة</th></tr></thead><tbody>'
      + rows.map(r => `<tr><td>${esc(r.fee_type)}</td><td>${fmtMoney(r.price)}</td><td>${esc(r.billing_period === 'annual' ? 'سنوي' : r.billing_period === 'one_time' ? 'مرة واحدة' : 'شهري')}</td><td>${fmtDate(r.effective_from)}</td><td>${r.is_active ? 'فعال' : 'متوقف'}</td></tr>`).join('')
      + '</tbody></table></div>'
    : emptyHtml('لم يتم إعداد أسعار بعد.');
}

async function refreshPaymentQuote() {
  if (!pickedStudent || !el('pay-type')?.value) return;
  const quote = await getStudentFeeQuote(pickedStudent, el('pay-type').value);
  const data = quote.ok ? (Array.isArray(quote.data) ? quote.data[0] : quote.data) : null;
  if (data && Number(data.list_price) > 0) {
    el('pay-due').value = Number(data.final_amount || 0).toFixed(2);
    el('pay-due').readOnly = true;
    const hint = el('pay-fee-quote');
    if (hint) hint.textContent = `السعر الأصلي: ${fmtMoney(data.list_price)} · الخصم: ${fmtMoney(data.discount_amount)}${data.discount_reason ? ' · السبب: ' + data.discount_reason : ''}`;
  } else {
    el('pay-due').readOnly = false;
    const hint = el('pay-fee-quote');
    if (hint) hint.textContent = 'لا يوجد سعر محدد لهذا النوع؛ أدخل المبلغ المستحق أو أضف سعراً من إعدادات الرسوم.';
  }
}

async function loadPaymentsList() {
  const panel = el('payments-panel');
  panel.innerHTML = loadingHtml();
  const res = await listPayments(null, 30);
  const rows = res.ok ? res.data || [] : [];
  panel.innerHTML = rows.length
    ? rows.map((p, i) => `<div class="list-card">
        <div class="list-card-head"><strong>${esc(p.student_name)}</strong><span class="time">${esc(p.fee_type)}</span></div>
        <div class="time">${fmtMoney(p.amount_paid)} / ${fmtMoney(p.amount_due)} · ${fmtDate(p.payment_date)} · ${esc(p.receipt_no || '')}</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
          <button type="button" class="quick-action-btn secondary" data-payment-receipt="${i}">🧾 تحميل/طباعة الوصل</button>
          <button type="button" class="quick-action-btn secondary" data-payment-correct="${i}">✏️ تصحيح الأداء</button>
          <button type="button" class="quick-action-btn secondary" data-payment-audit="${i}">📋 سجل التعديلات</button>
        </div>
      </div>`).join('')
    : emptyHtml('لا توجد أداءات.');
  panel.querySelectorAll('[data-payment-receipt]').forEach((b) => b.addEventListener('click', () => {
    const p = rows[Number(b.dataset.paymentReceipt)];
    if (p) openReceiptWindow('وصل الأداء', paymentReceiptRows(p), p.receipt_no || 'payment-receipt');
  }));
  panel.querySelectorAll('[data-payment-correct]').forEach((b) => b.addEventListener('click', async () => {
    const p = rows[Number(b.dataset.paymentCorrect)];
    if (!p?.payment_id) { toast('لا يتوفر معرف الأداء لتصحيحه.', 'error'); return; }
    const due = prompt('المبلغ المستحق الجديد:', String(p.amount_due ?? 0));
    if (due === null) return;
    const paid = prompt('المبلغ المؤدى الجديد:', String(p.amount_paid ?? 0));
    if (paid === null) return;
    const reason = prompt('سبب تصحيح الأداء (إلزامي):');
    if (!reason?.trim()) { toast('يجب إدخال سبب التصحيح.', 'error'); return; }
    const method = prompt('طريقة الأداء (اتركها فارغة للإبقاء على الحالية):', p.method || '') ?? '';
    const result = await correctPayment({ paymentId:p.payment_id, amountDue:Number(due), amountPaid:Number(paid), method, reason });
    if (!result.ok) { toast(result.error, 'error'); return; }
    toast('تم تصحيح الأداء مع حفظ القيم السابقة وهوية المنفذ.', 'success');
    loadFinance();
  }));
  panel.querySelectorAll('[data-payment-audit]').forEach((b) => b.addEventListener('click', async () => {
    const p = rows[Number(b.dataset.paymentAudit)];
    if (!p?.payment_id) return;
    const result = await getPaymentAuditHistory(p.payment_id);
    if (!result.ok) { toast(result.error, 'error'); return; }
    const history = result.data || [];
    const message = history.length ? history.map(h => `${fmtDateTime(h.created_at)} · المنفذ: ${h.actor_email || h.actor_id} · ${h.action} · ${h.reason} · ${JSON.stringify(h.old_values)} → ${JSON.stringify(h.new_values)}`).join('\\n\\n') : 'لا توجد تعديلات مسجلة.';
    alert(message);
  }));
}

async function loadExpensesList() {
  const panel = el('expenses-panel');
  panel.innerHTML = loadingHtml();
  const res = await listExpenses(30);
  const rows = res.ok ? res.data || [] : [];
  panel.innerHTML = rows.length
    ? rows.map((x) => `<div class="list-card">
        <div class="list-card-head"><strong>${esc(x.category)}</strong><span class="time">${esc(x.description || '')}</span></div>
        <div class="time">${fmtMoney(x.amount)} · ${fmtDate(x.expense_date)}</div>
      </div>`).join('')
    : emptyHtml('لا توجد مصاريف.');
}

// student picker shared by payment & incident forms
function wireStudentPicker(inputId, resultsId, onPick) {
  let timer = null;
  el(inputId).addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const q = el(inputId).value;
      const host = el(resultsId);
      if (!q.trim()) { host.innerHTML = ''; return; }
      const rows = await searchStudents(q);
      host.innerHTML = rows.map((s) => `<div class="search-result-item" data-pick="${s.id}" data-name="${esc(s.full_name)}">${esc(s.full_name)} <span class="time">#${esc(s.student_number || '')}</span></div>`).join('');
      host.querySelectorAll('[data-pick]').forEach((it) => it.addEventListener('click', () => {
        onPick(it.dataset.pick, it.dataset.name);
        el(inputId).value = it.dataset.name;
        host.innerHTML = '';
      }));
    }, 300);
  });
}

wireStudentPicker('pay-student-search', 'pay-student-results', (id) => { pickedStudent = id; refreshPaymentQuote(); const host=el('fee-ledger-obligations'); if(host) host.innerHTML=''; const form=el('fee-ledger-payment-form'); if(form) form.hidden=true; });
el('pay-type').addEventListener('change', refreshPaymentQuote);
el('pay-student-search').addEventListener('change', refreshPaymentQuote);

el('add-payment-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = el('add-payment-error');
  errEl.hidden = true;
  if (!pickedStudent) { errEl.hidden = false; errEl.textContent = 'اختر التلميذ من نتائج البحث.'; return; }
  const res = await recordPayment({
    studentId: pickedStudent, feeType: el('pay-type').value,
    amountDue: Number(el('pay-due').value || 0), amountPaid: Number(el('pay-paid').value || 0),
    method: el('pay-method').value,
  });
  if (!res.ok) { errEl.hidden = false; errEl.textContent = res.error; return; }
  toast('تم تسجيل الأداء.', 'success');
  e.target.reset();
  pickedStudent = null;
  const latest = await listPayments(res.data || null, 20);
  if (latest.ok && latest.data?.length) {
    const match = latest.data.find((x) => x.receipt_no);
    if (match) openReceiptWindow('وصل الأداء', paymentReceiptRows(match), match.receipt_no || 'payment-receipt');
  }
  loadFinance();
});

let ledgerObligationRows = [];
async function loadStudentLedgerObligations() {
  const host = el('fee-ledger-obligations');
  const form = el('fee-ledger-payment-form');
  if (!pickedStudent) { toast('اختر التلميذ أولاً من حقل البحث.', 'error'); return; }
  host.innerHTML = loadingHtml(); form.hidden = true;
  const res = await listStudentFeeObligations(pickedStudent);
  if (!res.ok) { host.innerHTML = errorHtml(mapRpcError(res.error)); return; }
  ledgerObligationRows = (res.data || []).filter(x => Number(x.remaining) > 0);
  if (!ledgerObligationRows.length) { host.innerHTML = emptyHtml('لا توجد مستحقات متبقية لهذا التلميذ.'); return; }
  host.innerHTML = '<div class="data-table-wrap"><table class="data-table"><thead><tr><th>اختيار</th><th>نوع الرسم</th><th>الفترة</th><th>قبل الخصم</th><th>الخصم</th><th>المتبقي</th><th>المبلغ المراد أداؤه</th></tr></thead><tbody>'
    + ledgerObligationRows.map((o,i)=>`<tr><td><input type="checkbox" data-ledger-check="${i}" aria-label="اختيار المستحق"></td><td>${esc(o.fee_type)}</td><td>${esc(o.period_key)}</td><td>${fmtMoney(o.list_amount)}</td><td>${fmtMoney(o.discount_amount)}</td><td>${fmtMoney(o.remaining)}</td><td><input type="number" min="0.01" max="${Number(o.remaining)}" step="0.01" value="${Number(o.remaining).toFixed(2)}" data-ledger-amount="${i}" class="search-input" style="min-width:110px" disabled></td></tr>`).join('')
    + '</tbody></table></div>';
  host.querySelectorAll('[data-ledger-check]').forEach(ch=>ch.addEventListener('change',()=>{
    const i=Number(ch.dataset.ledgerCheck); const amount=host.querySelector(`[data-ledger-amount="${i}"]`);
    amount.disabled=!ch.checked; updateLedgerTotal();
  }));
  host.querySelectorAll('[data-ledger-amount]').forEach(inp=>inp.addEventListener('input',updateLedgerTotal));
  form.hidden=false; updateLedgerTotal();
}
function getLedgerAllocations() {
  const host=el('fee-ledger-obligations');
  return ledgerObligationRows.flatMap((o,i)=>{
    const check=host.querySelector(`[data-ledger-check="${i}"]`);
    const input=host.querySelector(`[data-ledger-amount="${i}"]`);
    if (!check?.checked) return [];
    return [{obligation_id:o.obligation_id,amount:Number(input?.value||0)}];
  });
}
function updateLedgerTotal() {
  const allocations=getLedgerAllocations();
  const total=allocations.reduce((a,x)=>a+x.amount,0);
  const label=el('ledger-total'); if(label) label.textContent=`عدد المستحقات المحددة: ${allocations.length} · المجموع: ${fmtMoney(total)}`;
}
el('fee-ledger-load')?.addEventListener('click',loadStudentLedgerObligations);
el('fee-ledger-payment-form')?.addEventListener('submit',async e=>{
  e.preventDefault();
  const err=el('ledger-payment-error'); err.hidden=true;
  const allocations=getLedgerAllocations();
  if(!allocations.length || allocations.some(x=>!Number.isFinite(x.amount)||x.amount<=0)) {err.hidden=false;err.textContent='حدد مستحقاً واحداً على الأقل وأدخل مبلغاً صحيحاً.';return;}
  const result=await recordFeePaymentBatch({studentId:pickedStudent,allocations,method:el('ledger-method').value,paidOn:el('ledger-paid-on').value||null,receiptNo:el('ledger-receipt-no').value,notes:el('ledger-notes').value});
  if(!result.ok){err.hidden=false;err.textContent=mapRpcError(result.error);return;}
  toast('تم تسجيل الأداء الموحد وتوزيعه على المستحقات المحددة.','success');
  const studentLabel=el('pay-student-search')?.value || '—';
  const receiptRows=[['التلميذ',studentLabel],['رقم مرجع العملية',result.data || '—'],['تاريخ الأداء',fmtDate(el('ledger-paid-on').value || new Date().toISOString().slice(0,10))],['طريقة الأداء',el('ledger-method').value],...allocations.map(a=>{const o=ledgerObligationRows.find(x=>x.obligation_id===a.obligation_id);return [`${o?.fee_type || 'رسم'} · ${o?.period_key || ''}`,fmtMoney(a.amount)];}),['إجمالي الأداء',fmtMoney(allocations.reduce((a,x)=>a+x.amount,0))],['رقم الوصل',el('ledger-receipt-no').value || '—']];
  await openReceiptWindow('وصل تسوية مستحقات متعددة',receiptRows,'fee-ledger-receipt');
  e.target.reset(); await loadStudentLedgerObligations(); loadFinance();
});

el('add-expense-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = el('add-expense-error');
  errEl.hidden = true;
  const res = await recordExpense({
    category: el('ex-category').value, amount: Number(el('ex-amount').value || 0),
    description: el('ex-desc').value,
  });
  if (!res.ok) { errEl.hidden = false; errEl.textContent = res.error; return; }
  toast('تم تسجيل المصروف.', 'success');
  e.target.reset();
  loadFinance();
});

el('fee-plan-form')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = el('fee-plan-error'); if (err) err.hidden = true;
  const result = await upsertSchoolFeePlan({
    feeType: el('fee-plan-type').value, price: Number(el('fee-plan-price').value),
    billingPeriod: el('fee-plan-period').value, effectiveFrom: el('fee-plan-from').value || null,
    effectiveTo: el('fee-plan-to').value || null, isActive: true,
  });
  if (!result.ok) { if (err) { err.hidden=false; err.textContent=result.error; } return; }
  toast('تم حفظ سعر الرسوم.', 'success'); e.target.reset(); loadFeePlans();
});

wireStudentPicker('discount-student-search', 'discount-student-results', (id) => { pickedDiscountStudent = id; });
el('discount-form')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = el('discount-error'); if (err) err.hidden=true;
  if (!pickedDiscountStudent) { if (err) {err.hidden=false;err.textContent='اختر التلميذ أولاً.';} return; }
  const result = await createStudentFeeDiscount({
    studentId:pickedDiscountStudent, feeType:el('discount-fee-type').value,
    discountKind:el('discount-kind').value, discountValue:Number(el('discount-value').value),
    reason:el('discount-reason').value, effectiveFrom:el('discount-from').value || null,
    effectiveTo:el('discount-to').value || null,
  });
  if (!result.ok) { if (err) {err.hidden=false;err.textContent=result.error;} return; }
  toast('تم تسجيل الخصم وتوثيق صاحبه وسببه.', 'success');
  e.target.reset(); pickedDiscountStudent=null; loadFeePlans();
});

// ===== INCIDENTS =====
async function loadIncidentsView() {
  const panel = el('incidents-panel');
  panel.innerHTML = loadingHtml();
  const res = await listIncidents(el('inc-status').value || null, 50, 0);
  const rows = res.ok ? res.data || [] : [];
  panel.innerHTML = rows.length
    ? rows.map((i) => `<div class="history-item" style="flex-direction:column; align-items:flex-start; gap:4px;">
        <div><strong>${esc(i.title)}</strong> <span class="badge ${i.status === 'open' ? 'badge-red' : 'badge-green'}">${i.status === 'open' ? 'مفتوحة' : 'مغلقة'}</span></div>
        <div class="time">${esc(i.student_name)} · ${esc(i.type)} · ${fmtDateTime(i.occurred_at)} · سجلها: ${esc(i.reporter_name || '—')}</div>
        ${i.description ? `<div class="time">${esc(i.description)}</div>` : ''}
        ${i.action_taken ? `<div class="time">الإجراء: ${esc(i.action_taken)}</div>` : ''}
        ${i.status === 'open' ? `<button type="button" class="att-btn" data-close-inc="${i.incident_id}">إغلاق المخالفة</button>` : ''}
      </div>`).join('')
    : emptyHtml('لا توجد مخالفات.');
  panel.querySelectorAll('[data-close-inc]').forEach((b) => b.addEventListener('click', async () => {
    const action = prompt('الإجراء المتخذ (اختياري):') ?? '';
    const res2 = await updateIncident(b.dataset.closeInc, 'closed', action || null);
    if (!res2.ok) { toast(res2.error, 'error'); return; }
    toast('تم إغلاق المخالفة.', 'success');
    loadIncidentsView();
  }));
}
el('inc-status').addEventListener('change', loadIncidentsView);
el('btn-add-incident').addEventListener('click', () => { pickedStudent = null; el('add-incident-form').reset(); showView('incident-add'); });

wireStudentPicker('inc-student-search', 'inc-student-results', (id) => { pickedStudent = id; });

el('add-incident-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = el('add-incident-error');
  errEl.hidden = true;
  if (!pickedStudent) { errEl.hidden = false; errEl.textContent = 'اختر التلميذ من نتائج البحث.'; return; }
  const res = await reportIncident({
    studentId: pickedStudent, type: el('inc-type').value, title: el('inc-title').value,
    description: el('inc-desc').value, place: el('inc-place').value,
  });
  if (!res.ok) { errEl.hidden = false; errEl.textContent = res.error; return; }
  toast('تم تسجيل المخالفة.', 'success');
  e.target.reset();
  pickedStudent = null;
  showView('incidents');
  loadIncidentsView();
});

// ===== REPORTS =====
async function loadReportsView() {
  const classes = await ensureClasses();
  populateArchiveYears(cache.years || []);
  await refreshSchoolDocumentRequests();
  el('rp-class').innerHTML = '<option value="">كل الأقسام</option>'
    + classes.map((c) => `<option value="${c.class_id}">${esc(c.class_name)} — ${esc(c.year_name || '')}</option>`).join('');
  const now = new Date();
  el('rp-to').value = now.toISOString().slice(0, 10);
  el('rp-from').value = new Date(now.getTime() - 30 * 86400000).toISOString().slice(0, 10);
  el('report-result').hidden = true;
  el('council-class').innerHTML = classes.map((c) =>
    `<option value="${c.class_id}">${esc(c.class_name)} — ${esc(c.year_name || '')}</option>`
  ).join('');
  el('council-date').value = now.toISOString().slice(0, 10);
  el('council-title').value = '';
  el('council-minutes').value = '';
  el('council-status').textContent = '';
  el('council-results').innerHTML = emptyHtml('اختر القسم والفترة ثم اضغط احتساب النتائج.');
  el('council-save-decisions').hidden = true;
  currentCouncilId = null;
  currentCouncilRows = [];
  selectedCertificateStudent = null;
  el('cert-selected-student').textContent = 'لم يتم اختيار تلميذ.';
  el('cert-issue').disabled = true;
  el('cert-student-results').innerHTML = '';
  refreshCertificateList();
  selectedArchiveStudent = null;
  el('archive-selected-student').textContent = 'لم يتم ربط الوثيقة بتلميذ.';
  el('archive-student-results').innerHTML = '';
  el('archive-student-search').value = '';
  el('archive-title').value = '';
  el('archive-description').value = '';
  el('archive-file').value = '';
  refreshArchiveList();
}


async function loadCouncilResults() {
  const classId = el('council-class').value;
  const period = el('council-period').value;
  const host = el('council-results');
  if (!classId) { toast('اختر القسم أولاً.', 'error'); return; }
  host.innerHTML = loadingHtml();
  el('council-save-decisions').hidden = true;
  currentCouncilId = null;
  const [results, details] = await Promise.all([
    classFinalResults(classId, period),
    classCouncilDetails(classId, period)
  ]);
  if (!results.ok) {
    host.innerHTML = emptyHtml(mapRpcError(results.error));
    return;
  }
  currentCouncilRows = results.data || [];
  if (details.ok && details.data?.length) {
    const council = details.data[0];
    currentCouncilId = council.council_id;
    el('council-date').value = council.meeting_date || '';
    el('council-title').value = council.meeting_title || '';
    el('council-minutes').value = council.minutes || '';
    el('council-status').textContent = `آخر تحديث للمحضر: ${fmtDateTime(council.updated_at)}`;
  }
  if (!currentCouncilRows.length) {
    host.innerHTML = emptyHtml('لا يوجد تلاميذ مسجلون في هذا القسم.');
    return;
  }
  host.innerHTML = `<div class="time" style="margin-bottom:8px;">عدد التلاميذ: ${currentCouncilRows.length}. المعدل محسوب حسب معاملات المواد.</div>`
    + `<div class="data-table-wrap"><table class="data-table"><thead><tr>
      <th>التلميذ</th><th>الرقم</th><th>المعدل</th><th>المواد</th><th>التوصية</th><th>قرار المجلس</th><th>ملاحظة</th>
    </tr></thead><tbody>`
    + currentCouncilRows.map((r) => {
      const rec = r.recommendation === 'PASS' ? 'مستوفٍ للعتبة' :
        r.recommendation === 'REPEAT' ? 'دون عتبة النجاح' : 'لا توجد نقط كافية';
      const chosen = r.existing_decision || (r.recommendation === 'PASS' ? 'PASS' : r.recommendation === 'REPEAT' ? 'REPEAT' : 'REVIEW');
      return `<tr>
        <td>${esc(r.student_name || '')}</td>
        <td>${esc(r.student_number || '—')}</td>
        <td>${r.final_average == null ? '—' : Number(r.final_average).toFixed(2)}</td>
        <td>${r.subject_count || 0}</td>
        <td>${rec}</td>
        <td><select class="search-input" data-council-decision="${r.student_id}">
          <option value="PASS" ${chosen === 'PASS' ? 'selected' : ''}>ناجح</option>
          <option value="REPEAT" ${chosen === 'REPEAT' ? 'selected' : ''}>إعادة المستوى</option>
          <option value="REVIEW" ${chosen === 'REVIEW' ? 'selected' : ''}>قيد المراجعة</option>
        </select></td>
        <td><input class="search-input" data-council-note="${r.student_id}" value="${esc(r.decision_note || '')}" placeholder="ملاحظة القرار"></td>
      </tr>`;
    }).join('') + '</tbody></table></div>';
  el('council-save-decisions').hidden = false;
}

el('council-load').addEventListener('click', loadCouncilResults);

el('council-save').addEventListener('click', async () => {
  const classId = el('council-class').value;
  if (!classId) { toast('اختر القسم أولاً.', 'error'); return; }
  const res = await saveClassCouncil(
    classId, el('council-period').value, el('council-date').value,
    el('council-title').value, el('council-minutes').value
  );
  if (!res.ok) { toast(mapRpcError(res.error), 'error'); return; }
  currentCouncilId = res.data;
  el('council-status').textContent = 'تم حفظ محضر المجلس.';
  toast('تم حفظ محضر المجلس.', 'success');
});

el('council-save-decisions').addEventListener('click', async () => {
  const classId = el('council-class').value;
  if (!classId || !currentCouncilRows.length) return;
  let councilId = currentCouncilId;
  if (!councilId) {
    const council = await saveClassCouncil(
      classId, el('council-period').value, el('council-date').value,
      el('council-title').value, el('council-minutes').value
    );
    if (!council.ok) { toast(mapRpcError(council.error), 'error'); return; }
    councilId = council.data;
    currentCouncilId = councilId;
  }
  const items = currentCouncilRows.map((row) => ({
    student_id: row.student_id,
    decision: el('council-results').querySelector(`[data-council-decision="${row.student_id}"]`)?.value || 'REVIEW',
    final_average: row.final_average == null ? null : Number(row.final_average),
    decision_note: el('council-results').querySelector(`[data-council-note="${row.student_id}"]`)?.value || ''
  }));
  const button = el('council-save-decisions');
  button.disabled = true;
  const result = await saveClassCouncilDecisions(councilId, items);
  button.disabled = false;
  if (!result.ok) { toast(mapRpcError(result.error), 'error'); return; }
  toast(`تم اعتماد ${result.data} قراراً بنجاح.`, 'success');
  el('council-status').textContent = `تم اعتماد ${result.data} قراراً بتاريخ ${fmtDate(new Date())}.`;
  loadCouncilResults();
});


// ===== PHASE 90: CERTIFICATE REGISTER =====
let selectedCertificateStudent = null;
let currentCertificates = [];
let certificateSearchSerial = 0;

function certificateTypeLabel(type) {
  return ({
    ENROLLMENT: 'شهادة مدرسية',
    SUCCESS: 'شهادة النجاح',
    TRANSFER: 'شهادة الانتقال',
    DEPARTURE: 'شهادة المغادرة'
  })[type] || type || 'شهادة';
}

function certificateVerifyUrl(token) {
  const url = new URL('verify-certificate.html', window.location.href);
  url.searchParams.set('token', token);
  return url.toString();
}

function printIssuedCertificate(cert) {
  if (!cert) return;
  const snap = cert.snapshot || {};
  const profilePromise = getCachedSchoolProfile();
  profilePromise.then((profile) => {
    const verifyUrl = certificateVerifyUrl(cert.verification_token);
    printReport({
      schoolName: snap.school_name || profile.name,
      logoUrl: profile.logo_url,
      title: certificateTypeLabel(snap.certificate_type || cert.certificate_type),
      meta: [
        ['رقم الشهادة', cert.certificate_number],
        ['تاريخ الإصدار', fmtDate(cert.issue_date)],
        ['اسم التلميذ', snap.student_name || cert.student_name || '—'],
        ['رقم التلميذ', snap.student_number || cert.student_number || '—'],
        ['القسم', snap.class_name || cert.class_name || '—'],
        ['السنة الدراسية', snap.academic_year || cert.academic_year || '—']
      ],
      headers: ['البيان', 'التفاصيل'],
      rows: [[
        'موضوع الشهادة',
        snap.purpose || cert.purpose || certificateTypeLabel(snap.certificate_type || cert.certificate_type)
      ]],
      summary: [['حالة الوثيقة', cert.status === 'VOID' ? 'ملغاة' : 'صالحة']],
      footerNote: `للتحقق من صحة هذه الوثيقة افتح الرابط التالي: ${verifyUrl} — رمز التحقق: ${cert.verification_token}. هذه وثيقة صادرة عن المؤسسة عبر النظام وليست تصديقاً من الوزارة.`,
    });
  });
}

async function searchCertificateStudents() {
  const query = el('cert-student-search').value.trim();
  const host = el('cert-student-results');
  const serial = ++certificateSearchSerial;
  if (query.length < 2) { host.innerHTML = ''; return; }
  host.innerHTML = loadingHtml();
  const rows = await searchStudents(query);
  if (serial !== certificateSearchSerial) return;
  host.innerHTML = rows.length
    ? `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>التلميذ</th><th>الرقم</th><th></th></tr></thead><tbody>`
      + rows.map((r) => `<tr><td>${esc(r.full_name || '')}</td><td>${esc(r.student_number || '—')}</td>`
        + `<td><button type="button" class="quick-action-btn secondary" data-cert-pick="${esc(r.id)}">اختيار</button></td></tr>`).join('')
      + '</tbody></table></div>'
    : emptyHtml('لم يتم العثور على تلميذ مطابق.');
  host._studentRows = rows;
}

el('cert-student-search')?.addEventListener('input', searchCertificateStudents);
el('cert-student-results')?.addEventListener('click', (event) => {
  const button = event.target.closest('[data-cert-pick]');
  if (!button) return;
  const rows = button.closest('#cert-student-results')?._studentRows || [];
  selectedCertificateStudent = rows.find((r) => r.id === button.dataset.certPick) || null;
  el('cert-selected-student').textContent = selectedCertificateStudent
    ? `التلميذ المختار: ${selectedCertificateStudent.full_name} — ${selectedCertificateStudent.student_number || 'بدون رقم'}`
    : 'لم يتم اختيار تلميذ.';
  el('cert-issue').disabled = !selectedCertificateStudent;
});

async function refreshCertificateList() {
  const host = el('cert-list');
  if (!host) return;
  host.innerHTML = loadingHtml();
  const result = await listSchoolCertificates(el('cert-filter').value.trim(), 200);
  if (!result.ok) { host.innerHTML = emptyHtml(mapRpcError(result.error)); return; }
  currentCertificates = result.data || [];
  if (!currentCertificates.length) { host.innerHTML = emptyHtml('لا توجد شهادات مسجلة بعد.'); return; }
  host.innerHTML = `<div class="data-table-wrap"><table class="data-table"><thead><tr>
    <th>رقم الشهادة</th><th>النوع</th><th>التلميذ</th><th>القسم</th><th>تاريخ الإصدار</th><th>الحالة</th><th>إجراءات</th>
    </tr></thead><tbody>` + currentCertificates.map((c) => `<tr>
      <td>${esc(c.certificate_number)}</td><td>${esc(certificateTypeLabel(c.certificate_type))}</td>
      <td>${esc(c.student_name || '')}<div class="time">${esc(c.student_number || '')}</div></td>
      <td>${esc(c.class_name || '—')}</td><td>${esc(fmtDate(c.issue_date))}</td>
      <td>${c.status === 'VALID' ? 'صالحة' : 'ملغاة'}</td>
      <td><button type="button" class="quick-action-btn secondary" data-cert-print="${esc(c.id)}">طباعة</button>
      ${c.status === 'VALID' ? `<button type="button" class="quick-action-btn danger" data-cert-void="${esc(c.id)}">إلغاء</button>` : ''}</td>
    </tr>`).join('') + '</tbody></table></div>';
}

el('cert-issue')?.addEventListener('click', async () => {
  if (!selectedCertificateStudent) { toast('اختر التلميذ أولاً.', 'error'); return; }
  const button = el('cert-issue');
  button.disabled = true;
  const result = await issueSchoolCertificate(
    selectedCertificateStudent.id, el('cert-type').value, el('cert-purpose').value.trim()
  );
  button.disabled = false;
  if (!result.ok) { toast(mapRpcError(result.error), 'error'); return; }
  const cert = result.data || {};
  cert.certificate_type = el('cert-type').value;
  printIssuedCertificate(cert);
  toast(`تم إصدار الشهادة رقم ${cert.certificate_number}.`, 'success');
  el('cert-purpose').value = '';
  refreshCertificateList();
});

el('cert-refresh')?.addEventListener('click', refreshCertificateList);
el('cert-filter')?.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') refreshCertificateList();
});
el('cert-list')?.addEventListener('click', async (event) => {
  const printButton = event.target.closest('[data-cert-print]');
  if (printButton) {
    const cert = currentCertificates.find((x) => x.id === printButton.dataset.certPrint);
    if (cert) {
      // Re-fetching the list keeps the print snapshot aligned with the database record.
      const full = await listSchoolCertificates(cert.certificate_number, 5);
      const item = full.ok ? (full.data || []).find((x) => x.id === cert.id) : null;
      if (item) printIssuedCertificate({ ...item, snapshot: {
        school_name: (await getCachedSchoolProfile()).name,
        student_name: item.student_name, student_number: item.student_number,
        class_name: item.class_name, academic_year: item.academic_year,
        certificate_type: item.certificate_type, purpose: item.purpose
      }});
    }
    return;
  }
  const voidButton = event.target.closest('[data-cert-void]');
  if (!voidButton) return;
  const reason = window.prompt('أدخل سبب إلغاء الشهادة:');
  if (!reason || !reason.trim()) return;
  const result = await voidSchoolCertificate(voidButton.dataset.certVoid, reason.trim());
  if (!result.ok) { toast(mapRpcError(result.error), 'error'); return; }
  toast('تم إلغاء الشهادة وتحديث حالة التحقق.', 'success');
  refreshCertificateList();
});


// ===== PHASE 91: PRIVATE DIGITAL ARCHIVE =====
let selectedArchiveStudent = null;
let archiveStudentSearchSerial = 0;
let archiveRows = [];

const archiveCategoryLabels = {
  STUDENT_ID: 'وثائق تعريف التلميذ',
  ENROLLMENT: 'التسجيل والتمدرس',
  REPORT_CARD: 'كشوف النقط',
  CERTIFICATE: 'الشهادات',
  COUNCIL_MINUTES: 'محاضر مجالس الأقسام',
  MEDICAL_NOTE: 'وثائق طبية',
  TRANSFER: 'الانتقال والمغادرة',
  PAYMENT: 'الأداءات والوصولات',
  STAFF: 'ملفات الموظفين',
  ADMINISTRATIVE: 'وثائق إدارية',
  OTHER: 'أخرى'
};

function formatArchiveSize(size) {
  const bytes = Number(size || 0);
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

async function searchArchiveStudents() {
  const query = el('archive-student-search').value.trim();
  const host = el('archive-student-results');
  const serial = ++archiveStudentSearchSerial;
  if (query.length < 2) { host.innerHTML = ''; return; }
  host.innerHTML = loadingHtml();
  const rows = await searchStudents(query);
  if (serial !== archiveStudentSearchSerial) return;
  host._studentRows = rows;
  host.innerHTML = rows.length
    ? `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>التلميذ</th><th>الرقم</th><th></th></tr></thead><tbody>`
      + rows.map((r) => `<tr><td>${esc(r.full_name || '')}</td><td>${esc(r.student_number || '—')}</td>`
        + `<td><button type="button" class="quick-action-btn secondary" data-archive-student="${esc(r.id)}">اختيار</button></td></tr>`).join('')
      + '</tbody></table></div>'
    : emptyHtml('لم يتم العثور على تلميذ مطابق.');
}

el('archive-student-search')?.addEventListener('input', searchArchiveStudents);
el('archive-student-results')?.addEventListener('click', (event) => {
  const button = event.target.closest('[data-archive-student]');
  if (!button) return;
  const rows = el('archive-student-results')._studentRows || [];
  selectedArchiveStudent = rows.find((r) => r.id === button.dataset.archiveStudent) || null;
  el('archive-selected-student').textContent = selectedArchiveStudent
    ? `سيتم ربط الوثيقة بالتلميذ: ${selectedArchiveStudent.full_name} — ${selectedArchiveStudent.student_number || 'بدون رقم'}`
    : 'لم يتم ربط الوثيقة بتلميذ.';
});

function populateArchiveYears(years) {
  const options = (years || []).map((y) =>
    `<option value="${esc(y.year_id)}">${esc(y.year_name)}${y.is_current ? ' (الحالية)' : ''}</option>`
  ).join('');
  el('archive-year').innerHTML = '<option value="">دون تحديد سنة</option>' + options;
  el('archive-filter-year').innerHTML = '<option value="">كل السنوات</option>' + options;
  const current = (years || []).find((y) => y.is_current);
  if (current) el('archive-year').value = current.year_id;
}

async function refreshArchiveList() {
  const host = el('archive-list');
  if (!host) return;
  host.innerHTML = loadingHtml();
  const result = await listSchoolArchiveDocuments({
    query: el('archive-filter').value.trim(),
    academicYearId: el('archive-filter-year').value || null,
    status: el('archive-status').value || null,
    limit: 250
  });
  if (!result.ok) { host.innerHTML = emptyHtml(mapRpcError(result.error)); return; }
  archiveRows = result.data || [];
  if (!archiveRows.length) { host.innerHTML = emptyHtml('لا توجد وثائق مطابقة في الأرشيف.'); return; }
  host.innerHTML = `<div class="data-table-wrap"><table class="data-table"><thead><tr>
    <th>الوثيقة</th><th>التلميذ</th><th>السنة</th><th>التصنيف</th><th>الحجم</th><th>تاريخ الرفع</th><th>الحالة</th><th>إجراءات</th>
    </tr></thead><tbody>` + archiveRows.map((d) => `<tr>
      <td><b>${esc(d.title)}</b><div class="time">${esc(d.file_name)}</div></td>
      <td>${esc(d.student_name || 'عام')}<div class="time">${esc(d.student_number || '')}</div></td>
      <td>${esc(d.academic_year_name || '—')}</td>
      <td>${esc(archiveCategoryLabels[d.category] || d.category)}</td>
      <td>${formatArchiveSize(d.file_size)}</td>
      <td>${esc(fmtDate(d.uploaded_at))}</td>
      <td>${d.status === 'ACTIVE' ? 'نشطة' : 'مؤرشفة'}</td>
      <td><button type="button" class="quick-action-btn secondary" data-archive-download="${esc(d.id)}">تنزيل</button>
      ${d.status === 'ACTIVE' ? `<button type="button" class="quick-action-btn secondary" data-archive-close="${esc(d.id)}">أرشفة</button>` : ''}</td>
    </tr>`).join('') + '</tbody></table></div>';
}

el('archive-upload')?.addEventListener('click', async () => {
  const file = el('archive-file').files?.[0];
  const title = el('archive-title').value.trim();
  if (!file || title.length < 2) { toast('أدخل عنوان الوثيقة واختر الملف أولاً.', 'error'); return; }
  const button = el('archive-upload');
  button.disabled = true;
  button.textContent = 'جارٍ رفع الوثيقة...';
  const result = await uploadSchoolArchiveDocument(schoolId, file, {
    studentId: selectedArchiveStudent?.id || null,
    academicYearId: el('archive-year').value || null,
    category: el('archive-category').value,
    title,
    description: el('archive-description').value.trim()
  });
  button.disabled = false;
  button.textContent = 'رفع الوثيقة إلى الأرشيف الخاص';
  if (!result.ok) { toast(mapRpcError(result.error), 'error'); return; }
  toast('تم رفع الوثيقة وحفظ بياناتها في الأرشيف الخاص.', 'success');
  el('archive-file').value = '';
  el('archive-title').value = '';
  el('archive-description').value = '';
  refreshArchiveList();
});

el('archive-refresh')?.addEventListener('click', refreshArchiveList);
el('archive-filter')?.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') refreshArchiveList();
});
el('archive-filter-year')?.addEventListener('change', refreshArchiveList);
el('archive-status')?.addEventListener('change', refreshArchiveList);
el('archive-list')?.addEventListener('click', async (event) => {
  const downloadButton = event.target.closest('[data-archive-download]');
  if (downloadButton) {
    const row = archiveRows.find((d) => d.id === downloadButton.dataset.archiveDownload);
    if (!row) return;
    const result = await createArchiveDocumentLink(row.storage_path);
    if (!result.ok) { toast(mapRpcError(result.error), 'error'); return; }
    window.open(result.url, '_blank', 'noopener,noreferrer');
    return;
  }
  const archiveButton = event.target.closest('[data-archive-close]');
  if (!archiveButton) return;
  const reason = window.prompt('أدخل سبب أرشفة الوثيقة:');
  if (!reason || reason.trim().length < 3) return;
  const result = await archiveSchoolDocument(archiveButton.dataset.archiveClose, reason.trim());
  if (!result.ok) { toast(mapRpcError(result.error), 'error'); return; }
  toast('تمت أرشفة الوثيقة دون حذف الملف.', 'success');
  refreshArchiveList();
});


// ---- Phase 92/93: Parent document request inbox ----------------------------
const SCHOOL_DOC_TYPE_AR = { ENROLLMENT:'شهادة مدرسية', TRANSFER:'شهادة انتقال', REPORT_CARD:'نسخة كشف النقط', OTHER:'وثيقة أخرى' };
const SCHOOL_DOC_STATUS_AR = { SUBMITTED:'جديد', UNDER_REVIEW:'قيد الدراسة', APPROVED:'موافق عليه', REJECTED:'مرفوض', READY:'جاهز', DELIVERED:'تم التسليم', CANCELLED:'ملغى' };
let pdrRows = [];

function renderSchoolDocumentRequests() {
  const host = el('pdr-list');
  if (!host) return;
  const q = (el('pdr-search')?.value || '').trim().toLowerCase();
  const rows = q ? pdrRows.filter((r) => String(r.student_name || '').toLowerCase().includes(q)) : pdrRows;
  const stats = el('pdr-stats');
  if (stats) {
    const n = (st) => pdrRows.filter((r) => r.status === st).length;
    stats.innerHTML = [['جديدة', n('SUBMITTED')], ['قيد الدراسة', n('UNDER_REVIEW')], ['جاهزة للتسليم', n('READY')]]
      .map(([label, value]) => statCard(esc(String(value)), esc(label))).join('');
  }
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد طلبات وثائق في هذه القائمة.'); return; }
  const btn = (action, id, label) => `<button class="quick-action-btn secondary" data-pdr-action="${action}" data-pdr-id="${esc(id)}">${label}</button>`;
  host.innerHTML = `<div class="data-table-wrap"><table class="data-table"><thead><tr>
    <th>التلميذ</th><th>الوثيقة</th><th>الغرض</th><th>تاريخ الطلب</th><th>الحالة</th><th>إجراءات</th>
  </tr></thead><tbody>${rows.map((r) => `<tr>
    <td>${esc(r.student_name || '—')}</td><td>${esc(SCHOOL_DOC_TYPE_AR[r.request_type] || r.request_type)}</td>
    <td>${esc(r.purpose || '—')}</td><td>${fmtDateTime(r.created_at)}</td>
    <td><span class="badge ${r.status==='REJECTED'||r.status==='CANCELLED'?'badge-red':r.status==='READY'||r.status==='DELIVERED'?'badge-green':'badge-blue'}">${esc(SCHOOL_DOC_STATUS_AR[r.status] || r.status)}</span>
    ${r.admin_response ? `<div class="time">${esc(r.admin_response)}</div>` : ''}</td>
    <td style="min-width:230px;">
      ${!['REJECTED','DELIVERED','CANCELLED'].includes(r.status) ? `
        <div style="display:flex;gap:5px;flex-wrap:wrap;">
          ${r.status==='SUBMITTED' ? btn('UNDER_REVIEW', r.id, 'بدء الدراسة') : ''}
          ${['SUBMITTED','UNDER_REVIEW'].includes(r.status) ? btn('APPROVED', r.id, 'موافقة') : ''}
          ${['SUBMITTED','UNDER_REVIEW','APPROVED'].includes(r.status) ? btn('REJECTED', r.id, 'رفض') : ''}
          ${['APPROVED','READY'].includes(r.status) ? btn('READY', r.id, r.status==='READY' ? 'تغيير الوثيقة' : 'ربط الوثيقة وإعلان الجاهزية') : ''}
          ${r.status==='READY' ? btn('DELIVERED', r.id, 'تأكيد التسليم') : ''}
        </div>` : '—'}
    </td></tr>`).join('')}</tbody></table></div>`;
}

async function refreshSchoolDocumentRequests() {
  const host = el('pdr-list');
  if (!host) return;
  host.innerHTML = loadingHtml();
  try {
    // Call the RPC directly here. This keeps the reports view independent of
    // a stale/mismatched helper export in an older cached school.js module.
    const { data, error } = await supabase.rpc('fn_list_school_document_requests', {
      p_status: el('pdr-status')?.value || null,
    });
    if (error) { host.innerHTML = errorHtml(mapRpcError(error)); return; }
    pdrRows = Array.isArray(data) ? data : (data ? [data] : []);
    renderSchoolDocumentRequests();
  } catch (error) {
    console.error('document requests load error:', error);
    host.innerHTML = errorHtml('تعذر تحميل طلبات الوثائق.');
  }
}

// Picker that replaces the old "paste a UUID" prompt: lists the student's active archive documents.
function pickArchiveDocument(docs) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `<div class="modal-card" role="dialog" aria-modal="true">
      <p class="section-title" style="margin-top:0;">اختر وثيقة الأرشيف المراد تسليمها</p>
      <div style="display:grid;gap:8px;max-height:50vh;overflow:auto;">${docs.map((d, i) => `
        <label class="panel" style="display:flex;gap:8px;align-items:center;cursor:pointer;">
          <input type="radio" name="pdr-doc" value="${i}" ${i === 0 ? 'checked' : ''}>
          <span style="flex:1">${esc(d.title)}<br><small class="time">${esc(d.file_name)} — ${esc(d.category)}</small></span>
          <button type="button" class="quick-action-btn secondary" data-preview="${i}">معاينة</button>
        </label>`).join('')}</div>
      <div style="display:flex;gap:8px;margin-top:12px;">
        <button type="button" class="quick-action-btn" data-ok>تأكيد</button>
        <button type="button" class="quick-action-btn secondary" data-cancel>إلغاء</button>
      </div></div>`;
    document.body.appendChild(overlay);
    const close = (value) => { overlay.remove(); resolve(value); };
    overlay.addEventListener('click', async (e) => {
      if (e.target === overlay || e.target.closest('[data-cancel]')) return close(null);
      if (e.target.closest('[data-ok]')) {
        const chosen = overlay.querySelector('input[name="pdr-doc"]:checked');
        return close(chosen ? docs[Number(chosen.value)] : null);
      }
      const pv = e.target.closest('[data-preview]');
      if (pv) {
        e.preventDefault();
        const link = await createArchiveDocumentLink(docs[Number(pv.dataset.preview)].storage_path);
        if (!link.ok) { toast(link.error || 'تعذر فتح المعاينة.', 'error'); return; }
        window.open(link.url, '_blank', 'noopener');
      }
    });
  });
}

el('pdr-refresh')?.addEventListener('click', refreshSchoolDocumentRequests);
el('pdr-status')?.addEventListener('change', refreshSchoolDocumentRequests);
el('pdr-search')?.addEventListener('input', renderSchoolDocumentRequests);
el('pdr-list')?.addEventListener('click', async (event) => {
  const btn = event.target.closest('[data-pdr-action]');
  if (!btn || btn.disabled) return;
  const status = btn.dataset.pdrAction;
  const row = pdrRows.find((r) => r.id === btn.dataset.pdrId);
  let response = null, archiveId = null;
  if (status === 'REJECTED') {
    response = window.prompt('اكتب سبب رفض الطلب (إجباري):');
    if (!response || response.trim().length < 3) return;
  } else if (status === 'READY') {
    btn.disabled = true;
    const docsRes = await listSchoolArchiveDocuments({ studentId: row?.student_id, status: 'ACTIVE', limit: 50 });
    btn.disabled = false;
    if (!docsRes.ok) { toast(mapRpcError(docsRes.error), 'error'); return; }
    const docs = docsRes.data || [];
    if (!docs.length) { toast('لا توجد وثائق نشطة لهذا التلميذ في الأرشيف. ارفع الوثيقة أولاً من لوحة الأرشيف.', 'error'); return; }
    const chosen = await pickArchiveDocument(docs);
    if (!chosen) return;
    archiveId = chosen.id;
    response = window.prompt('رسالة إلى ولي الأمر (اختياري):') || null;
  } else if (status === 'APPROVED') {
    response = window.prompt('ملاحظة الموافقة (اختياري):') || null;
  } else if (status === 'DELIVERED') {
    if (!(await confirmDialog('تأكيد تسليم الوثيقة إلى ولي الأمر؟ لا يمكن التراجع بعد ذلك.'))) return;
  }
  btn.disabled = true;
  const result = await updateSchoolDocumentRequest(btn.dataset.pdrId, status, response, archiveId);
  btn.disabled = false;
  if (!result.ok) { toast(mapRpcError(result.error), 'error'); return; }
  toast('تم تحديث حالة الطلب.', 'success');
  refreshSchoolDocumentRequests();
});

let activeReportExport = null;
function closeReportModal() {
  document.getElementById('smart-report-modal')?.remove();
  document.body.style.overflow = '';
}
function openReportModal(title, headers, rows, filename, summary = [], opts = {}) {
  closeReportModal();
  const overlay = document.createElement('div');
  overlay.id = 'smart-report-modal';
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `<div class="modal-card" role="dialog" aria-modal="true" aria-label="${esc(title)}" style="width:min(1100px,96vw);max-height:92vh;overflow:auto;">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;position:sticky;top:0;background:var(--panel,#fff);z-index:2;padding:4px 0 12px;border-bottom:1px solid var(--border,#e5e7eb);">
      <div><p class="section-title" style="margin:0">${esc(title)}</p><small class="time" id="report-count">${rows.length} سجل</small></div>
      <button type="button" class="quick-action-btn secondary" data-report-close>إغلاق ✕</button>
    </div>
    <div class="panel" style="margin:12px 0;padding:12px;">
      <strong>البحث والتصفية المتقدمة</strong>
      <div class="form-grid" style="margin-top:8px;">
        <div class="full"><label>بحث بالاسم أو الرقم أو أي معلومة</label><input id="report-search" class="search-input" type="search" placeholder="اكتب اسم التلميذ أو رقم الوصل أو التصنيف..."></div>
        <div><label>من تاريخ</label><input id="report-from" class="search-input" type="date" value="${esc(el('rp-from')?.value || '')}"></div>
        <div><label>إلى تاريخ</label><input id="report-to" class="search-input" type="date" value="${esc(el('rp-to')?.value || '')}"></div>
        <div><label>القسم</label><select id="report-class" class="search-input"><option value="">كل الأقسام</option>${(cache.classes || []).map(c=>`<option value="${esc(c.class_name)}">${esc(c.class_name)}</option>`).join('')}</select></div>
        <div><label>عرض</label><select id="report-scope" class="search-input"><option value="all">جميع النتائج</option><option value="class">القسم المحدد</option><option value="person">شخص محدد</option></select></div>
      </div>
      <p class="time" style="margin:8px 0 0">يمكنك الجمع بين الفترة الزمنية والقسم والبحث باسم شخص محدد.</p>
    </div>
    <div id="report-summary" class="stats-grid" style="margin-bottom:12px"></div>
    <div id="report-table-host"></div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px;">
      <button type="button" class="quick-action-btn" id="rp-excel" style="flex:1;">📊 تصدير Excel</button>
      <button type="button" class="quick-action-btn secondary" id="rp-pdf" style="flex:1;">🖨️ طباعة / PDF</button>
      <button type="button" class="back-link" id="rp-csv" style="flex:1;">تصدير CSV</button>
    </div>
  </div>`;
  document.body.appendChild(overlay);
  document.body.style.overflow='hidden';
  const state={rows,headers,filename,title,summary,opts,filtered:rows};
  const tableHost=overlay.querySelector('#report-table-host');
  const summaryHost=overlay.querySelector('#report-summary');
  const render=()=>{
    const q=(overlay.querySelector('#report-search').value||'').trim().toLowerCase();
    const cls=overlay.querySelector('#report-class').value;
    const scope=overlay.querySelector('#report-scope').value;
    const from=overlay.querySelector('#report-from').value;
    const to=overlay.querySelector('#report-to').value;
    const candidates=opts.filterRows?opts.filterRows(state.rows,from,to):state.rows;
    state.filtered=candidates.filter((r)=>{
      const text=Array.isArray(r)?r.join(' ').toLowerCase():String(r.searchText||'').toLowerCase();
      if(q && !text.includes(q)) return false;
      if(cls && opts.classIndex!=null && String(r[opts.classIndex]||'')!==cls) return false;
      if(scope==='person' && !q) return false;
      if(from && opts.dateIndex!=null && String(r[opts.dateIndex]||'')<from) return false;
      if(to && opts.dateIndex!=null && String(r[opts.dateIndex]||'')>to) return false;
      return true;
    });
    overlay.querySelector('#report-count').textContent=`${state.filtered.length} من ${state.rows.length} سجل`;
    const liveSummary=opts.summaryBuilder?opts.summaryBuilder(state.filtered):summary;
    summaryHost.innerHTML=liveSummary.map(([label,value])=>statCard(esc(String(value)),esc(label))).join('');
    tableHost.innerHTML=state.filtered.length?`<div class="data-table-wrap"><table class="data-table"><thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${state.filtered.map((r,i)=>`<tr>${r.map((c,j)=>`<td>${opts.cellHtml?opts.cellHtml(r,j,i):esc(c??'')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`:emptyHtml('لا توجد نتائج مطابقة للفلاتر المحددة.');
  };
  ['report-search','report-class','report-scope','report-from','report-to'].forEach(id=>overlay.querySelector('#'+id).addEventListener(id==='report-search'?'input':'change',render));
  render();
  overlay.addEventListener('click',async e=>{
    if(e.target===overlay||e.target.closest('[data-report-close]')){closeReportModal();return;}
    const detail=e.target.closest('[data-att-detail]');
    if(detail){
      detail.disabled=true;
      const {data,error}=await supabase.rpc('fn_report_student_attendance_detail',{p_student_number:detail.dataset.attDetail,p_student_name:detail.dataset.attName,p_from:overlay.querySelector('#report-from').value||null,p_to:overlay.querySelector('#report-to').value||null});
      detail.disabled=false;
      if(error){toast(mapRpcError(error),'error');return;}
      const list=Array.isArray(data)?data:[];
      const inner=document.createElement('div');inner.className='modal-overlay';inner.style.zIndex='10001';
      inner.innerHTML=`<div class="modal-card" role="dialog" aria-modal="true" style="width:min(700px,94vw);max-height:80vh;overflow:auto;"><div style="display:flex;justify-content:space-between;align-items:center;"><strong>تفاصيل الغياب والتأخر — ${esc(detail.dataset.attDetail)}</strong><button class="quick-action-btn secondary" data-close-detail>إغلاق</button></div>${list.length?`<div class="data-table-wrap"><table class="data-table"><thead><tr><th>التاريخ</th><th>الوقت</th><th>الحالة</th><th>ملاحظة</th></tr></thead><tbody>${list.map(x=>`<tr><td>${esc(fmtDate(x.att_date))}</td><td>${esc(x.created_at?new Date(x.created_at).toLocaleTimeString('ar-MA',{hour:'2-digit',minute:'2-digit'}):'غير مسجل')}</td><td>${esc(attStatusAr(x.status))}</td><td>${esc(x.note||'—')}</td></tr>`).join('')}</tbody></table></div>`:emptyHtml('لا توجد تفاصيل غياب أو تأخر لهذا التلميذ في الفترة المحددة.')}</div>`;
      overlay.appendChild(inner);inner.addEventListener('click',ev=>{if(ev.target===inner||ev.target.closest('[data-close-detail]'))inner.remove();});
    }
  });
  overlay.querySelector('#rp-csv').addEventListener('click',()=>downloadCSV(filename,headers,state.filtered));
  overlay.querySelector('#rp-excel').addEventListener('click',async e=>{const b=e.currentTarget;b.disabled=true;try{await exportToExcel(filename.replace(/\.csv$/,''),{name:title.slice(0,31),headers,rows:state.filtered});}catch(err){toast(err.message||'تعذر التصدير.','error');}finally{b.disabled=false;}});
  overlay.querySelector('#rp-pdf').addEventListener('click',async()=>{const profile=await getCachedSchoolProfile();printReport({schoolName:profile.name,logoUrl:profile.logo_url,title,meta:[['تاريخ الإصدار',fmtDate(new Date())],['عدد السجلات',state.filtered.length]],headers,rows:state.filtered,summary,footerNote:'وثيقة مُولَّدة آليًا عبر نظام Smart School.'});});
  overlay.querySelector('#report-search').focus();
}
function renderReport(title, headers, rows, filename, summary = [], opts = {}) {
  openReportModal(title,headers,rows,filename,summary,opts);
}

el('rp-attendance').addEventListener('click', async () => {
  const res = await reportAttendance(el('rp-from').value, el('rp-to').value, el('rp-class').value || null);
  if (!res.ok) { toast(res.error, 'error'); return; }
  const grouped=new Map();
  (res.data||[]).forEach(r=>{const key=[r.student_name,r.student_number,r.class_name].join('|');const g=grouped.get(key)||{name:r.student_name,number:r.student_number,className:r.class_name,rows:[],present:0,absent:0,late:0,excused:0};g.rows.push(r);g[r.status]=(g[r.status]||0)+1;grouped.set(key,g);});
  const groups=[...grouped.values()].sort((a,b)=>String(a.name).localeCompare(String(b.name),'ar'));
  const toRow=g=>[g.name||'—',g.number||'—',g.className||'—',g.rows.length,g.present,g.absent,g.late,g.excused];
  const rows=groups.map(toRow);
  const totals=groups.reduce((a,g)=>{a.present+=g.present;a.absent+=g.absent;a.late+=g.late;a.excused+=g.excused;return a;},{present:0,absent:0,late:0,excused:0});
  renderReport('التقرير التفصيلي للحضور والغياب',['التلميذ','رقم التلميذ','القسم','أيام التسجيل','حاضر','غياب','تأخر','مبرر'],rows,'attendance-report.csv', [['عدد التلاميذ',groups.length],['مجموع الحضور',totals.present],['مجموع الغياب',totals.absent],['مجموع التأخر',totals.late],['الغياب المبرر',totals.excused]], {classIndex:2,filterRows:(_base,from,to)=>groups.map(g=>{const rr=g.rows.filter(x=>(!from||String(x.att_date)>=from)&&(!to||String(x.att_date)<=to));const h={...g,rows:rr,present:0,absent:0,late:0,excused:0};rr.forEach(x=>{h[x.status]=(h[x.status]||0)+1;});return toRow(h);}).filter(r=>r[3]>0),summaryBuilder:filtered=>[['عدد التلاميذ',filtered.length],['مجموع الحضور',filtered.reduce((a,r)=>a+Number(r[4]||0),0)],['مجموع الغياب',filtered.reduce((a,r)=>a+Number(r[5]||0),0)],['مجموع التأخر',filtered.reduce((a,r)=>a+Number(r[6]||0),0)],['الغياب المبرر',filtered.reduce((a,r)=>a+Number(r[7]||0),0)]],cellHtml:(row,col)=>((col===5||col===6)&&Number(row[col])>0)?`<button type="button" class="quick-action-btn secondary" data-att-detail="${esc(row[1])}" data-att-name="${esc(row[0])}">${esc(row[col])} — التفاصيل</button>`:esc(row[col]??'')});
});
async function getFilteredPaymentRows() {
  const {data,error}=await supabase.rpc('fn_report_payments',{p_from:el('rp-from').value||null,p_to:el('rp-to').value||null,p_class_id:el('rp-class').value||null});
  if(error){toast(mapRpcError(error),'error');return null;}
  return Array.isArray(data)?data:[];
}

el('rp-payments').addEventListener('click', async () => {
  const payments = await getFilteredPaymentRows();
  if (!payments) return;
  const rows = payments.map(p => [p.student_name, p.student_number, p.class_name || '—', p.fee_type, `${String(p.billing_month||'').padStart(2,'0')}/${p.billing_year||''}`, Number(p.amount_due || 0), Number(p.amount_paid || 0), Number(p.remaining || 0), String(p.payment_date||'').slice(0,10), p.method || '', p.receipt_no || '']);
  const due = payments.reduce((a,p)=>a+Number(p.amount_due||0),0);
  const paid = payments.reduce((a,p)=>a+Number(p.amount_paid||0),0);
  renderReport('Journal des paiements — سجل الأداءات', ['التلميذ','رقم التلميذ','القسم','نوع الرسوم','الشهر المستخلص','المستحق','المؤدى','المتبقي','تاريخ الأداء الفعلي','الطريقة','رقم الوصل'], rows, 'payments-journal.csv', [['عدد السجلات',payments.length],['إجمالي المستحق',fmtMoney(due)],['إجمالي المؤدى',fmtMoney(paid)],['إجمالي المتبقي',fmtMoney(Math.max(0,due-paid))]], {classIndex:2,dateIndex:8,cellHtml:(row,col)=>col===8?esc(fmtDate(row[col])):esc(row[col]??''),summaryBuilder:filtered=>[['عدد السجلات',filtered.length],['إجمالي المستحق',fmtMoney(filtered.reduce((a,r)=>a+Number(r[5]||0),0))],['إجمالي المحصل',fmtMoney(filtered.reduce((a,r)=>a+Number(r[6]||0),0))],['إجمالي المتبقي',fmtMoney(filtered.reduce((a,r)=>a+Number(r[7]||0),0))]]});
});

el('rp-unpaid').addEventListener('click', async () => {
  const payments = await getFilteredPaymentRows();
  if (!payments) return;
  const unpaid = payments.filter(p => Number(p.amount_due || 0) > Number(p.amount_paid || 0));
  const rows = unpaid.map(p => [p.student_name,p.student_number,p.class_name||'—',p.fee_type,`${String(p.billing_month||'').padStart(2,'0')}/${p.billing_year||''}`,Number(p.amount_due||0),Number(p.amount_paid||0),Number(p.remaining||0),String(p.payment_date||'').slice(0,10),p.method||'']);
  const balance = unpaid.reduce((a,p)=>a+Math.max(0,Number(p.amount_due||0)-Number(p.amount_paid||0)),0);
  renderReport('Liste des impayés — لائحة المستحقات غير المؤداة', ['التلميذ','رقم التلميذ','القسم','نوع الرسوم','الشهر','المستحق','المؤدى','المتبقي','تاريخ الأداء','طريقة الأداء'], rows, 'unpaid-list.csv', [['عدد الملفات غير المسواة',unpaid.length],['إجمالي المتأخرات',fmtMoney(balance)]], {classIndex:2,dateIndex:8,cellHtml:(row,col)=>col===8?esc(fmtDate(row[col])):esc(row[col]??''),summaryBuilder:filtered=>[['عدد الملفات غير المسواة',filtered.length],['إجمالي المتأخرات',fmtMoney(filtered.reduce((a,r)=>a+Number(r[7]||0),0))]]});
});

el('rp-discounts').addEventListener('click', async () => {
  const { data, error } = await reportStudentFeeDiscounts({
    from: el('rp-from').value || null, to: el('rp-to').value || null,
    classId: el('rp-class').value || null,
  });
  if (error) { toast(mapRpcError(error), 'error'); return; }
  const discounts = Array.isArray(data) ? data : [];
  const rows = discounts.map(d => [d.student_name, d.student_number, d.class_name || '—', d.fee_type,
    d.discount_kind === 'percent' ? `${Number(d.discount_value).toFixed(2)}%` : `${fmtMoney(d.discount_value)} (مبلغ ثابت)`,
    Number(d.list_price || 0), Number(d.discount_amount || 0), `${Number(d.discount_percent || 0).toFixed(2)}%`,
    Number(d.final_amount || 0), d.reason || '', d.status_label || '—',
    String(d.effective_from || '').slice(0,10), d.effective_to ? String(d.effective_to).slice(0,10) : 'مفتوح']);
  const totalOriginal = discounts.reduce((a,d)=>a+Number(d.list_price||0),0);
  const totalDiscount = discounts.reduce((a,d)=>a+Number(d.discount_amount||0),0);
  const beneficiaries = new Set(discounts.map(d=>d.student_id)).size;
  renderReport('تقرير المستفيدين من الخصومات',
    ['التلميذ','رقم التلميذ','القسم','نوع الرسم','صيغة الخصم','السعر الأصلي','قيمة الخصم','نسبة الخصم الفعلية','الصافي بعد الخصم','سبب الخصم','الحالة','بداية الخصم','نهاية الخصم'],
    rows, 'student-fee-discounts.csv',
    [['عدد المستفيدين',beneficiaries],['عدد قرارات الخصم',discounts.length],['مجموع الأسعار الأصلية',fmtMoney(totalOriginal)],
     ['إجمالي قيمة الخصومات',fmtMoney(totalDiscount)],['متوسط نسبة الخصم',totalOriginal>0?`${(totalDiscount/totalOriginal*100).toFixed(2)}%`:'—'],
     ['الصافي بعد الخصومات',fmtMoney(Math.max(0,totalOriginal-totalDiscount))]],
    {classIndex:2,dateIndex:11,summaryBuilder:filtered=>{
      const original=filtered.reduce((a,r)=>a+Number(r[5]||0),0), discount=filtered.reduce((a,r)=>a+Number(r[6]||0),0);
      return [['عدد المستفيدين',new Set(filtered.map(r=>r[1])).size],['عدد قرارات الخصم',filtered.length],
        ['السعر الأصلي',fmtMoney(original)],['قيمة الخصومات',fmtMoney(discount)],
        ['متوسط نسبة الخصم',original>0?`${(discount/original*100).toFixed(2)}%`:'—'],['الصافي',fmtMoney(Math.max(0,original-discount))]];
    }});
});

el('rp-payment-summary').addEventListener('click', async () => {
  const payments = await getFilteredPaymentRows();
  if (!payments) return;
  const groups = new Map();
  payments.forEach(p => {
    const className=p.class_name||'بدون قسم'; const type=p.fee_type||'غير محدد';
    const key = `${className}::${type}`;
    const g = groups.get(key) || { className,type,count:0,due:0,paid:0 };
    g.count++; g.due += Number(p.amount_due||0); g.paid += Number(p.amount_paid||0); groups.set(key,g);
  });
  const rows = [...groups.values()].sort((a,b)=>a.className.localeCompare(b.className,'ar')).map(g=>[g.className,g.type,g.count,g.due,g.paid,Math.max(0,g.due-g.paid)]);
  const due = payments.reduce((a,p)=>a+Number(p.amount_due||0),0);
  const paid = payments.reduce((a,p)=>a+Number(p.amount_paid||0),0);
  renderReport('Synthèse des paiements — ملخص الأداءات', ['القسم','نوع الرسوم','عدد السجلات','المستحق','المؤدى','المتبقي'], rows, 'payments-summary.csv', [['إجمالي المستحق',fmtMoney(due)],['إجمالي المحصل',fmtMoney(paid)],['نسبة التحصيل',due>0?`${(paid/due*100).toFixed(1)}%`:'—']], {classIndex:0,summaryBuilder:filtered=>{const d=filtered.reduce((a,r)=>a+Number(r[3]||0),0),p=filtered.reduce((a,r)=>a+Number(r[4]||0),0);return [['إجمالي المستحق',fmtMoney(d)],['إجمالي المحصل',fmtMoney(p)],['نسبة التحصيل',d>0?`${(p/d*100).toFixed(1)}%`:'—']];}});
});
el('rp-fee-obligations').addEventListener('click', async () => {
  const res = await reportFeeObligations({ classId: el('rp-class').value || null, from: el('rp-from').value || null, to: el('rp-to').value || null });
  if (!res.ok) { toast(mapRpcError(res.error), 'error'); return; }
  const items = Array.isArray(res.data) ? res.data : [];
  const rows = items.map(x => [x.student_name,x.student_number,x.class_name||'—',x.fee_type,x.period_key,Number(x.list_amount||0),Number(x.discount_amount||0),Number(x.amount_due||0),Number(x.amount_paid||0),Number(x.remaining||0),x.status==='paid'?'مؤدى':x.status==='partial'?'جزئي':x.status==='waived'?'معفى':'غير مؤدى',x.uses_transport?'نعم':'لا']);
  const sum=(i)=>items.reduce((a,x)=>a+Number(x[i]||0),0);
  renderReport('تقرير المستحقات والخصومات والأداءات',['التلميذ','رقم التلميذ','القسم','نوع الرسم','الفترة','قبل الخصم','قيمة الخصم','المستحق بعد الخصم','المؤدى','المتبقي','الحالة','يستفيد من النقل'],rows,'fee-obligations.csv',
   [['عدد المستحقات',items.length],['المبالغ قبل الخصم',fmtMoney(sum('list_amount'))],['إجمالي الخصومات',fmtMoney(sum('discount_amount'))],['صافي المستحقات',fmtMoney(sum('amount_due'))],['إجمالي المؤدى',fmtMoney(sum('amount_paid'))],['إجمالي المتبقي',fmtMoney(sum('remaining'))],['عدد المستفيدين من النقل',new Set(items.filter(x=>x.uses_transport).map(x=>x.student_id)).size]],
   {classIndex:2,summaryBuilder:filtered=>[['عدد السجلات',filtered.length],['قبل الخصم',fmtMoney(filtered.reduce((a,r)=>a+Number(r[5]||0),0))],['الخصومات',fmtMoney(filtered.reduce((a,r)=>a+Number(r[6]||0),0))],['المتبقي',fmtMoney(filtered.reduce((a,r)=>a+Number(r[9]||0),0))]]});
});

el('rp-expenses').addEventListener('click', async () => {
  const res = await listExpenses(500);
  if (!res.ok) { toast(res.error, 'error'); return; }
  renderReport('تقرير المصاريف', ['التصنيف', 'المبلغ', 'التاريخ', 'الوصف', 'الموظف'],
    (res.data || []).map((x) => [x.category, x.amount, String(x.expense_date||'').slice(0,10), x.description || '', x.recorder_name || '']),
    'expenses-report.csv', [], {dateIndex:2,cellHtml:(row,col)=>col===2?esc(fmtDate(row[col])):esc(row[col]??'')});
});
el('rp-incidents').addEventListener('click', async () => {
  const res = await listIncidents(null, 500, 0);
  if (!res.ok) { toast(res.error, 'error'); return; }
  renderReport('تقرير المخالفات', ['التلميذ', 'النوع', 'العنوان', 'التاريخ', 'الحالة', 'الإجراء'],
    (res.data || []).map((i) => [i.student_name, i.type, i.title, String(i.occurred_at||'').slice(0,10), i.status === 'open' ? 'مفتوحة' : 'مغلقة', i.action_taken || '']),
    'incidents-report.csv', [], {dateIndex:3,cellHtml:(row,col)=>col===3?esc(fmtDate(row[col])):esc(row[col]??'')});
});
el('rp-students').addEventListener('click', async () => {
  const rows = await filterStudents({ limit: 500 });
  renderReport('تقرير التلاميذ', ['الاسم', 'الرقم', 'القسم', 'الحالة'],
    rows.map((r) => [r.student?.fullName || '', r.student?.studentNumber || '', r.student?.className || '', r.resultType === 'AUTHORIZED' ? 'نشط' : 'غير نشط']),
    'students-report.csv', [], {classIndex:2});
});

// ===== NOTIFICATIONS =====
async function loadNotificationsView() {
  const panel = el('my-notifs-panel');
  panel.innerHTML = loadingHtml();
  const res = await listMyNotifications(50);
  if (!res.ok) { panel.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  const typeLabels = { announcement:'إعلان', incident:'بلاغ', attendance:'حضور', grade:'نقطة', transport:'نقل', schedule:'جدول', system:'نظام' };
  panel.innerHTML = rows.length
    ? rows.map((n) => `
      <div class="notif-swipe-wrap">
        <div class="notif-delete-zone">🗑 حذف</div>
        <div class="notif-card" data-notif="${n.notification_id || n.id}" style="${n.is_read ? 'opacity:.65;' : ''}">
          <div class="notif-head"><strong>${esc(n.title)}</strong> <span class="badge badge-blue">${esc(typeLabels[n.type] || n.type || 'إشعار')}</span></div>
          <div class="time">${fmtDateTime(n.created_at)}</div>
          ${n.body ? `<div class="notif-body">${esc(n.body)}</div>` : ''}
          ${n.image_url ? `<img src="${esc(n.image_url)}" alt="">` : ''}
        </div>
      </div>`).join('')
    : emptyHtml('لا توجد إشعارات.');

  panel.querySelectorAll('.notif-card').forEach((card) => {
    card.addEventListener('click', async (e) => {
      if (card.dataset.swiping === '1') return; // تجاهل النقر أثناء/بعد السحب مباشرة
      await markNotificationRead(card.dataset.notif);
      card.style.opacity = '.65';
      openNotificationDetails(rows.find((n) => (n.notification_id || n.id) === card.dataset.notif));
      refreshNotifCount();
    });

    // سحب بسيط للحذف (يمين→يسار على الهاتف)
    let startX = 0, dx = 0, dragging = false;
    card.addEventListener('touchstart', (e) => { startX = e.touches[0].clientX; dragging = true; card.style.transition = 'none'; }, { passive: true });
    card.addEventListener('touchmove', (e) => {
      if (!dragging) return;
      dx = e.touches[0].clientX - startX;
      if (dx < 0) card.style.transform = `translateX(${dx}px)`;
    }, { passive: true });
    card.addEventListener('touchend', async () => {
      dragging = false;
      card.style.transition = 'transform .2s';
      if (dx < -90) {
        card.dataset.swiping = '1';
        card.style.transform = 'translateX(-100%)';
        const res2 = await deleteMyNotification(card.dataset.notif);
        if (res2.ok) {
          setTimeout(() => { card.closest('.notif-swipe-wrap')?.remove(); refreshNotifCount(); }, 180);
        } else {
          toast(res2.error, 'error');
          card.style.transform = 'translateX(0)';
          setTimeout(() => { card.dataset.swiping = '0'; }, 200);
        }
      } else {
        card.style.transform = 'translateX(0)';
      }
      dx = 0;
    });
  });
}

// ===== إشعار شخصي لشخص محدد (Phase 76) =====
// يجمع الموظفين (listSchoolStaff) وأولياء الأمور (listParents) في قائمة واحدة
// قابلة للبحث؛ الإرسال يستعمل p_target_profile_id الموجود أصلًا في
// fn_send_notification (أولياء الأمور لهم صفوف user_roles، فيصلهم الإشعار).
let notifPeopleCache = null;
async function loadNotifPeople() {
  if (notifPeopleCache) return notifPeopleCache;
  const sel = el('nt-person');
  sel.innerHTML = '<option value="">جارٍ تحميل الأشخاص...</option>';
  const [staffRes, parents] = await Promise.all([listSchoolStaff(schoolId), listParents('')]);
  const roleAr = { admin: 'مدير المؤسسة', director: 'مدير', teacher: 'أستاذ', guard: 'حارس', driver: 'سائق', parent: 'ولي أمر' };
  const people = [];
  if (staffRes.ok) {
    for (const s of staffRes.data || []) {
      people.push({ id: s.profile_id, name: s.full_name || '—', phone: s.phone || '', role: roleAr[s.role] || s.role });
    }
  }
  // listParents (accounts.js) يرجع مصفوفة مباشرة بحقول profiles المتداخلة
  for (const p of parents || []) {
    people.push({
      id: p.profile_id,
      name: p.profiles?.full_name || '—',
      phone: p.profiles?.phone || '',
      role: 'ولي أمر',
    });
  }
  // استبعاد المدير نفسه ومن ليس لهم حساب دخول (بدون profile_id)
  notifPeopleCache = people.filter((p) => p.id && p.id !== ctx.profile.id);
  renderNotifPeople('');
  return notifPeopleCache;
}
function renderNotifPeople(query) {
  const q = (query || '').trim().toLowerCase();
  const sel = el('nt-person');
  const list = (notifPeopleCache || []).filter((p) =>
    !q || (p.name || '').toLowerCase().includes(q) || (p.phone || '').includes(q));
  if (!list.length) {
    sel.innerHTML = '<option value="">لا نتائج مطابقة.</option>';
    return;
  }
  sel.innerHTML = list.map((p) =>
    `<option value="${p.id}">${esc(p.role)} — ${esc(p.name)}${p.phone ? ' (' + esc(p.phone) + ')' : ''}</option>`).join('');
}
el('nt-target').addEventListener('change', async (e) => {
  const isPerson = e.target.value === '__person__';
  el('nt-person-box').hidden = !isPerson;
  if (isPerson) await loadNotifPeople();
});
el('nt-person-search').addEventListener('input', (e) => renderNotifPeople(e.target.value));

el('send-notif-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = el('send-notif-error');
  errEl.hidden = true;
  const submitBtn = e.target.querySelector('button[type="submit"]');

  // تحقق من اختيار الشخص عند الإرسال الشخصي
  const isPerson = el('nt-target').value === '__person__';
  let targetProfileId = null;
  if (isPerson) {
    targetProfileId = el('nt-person').value || null;
    if (!targetProfileId) {
      errEl.hidden = false;
      errEl.textContent = 'اختر الشخص المستهدف من القائمة أولًا.';
      return;
    }
  }

  let imageUrl = null;
  const file = el('nt-image').files[0];
  if (file) {
    submitBtn.disabled = true; submitBtn.textContent = 'جارٍ رفع الصورة...';
    const up = await uploadNotificationImage(schoolId, file);
    submitBtn.disabled = false; submitBtn.textContent = 'إرسال';
    if (!up.ok) { errEl.hidden = false; errEl.textContent = 'تعذر رفع الصورة: ' + up.error; return; }
    imageUrl = up.data;
  }

  const res = await sendNotification({
    title: el('nt-title').value, body: el('nt-body').value,
    type: el('nt-type').value,
    targetRole: isPerson ? null : (el('nt-target').value || null),
    targetProfileId,
    imageUrl,
  });
  if (!res.ok) { errEl.hidden = false; errEl.textContent = res.error; return; }
  toast(isPerson ? 'تم إرسال الرسالة الشخصية.' : 'تم إرسال الإشعار.', 'success');
  e.target.reset();
  el('nt-person-box').hidden = true;
  loadNotificationsView();
});

// ===== SCHOOL WEBSITE (Phase 77): موقع المؤسسة العام ========================
// الرابط يُولَّد تلقائيًا من school_id: school.html?id=<uuid>
// الاسم/الشعار/التواصل مربوطة ببيانات المؤسسة (صفحة «المؤسسة») — لا تكرار للإدخال.
// ===== BACKUP (Phase 81) =====
function loadBackupView() { /* الأحداث مربوطة مرة واحدة أدناه */ }
let backupResetTicket = null;
let backupResetPreview = null;
const backupResetAck = el('backup-reset-ack');
const backupResetBtn = el('backup-reset');
const backupPreviewBtn = el('backup-reset-preview');
const backupDownloadBtn = el('backup-download');
const backupPreviewStatus = el('backup-reset-preview-status');

if (backupResetAck) backupResetAck.addEventListener('change', () => {
  // Destructive reset stays disabled until Phase 106 completes dependent-FK cleanup.
  if (backupResetBtn) backupResetBtn.disabled = true;
});

backupPreviewBtn?.addEventListener('click', async () => {
  backupPreviewBtn.disabled = true;
  backupPreviewStatus.textContent = '⏳ جارٍ فحص بيانات المؤسسة المرتبطة بحسابك...';
  backupResetTicket = null;
  backupResetPreview = null;
  if (backupResetAck) { backupResetAck.checked = false; backupResetAck.disabled = true; }
  if (backupResetBtn) backupResetBtn.disabled = true;
  if (backupDownloadBtn) backupDownloadBtn.disabled = true;
  try {
    const res = await previewSchoolReset();
    if (!res.ok || !res.data) {
      backupPreviewStatus.textContent = '❌ تعذرت المعاينة: ' + (res.error || 'خطأ غير معروف');
      return;
    }
    backupResetPreview = res.data;
    const counts = res.data.counts_by_table || {};
    const rows = Object.entries(counts).map(([name, count]) =>
      `<div style="display:flex;justify-content:space-between;gap:10px;border-bottom:1px solid var(--border,#e5e7eb);padding:5px 0;"><span>${esc(name)}</span><strong>${Number(count).toLocaleString('ar-MA')}</strong></div>`
    ).join('');
    backupPreviewStatus.innerHTML = `<div class="panel" style="margin-top:8px;"><strong>✅ تمت المعاينة — المؤسسة المرتبطة بحسابك</strong><div class="time" style="margin:6px 0;">إجمالي السجلات المباشرة: <strong>${Number(res.data.total_direct_records || 0).toLocaleString('ar-MA')}</strong></div>${rows || '<div class="time">لا توجد سجلات مباشرة في الجداول المشمولة.</div>'}<p class="time" style="margin-top:8px;color:#92400e;">${esc(res.data.warning || 'المعاينة لا تشمل بعد كل الجداول التابعة التي لا تحتوي على school_id.')}</p></div>`;
    if (backupDownloadBtn) backupDownloadBtn.disabled = false;
  } catch (error) {
    backupPreviewStatus.textContent = '❌ ' + (error?.message || 'تعذرت المعاينة');
  } finally {
    backupPreviewBtn.disabled = false;
  }
});

el('backup-download').addEventListener('click', async () => {
  const btn = el('backup-download');
  const status = el('backup-download-status');
  if (!backupResetPreview) {
    status.textContent = 'يجب إجراء معاينة البيانات أولاً.';
    return;
  }
  btn.disabled = true;
  status.textContent = '⏳ جارٍ تجهيز النسخة الاحتياطية...';
  const res = await exportSchoolBackup();
  btn.disabled = false;
  if (!res.ok || !res.data) {
    status.textContent = '❌ ' + res.error + (String(res.error).includes('fn_export_school_backup') ? ' — نفّذ Migration النسخ الاحتياطي أولاً.' : '');
    return;
  }
  backupResetTicket = res.data._reset_ticket || null;
  if (backupResetAck) { backupResetAck.checked = false; backupResetAck.disabled = !backupResetTicket; }
  if (backupResetBtn) backupResetBtn.disabled = true;
  const backupPayload = { ...res.data };
  delete backupPayload._reset_ticket;
  const blob = new Blob([JSON.stringify(backupPayload, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  const stamp = new Date().toISOString().slice(0, 10);
  a.href = URL.createObjectURL(blob);
  a.download = `نسخة-احتياطية-${stamp}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  const tables = res.data.tables || {};
  const total = Object.values(tables).reduce((sum, rows) => sum + (Array.isArray(rows) ? rows.length : 0), 0);
  status.textContent = `✅ تم تجهيز وتنزيل النسخة — ${total} سجل في ${Object.keys(tables).length} جدول. أكد حفظ الملف لتفعيل التصفير.`;
});

backupResetBtn?.addEventListener('click', () => {
  const status = el('backup-reset-status');
  status.textContent = 'التصفير النهائي متوقف مؤقتاً لحماية البيانات إلى حين استكمال فحص وحذف جميع السجلات التابعة التي لا تحتوي على school_id (Phase 106). يمكنك حالياً معاينة البيانات وتنزيل النسخة الاحتياطية.';
});

el('backup-restore').addEventListener('click', async () => {
  const file = el('backup-file').files?.[0];
  const status = el('backup-restore-status');
  if (!file) { toast('اختر ملف النسخة الاحتياطية أولًا.', 'error'); return; }
  let data;
  try {
    data = JSON.parse(await file.text());
  } catch {
    status.innerHTML = '<span style="color:#b91c1c;">❌ الملف ليس ملف JSON صالحًا.</span>';
    return;
  }
  if (data?.app !== 'smart-school') {
    status.innerHTML = '<span style="color:#b91c1c;">❌ هذا الملف ليس نسخة احتياطية صادرة عن المنصة.</span>';
    return;
  }
  const ok = await confirmDialog('سيتم إدراج السجلات الناقصة فقط — البيانات الحالية لن تتغير. متابعة الاسترجاع؟');
  if (!ok) return;
  const btn = el('backup-restore');
  btn.disabled = true;
  status.innerHTML = '⏳ جارٍ الاسترجاع…';
  const res = await importSchoolBackup(data, schoolId);
  btn.disabled = false;
  if (!res.ok || !res.data) {
    status.innerHTML = '<span style="color:#b91c1c;">❌ ' + esc(res.error || 'فشل الاسترجاع') + (String(res.error).includes('fn_import_school_backup_safe') ? ' — نفّذ phase84_secure_backup_migration.sql أولًا.' : '') + '</span>';
    return;
  }
  const results = res.data.results || {};
  const rows = Object.entries(results)
    .map(([t, v]) => `<div style="display:flex;justify-content:space-between;gap:8px;"><span>${esc(t)}</span><strong>${typeof v === 'number' ? v + ' سجل جديد' : esc(String(v))}</span></div>`)
    .join('');
  status.innerHTML = `<div class="panel" style="margin-top:6px;border:1px solid #bbf7d0;"><strong style="color:#166534;">✅ تم الاسترجاع</strong>${rows || '<div class="time">لا جديد.</div>'}</div>`;
  toast('تم استرجاع النسخة الاحتياطية.', 'success');
});

async function loadWebsiteView() {
  const link = new URL('school.html', location.href).href + '?id=' + schoolId;
  el('site-link').value = link;

  // نبذة المؤسسة وروابط التواصل الحالية
  const prof = await getSchoolProfile(schoolId);
  if (prof.ok && prof.data) {
    const s = prof.data;
    el('site-description').value = s.description || '';
    el('site-tagline').value = s.tagline || '';
    el('site-facebook').value = s.facebook_url || '';
    el('site-instagram').value = s.instagram_url || '';
    el('site-tiktok').value = s.tiktok_url || '';
    el('site-youtube').value = s.youtube_url || '';
    el('site-whatsapp').value = s.whatsapp_number || '';
    // كشف قاعدة بيانات قديمة (الحقول غير موجودة أصلًا في الاستجابة)
    if (!('facebook_url' in s)) {
      toast('⚠️ قاعدة البيانات تحتاج تحديثًا — نفّذ phase79_school_site_fixes.sql في Supabase حتى تُحفظ روابط التواصل.', 'error');
    }
  }

  await loadSchoolPosts();
}

el('site-copy').addEventListener('click', async () => {
  const input = el('site-link');
  try {
    await navigator.clipboard.writeText(input.value);
    toast('تم نسخ رابط الموقع.', 'success');
  } catch {
    input.select();
    document.execCommand('copy');
    toast('تم نسخ رابط الموقع.', 'success');
  }
});
el('site-open').addEventListener('click', () => window.open(el('site-link').value, '_blank', 'noopener'));

el('site-desc-save').addEventListener('click', async () => {
  const btn = el('site-desc-save');
  btn.disabled = true;
  const payload = {
    description: el('site-description').value,
    tagline: el('site-tagline').value,
  };
  const res = await updateSchool(schoolId, payload);
  btn.disabled = false;
  if (!res.ok) {
    toast(res.error + (String(res.error).includes('tagline') ? ' — نفّذ phase79_school_site_fixes.sql أولًا.' : ''), 'error');
    return;
  }
  // تحقّق فعلي من الحفظ (الدالة القديمة تتجاهل tagline بصمت)
  const check = await getSchoolProfile(schoolId);
  const saved = check.ok && check.data && 'tagline' in check.data
    && String(check.data.tagline || '') === payload.tagline.trim();
  if (!saved) {
    toast('⚠️ الحقول لم تُحفظ في قاعدة البيانات — نفّذ ملف phase79_school_site_fixes.sql في Supabase ثم أعد المحاولة.', 'error');
    return;
  }
  toast('تم الحفظ — ستظهر في موقع المؤسسة.', 'success');
});

el('site-social-save').addEventListener('click', async () => {
  const btn = el('site-social-save');
  btn.disabled = true;
  const payload = {
    facebook_url: el('site-facebook').value,
    instagram_url: el('site-instagram').value,
    tiktok_url: el('site-tiktok').value,
    youtube_url: el('site-youtube').value,
    whatsapp_number: el('site-whatsapp').value,
  };
  const res = await updateSchool(schoolId, payload);
  btn.disabled = false;
  if (!res.ok) {
    toast(res.error + (String(res.error).includes('facebook') ? ' — نفّذ phase79_school_site_fixes.sql أولًا.' : ''), 'error');
    return;
  }
  // تحقّق فعلي من الحفظ — الدالة القديمة تتجاهل الحقول بصمت وتُرجع نجاحًا زائفًا
  const check = await getSchoolProfile(schoolId);
  const saved = check.ok && check.data && 'facebook_url' in check.data
    && String(check.data.facebook_url || '') === payload.facebook_url.trim();
  if (!saved) {
    toast('⚠️ الحقول لم تُحفظ في قاعدة البيانات — نفّذ ملف phase79_school_site_fixes.sql في Supabase ثم أعد المحاولة.', 'error');
    return;
  }
  toast('تم حفظ روابط التواصل الاجتماعي.', 'success');
});

async function loadSchoolPosts() {
  const host = el('posts-list');
  host.innerHTML = loadingHtml();
  const res = await listSchoolPosts(schoolId);
  if (!res.ok) {
    host.innerHTML = errorHtml(res.error + (String(res.error).includes('fn_list_school_posts') ? ' — نفّذ phase77_school_website.sql أولًا.' : ''));
    return;
  }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد منشورات بعد — أنشر أول إعلان من النموذج أعلاه.'); return; }
  host.innerHTML = rows.map((p) => `
    <div class="panel" style="margin-bottom:10px;">
      <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:8px; flex-wrap:wrap;">
        <div style="flex:1; min-width:180px;">
          <strong>${p.kind === 'announcement' ? '📢' : '📝'} ${esc(p.title)}</strong>
          ${p.is_published ? '' : ' <span class="time" style="color:#b45309;">(مخفي عن الموقع)</span>'}
          ${p.body ? `<div class="time" style="margin-top:4px;">${esc(p.body.slice(0, 120))}${p.body.length > 120 ? '…' : ''}</div>` : ''}
          ${p.image_url ? `<div class="time">🖼️ يتضمن صورة</div>` : ''}
          <div class="time">${fmtDateTime(p.published_at)}</div>
        </div>
        <div style="display:flex; gap:6px; flex-wrap:wrap;">
          <button type="button" class="quick-action-btn secondary" data-post-edit="${p.id}">✏️ تعديل</button>
          <button type="button" class="quick-action-btn secondary" data-post-toggle="${p.id}" data-pub="${p.is_published ? 1 : 0}">${p.is_published ? '🙈 إخفاء' : '👁️ نشر'}</button>
          <button type="button" class="quick-action-btn secondary" data-post-del="${p.id}" style="color:#dc2626;">🗑️ حذف</button>
        </div>
      </div>
    </div>`).join('');
  host.querySelectorAll('[data-post-edit]').forEach((b) => b.addEventListener('click', () => {
    const p = rows.find((x) => x.id === b.dataset.postEdit);
    if (!p) return;
    el('post-id').value = p.id;
    el('post-title').value = p.title || '';
    el('post-body').value = p.body || '';
    el('post-kind').value = p.kind || 'post';
    el('post-published').checked = !!p.is_published;
    el('post-submit').textContent = 'حفظ التعديلات';
    el('post-cancel').hidden = false;
    el('post-form').scrollIntoView({ behavior: 'smooth' });
  }));
  host.querySelectorAll('[data-post-toggle]').forEach((b) => b.addEventListener('click', async () => {
    const p = rows.find((x) => x.id === b.dataset.postToggle);
    if (!p) return;
    const res = await saveSchoolPost({ id: p.id, title: p.title, body: p.body, imageUrl: p.image_url, kind: p.kind, isPublished: !p.is_published });
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast(p.is_published ? 'تم إخفاء المنشور عن الموقع.' : 'تم نشر المنشور.', 'success');
    loadSchoolPosts();
  }));
  host.querySelectorAll('[data-post-del]').forEach((b) => b.addEventListener('click', async () => {
    if (!confirm('حذف هذا المنشور نهائيًا من الموقع؟')) return;
    const res = await deleteSchoolPost(b.dataset.postDel);
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast('تم حذف المنشور.', 'success');
    loadSchoolPosts();
  }));
}

el('post-cancel').addEventListener('click', () => {
  el('post-form').reset();
  el('post-id').value = '';
  el('post-submit').textContent = 'نشر';
  el('post-cancel').hidden = true;
});

el('post-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = el('post-error');
  errEl.hidden = true;
  const btn = el('post-submit');
  const editingId = el('post-id').value || null;

  btn.disabled = true; btn.textContent = 'جارٍ الحفظ...';
  try {
    let imageUrl = null;
    const file = el('post-image').files[0];
    if (file) {
      const up = await uploadNotificationImage(schoolId, file);
      if (!up.ok) { errEl.hidden = false; errEl.textContent = 'تعذر رفع الصورة: ' + up.error; return; }
      imageUrl = up.data;
    } else if (editingId) {
      // إبقاء الصورة القديمة عند التعديل دون اختيار صورة جديدة
      const cur = (await listSchoolPosts(schoolId)).data?.find((x) => x.id === editingId);
      imageUrl = cur?.image_url || null;
    }
    const res = await saveSchoolPost({
      id: editingId,
      title: el('post-title').value,
      body: el('post-body').value,
      imageUrl,
      kind: el('post-kind').value,
      isPublished: el('post-published').checked,
    });
    if (!res.ok) {
      errEl.hidden = false;
      errEl.textContent = res.error + (String(res.error).includes('fn_save_school_post') ? ' — نفّذ phase77_school_website.sql أولًا.' : '');
      return;
    }
    toast(editingId ? 'تم حفظ التعديلات.' : 'تم نشر المنشور على موقع المؤسسة.', 'success');
    e.target.reset();
    el('post-id').value = '';
    el('post-submit').textContent = 'نشر';
    el('post-cancel').hidden = true;
    loadSchoolPosts();
  } finally {
    btn.disabled = false;
    btn.textContent = el('post-id').value ? 'حفظ التعديلات' : 'نشر';
  }
});

// ===== AUDIT =====
async function loadAuditView() {
  const panel = el('audit-panel');
  panel.innerHTML = loadingHtml();
  const res = await schoolAudit(PAGE_SIZE, auditOffset);
  if (!res.ok) { panel.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  panel.innerHTML = rows.length
    ? `<div class="audit-list">${rows.map((r) => `<div class="audit-row">
        <div class="audit-main">
          <div class="audit-action">${esc(r.action || '—')}</div>
          <div class="audit-entity">${esc(r.entity || '—')}</div>
        </div>
        <div class="audit-meta">
          <span class="audit-actor">👤 ${esc(r.actor_name || 'غير معروف')}</span>
          <span class="audit-date">🕒 ${esc(fmtDateTime(r.created_at))}</span>
        </div>
      </div>`).join('')}</div>`
    : emptyHtml('لا توجد سجلات.');
  el('audit-page-info').textContent = 'الصفحة ' + (Math.floor(auditOffset / PAGE_SIZE) + 1);
  el('audit-prev').disabled = auditOffset === 0;
  el('audit-next').disabled = rows.length < PAGE_SIZE;
}
el('audit-prev').addEventListener('click', () => { auditOffset = Math.max(0, auditOffset - PAGE_SIZE); loadAuditView(); });
el('audit-next').addEventListener('click', () => { auditOffset += PAGE_SIZE; loadAuditView(); });

// ===== TEACHER ACADEMIC ASSIGNMENTS (PHASE 14) =====
// Director/admin links a teacher to subjects and classes. The server
// re-verifies school membership and same-school subject/class on every call.
let assignTeacherId = null;
let currentTeacherId = null;
let currentTeacherName = '';

async function openTeacherAssign(teacherId, name) {
  assignTeacherId = teacherId;
  el('ta-title').textContent = 'الربط الأكاديمي — ' + (name || '');
  showView('teacher-assign');
  await Promise.all([renderAssignSubjects(), renderAssignClasses()]);
}
el('ta-back').addEventListener('click', () => showView('teacher-detail'));

// ===== TEACHER PROFILE (Phase 19) =====
async function openTeacherDetail(teacherId) {
  currentTeacherId = teacherId;
  showView('teacher-detail');
  const infoHost = el('td-info');
  infoHost.innerHTML = loadingHtml();
  const res = await getTeacherFull(teacherId);
  if (!res.ok || !res.data) { infoHost.innerHTML = emptyHtml(res.error || 'تعذر تحميل ملف الأستاذ.'); return; }
  const t = res.data;
  currentTeacherName = t.full_name || '';
  const row = (k, v) => `<div class="detail-row"><span class="k">${k}</span><span class="v">${esc(v ?? '—')}</span></div>`;
  infoHost.innerHTML = `
    ${row('الاسم', t.full_name)}${row('الهاتف', t.phone)}${row('رقم الحساب', t.user_number)}
    ${row('رقم الموظف', t.employee_number)}${row('المؤسسة', t.school_name)}${row('السنة الدراسية الحالية', t.current_year_label)}
    ${row('الحالة', t.is_active ? 'نشط' : 'معطل')}`;

  el('td-subjects-classes-summary').innerHTML =
    `<div class="detail-row"><span class="k">عدد المواد</span><span class="v">${t.subjects_count ?? 0}</span></div>
     <div class="detail-row"><span class="k">عدد الأقسام</span><span class="v">${t.classes_count ?? 0}</span></div>`;

  el('td-rate').value = t.hourly_rate ?? '';
  el('td-month').value = new Date().toISOString().slice(0, 7);

  await renderTeacherSchedule(teacherId);
  await renderTeacherPayroll(teacherId);
}

el('td-open-assign').addEventListener('click', () => {
  if (!currentTeacherId) return;
  openTeacherAssign(currentTeacherId, currentTeacherName);
});

async function renderTeacherSchedule(teacherId) {
  const host = el('td-schedule');
  host.innerHTML = loadingHtml();
  const [scheduleRes, classRes, subjectRes] = await Promise.all([
    getTeacherSchedule(teacherId),
    listTeacherClasses(teacherId),
    listTeacherSubjects(teacherId),
  ]);
  const rows = scheduleRes.ok
    ? (scheduleRes.data || []).map((r) => ({ ...r, id: r.id || r.entry_id }))
    : [];
  const durationMinutes = (r) => {
    if (!r?.starts_at || !r?.ends_at) return 45;
    const [sh, sm] = String(r.starts_at).slice(0, 5).split(':').map(Number);
    const [eh, em] = String(r.ends_at).slice(0, 5).split(':').map(Number);
    const d = (eh * 60 + em) - (sh * 60 + sm);
    return Number.isFinite(d) && d > 0 ? d : 45;
  };
  const totalMinutes = rows.reduce((sum, r) => sum + durationMinutes(r), 0);
  el('td-hours-summary').textContent = `${rows.length} حصة — ${(totalMinutes / 60).toFixed(2)} ساعة/أسبوع`;

  const scheduleHtml = rows.length
    ? '<div class="data-table-wrap"><table class="data-table"><thead><tr><th>اليوم</th><th>الحصة</th><th>التوقيت</th><th>القسم</th><th>المادة</th></tr></thead><tbody>'
      + rows.map((r) => `<tr><td>${WEEKDAYS_AR[r.weekday] || r.weekday}</td><td>${r.period}</td><td>${esc(String(r.starts_at || '').slice(0,5) || '—')} – ${esc(String(r.ends_at || '').slice(0,5) || '—')}</td><td>${esc(r.class_name || '—')}</td><td>${esc(r.subject_name || '—')}</td></tr>`).join('')
      + '</tbody></table></div>'
    : emptyHtml(scheduleRes.ok ? 'لا توجد حصص زمنية مسجلة لهذا الأستاذ حاليًا.' : scheduleRes.error || 'تعذر تحميل جدول الأستاذ.');

  const classes = classRes.ok ? classRes.data || [] : [];
  const subjects = subjectRes.ok ? subjectRes.data || [] : [];
  const assignmentsHtml = `<div class="panel" style="margin-top:10px;"><strong>الربط الأكاديمي للأستاذ</strong>
    <div class="detail-row"><span class="k">الأقسام المسندة</span><span class="v">${classes.length ? classes.map(c => esc(c.class_name) + (c.year_name ? ' — ' + esc(c.year_name) : '')).join('، ') : 'لا توجد'}</span></div>
    <div class="detail-row"><span class="k">المواد المسندة</span><span class="v">${subjects.length ? subjects.map(x => esc(x.subject_name)).join('، ') : 'لا توجد'}</span></div>
  </div>`;
  host.innerHTML = scheduleHtml + assignmentsHtml;
}

el('td-rate-save').addEventListener('click', async () => {
  if (!currentTeacherId) return;
  const rate = Number(el('td-rate').value);
  if (!Number.isFinite(rate) || rate < 0) { toast('أدخل سعرًا صالحًا.', 'error'); return; }
  const res = await setTeacherRate(currentTeacherId, rate);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم حفظ سعر الساعة.', 'success');
});

el('td-month-save').addEventListener('click', async () => {
  if (!currentTeacherId) return;
  const month = el('td-month').value; // yyyy-mm
  const hours = Number(el('td-month-hours').value);
  if (!month) { toast('اختر الشهر.', 'error'); return; }
  if (!Number.isFinite(hours) || hours < 0) { toast('أدخل عدد ساعات صالح.', 'error'); return; }
  const res = await upsertTeacherMonth(currentTeacherId, month + '-01', hours, el('td-month-notes').value || null);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم حفظ الشهر.', 'success');
  el('td-month-hours').value = '';
  el('td-month-notes').value = '';
  renderTeacherPayroll(currentTeacherId);
});

async function renderTeacherPayroll(teacherId) {
  const host = el('td-payroll-list');
  host.innerHTML = loadingHtml();
  const res = await listTeacherPayroll(teacherId);
  const rows = res.ok ? res.data || [] : [];
  host.innerHTML = rows.length
    ? rows.map((r) => `<div class="history-item" style="flex-direction:column; align-items:stretch; gap:4px;">
        <div style="display:flex; justify-content:space-between;">
          <strong>${new Date(r.period_month).toLocaleDateString(window.ssLoc('ar'), { year: 'numeric', month: 'long' })}</strong>
          <span class="time">${r.hours_worked} ساعة × ${fmtMoney(r.hourly_rate)}</span>
        </div>
        <div class="detail-row"><span class="k">المستحق</span><span class="v">${fmtMoney(r.amount_due)}</span></div>
        <div class="detail-row"><span class="k">المدفوع</span><span class="v">${fmtMoney(r.amount_paid)}</span></div>
        <div class="detail-row"><span class="k">الباقي</span><span class="v" style="font-weight:700; color:${r.balance > 0 ? '#dc2626' : '#16a34a'};">${fmtMoney(r.balance)}</span></div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
          ${r.balance > 0 ? `<button type="button" class="quick-action-btn secondary" data-pay-month="${r.period_month}" data-pay-balance="${r.balance}">تسجيل دفعة</button>` : ''}
          ${r.amount_paid > 0 ? `<button type="button" class="quick-action-btn secondary" data-teacher-receipt="${r.period_month}" style="flex:1;">🧾 تحميل/طباعة الوصل</button>` : ''}
        </div>
      </div>`).join('')
    : emptyHtml('لا يوجد سجل بعد. أدخل ساعات الشهر أعلاه.');

  host.querySelectorAll('[data-teacher-receipt]').forEach((b) => b.addEventListener('click', () => {
    const r = rows.find((x) => String(x.period_month) === String(b.dataset.teacherReceipt));
    if (!r) return;
    openReceiptWindow('وصل أداء الأستاذ', [
      ['الأستاذ', currentTeacherName || '—'],
      ['الشهر', new Date(r.period_month).toLocaleDateString(window.ssLoc('ar-MA'), { year:'numeric', month:'long' })],
      ['الساعات', r.hours_worked + ' ساعة'],
      ['سعر الساعة', fmtMoney(r.hourly_rate)],
      ['المستحق', fmtMoney(r.amount_due)],
      ['المدفوع', fmtMoney(r.amount_paid)],
      ['الباقي', fmtMoney(r.balance)],
      ['مرجع العملية', 'TEACHER-' + String(r.id || r.period_month).slice(0, 8).toUpperCase()],
    ], 'teacher-payment-receipt');
  }));

  host.querySelectorAll('[data-pay-month]').forEach((b) => b.addEventListener('click', async () => {
    const amountStr = prompt('المبلغ المدفوع (الباقي: ' + b.dataset.payBalance + ')');
    if (!amountStr) return;
    const amount = Number(amountStr);
    if (!Number.isFinite(amount) || amount <= 0) { toast('مبلغ غير صالح.', 'error'); return; }
    const res2 = await recordTeacherPayment(currentTeacherId, b.dataset.payMonth, amount);
    if (!res2.ok) { toast(res2.error, 'error'); return; }
    toast('تم تسجيل الدفعة.', 'success');
    const r = rows.find((x) => String(x.period_month) === String(b.dataset.payMonth));
    if (r) {
      openReceiptWindow('وصل أداء الأستاذ', [
        ['الأستاذ', currentTeacherName || '—'],
        ['الشهر', new Date(r.period_month).toLocaleDateString(window.ssLoc('ar-MA'), { year:'numeric', month:'long' })],
        ['المبلغ المدفوع الآن', fmtMoney(amount)],
        ['إجمالي المدفوع بعد العملية', fmtMoney(Number(r.amount_paid || 0) + amount)],
        ['مرجع العملية', 'TEACHER-' + String(r.id || r.period_month).slice(0, 8).toUpperCase()],
      ], 'teacher-payment-receipt');
    }
    renderTeacherPayroll(currentTeacherId);
  }));
}

async function renderAssignSubjects() {
  const list = el('ta-subjects-list');
  list.innerHTML = loadingHtml();
  const [assignedRes, allRes] = await Promise.all([listTeacherSubjects(assignTeacherId), listSubjects()]);
  const assigned = assignedRes.ok ? assignedRes.data || [] : [];
  const all = allRes.ok ? allRes.data || [] : [];
  const assignedIds = new Set(assigned.map((s) => s.subject_id));

  list.innerHTML = assigned.length
    ? assigned.map((s) => `<div class="history-item"><strong>${esc(s.subject_name)}</strong>
        <button type="button" class="quick-action-btn secondary" data-ta-unsubject="${s.subject_id}">إزالة</button></div>`).join('')
    : emptyHtml('لا توجد مواد مسندة.');

  const sel = el('ta-subject-select');
  const remaining = all.filter((s) => !assignedIds.has(s.subject_id));
  sel.innerHTML = remaining.length
    ? remaining.map((s) => `<option value="${s.subject_id}">${esc(s.subject_name)}</option>`).join('')
    : '<option value="">كل المواد مسندة</option>';

  list.querySelectorAll('[data-ta-unsubject]').forEach((b) => b.addEventListener('click', async () => {
    b.disabled = true;
    const res = await removeTeacherSubject(assignTeacherId, b.dataset.taUnsubject);
    if (!res.ok) { toast(res.error, 'error'); b.disabled = false; return; }
    toast('تمت إزالة المادة.', 'success');
    renderAssignSubjects();
  }));
}

async function renderAssignClasses() {
  const list = el('ta-classes-list');
  list.innerHTML = loadingHtml();
  const [assignedRes, classesRes] = await Promise.all([listTeacherClasses(assignTeacherId), ensureClasses()]);
  const assigned = assignedRes.ok ? assignedRes.data || [] : [];
  const all = (classesRes || []).filter((c) => !c.is_disabled);
  const assignedIds = new Set(assigned.map((c) => c.class_id));

  list.innerHTML = assigned.length
    ? assigned.map((c) => `<div class="history-item"><strong>${esc(c.class_name)}${c.level ? ' — ' + esc(c.level) : ''}</strong>
        <span class="time">${esc(c.year_name || '')}</span>
        <button type="button" class="quick-action-btn secondary" data-ta-unclass="${c.class_id}">إزالة</button></div>`).join('')
    : emptyHtml('لا توجد أقسام مسندة.');

  const sel = el('ta-class-select');
  const remaining = all.filter((c) => !assignedIds.has(c.class_id));
  sel.innerHTML = remaining.length
    ? remaining.map((c) => `<option value="${c.class_id}">${esc(c.class_name)}${c.level ? ' — ' + esc(c.level) : ''}</option>`).join('')
    : '<option value="">كل الأقسام مسندة</option>';

  list.querySelectorAll('[data-ta-unclass]').forEach((b) => b.addEventListener('click', async () => {
    b.disabled = true;
    const res = await removeTeacherClass(assignTeacherId, b.dataset.taUnclass);
    if (!res.ok) { toast(res.error, 'error'); b.disabled = false; return; }
    toast('تمت إزالة القسم.', 'success');
    renderAssignClasses();
  }));
}

el('ta-subject-add').addEventListener('click', async () => {
  const subjectId = el('ta-subject-select').value;
  if (!subjectId || !assignTeacherId) return;
  const res = await assignTeacherSubject(assignTeacherId, subjectId);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم ربط المادة بالأستاذ.', 'success');
  renderAssignSubjects();
});
el('ta-class-add').addEventListener('click', async () => {
  const classId = el('ta-class-select').value;
  if (!classId || !assignTeacherId) return;
  const res = await assignTeacherClass(assignTeacherId, classId);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم ربط القسم بالأستاذ.', 'success');
  renderAssignClasses();
});
