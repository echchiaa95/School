// ============================================================================
// modules/ui.js
// Shared UI helpers for all consoles: DOM shortcuts, toasts, confirm dialogs,
// formatting, CSV export, loading/empty/error states. RTL-first.
// ============================================================================

export function el(id) { return document.getElementById(id); }

export function esc(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

export function fmtDate(value) {
  if (!value) return '—';
  try {
    return new Intl.DateTimeFormat('ar', { year: 'numeric', month: 'short', day: 'numeric' }).format(new Date(value));
  } catch { return '—'; }
}

export function fmtDateTime(value) {
  if (!value) return '—';
  try {
    return new Intl.DateTimeFormat('ar', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(value));
  } catch { return '—'; }
}

export function fmtMoney(value) {
  const n = Number(value || 0);
  return n.toLocaleString('ar-MA', { maximumFractionDigits: 2 }) + ' د.م.';
}

export function fmtTime(value) {
  if (!value) return '—';
  try {
    return new Intl.DateTimeFormat('ar', { hour: '2-digit', minute: '2-digit' }).format(new Date(value));
  } catch { return '—'; }
}

export function todayAr() {
  return new Intl.DateTimeFormat('ar', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }).format(new Date());
}

const ATT_STATUS_AR = { present: 'حاضر', absent: 'غائب', late: 'متأخر', excused: 'مبرر' };
export function attStatusAr(s) { return ATT_STATUS_AR[s] || s || '—'; }

const ROLE_AR = {
  superadmin: 'SuperAdmin', admin: 'إداري', director: 'مدير', guard: 'حارس',
  teacher: 'أستاذ', driver: 'سائق', parent: 'ولي أمر',
};
export function roleAr(r) { return ROLE_AR[r] || r || '—'; }

/** Show a transient toast message (success | error | info). */
let toastHost = null;
export function toast(message, kind = 'info') {
  if (!toastHost) {
    toastHost = document.createElement('div');
    toastHost.className = 'toast-host';
    document.body.appendChild(toastHost);
  }
  const item = document.createElement('div');
  item.className = `toast toast-${kind}`;
  item.textContent = message;
  toastHost.appendChild(item);
  setTimeout(() => item.classList.add('show'), 10);
  setTimeout(() => { item.classList.remove('show'); setTimeout(() => item.remove(), 300); }, 3500);
}

/** Promise-based confirmation dialog. Resolves true/false. */
export function confirmDialog(message) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal-card" role="dialog" aria-modal="true">
        <p style="margin:0 0 16px; font-weight:600;">${esc(message)}</p>
        <div style="display:flex; gap:8px;">
          <button type="button" class="quick-action-btn" data-act="ok" style="flex:1;">تأكيد</button>
          <button type="button" class="back-link" data-act="cancel" style="flex:1; text-align:center;">إلغاء</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay || e.target.dataset.act === 'cancel') { overlay.remove(); resolve(false); }
      if (e.target.dataset.act === 'ok') { overlay.remove(); resolve(true); }
    });
  });
}

/** Render helpers */
export function loadingHtml(text = 'جارٍ التحميل...') {
  return `<div class="loading-state">${esc(text)}</div>`;
}
export function emptyHtml(text) {
  return `<div class="empty-state">${esc(text)}</div>`;
}
export function errorHtml(text) {
  return `<div class="empty-state" style="color:#dc2626;">${esc(text)}</div>`;
}

export function statCard(value, label, tone = '') {
  return `<div class="stat-card ${tone}"><div class="stat-value">${esc(value)}</div><div class="stat-label">${esc(label)}</div></div>`;
}

/** Download rows as a CSV file (UTF-8 BOM for Excel Arabic support). */
export function downloadCSV(filename, headers, rows) {
  const escapeCell = (v) => {
    const s = String(v ?? '');
    return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  const csv = '﻿' + [headers, ...rows].map((r) => r.map(escapeCell).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

/** Set the standard page header (school name, user, date) and wire logout. */
export async function initPageHeader(ctx, schoolName, logoutFn) {
  const who = el('who-label');
  if (who) who.textContent = `${ctx.profile.full_name} - ${roleAr(ctx.role)}`;
  const dl = el('date-line');
  if (dl) dl.textContent = todayAr();
  const sn = el('school-name-label');
  if (sn && schoolName) sn.textContent = schoolName;
  const btn = el('logout-btn');
  if (btn) {
    btn.style.display = 'inline-block';
    btn.addEventListener('click', logoutFn);
  }
}

/** Simple view switcher: hides every [data-view] section, shows one. */
export function showView(name) {
  document.querySelectorAll('[data-view]').forEach((s) => { s.hidden = true; });
  const target = document.querySelector(`[data-view="${name}"]`);
  if (target) target.hidden = false;
  document.querySelectorAll('[data-nav]').forEach((b) => {
    b.classList.toggle('active', b.dataset.nav === name);
  });
  window.scrollTo({ top: 0 });
}
