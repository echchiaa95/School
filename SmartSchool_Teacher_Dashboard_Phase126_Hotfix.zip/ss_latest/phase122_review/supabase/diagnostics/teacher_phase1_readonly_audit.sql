-- ============================================================================
-- Smart School — Teacher Dashboard — PHASE 1 READ-ONLY AUDIT
-- SELECT only. No INSERT / UPDATE / DELETE / DDL. Safe to run on production.
-- Run QUERY A, copy the single JSON cell, then run QUERY B and copy it too.
-- ============================================================================

-- ============================ QUERY A: structure ============================
with t(name) as (values
  ('schools'),('profiles'),('user_roles'),('teachers'),('teacher_subjects'),('teacher_classes'),
  ('classes'),('subjects'),('students'),('student_enrollments'),('academic_years'),
  ('timetables'),('timetable_entries'),('class_sessions'),('school_period_configs'),
  ('attendance_records'),('attendance_change_audit'),
  ('grade_assessments'),('student_grades'),('grade_subject_coefficients'),
  ('notifications'),('audit_logs'),('user_permissions')
)
select jsonb_pretty(jsonb_build_object(
  'server_timezone', current_setting('TimeZone'),

  'tables_present', (
    select jsonb_agg(jsonb_build_object('table', t.name, 'exists', to_regclass('public.'||t.name) is not null) order by t.name)
    from t
  ),

  'columns', (
    select jsonb_object_agg(table_name, cols)
    from (
      select c.table_name,
             jsonb_agg(c.column_name||' '||c.data_type||case when c.is_nullable='NO' then ' NOT NULL' else '' end
                       order by c.ordinal_position) as cols
      from information_schema.columns c
      where c.table_schema='public' and c.table_name in (select name from t)
      group by c.table_name
    ) x
  ),

  'constraints', (
    select jsonb_agg(jsonb_build_object('table', cl.relname, 'name', co.conname, 'def', pg_get_constraintdef(co.oid))
                     order by cl.relname, co.conname)
    from pg_constraint co
    join pg_class cl on cl.oid = co.conrelid
    join pg_namespace n on n.oid = cl.relnamespace
    where n.nspname='public' and cl.relname in (select name from t)
      and co.contype in ('u','c','p','f')
  ),

  'rls_enabled', (
    select jsonb_agg(jsonb_build_object('table', cl.relname, 'rls', cl.relrowsecurity, 'forced', cl.relforcerowsecurity)
                     order by cl.relname)
    from pg_class cl
    join pg_namespace n on n.oid = cl.relnamespace
    where n.nspname='public' and cl.relkind='r' and cl.relname in (select name from t)
  ),

  'policies', (
    select jsonb_agg(jsonb_build_object('table', tablename, 'policy', policyname, 'cmd', cmd,
                                        'roles', roles, 'using', qual, 'with_check', with_check)
                     order by tablename, policyname)
    from pg_policies
    where schemaname='public' and tablename in (select name from t)
  ),

  'triggers', (
    select jsonb_agg(jsonb_build_object('table', cl.relname, 'trigger', tg.tgname,
                                        'def', pg_get_triggerdef(tg.oid)) order by cl.relname, tg.tgname)
    from pg_trigger tg
    join pg_class cl on cl.oid = tg.tgrelid
    join pg_namespace n on n.oid = cl.relnamespace
    where n.nspname='public' and not tg.tgisinternal and cl.relname in (select name from t)
  )
)) as audit_a_structure;


-- ====================== QUERY B: functions + row counts =====================
select jsonb_pretty(jsonb_build_object(
  'teacher_related_functions', (
    select jsonb_agg(jsonb_build_object(
             'name', p.proname,
             'args', pg_get_function_identity_arguments(p.oid),
             'security_definer', p.prosecdef,
             'definition', pg_get_functiondef(p.oid)
           ) order by p.proname)
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname='public'
      and p.proname in (
        'fn_teacher_classes','fn_my_teacher_subjects','fn_teacher_class_roster',
        'fn_get_my_teacher_schedule','fn_get_teacher_schedule','fn_get_class_attendance',
        'fn_save_attendance','fn_create_grade_assessment','fn_save_grade_mark',
        'fn_is_school_staff','fn_resolve_my_role','fn_has_permission'
      )
  ),

  'row_counts', (
    select jsonb_object_agg(
             n,
             case when to_regclass('public.'||n) is null then null
                  else (xpath('/row/c/text()',
                         query_to_xml(format('select count(*) as c from public.%I', n), false, true, '')))[1]::text::int
             end)
    from unnest(array['teachers','teacher_subjects','teacher_classes','classes','subjects',
                      'timetables','timetable_entries','class_sessions','school_period_configs',
                      'attendance_records']) as n
  )
)) as audit_b_functions;
-- row_counts shows null for any table that does not exist (no error).
