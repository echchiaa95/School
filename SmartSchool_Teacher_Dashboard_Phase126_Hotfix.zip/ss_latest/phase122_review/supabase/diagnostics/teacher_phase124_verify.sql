-- Read-only verification of the teacher security hardening (phase124).
-- Run once; paste the result table.
select p.proname,
       pg_get_function_identity_arguments(p.oid)                     as args,
       has_function_privilege('anon',          p.oid, 'EXECUTE')     as anon_can_run,
       has_function_privilege('authenticated', p.oid, 'EXECUTE')     as authenticated_can_run,
       has_function_privilege('public',        p.oid, 'EXECUTE')     as public_can_run,
       pg_get_functiondef(p.oid) ilike '%fn_can_manage_grades%'
         or pg_get_functiondef(p.oid) ilike '%fn_teacher_assigned_to_class%' as has_new_check
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and p.proname in (
    'fn_teacher_assigned_to_class','fn_can_manage_grades',
    'fn_create_grade_assessment','fn_save_grade_mark',
    'fn_update_grade_assessment_coefficient','fn_save_attendance',
    'fn_get_class_attendance','fn_teacher_class_roster',
    'fn_get_my_teacher_schedule','fn_get_teacher_schedule','fn_report_incident'
  )
order by p.proname;
