-- QUERY C — read-only. Who can EXECUTE the teacher-related functions?
-- Run, then paste the result table (or export as JSON).
select p.proname,
       pg_get_function_identity_arguments(p.oid) as args,
       p.prosecdef                               as security_definer,
       has_function_privilege('anon',          p.oid, 'EXECUTE') as anon_can_run,
       has_function_privilege('authenticated', p.oid, 'EXECUTE') as authenticated_can_run,
       has_function_privilege('public',        p.oid, 'EXECUTE') as public_can_run
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and p.proname in (
    'fn_create_grade_assessment','fn_save_grade_mark','fn_save_attendance',
    'fn_get_class_attendance','fn_teacher_class_roster','fn_get_my_teacher_schedule',
    'fn_get_teacher_schedule','fn_update_grade_assessment_coefficient',
    'fn_list_grade_assessments','fn_report_incident'
  )
order by p.proname;
