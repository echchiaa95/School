-- ============================================================================
-- phase126_teacher_class_space_lesson_log.sql
-- STATUS: NOT YET APPLIED — review, then run in Supabase SQL Editor
--         (after phase124 and phase125).
--
-- ADDITIVE ONLY. One new table (lesson_log_entries = "cahier de textes") and
-- three new functions. No existing table, column, policy, function or row is
-- changed.
--
-- Security model:
--   * lesson_log_entries has RLS enabled. Teachers have NO direct table access;
--     every write/read goes through the SECURITY DEFINER functions below.
--     Only school admins / directors get a direct SELECT policy (read-only).
--   * A teacher can write/read only lessons for a class AND subject they are
--     assigned to (fn_teacher_assigned_to_class from phase124) and can edit
--     only their own entries.
--   * Admins / directors can read (not write) lessons of their school.
--
-- Rollback (nothing else depends on these objects):
--   drop function public.fn_teacher_class_space(uuid);
--   drop function public.fn_list_lesson_log(uuid, uuid, date, date, text, int);
--   drop function public.fn_save_lesson_log(uuid, uuid, uuid, date, smallint,
--        text, text, text, text, text, text, text);
--   drop table public.lesson_log_entries;
-- ============================================================================

begin;

-- ---------------------------------------------------------------------------
-- 1. Table
-- ---------------------------------------------------------------------------
create table if not exists public.lesson_log_entries (
  id          uuid primary key default gen_random_uuid(),
  school_id   uuid not null references public.schools(id)  on delete cascade,
  class_id    uuid not null references public.classes(id)  on delete cascade,
  subject_id  uuid not null references public.subjects(id) on delete cascade,
  teacher_id  uuid not null references public.teachers(id) on delete cascade,
  lesson_date date not null,
  period      smallint check (period is null or period between 1 and 12),
  title       text not null check (length(trim(title)) > 0),
  objectives  text,
  topics      text,
  activities  text,
  homework    text,
  notes       text,
  status      text not null default 'done' check (status in ('planned', 'done')),
  created_by  uuid,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- One entry per teacher / class / subject / date / period (null period = 0).
create unique index if not exists ux_lesson_log_slot
  on public.lesson_log_entries (teacher_id, class_id, subject_id, lesson_date, coalesce(period, 0));
create index if not exists ix_lesson_log_class_date
  on public.lesson_log_entries (school_id, class_id, lesson_date desc);

alter table public.lesson_log_entries enable row level security;

revoke all on table public.lesson_log_entries from anon, authenticated;
grant select on table public.lesson_log_entries to authenticated;

do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'lesson_log_entries'
      and policyname = 'p_lesson_log_staff_read'
  ) then
    create policy p_lesson_log_staff_read on public.lesson_log_entries
      for select to authenticated
      using (
        public.fn_is_school_staff(school_id)
        or coalesce(public.fn_resolve_my_role(school_id) = 'director', false)
      );
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- 2. fn_save_lesson_log — create (p_id null) or update (p_id set) own lesson.
-- ---------------------------------------------------------------------------
create or replace function public.fn_save_lesson_log(
  p_id          uuid,
  p_class_id    uuid,
  p_subject_id  uuid,
  p_lesson_date date,
  p_period      smallint,
  p_title       text,
  p_objectives  text,
  p_topics      text,
  p_activities  text,
  p_homework    text,
  p_notes       text,
  p_status      text default 'done'
) returns public.lesson_log_entries
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_teacher   uuid;
  v_existing  public.lesson_log_entries;
  v_row       public.lesson_log_entries;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select c.school_id into v_school_id
  from public.classes c
  where c.id = p_class_id;

  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;

  if not exists (select 1 from public.subjects s
                 where s.id = p_subject_id and s.school_id = v_school_id) then
    raise exception 'INVALID_SUBJECT';
  end if;

  select t.id into v_teacher
  from public.teachers t
  where t.profile_id = auth.uid()
    and t.school_id = v_school_id
    and t.deleted_at is null
  limit 1;

  -- Only a teacher assigned to this class AND subject writes lessons.
  if v_teacher is null
     or not public.fn_teacher_assigned_to_class(p_class_id, p_subject_id) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if p_lesson_date is null then
    raise exception 'LESSON_DATE_REQUIRED';
  end if;
  if trim(coalesce(p_title, '')) = '' then
    raise exception 'LESSON_TITLE_REQUIRED';
  end if;
  if coalesce(p_status, 'done') not in ('planned', 'done') then
    raise exception 'INVALID_STATUS';
  end if;
  if p_period is not null and (p_period < 1 or p_period > 12) then
    raise exception 'INVALID_PERIOD';
  end if;

  begin
    if p_id is null then
      insert into public.lesson_log_entries (
        school_id, class_id, subject_id, teacher_id, lesson_date, period, title,
        objectives, topics, activities, homework, notes, status, created_by
      ) values (
        v_school_id, p_class_id, p_subject_id, v_teacher, p_lesson_date, p_period,
        trim(p_title),
        nullif(trim(coalesce(p_objectives, '')), ''),
        nullif(trim(coalesce(p_topics, '')), ''),
        nullif(trim(coalesce(p_activities, '')), ''),
        nullif(trim(coalesce(p_homework, '')), ''),
        nullif(trim(coalesce(p_notes, '')), ''),
        coalesce(p_status, 'done'), auth.uid()
      )
      returning * into v_row;
    else
      select * into v_existing
      from public.lesson_log_entries e
      where e.id = p_id;

      if v_existing.id is null then
        raise exception 'LESSON_NOT_FOUND';
      end if;
      if v_existing.teacher_id <> v_teacher or v_existing.school_id <> v_school_id then
        raise exception 'PERMISSION_DENIED';
      end if;

      update public.lesson_log_entries e
      set class_id    = p_class_id,
          subject_id  = p_subject_id,
          lesson_date = p_lesson_date,
          period      = p_period,
          title       = trim(p_title),
          objectives  = nullif(trim(coalesce(p_objectives, '')), ''),
          topics      = nullif(trim(coalesce(p_topics, '')), ''),
          activities  = nullif(trim(coalesce(p_activities, '')), ''),
          homework    = nullif(trim(coalesce(p_homework, '')), ''),
          notes       = nullif(trim(coalesce(p_notes, '')), ''),
          status      = coalesce(p_status, 'done'),
          updated_at  = now()
      where e.id = p_id
      returning * into v_row;
    end if;
  exception
    when unique_violation then
      raise exception 'LESSON_ALREADY_LOGGED';
  end;

  perform public.fn_safe_audit(
    v_school_id, 'SAVE_LESSON_LOG', 'lesson_log_entries', v_row.id, null,
    jsonb_build_object('class_id', p_class_id, 'subject_id', p_subject_id,
                       'date', p_lesson_date, 'status', v_row.status,
                       'mode', case when p_id is null then 'create' else 'update' end)
  );

  return v_row;
end;
$$;

-- ---------------------------------------------------------------------------
-- 3. fn_list_lesson_log — teacher: own lessons of an assigned class;
--    admin / director: all lessons of the class (read-only).
-- ---------------------------------------------------------------------------
create or replace function public.fn_list_lesson_log(
  p_class_id   uuid,
  p_subject_id uuid default null,
  p_from       date default null,
  p_to         date default null,
  p_search     text default null,
  p_limit      int  default 100
) returns table(
  id          uuid,
  class_id    uuid,
  class_name  text,
  subject_id  uuid,
  subject_name text,
  lesson_date date,
  period      smallint,
  title       text,
  objectives  text,
  topics      text,
  activities  text,
  homework    text,
  notes       text,
  status      text,
  updated_at  timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_teacher   uuid;
  v_priv      boolean;
  v_q         text;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select c.school_id into v_school_id
  from public.classes c
  where c.id = p_class_id;

  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;

  v_priv := public.fn_is_school_staff(v_school_id)
         or coalesce(public.fn_resolve_my_role(v_school_id) = 'director', false);

  select t.id into v_teacher
  from public.teachers t
  where t.profile_id = auth.uid()
    and t.school_id = v_school_id
    and t.deleted_at is null
  limit 1;

  if not (v_priv or (v_teacher is not null
                     and public.fn_teacher_assigned_to_class(p_class_id))) then
    raise exception 'PERMISSION_DENIED';
  end if;

  v_q := lower(nullif(trim(coalesce(p_search, '')), ''));

  return query
  select e.id, e.class_id, c.name, e.subject_id, su.name,
         e.lesson_date, e.period, e.title, e.objectives, e.topics,
         e.activities, e.homework, e.notes, e.status, e.updated_at
  from public.lesson_log_entries e
  join public.classes  c  on c.id  = e.class_id
  join public.subjects su on su.id = e.subject_id
  where e.class_id = p_class_id
    and (v_priv or e.teacher_id = v_teacher)
    and (p_subject_id is null or e.subject_id = p_subject_id)
    and (p_from is null or e.lesson_date >= p_from)
    and (p_to   is null or e.lesson_date <= p_to)
    and (v_q is null or strpos(lower(
           coalesce(e.title, '') || ' ' || coalesce(e.objectives, '') || ' ' ||
           coalesce(e.topics, '') || ' ' || coalesce(e.activities, '') || ' ' ||
           coalesce(e.homework, '') || ' ' || coalesce(e.notes, '')), v_q) > 0)
  order by e.lesson_date desc, e.period desc nulls last, e.updated_at desc
  limit least(greatest(coalesce(p_limit, 100), 1), 500);
end;
$$;

-- ---------------------------------------------------------------------------
-- 4. fn_teacher_class_space — one JSON document for the "class space" screen.
--    Read-only. Nothing is invented: averages are null when there are no marks.
-- ---------------------------------------------------------------------------
create or replace function public.fn_teacher_class_space(p_class_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_teacher   uuid;
  v_priv      boolean;
  v_tz        text;
  v_today     date;
  v_from      date;
  v_att       jsonb;
  v_results   jsonb;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select c.school_id into v_school_id
  from public.classes c
  where c.id = p_class_id;

  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;

  v_priv := public.fn_is_school_staff(v_school_id)
         or coalesce(public.fn_resolve_my_role(v_school_id) = 'director', false);

  if not (v_priv or public.fn_teacher_assigned_to_class(p_class_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  select t.id into v_teacher
  from public.teachers t
  where t.profile_id = auth.uid()
    and t.school_id = v_school_id
    and t.deleted_at is null
  limit 1;

  select coalesce(nullif(to_jsonb(s) ->> 'timezone', ''), 'Africa/Casablanca')
    into v_tz
  from public.schools s
  where s.id = v_school_id;

  v_today := (now() at time zone coalesce(v_tz, 'Africa/Casablanca'))::date;
  v_from  := v_today - 29;

  -- Attendance summary, last 30 days (this class).
  select jsonb_build_object(
           'from', v_from,
           'to', v_today,
           'records', count(*),
           'present', count(*) filter (where ar.status = 'present'),
           'absent',  count(*) filter (where ar.status = 'absent'),
           'late',    count(*) filter (where ar.status = 'late'),
           'excused', count(*) filter (where ar.status = 'excused'),
           'rate_percent', case when count(*) = 0 then null
                           else round(100.0 * count(*) filter (where ar.status in ('present', 'late'))
                                      / count(*), 1) end
         )
    into v_att
  from public.attendance_records ar
  where ar.class_id = p_class_id
    and ar.att_date between v_from and v_today;

  -- Results: weighted average on 20 over marks of this class, limited to the
  -- teacher's own subjects (admins / directors: all subjects).
  select jsonb_build_object(
           'average_on_20',
             case when coalesce(sum(ga.coefficient), 0) = 0 then null
                  else round(sum((gm.score / nullif(ga.max_score, 0)) * 20 * ga.coefficient)
                             / sum(ga.coefficient), 2) end,
           'marks_count', count(*),
           'assessments_count', count(distinct ga.id)
         )
    into v_results
  from public.grade_marks gm
  join public.grade_assessments ga on ga.id = gm.assessment_id
  where ga.class_id = p_class_id
    and ga.max_score > 0
    and (v_priv or ga.subject_id in (select ts.subject_id
                                     from public.teacher_subjects ts
                                     where ts.teacher_id = v_teacher));

  return jsonb_build_object(
    'class', (
      select jsonb_build_object('id', c.id, 'name', c.name, 'level', c.level, 'year_name', ay.label)
      from public.classes c
      left join public.academic_years ay on ay.id = c.academic_year_id
      where c.id = p_class_id
    ),
    'today', v_today,
    'student_count', (
      select count(*) from public.student_enrollments se
      where se.class_id = p_class_id and se.status = 'ACTIVE'
    ),
    'subjects', coalesce((
      select jsonb_agg(distinct jsonb_build_object('subject_id', su.id, 'subject_name', su.name))
      from public.timetable_entries te
      join public.subjects su on su.id = te.subject_id
      where te.class_id = p_class_id
        and (v_priv or te.teacher_id = v_teacher)
    ), '[]'::jsonb),
    'weekly_program', coalesce((
      select jsonb_agg(jsonb_build_object(
               'weekday', te.weekday - 1,
               'period', coalesce(te.period, 1),
               'subject_name', su.name,
               'starts_at', te.starts_at,
               'ends_at', te.ends_at)
             order by te.weekday, te.starts_at)
      from public.timetable_entries te
      join public.subjects su on su.id = te.subject_id
      where te.class_id = p_class_id
        and (v_priv or te.teacher_id = v_teacher)
    ), '[]'::jsonb),
    'attendance_30d', v_att,
    'results', v_results,
    'students', coalesce((
      select jsonb_agg(jsonb_build_object(
               'student_id', st.id,
               'full_name', st.full_name,
               'student_number', st.student_number,
               'today_status', (select ar.status from public.attendance_records ar
                                where ar.student_id = st.id and ar.class_id = p_class_id
                                  and ar.att_date = v_today),
               'absences_30d', (select count(*) from public.attendance_records ar
                                where ar.student_id = st.id and ar.class_id = p_class_id
                                  and ar.status = 'absent'
                                  and ar.att_date between v_from and v_today),
               'lates_30d', (select count(*) from public.attendance_records ar
                             where ar.student_id = st.id and ar.class_id = p_class_id
                               and ar.status = 'late'
                               and ar.att_date between v_from and v_today))
             order by st.full_name)
      from public.student_enrollments se
      join public.students st on st.id = se.student_id and st.deleted_at is null
      where se.class_id = p_class_id and se.status = 'ACTIVE'
    ), '[]'::jsonb),
    'recent_lessons', coalesce((
      select jsonb_agg(x.j order by x.d desc)
      from (
        select e.lesson_date as d,
               jsonb_build_object('id', e.id, 'lesson_date', e.lesson_date, 'title', e.title,
                                  'subject_name', su.name, 'status', e.status) as j
        from public.lesson_log_entries e
        join public.subjects su on su.id = e.subject_id
        where e.class_id = p_class_id
          and (v_priv or e.teacher_id = v_teacher)
        order by e.lesson_date desc, e.updated_at desc
        limit 5
      ) x
    ), '[]'::jsonb)
  );
end;
$$;

-- ---------------------------------------------------------------------------
-- 5. Privileges: logged-in users only; each function enforces its own checks.
-- ---------------------------------------------------------------------------
revoke execute on function public.fn_save_lesson_log(uuid, uuid, uuid, date, smallint, text, text, text, text, text, text, text) from public, anon;
revoke execute on function public.fn_list_lesson_log(uuid, uuid, date, date, text, int) from public, anon;
revoke execute on function public.fn_teacher_class_space(uuid) from public, anon;
grant  execute on function public.fn_save_lesson_log(uuid, uuid, uuid, date, smallint, text, text, text, text, text, text, text) to authenticated;
grant  execute on function public.fn_list_lesson_log(uuid, uuid, date, date, text, int) to authenticated;
grant  execute on function public.fn_teacher_class_space(uuid) to authenticated;

commit;
