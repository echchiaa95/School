-- ============================================================================
-- phase124_teacher_security_hardening.sql
-- STATUS: APPLIED to production. This repo copy already contains the NULL-SAFE
-- fix; production additionally needs phase124_1_null_safe_authorization_fix.sql
-- (a NULL from fn_resolve_my_role for a user with no role in the school made
-- 'if not (...)' skip the PERMISSION_DENIED raise).
--
-- Scope: server-side authorization only. No table/column changes, no data
-- changes, no RLS changes, no signature changes (same names, args, returns),
-- so the existing UI keeps working. Admin / guard / parent / driver
-- permissions are NOT widened; only unauthorized access is closed.
--
-- Rollback: the previous definitions are in your QUERY B output
-- (audit_b_functions). Keep that file before applying.
--
-- Findings fixed (from live audit):
--  F1 fn_create_grade_assessment : no auth/role/assignment check, runnable by anon
--  F2 fn_save_grade_mark         : no auth/role/assignment check, runnable by anon
--  F3 fn_save_attendance         : any teacher of the school could write any class
--  F4 fn_get_class_attendance    : any member (parent, driver...) could read any class
--  F5 EXECUTE granted to anon on all teacher functions
--  F2b fn_update_grade_assessment_coefficient : no auth/role/assignment check, runnable by anon
-- ============================================================================

begin;

-- ---------------------------------------------------------------------------
-- H1. Is the caller a teacher assigned to this class (and, optionally, subject)?
--     Assigned = homeroom (classes.teacher_id) OR teacher_classes OR a
--     timetable entry. Subject check uses teacher_subjects.
-- ---------------------------------------------------------------------------
create or replace function public.fn_teacher_assigned_to_class(
  p_class_id uuid,
  p_subject_id uuid default null
) returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.teachers t
    join public.classes c
      on c.id = p_class_id
     and c.school_id = t.school_id
    where auth.uid() is not null
      and t.profile_id = auth.uid()
      and t.deleted_at is null
      and (
        c.teacher_id = t.id
        or exists (select 1 from public.teacher_classes tc
                   where tc.teacher_id = t.id and tc.class_id = c.id)
        or exists (select 1 from public.timetable_entries te
                   where te.teacher_id = t.id and te.class_id = c.id)
      )
      and (
        p_subject_id is null
        or exists (select 1 from public.teacher_subjects ts
                   where ts.teacher_id = t.id and ts.subject_id = p_subject_id)
      )
  );
$$;

-- ---------------------------------------------------------------------------
-- H2. May the caller create/enter grades for (school, class, subject)?
--     Class and subject must belong to the stated school (blocks id tampering).
-- ---------------------------------------------------------------------------
create or replace function public.fn_can_manage_grades(
  p_school_id uuid,
  p_class_id uuid,
  p_subject_id uuid
) returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select auth.uid() is not null
     and exists (select 1 from public.classes c
                 where c.id = p_class_id and c.school_id = p_school_id)
     and exists (select 1 from public.subjects s
                 where s.id = p_subject_id and s.school_id = p_school_id)
     and (
          public.fn_is_school_staff(p_school_id)
       or coalesce(public.fn_resolve_my_role(p_school_id) = 'director', false)
       or public.fn_has_permission('grades.manage', p_school_id)
       or public.fn_teacher_assigned_to_class(p_class_id, p_subject_id)
     );
$$;

-- ---------------------------------------------------------------------------
-- F1. fn_create_grade_assessment — same body, authorization added at the top.
-- ---------------------------------------------------------------------------
create or replace function public.fn_create_grade_assessment(
  p_school_id uuid, p_class_id uuid, p_subject_id uuid, p_academic_year_id uuid,
  p_period text, p_title text, p_assessment_type text,
  p_coefficient numeric, p_max_score numeric, p_assessment_date date default null::date
) returns grade_assessments
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_assessment public.grade_assessments;
  v_period text;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  if not public.fn_can_manage_grades(p_school_id, p_class_id, p_subject_id) then
    raise exception 'PERMISSION_DENIED';
  end if;

  v_period := case
    when p_period in ('1', 'SEMESTER_1', 'الأسدوس الأول') then 'SEMESTER_1'
    when p_period in ('2', 'SEMESTER_2', 'الأسدوس الثاني') then 'SEMESTER_2'
    when p_period in ('ANNUAL', 'النتيجة السنوية') then 'ANNUAL'
    else p_period
  end;

  if p_coefficient <= 0 then
    raise exception 'معامل التقييم يجب أن يكون أكبر من صفر';
  end if;
  if p_max_score <= 0 then
    raise exception 'النقطة القصوى يجب أن تكون أكبر من صفر';
  end if;
  if trim(coalesce(p_title, '')) = '' then
    raise exception 'عنوان التقييم مطلوب';
  end if;

  insert into public.grade_assessments (
    school_id, class_id, subject_id, academic_year_id, period, title,
    assessment_type, coefficient, max_score, assessment_date, created_by
  ) values (
    p_school_id, p_class_id, p_subject_id, p_academic_year_id, v_period,
    trim(p_title), p_assessment_type, p_coefficient, p_max_score,
    p_assessment_date, auth.uid()
  )
  returning * into v_assessment;

  return v_assessment;
end;
$function$;

-- ---------------------------------------------------------------------------
-- F2. fn_save_grade_mark — same behaviour (0..max_score, upsert), plus:
--     authentication, role/assignment, and student must be ACTIVE in the
--     assessment's class.
-- ---------------------------------------------------------------------------
create or replace function public.fn_save_grade_mark(
  p_assessment_id uuid, p_student_id uuid, p_score numeric,
  p_teacher_note text default null::text
) returns grade_marks
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_mark public.grade_marks;
  v_max_score numeric;
  v_school_id uuid;
  v_class_id uuid;
  v_subject_id uuid;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select ga.max_score, ga.school_id, ga.class_id, ga.subject_id
    into v_max_score, v_school_id, v_class_id, v_subject_id
  from public.grade_assessments ga
  where ga.id = p_assessment_id;

  if v_max_score is null then
    raise exception 'التقييم غير موجود';
  end if;

  if not public.fn_can_manage_grades(v_school_id, v_class_id, v_subject_id) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if not exists (
    select 1 from public.student_enrollments se
    where se.student_id = p_student_id
      and se.class_id = v_class_id
      and se.status = 'ACTIVE'
  ) then
    raise exception 'STUDENT_NOT_IN_CLASS';
  end if;

  if p_score is null or p_score < 0 or p_score > v_max_score then
    raise exception 'النقطة يجب أن تكون بين 0 و %', v_max_score;
  end if;

  insert into public.grade_marks (assessment_id, student_id, score, teacher_note)
  values (p_assessment_id, p_student_id, p_score, p_teacher_note)
  on conflict (assessment_id, student_id)
  do update set
    score = excluded.score,
    teacher_note = excluded.teacher_note,
    updated_at = now()
  returning * into v_mark;

  return v_mark;
end;
$function$;

-- ---------------------------------------------------------------------------
-- F2b. fn_update_grade_assessment_coefficient — same body (coefficient > 0,
--      update, return row); authorization added using the assessment's own
--      school / class / subject.
-- ---------------------------------------------------------------------------
create or replace function public.fn_update_grade_assessment_coefficient(
  p_assessment_id uuid, p_coefficient numeric
) returns grade_assessments
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_assessment public.grade_assessments;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select * into v_assessment
  from public.grade_assessments
  where id = p_assessment_id;

  if v_assessment.id is null then
    raise exception 'التقييم غير موجود';
  end if;

  if not public.fn_can_manage_grades(
       v_assessment.school_id, v_assessment.class_id, v_assessment.subject_id) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if p_coefficient is null or p_coefficient <= 0 then
    raise exception 'معامل التقييم يجب أن يكون أكبر من صفر';
  end if;

  update public.grade_assessments
  set coefficient = p_coefficient
  where id = p_assessment_id
  returning * into v_assessment;

  return v_assessment;
end;
$function$;

-- ---------------------------------------------------------------------------
-- F3. fn_save_attendance — identical to the live (phase87) body except the
--     authorization: a TEACHER must now be assigned to the class.
--     Unchanged: school staff (admin/superadmin) and holders of
--     attendance.manage (this is how the guard is authorized today).
-- ---------------------------------------------------------------------------
create or replace function public.fn_save_attendance(
  p_class_id uuid, p_date date, p_rows jsonb
) returns integer
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_school_id uuid;
  v_row jsonb;
  v_count integer := 0;
  v_status text;
  v_minutes integer;
begin
  select school_id into v_school_id
  from public.classes
  where id = p_class_id;

  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;

  if not (
    public.fn_is_school_staff(v_school_id)
    or public.fn_has_permission('attendance.manage', v_school_id)
    or public.fn_teacher_assigned_to_class(p_class_id)
  ) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if p_rows is null or jsonb_typeof(p_rows) <> 'array' then
    raise exception 'INVALID_ROWS';
  end if;

  for v_row in select * from jsonb_array_elements(p_rows)
  loop
    if not exists (
      select 1 from public.student_enrollments se
      where se.student_id = (v_row->>'student_id')::uuid
        and se.class_id = p_class_id
        and se.status = 'ACTIVE'
    ) then
      continue;
    end if;

    v_status := coalesce(v_row->>'status', '');
    if v_status not in ('present', 'absent', 'late', 'excused') then
      continue;
    end if;

    v_minutes := nullif(v_row->>'minutes_late', '')::integer;
    if v_status = 'late'
       and (v_minutes is null or v_minutes < 1 or v_minutes > 1440) then
      v_minutes := null;
    elsif v_status <> 'late' then
      v_minutes := null;
    end if;

    insert into public.attendance_records(
      school_id, student_id, class_id, att_date, status, note,
      excuse_reason, minutes_late, correction_reason, recorded_by
    ) values (
      v_school_id,
      (v_row->>'student_id')::uuid,
      p_class_id,
      coalesce(p_date, current_date),
      v_status,
      nullif(trim(coalesce(v_row->>'note', '')), ''),
      case when v_status = 'excused'
           then nullif(trim(coalesce(v_row->>'excuse_reason', '')), '')
           else null end,
      v_minutes,
      nullif(trim(coalesce(v_row->>'correction_reason', '')), ''),
      auth.uid()
    )
    on conflict (student_id, class_id, att_date)
    do update set
      status = excluded.status,
      note = excluded.note,
      excuse_reason = excluded.excuse_reason,
      minutes_late = excluded.minutes_late,
      correction_reason = excluded.correction_reason,
      recorded_by = excluded.recorded_by,
      updated_at = now();

    v_count := v_count + 1;
  end loop;

  perform public.fn_safe_audit(
    v_school_id, 'SAVE_ATTENDANCE', 'attendance_records', p_class_id, null,
    jsonb_build_object('date', coalesce(p_date, current_date), 'count', v_count)
  );

  return v_count;
end;
$function$;

-- ---------------------------------------------------------------------------
-- F4. fn_get_class_attendance — identical body; authorization narrowed from
--     "any school member" to: staff, assigned teacher, attendance.view/manage,
--     or role guard / director (guard.html uses this function today).
--     Parents, drivers and UNASSIGNED teachers lose access.
-- ---------------------------------------------------------------------------
create or replace function public.fn_get_class_attendance(
  p_class_id uuid, p_date date default null::date
) returns table(student_id uuid, full_name text, student_number text, status text, note text)
language plpgsql
stable
security definer
set search_path to 'public'
as $function$
declare
  v_school_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select school_id into v_school_id from classes where id = p_class_id;
  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;

  if not (
    fn_is_school_staff(v_school_id)
    or fn_teacher_assigned_to_class(p_class_id)
    or fn_has_permission('attendance.view', v_school_id)
    or fn_has_permission('attendance.manage', v_school_id)
    or coalesce(fn_resolve_my_role(v_school_id) in ('guard', 'director'), false)
  ) then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select
    st.id, st.full_name, st.student_number,
    ar.status, ar.note
  from student_enrollments se
  join students st on st.id = se.student_id and st.deleted_at is null
  left join attendance_records ar
    on ar.student_id = st.id and ar.class_id = se.class_id
   and ar.att_date = coalesce(p_date, current_date)
  where se.class_id = p_class_id
    and se.status = 'ACTIVE'
  order by st.full_name;
end;
$function$;

-- ---------------------------------------------------------------------------
-- F5. Remove anonymous / PUBLIC execution. Logged-in users keep access.
--     (Each function still enforces its own checks.)
-- ---------------------------------------------------------------------------
revoke execute on function public.fn_teacher_assigned_to_class(uuid, uuid) from public, anon;
revoke execute on function public.fn_can_manage_grades(uuid, uuid, uuid)   from public, anon;
grant  execute on function public.fn_teacher_assigned_to_class(uuid, uuid) to authenticated;
grant  execute on function public.fn_can_manage_grades(uuid, uuid, uuid)   to authenticated;

revoke execute on function public.fn_create_grade_assessment(uuid, uuid, uuid, uuid, text, text, text, numeric, numeric, date) from public, anon;
revoke execute on function public.fn_save_grade_mark(uuid, uuid, numeric, text)                 from public, anon;
revoke execute on function public.fn_update_grade_assessment_coefficient(uuid, numeric)         from public, anon;
revoke execute on function public.fn_save_attendance(uuid, date, jsonb)                         from public, anon;
revoke execute on function public.fn_get_class_attendance(uuid, date)                           from public, anon;
revoke execute on function public.fn_teacher_class_roster(uuid)                                 from public, anon;
revoke execute on function public.fn_get_my_teacher_schedule()                                  from public, anon;
revoke execute on function public.fn_get_teacher_schedule(uuid)                                 from public, anon;
revoke execute on function public.fn_report_incident(uuid, text, text, text, text, timestamptz) from public, anon;

grant execute on function public.fn_create_grade_assessment(uuid, uuid, uuid, uuid, text, text, text, numeric, numeric, date) to authenticated;
grant execute on function public.fn_save_grade_mark(uuid, uuid, numeric, text)                 to authenticated;
grant execute on function public.fn_update_grade_assessment_coefficient(uuid, numeric)         to authenticated;
grant execute on function public.fn_save_attendance(uuid, date, jsonb)                         to authenticated;
grant execute on function public.fn_get_class_attendance(uuid, date)                           to authenticated;
grant execute on function public.fn_teacher_class_roster(uuid)                                 to authenticated;
grant execute on function public.fn_get_my_teacher_schedule()                                  to authenticated;
grant execute on function public.fn_get_teacher_schedule(uuid)                                 to authenticated;
grant execute on function public.fn_report_incident(uuid, text, text, text, text, timestamptz) to authenticated;

commit;

-- ============================================================================
-- POST-APPLY CHECKS (read-only), run after approval + apply:
--  1. Re-run teacher_phase1_query_c_grants.sql: anon_can_run / public_can_run
--     must be false for every row.
--  2. As a teacher: attendance on an assigned class works; on a non-assigned
--     class returns PERMISSION_DENIED.
--  3. As the guard: guard.html still loads and saves attendance.
--  4. As a parent: calling fn_get_class_attendance returns PERMISSION_DENIED.
-- ============================================================================
