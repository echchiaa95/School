-- ============================================================================
-- phase125_teacher_today_overview.sql
-- STATUS: NOT YET APPLIED — review, then run in Supabase SQL Editor.
-- Adds ONE new READ-ONLY function. No table/column/RLS/data changes, no
-- existing function touched. Safe to roll back with:
--   drop function public.fn_teacher_today_overview();
--
-- Purpose: today's sessions for the logged-in teacher, with each session's
-- state (done / current / upcoming) computed on the SERVER in the school's
-- timezone — not from the phone clock.
--
-- Timezone: schools has no timezone column today. The function reads a
-- `timezone` key if one is ever added to schools, otherwise falls back to
-- 'Africa/Casablanca'. >>> CONFIRM THIS DEFAULT BEFORE APPLYING <<<
--
-- Scope notes (same as the existing fn_get_my_teacher_schedule):
--  * timetable_entries.weekday: 1 = Sunday .. 7 = Saturday
--  * disabled classes are excluded
--  * no academic-year filter (consistent with current behaviour)
-- ============================================================================

create or replace function public.fn_teacher_today_overview()
returns table(
  entry_id         uuid,
  class_id         uuid,
  class_name       text,
  subject_id       uuid,
  subject_name     text,
  period           smallint,
  starts_at        time,
  ends_at          time,
  state            text,      -- 'done' | 'current' | 'upcoming'
  attendance_taken boolean,   -- any attendance record for this class today
  student_count    bigint,
  school_now       timestamp, -- school-local "now", for display/debug
  school_tz        text
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_teacher_id uuid;
  v_school_id  uuid;
  v_tz         text;
  v_now        timestamp;
  v_today      date;
  v_time       time;
  v_weekday    int;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select t.id, t.school_id
    into v_teacher_id, v_school_id
  from public.teachers t
  where t.profile_id = auth.uid()
    and t.deleted_at is null
  limit 1;

  if v_teacher_id is null then
    return;
  end if;

  select coalesce(nullif(to_jsonb(s) ->> 'timezone', ''), 'Africa/Casablanca')
    into v_tz
  from public.schools s
  where s.id = v_school_id;

  v_now     := now() at time zone coalesce(v_tz, 'Africa/Casablanca');
  v_today   := v_now::date;
  v_time    := v_now::time;
  v_weekday := extract(dow from v_today)::int + 1;   -- 1 = Sunday

  return query
  select
    te.id,
    c.id,
    c.name,
    su.id,
    su.name,
    coalesce(te.period, 1)::smallint,
    te.starts_at,
    te.ends_at,
    case
      when te.ends_at <= v_time then 'done'
      when te.starts_at <= v_time and v_time < te.ends_at then 'current'
      else 'upcoming'
    end,
    exists (select 1 from public.attendance_records ar
            where ar.class_id = c.id and ar.att_date = v_today),
    (select count(*) from public.student_enrollments se
      where se.class_id = c.id and se.status = 'ACTIVE'),
    v_now,
    coalesce(v_tz, 'Africa/Casablanca')
  from public.timetable_entries te
  join public.classes  c  on c.id  = te.class_id
  join public.subjects su on su.id = te.subject_id
  where te.teacher_id = v_teacher_id
    and te.weekday = v_weekday
    and not c.is_disabled
  order by te.starts_at, coalesce(te.period, 1);
end;
$$;

revoke execute on function public.fn_teacher_today_overview() from public, anon;
grant  execute on function public.fn_teacher_today_overview() to authenticated;

-- Post-apply check (read-only), run as a teacher in the app, or in SQL editor
-- after impersonating one: select * from public.fn_teacher_today_overview();
