-- ============================================================================
-- phase124_1_null_safe_authorization_fix.sql
-- STATUS: NOT YET APPLIED — APPLY THIS FIRST (before phase125 / phase126).
--
-- Bug found in my phase124 while reviewing: fn_resolve_my_role() returns NULL
-- for an authenticated user who has NO role in the target school. In
--   fn_can_manage_grades      -> "... or fn_resolve_my_role(..) = 'director' ..."
--   fn_get_class_attendance   -> "... or fn_resolve_my_role(..) in ('guard','director')"
-- the whole condition became NULL, and in PL/pgSQL "if not NULL" does NOT
-- raise, so PERMISSION_DENIED was skipped. Effect: a logged-in user from
-- ANOTHER school (who also knows a class/assessment UUID) could pass the check.
-- Anonymous users are NOT affected (auth.uid() checks + revoked EXECUTE).
--
-- Fix: coalesce(..., false) around the role comparisons. Same signatures,
-- same behaviour for every legitimate caller. Privileges are preserved by
-- CREATE OR REPLACE. Rollback = re-run the previous definitions from phase124.
-- ============================================================================

begin;

create or replace function public.fn_can_manage_grades(
  p_school_id uuid,
  p_class_id uuid,
  p_subject_id uuid
) returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select auth.uid() is not null
     and exists (select 1 from public.classes c
                 where c.id = p_class_id and c.school_id = p_school_id)
     and exists (select 1 from public.subjects s
                 where s.id = p_subject_id and s.school_id = p_school_id)
     and (
          public.fn_is_school_staff(p_school_id)
       or coalesce(public.fn_resolve_my_role(p_school_id) = 'director', false)
       or public.fn_has_permission('grades.manage', p_school_id)
       or public.fn_teacher_assigned_to_class(p_class_id, p_subject_id)
     );
$$;

create or replace function public.fn_get_class_attendance(
  p_class_id uuid, p_date date default null::date
) returns table(student_id uuid, full_name text, student_number text, status text, note text)
language plpgsql
stable
security definer
set search_path to 'public'
as $function$
declare
  v_school_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select school_id into v_school_id from classes where id = p_class_id;
  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;

  if not (
    fn_is_school_staff(v_school_id)
    or fn_teacher_assigned_to_class(p_class_id)
    or fn_has_permission('attendance.view', v_school_id)
    or fn_has_permission('attendance.manage', v_school_id)
    or coalesce(fn_resolve_my_role(v_school_id) in ('guard', 'director'), false)
  ) then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select
    st.id, st.full_name, st.student_number,
    ar.status, ar.note
  from student_enrollments se
  join students st on st.id = se.student_id and st.deleted_at is null
  left join attendance_records ar
    on ar.student_id = st.id and ar.class_id = se.class_id
   and ar.att_date = coalesce(p_date, current_date)
  where se.class_id = p_class_id
    and se.status = 'ACTIVE'
  order by st.full_name;
end;
$function$;

commit;

-- Post-apply test (read-only reasoning): as a teacher/parent of school B call
-- fn_get_class_attendance(<class of school A>) -> must raise PERMISSION_DENIED.
