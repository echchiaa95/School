# واجهة الأستاذ — المراحل 124 إلى 126

## ترتيب التنفيذ في Supabase SQL Editor
1. `supabase/migrations/phase124_1_null_safe_authorization_fix.sql` — **عاجل، أولاً** (إصلاح ثغرة NULL في phase124).
2. `supabase/migrations/phase125_teacher_today_overview.sql` — دالة قراءة لحصص اليوم.
3. `supabase/migrations/phase126_teacher_class_space_lesson_log.sql` — جدول دفتر النصوص + دالتا الحفظ والعرض + دالة فضاء القسم.
4. ارفع ملفات الواجهة: `teacher.html`, `modules/school.js`, `modules/teacherConsole.js`.

`phase124_teacher_security_hardening.sql` مطبّق سابقاً في الإنتاج؛ نسخة المستودع تتضمن الإصلاح NULL-safe.

## ما أُضيف
- **المرحلة 124:** تحقق من الهوية والإسناد في دوال النقط والحضور، وسحب EXECUTE من anon/public.
- **المرحلة 125:** `fn_teacher_today_overview` — الحصة الجارية/القادمة بتوقيت المؤسسة (الافتراضي `Africa/Casablanca` إن لم يوجد عمود timezone في schools) + بطاقة اليوم في الصفحة الرئيسية.
- **المرحلة 126:** فضاء القسم (`fn_teacher_class_space`) ودفتر النصوص (`lesson_log_entries`, `fn_save_lesson_log`, `fn_list_lesson_log`).

## قواعد الأمان
- `lesson_log_entries`: RLS مفعّل، لا وصول مباشر للأستاذ؛ المدير والمدير العام (director) قراءة فقط.
- الأستاذ يكتب ويقرأ دروسه فقط في قسم ومادة مسندين إليه.
- كل التحققات تُجرى في الخادم، ومحمية من قيم NULL.

## التراجع (Rollback)
```sql
drop function public.fn_teacher_class_space(uuid);
drop function public.fn_list_lesson_log(uuid, uuid, date, date, text, int);
drop function public.fn_save_lesson_log(uuid, uuid, uuid, date, smallint, text, text, text, text, text, text, text);
drop table public.lesson_log_entries;
drop function public.fn_teacher_today_overview();
```

## حدود معروفة (لم تُنجز بعد)
- الحضور ما زال مرتبطاً باليوم وليس بالحصة (`unique(student, class, date)`)، ولا توجد حالة «مغادرة مبكرة». يتطلب تغيير مخطط على بيانات حقيقية، ومؤجل لقرار مستقل.
- لا توجد مرفقات لدفتر النصوص، ولا مقرر دراسي رسمي (لا يُخترع محتواه) فلا تظهر نسبة تغطية البرنامج.
- لا يوجد بعد: الواجبات المنزلية، الدعم التربوي، التقارير، الرسائل.
- صور التلاميذ غير معروضة في فضاء القسم.
- لم يُجرَّب `vite build` ولا SQL على قاعدة حقيقية داخل بيئة العمل؛ يلزم اختبار حسب الأدوار.
