# Phase 124 — Selected Student Payment History Fix

- Loading the student payment history is now triggered when the user clicks “تسجيل أداء لهذا الشهر” from the student's monthly fee calendar.
- The selected student UUID remains synchronized with the payment form.
- The history loader handles both legacy `payments` rows and unified ledger transactions, normalizes date/amount/note fields, and filters ledger rows by student UUID.
- Stale asynchronous responses are ignored when the selected student changes.
- After a successful payment, the existing refresh call reloads the same student's history.

No database migrations or schema changes are included.
