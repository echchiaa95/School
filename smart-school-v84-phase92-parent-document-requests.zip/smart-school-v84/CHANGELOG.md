# Phase 91 — Digital School Archive\n\n- Added private document storage, metadata register, search, temporary signed downloads, and soft archival.\n- Added an archive panel to Admin → Reports.\n- See `PHASE91_DIGITAL_SCHOOL_ARCHIVE.md` for security and validation details.\n\n# Phase 90 — School Certificates and Public Verification\n\n- Added school certificate registry, sequential numbering, immutable snapshots, cancellation, and public token verification.\n- Added Admin → Reports issuance and register UI plus a public verification page.\n- See `PHASE90_SCHOOL_CERTIFICATES_VERIFICATION.md` for scope and limitations.\n\n# Smart School v23 — Admin Runtime Cleanup

- Fixed Admin schedule crash: declared `scEditingEntryId`.
- Added class schedule preview directly under the Years & Classes list: click a class name to show its weekly timetable with Print / PDF download.
- Driver passenger ordering now re-renders from persisted server order after save, keeping ↑/↓ controls visible.
- Notifications now show clear RPC errors instead of silently appearing empty, and use Arabic type labels.
- Audit log: backfills missing `actor_id` from existing `user_id`, future audit writes set both, and the school audit reader falls back to `user_id`.
- Tightened anonymous execute access on the admin school-location RPC.
- Frontend cache bumped to v29.
- No timezone/time changes. No Phase 29/30/31 rerun.

## Phase 82 — Student Import Center (initial delivery)
- Added Excel/CSV student import entry point and guided mapping/validation/preview flow.
- Imports validated students through the existing authenticated registration RPC.
- Added downloadable Excel template and CSV error report.
- Added payment journal, unpaid-balance list, payment synthesis, date filtering, and summary-aware Excel/PDF exports.
- Replaced free-text fee and expense categories with controlled choices.
- See `PHASE82_STUDENT_IMPORT_CENTER.md` for scope, verification, and remaining migration work.

## Phase 82 — Student Import Center (initial delivery)
- Added Excel/CSV student import entry point and guided mapping/validation/preview flow.
- Imports validated students through the existing authenticated registration RPC.
- Added downloadable Excel template and CSV error report.
- Added payment journal, unpaid-balance list, payment synthesis, date filtering, and summary-aware Excel/PDF exports.
- Replaced free-text fee and expense categories with controlled choices.
- See `PHASE82_STUDENT_IMPORT_CENTER.md` for scope, verification, and remaining migration work.

## Phase 83 — Durable Institution Migration Assistant
- Added tenant-scoped migration job, batch, and row outcome persistence.
- Added server-checked migration RPCs and migration history UI.
- Connected the student import workflow to durable job and batch logging.
- Interrupted/in-flight rows are surfaced for review rather than automatically retried.
- Added Phase 83 deployment and safety notes in `PHASE83_MIGRATION_ASSISTANT.md`.

## Phase 84 — Migration Assistant and Safe Backup Transfer
- Added a dedicated institution migration assistant page in the admin dashboard.
- Added Smart School JSON backup inspection and migration with durable table-level outcomes.
- Added exact-school safe backup export/restore RPCs and tenant-bound restore validation.
- Switched backup UI to the safe RPC pair; see `PHASE84_MIGRATION_ASSISTANT.md` for scope and deployment order.


## Phase 85 — Financial Management Upgrade
- Added fee-plan configuration and server-calculated student fee quotes.
- Added reasoned, permission-controlled student discounts.
- Added audited payment correction with before/after values and correcting account attribution.
- Added finance UI for fee plans, discounts, automatic fee quote preview, correction, and audit history.
- Added `supabase/migrations/phase85_financial_management.sql`.
- See `PHASE85_FINANCIAL_MANAGEMENT.md` for deployment prerequisites and verification limits.


## Phase 86 — Multi-Run Daily Transportation
- Added recurring multi-route runs per bus/day/direction with sequence numbers and scheduled times.
- Added admin schedule configuration and driver selection for today's scheduled runs.
- Linked trips to scheduled runs and filtered the active passenger list by route.
- Parent departure notices now identify the selected run/route and target parents of pupils assigned to that route.
- Hardened direct access to the internal trip notification RPC.
- See `PHASE86_MULTI_ROUTE_TRANSPORT.md` for schedule behavior and deployment notes.


## Phase 87 — Advanced Attendance
- Added absence reasons, late-minute metadata, correction audit, and repeated-absence reporting.


## Phase 88 — Annual Student Progression
- Added controlled annual promotion/repetition, historical progression ledger, and admin workflow.


## Phase 89 — Class Councils and Final Decisions
- Added council minutes, weighted final results, and official PASS/REPEAT/REVIEW decisions with atomic batch approval.


## Phase 92 — Parent Document Requests
- Added secure parent document request workflow and school administration inbox. See `PHASE92_PARENT_DOCUMENT_REQUESTS.md`.
