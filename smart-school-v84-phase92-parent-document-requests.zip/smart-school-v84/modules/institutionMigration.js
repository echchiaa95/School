// Durable institution migration job API (Phase 83).
// Sensitive source-row values are never stored here; only row numbers,
// opaque fingerprints, target IDs and bounded outcome/error metadata.
import { supabase } from './supabase.js';

const rpc = async (name, args) => {
  const { data, error } = await supabase.rpc(name, args);
  if (error) throw new Error(error.message || `تعذر تنفيذ ${name}`);
  return data;
};

export async function createMigrationJob({ schoolId, sourceName, totalRows, metadata = {}, sourceType = 'student_import' }) {
  return rpc('fn_migration_create_job', {
    p_school_id: schoolId,
    p_source_name: sourceName,
    p_source_type: sourceType,
    p_total_rows: totalRows,
    p_metadata: metadata,
  });
}

export async function recordMigrationBatch({ jobId, batchNumber, idempotencyKey, rows }) {
  return rpc('fn_migration_record_batch', {
    p_job_id: jobId,
    p_batch_number: batchNumber,
    p_idempotency_key: idempotencyKey,
    p_rows: rows,
  });
}

export async function finishMigrationJob(jobId, forceReview = false) {
  return rpc('fn_migration_finish_job', { p_job_id: jobId, p_force_review: forceReview });
}

export async function cancelMigrationJob(jobId) {
  return rpc('fn_migration_cancel_job', { p_job_id: jobId });
}

export async function listMigrationJobs(schoolId, limit = 20) {
  return rpc('fn_migration_list_jobs', { p_school_id: schoolId, p_limit: limit });
}

export async function listMigrationRows(jobId) {
  return rpc('fn_migration_job_rows', { p_job_id: jobId });
}

const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const statusLabel = status => ({
  CREATED: 'جديد', RUNNING: 'قيد التنفيذ', COMPLETED: 'مكتمل',
  COMPLETED_WITH_ERRORS: 'مكتمل مع أخطاء', CANCELLED: 'ملغى', NEEDS_REVIEW: 'يتطلب مراجعة',
}[status] || status || '—');
const statusColor = status => status === 'COMPLETED' ? '#15803d'
  : ['COMPLETED_WITH_ERRORS','NEEDS_REVIEW'].includes(status) ? '#b45309'
  : status === 'CANCELLED' ? '#64748b' : '#1d4ed8';

export async function renderMigrationHistory(host, schoolId) {
  if (!host) return;
  host.innerHTML = '<div class="loading-state">جارٍ تحميل سجل عمليات الترحيل...</div>';
  try {
    const jobs = await listMigrationJobs(schoolId, 30);
    if (!jobs?.length) {
      host.innerHTML = '<div class="empty-state">لا توجد عمليات ترحيل سابقة لهذه المؤسسة.</div>';
      return;
    }
    host.innerHTML = `<div class="data-table-wrap"><table class="data-table">
      <thead><tr><th>الملف</th><th>الحالة</th><th>الناجح</th><th>الأخطاء</th><th>التاريخ</th><th>التفاصيل</th></tr></thead>
      <tbody>${jobs.map(j => `<tr>
        <td>${esc(j.source_name)}</td>
        <td><span style="font-weight:700;color:${statusColor(j.status)}">${esc(statusLabel(j.status))}</span></td>
        <td>${Number(j.succeeded_rows)||0} / ${Number(j.total_rows)||0}</td>
        <td>${Number(j.failed_rows)||0}</td>
        <td>${esc(j.created_at ? new Date(j.created_at).toLocaleString('ar-MA') : '—')}</td>
        <td><button type="button" class="att-btn" data-migration-detail="${esc(j.job_id)}">عرض</button></td>
      </tr>`).join('')}</tbody></table></div><div class="panel" id="migration-job-detail" hidden></div>`;
    host.querySelectorAll('[data-migration-detail]').forEach(button => button.addEventListener('click', async () => {
      const detail = host.querySelector('#migration-job-detail');
      detail.hidden = false;
      detail.innerHTML = '<div class="loading-state">جارٍ تحميل التفاصيل...</div>';
      try {
        const rows = await listMigrationRows(button.dataset.migrationDetail);
        const counts = rows.reduce((a,r) => (a[r.status]=(a[r.status]||0)+1,a), {});
        detail.innerHTML = `<h4>تفاصيل العملية</h4><div class="stats-grid">
          <div class="stat-card"><strong>${rows.length}</strong><span>السجلات المسجلة</span></div>
          <div class="stat-card"><strong>${counts.SUCCEEDED||0}</strong><span>ناجحة</span></div>
          <div class="stat-card"><strong>${counts.FAILED||0}</strong><span>فاشلة</span></div>
          <div class="stat-card"><strong>${(counts.NEEDS_REVIEW||0)+(counts.PROCESSING||0)}</strong><span>تحتاج مراجعة</span></div></div>
          <div class="data-table-wrap" style="max-height:300px;overflow:auto"><table class="data-table"><thead><tr><th>السطر</th><th>الحالة</th><th>الخطأ</th></tr></thead><tbody>
          ${rows.map(r=>`<tr><td>${r.source_row_number}</td><td>${esc(statusLabel(r.status))}</td><td>${esc(r.error_message||r.error_code||'—')}</td></tr>`).join('')}</tbody></table></div>`;
      } catch (error) { detail.textContent = error.message; }
    }));
  } catch (error) {
    host.innerHTML = `<p class="empty-state">تعذر تحميل سجل الترحيل: ${esc(error.message)}</p>`;
  }
}

// Full Smart School JSON backup migration. This uses the existing, audited
// fn_import_school_backup RPC which rebinds school_id to the destination
// institution and inserts only missing rows. It is not a generic importer
// for unrelated third-party export formats.
import { importSchoolBackup } from './school.js';

export function renderInstitutionMigrationAssistant(host, schoolId, onComplete) {
  if (!host || host.dataset.fullMigrationReady) return;
  host.dataset.fullMigrationReady = '1';
  host.innerHTML = `
    <div class="panel">
      <h3 style="margin-top:0">ترحيل مؤسسة من نسخة Smart School</h3>
      <p class="time">ارفع ملف JSON صادرًا من وحدة النسخ الاحتياطي في Smart School. سيُعاد ربط السجلات بالمؤسسة الحالية، وتُضاف السجلات غير الموجودة فقط وفق وظيفة الاسترجاع الموجودة.</p>
      <div class="form-grid">
        <div class="full"><label>ملف النسخة الاحتياطية JSON</label><input id="im-file" class="search-input" type="file" accept=".json,application/json"></div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
        <button type="button" class="quick-action-btn" id="im-inspect">فحص النسخة ومعاينتها</button>
        <a class="quick-action-btn secondary" href="./admin.html" style="text-decoration:none">العودة للإدارة</a>
      </div>
      <div id="im-status" class="time" style="margin-top:10px" aria-live="polite"></div>
    </div>
    <div class="panel" id="im-preview" hidden>
      <h3 style="margin-top:0">معاينة محتويات النسخة</h3>
      <div id="im-summary" class="stats-grid"></div>
      <div class="data-table-wrap" style="max-height:320px;overflow:auto;margin-top:10px"><table class="data-table"><thead><tr><th>الجدول</th><th>عدد السجلات</th></tr></thead><tbody id="im-tables"></tbody></table></div>
      <p class="time">تنبيه: هذه العملية مخصصة لنسخ Smart School المتوافقة. لا تستورد حسابات Auth أو حسابات أولياء الأمور/الأساتذة/السائقين، ولا تحذف البيانات الموجودة. الجداول التي لا تظهر في النسخة لن تتغير؛ راجع تقرير كل جدول بعد الترحيل.</p>
      <button type="button" class="quick-action-btn" id="im-run" style="width:100%">بدء ترحيل البيانات إلى المؤسسة الحالية</button>
      <div id="im-result" style="margin-top:10px"></div>
    </div>
    <div class="panel"><h3 style="margin-top:0">سجل عمليات الترحيل</h3><div id="im-history"></div></div>`;

  const $ = id => host.querySelector('#' + id);
  let backup = null;
  const setStatus = (message, bad=false) => { $('im-status').textContent=message; $('im-status').style.color=bad?'#b91c1c':''; };
  renderMigrationHistory($('im-history'), schoolId);

  $('im-inspect').addEventListener('click', async () => {
    const file=$('im-file').files?.[0];
    if (!file) return setStatus('اختر ملف النسخة الاحتياطية أولاً.',true);
    if (file.size>100*1024*1024) return setStatus('حجم الملف يتجاوز 100 ميغابايت.',true);
    try {
      const parsed=JSON.parse(await file.text());
      if (parsed?.app!=='smart-school' || !parsed?.tables || typeof parsed.tables!=='object' || Array.isArray(parsed.tables))
        throw new Error('الملف ليس نسخة Smart School JSON معروفة أو أن بنيته غير صالحة.');
      if (![1].includes(Number(parsed.backup_version))) throw new Error('إصدار النسخة الاحتياطية غير مدعوم.');
      const tables=Object.entries(parsed.tables).filter(([,rows])=>Array.isArray(rows)&&rows.length);
      if (!tables.length) throw new Error('لا توجد جداول تحتوي على بيانات قابلة للترحيل.');
      const records=tables.reduce((sum,[,rows])=>sum+rows.length,0);
      backup=parsed;
      $('im-summary').innerHTML=`<div class="stat-card"><strong>${tables.length}</strong><span>جداول</span></div><div class="stat-card"><strong>${records.toLocaleString('en-US')}</strong><span>سجلات مصدرية</span></div><div class="stat-card"><strong>${esc(parsed.backup_version)}</strong><span>إصدار النسخة</span></div>`;
      $('im-tables').innerHTML=tables.map(([name,rows])=>`<tr><td>${esc(name)}</td><td>${rows.length.toLocaleString('en-US')}</td></tr>`).join('');
      $('im-preview').hidden=false;
      setStatus(`النسخة صالحة للمعاينة: ${records} سجل في ${tables.length} جدول. لم يتم استيراد أي بيانات بعد.`);
    } catch(error) { backup=null; $('im-preview').hidden=true; setStatus(error.message||'تعذر فحص الملف.',true); }
  });

  $('im-run').addEventListener('click', async () => {
    if (!backup) return setStatus('افحص ملف النسخة أولاً.',true);
    if (!schoolId) return setStatus('تعذر تحديد المؤسسة الحالية.',true);
    const tableEntries=Object.entries(backup.tables).filter(([,rows])=>Array.isArray(rows)&&rows.length);
    const recordCounts=Object.fromEntries(tableEntries.map(([name,rows])=>[name,rows.length]));
    if (!confirm(`سيتم ترحيل ${Object.values(recordCounts).reduce((a,b)=>a+b,0)} سجل إلى المؤسسة الحالية. ستضاف السجلات غير الموجودة فقط. لا يمكن حذف السجلات المستوردة تلقائياً. هل تريد المتابعة؟`)) return;
    $('im-run').disabled=true; $('im-result').textContent='جارٍ إنشاء عملية الترحيل...';
    let jobId=null;
    try {
      jobId=await createMigrationJob({
        schoolId, sourceName:$('im-file').files?.[0]?.name||'smart-school-backup.json',
        sourceType:'institution_migration', totalRows:tableEntries.length,
        metadata:{workflow:'smart_school_backup_restore_v1',backup_version:backup.backup_version,source_school_id:backup.school_id||null,source_exported_at:backup.exported_at||null,record_counts:recordCounts,total_source_records:Object.values(recordCounts).reduce((a,b)=>a+b,0)}
      });
      const tableRows=tableEntries.map(([,],index)=>({row_number:index+1,status:'PROCESSING'}));
      const key=`${jobId}:backup-tables`;
      await recordMigrationBatch({jobId,batchNumber:1,idempotencyKey:key,rows:tableRows});
      const result=await importSchoolBackup(backup,schoolId);
      if (!result.ok || !result.data) throw new Error(result.error||'تعذر تنفيذ استيراد النسخة الاحتياطية.');
      const imported=result.data.results||{};
      const outcomes=tableEntries.map(([table],index)=>{
        const value=imported[table];
        if (typeof value==='number') return {row_number:index+1,status:'SUCCEEDED',error_message:`${table}: أضيف ${value} سجل. المصدر يحتوي ${recordCounts[table]} سجل.`};
        return {row_number:index+1,status:'FAILED',error_code:'TABLE_IMPORT_FAILED',error_message:String(value||'لم يرجع محرك الاستيراد نتيجة لهذا الجدول.')};
      });
      await recordMigrationBatch({jobId,batchNumber:1,idempotencyKey:key,rows:outcomes});
      const final=await finishMigrationJob(jobId,false);
      const successful=outcomes.filter(r=>r.status==='SUCCEEDED').length;
      const failed=outcomes.length-successful;
      $('im-result').innerHTML=`<div class="panel"><strong style="color:${failed?'#b45309':'#15803d'}">انتهت عملية الترحيل: ${esc(statusLabel(final?.status))}</strong><p>جداول ناجحة: ${successful} — جداول بها أخطاء: ${failed}</p><p class="time">معرف العملية: ${esc(jobId)}</p><div class="data-table-wrap"><table class="data-table"><thead><tr><th>الجدول</th><th>نتيجة الاستيراد</th></tr></thead><tbody>${tableEntries.map(([name],i)=>`<tr><td>${esc(name)}</td><td>${esc(outcomes[i].error_message||'تم الاستيراد')}</td></tr>`).join('')}</tbody></table></div></div>`;
      setStatus('اكتملت معالجة ملف النسخة الاحتياطية. راجع تفاصيل الجداول قبل اعتماد المؤسسة للعمل اليومي.');
      await renderMigrationHistory($('im-history'),schoolId);
      onComplete?.();
    } catch(error) {
      $('im-result').textContent=`توقفت العملية: ${error.message}. راجع سجل الترحيل قبل إعادة المحاولة.`;
      setStatus(error.message||'تعذر إكمال الترحيل.',true);
      if(jobId) { try { await finishMigrationJob(jobId,true); } catch(e) { console.error(e); } await renderMigrationHistory($('im-history'),schoolId); }
    } finally { $('im-run').disabled=false; }
  });
}
