// ============================================================================
// modules/auth.js
// Central authentication and role-routing service.
//
// Authentication is Email + Password via Supabase Auth ONLY.
// No PIN, no QR login, no magic link, no user-number login, no remembered
// device. The browser never trusts a role from the URL, localStorage,
// sessionStorage, or caller-provided state. The authenticated context is
// always rebuilt from Supabase Auth -> profiles -> user_roles.
// ============================================================================

import { supabase } from './supabase.js?v=21';
import { homePageForRole, isRoleAllowedOnPage, pickPrimaryRole } from './permissions.js?v=21';

const AUTH_TIMEOUT_MS = 15000;
const LOGIN_PAGE = 'index.html';

// User-safe Arabic messages — never a raw Supabase/Postgres error string.
export const AUTH_ERRORS = Object.freeze({
  INVALID_CREDENTIALS: 'البريد الإلكتروني أو كلمة المرور غير صحيحة.',
  ACCOUNT_DISABLED: 'هذا الحساب معطل.',
  NETWORK_ERROR: 'تعذر الاتصال بالخادم، حاول مرة أخرى.',
  NO_ROLE: 'لا يوجد دور صالح لهذا الحساب.',
  INVALID_INPUT: 'أدخل بريدًا إلكترونيًا وكلمة مرور صالحين.',
});

function withTimeout(promise, ms, label) {
  let timeoutId;
  const timeout = new Promise((_, reject) => {
    timeoutId = setTimeout(() => reject(new Error(`TIMEOUT: ${label}`)), ms);
  });

  return Promise.race([promise, timeout]).finally(() => clearTimeout(timeoutId));
}

function goTo(page) {
  window.location.replace(page);
}

async function signOutAndGoToLogin() {
  try {
    await withTimeout(supabase.auth.signOut(), AUTH_TIMEOUT_MS, 'signOut');
  } catch (error) {
    console.error('signOut error:', error);
  } finally {
    goTo(LOGIN_PAGE);
  }
}

/**
 * Authenticate with Email + Password via Supabase Auth.
 * Returns { ok: true } on success, or { ok: false, error } with a
 * user-safe Arabic message from AUTH_ERRORS.
 */
export async function login(email, password) {
  try {
    const normalizedEmail = typeof email === 'string' ? email.trim().toLowerCase() : '';
    if (!normalizedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      return { ok: false, error: AUTH_ERRORS.INVALID_INPUT };
    }
    if (!password || typeof password !== 'string' || password.length < 6) {
      return { ok: false, error: AUTH_ERRORS.INVALID_INPUT };
    }

    const { data, error } = await withTimeout(
      supabase.auth.signInWithPassword({ email: normalizedEmail, password }),
      AUTH_TIMEOUT_MS,
      'signInWithPassword'
    );

    if (error) {
      console.error('signInWithPassword error:', error);
      const msg = (error.message || '').toLowerCase();
      if (msg.includes('invalid login') || msg.includes('invalid credentials')) {
        return { ok: false, error: AUTH_ERRORS.INVALID_CREDENTIALS };
      }
      if (msg.includes('ban') || msg.includes('disabled')) {
        return { ok: false, error: AUTH_ERRORS.ACCOUNT_DISABLED };
      }
      return { ok: false, error: AUTH_ERRORS.INVALID_CREDENTIALS };
    }

    if (!data?.session || !data?.user) {
      return { ok: false, error: AUTH_ERRORS.INVALID_CREDENTIALS };
    }

    return { ok: true };
  } catch (error) {
    console.error('login error:', error);
    return { ok: false, error: AUTH_ERRORS.NETWORK_ERROR };
  }
}

/**
 * Send a password-recovery email via Supabase Auth.
 * The redirect always targets the ACTUAL deployed origin (never a
 * hardcoded localhost), pointing at the app's reset-password page.
 */
export async function requestPasswordReset(email) {
  try {
    const normalizedEmail = typeof email === 'string' ? email.trim().toLowerCase() : '';
    if (!normalizedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      return { ok: false, error: AUTH_ERRORS.INVALID_INPUT };
    }

    const redirectTo = `${window.location.origin}/reset-password.html`;

    const { error } = await withTimeout(
      supabase.auth.resetPasswordForEmail(normalizedEmail, { redirectTo }),
      AUTH_TIMEOUT_MS,
      'resetPasswordForEmail'
    );
    if (error) {
      console.error('resetPasswordForEmail error:', error);
      return { ok: false, error: AUTH_ERRORS.NETWORK_ERROR };
    }
    return { ok: true };
  } catch (error) {
    console.error('requestPasswordReset error:', error);
    return { ok: false, error: AUTH_ERRORS.NETWORK_ERROR };
  }
}

/**
 * Set a new password during an active recovery session
 * (the session Supabase creates from the recovery email link).
 */
export async function updatePassword(newPassword) {
  try {
    if (!newPassword || typeof newPassword !== 'string' || newPassword.length < 8) {
      return { ok: false, error: 'كلمة المرور يجب أن تكون 8 أحرف على الأقل.' };
    }

    const { error } = await withTimeout(
      supabase.auth.updateUser({ password: newPassword }),
      AUTH_TIMEOUT_MS,
      'updateUser'
    );
    if (error) {
      console.error('updateUser error:', error);
      const msg = (error.message || '').toLowerCase();
      if (msg.includes('session') || msg.includes('token')) {
        return { ok: false, error: 'انتهت صلاحية رابط الاسترجاع، اطلب رابطًا جديدًا.' };
      }
      return { ok: false, error: 'تعذر تحديث كلمة المرور، حاول مرة أخرى.' };
    }
    return { ok: true };
  } catch (error) {
    console.error('updatePassword error:', error);
    return { ok: false, error: AUTH_ERRORS.NETWORK_ERROR };
  }
}

export async function logout() {
  await signOutAndGoToLogin();
}

export async function getSession() {
  try {
    const { data, error } = await withTimeout(
      supabase.auth.getSession(),
      AUTH_TIMEOUT_MS,
      'getSession'
    );
    if (error) {
      console.error('getSession error:', error);
      return null;
    }
    return data.session ?? null;
  } catch (error) {
    console.error('getSession error:', error);
    return null;
  }
}

export async function getCurrentUser() {
  try {
    const { data, error } = await withTimeout(
      supabase.auth.getUser(),
      AUTH_TIMEOUT_MS,
      'getUser'
    );
    if (error) {
      console.error('getUser error:', error);
      return null;
    }
    return data.user ?? null;
  } catch (error) {
    console.error('getUser error:', error);
    return null;
  }
}

async function loadCurrentProfile(userId) {
  try {
    const { data, error } = await withTimeout(
      supabase
        .from('profiles')
        .select('id, full_name, phone, avatar_url, is_disabled')
        .eq('id', userId)
        .maybeSingle(),
      AUTH_TIMEOUT_MS,
      'loadCurrentProfile'
    );
    if (error) {
      console.error('loadCurrentProfile error:', error);
      return null;
    }
    return data ?? null;
  } catch (error) {
    console.error('loadCurrentProfile error:', error);
    return null;
  }
}

async function loadUserRoles(userId) {
  try {
    const { data, error } = await withTimeout(
      supabase
        .from('user_roles')
        .select('school_id, role')
        .eq('profile_id', userId),
      AUTH_TIMEOUT_MS,
      'loadUserRoles'
    );
    if (error) {
      console.error('loadUserRoles error:', error);
      return [];
    }
    return data ?? [];
  } catch (error) {
    console.error('loadUserRoles error:', error);
    return [];
  }
}

/**
 * Single source of truth for the signed-in identity and primary role.
 * Returns null for every unauthenticated, disabled, or misconfigured state.
 */
export async function getAuthenticatedContext() {
  try {
    const session = await getSession();
    if (!session?.user?.id) return null;

    const user = await getCurrentUser();
    if (!user?.id || user.id !== session.user.id) return null;

    const profile = await loadCurrentProfile(user.id);
    if (!profile || profile.is_disabled) return null;

    const roles = await loadUserRoles(user.id);
    const primary = pickPrimaryRole(roles);
    if (!primary?.role || !primary?.school_id) return null;

    return {
      session,
      user,
      profile,
      role: primary.role,
      schoolId: primary.school_id,
    };
  } catch (error) {
    console.error('getAuthenticatedContext error:', error);
    return null;
  }
}

/**
 * The current user's primary role, resolved from user_roles only.
 * Returns null when there is no valid authenticated context.
 */
export async function getCurrentUserRole() {
  const ctx = await getAuthenticatedContext();
  return ctx?.role ?? null;
}

/**
 * Post-login validation with specific, user-safe error reasons.
 * Distinguishes a disabled account from a missing/invalid role so the
 * login page can show the correct message (never a raw server error).
 * Signs the user out on any failure so no half-valid session lingers.
 * Returns { ok: true, ctx } or { ok: false, error }.
 */
export async function resolvePostLoginContext() {
  try {
    const session = await getSession();
    if (!session?.user?.id) {
      await signOutSilently();
      return { ok: false, error: AUTH_ERRORS.INVALID_CREDENTIALS };
    }

    const profile = await loadCurrentProfile(session.user.id);
    if (!profile || profile.is_disabled) {
      await signOutSilently();
      return { ok: false, error: AUTH_ERRORS.ACCOUNT_DISABLED };
    }

    const roles = await loadUserRoles(session.user.id);
    const primary = pickPrimaryRole(roles);
    if (!primary?.role || !primary?.school_id) {
      await signOutSilently();
      return { ok: false, error: AUTH_ERRORS.NO_ROLE };
    }

    return {
      ok: true,
      ctx: {
        session,
        user: session.user,
        profile,
        role: primary.role,
        schoolId: primary.school_id,
      },
    };
  } catch (error) {
    console.error('resolvePostLoginContext error:', error);
    await signOutSilently();
    return { ok: false, error: AUTH_ERRORS.NETWORK_ERROR };
  }
}

async function signOutSilently() {
  try {
    await withTimeout(supabase.auth.signOut(), AUTH_TIMEOUT_MS, 'signOut');
  } catch (error) {
    console.error('signOut error:', error);
  }
}

export async function redirectToRoleHome() {
  try {
    const ctx = await getAuthenticatedContext();
    const page = ctx ? homePageForRole(ctx.role) : null;
    if (!ctx || !page) {
      await signOutAndGoToLogin();
      return;
    }
    goTo(page);
  } catch (error) {
    console.error('redirectToRoleHome error:', error);
    await signOutAndGoToLogin();
  }
}

/**
 * Guard one role-specific page. currentPageFileName is supplied explicitly by
 * the page itself; the URL is never used to derive identity, role, or access.
 */
export async function requireAuth(currentPageFileName) {
  try {
    if (!currentPageFileName || typeof currentPageFileName !== 'string') {
      throw new Error('INVALID_PAGE_GUARD');
    }

    const ctx = await withTimeout(
      getAuthenticatedContext(),
      AUTH_TIMEOUT_MS,
      'requireAuth'
    );

    if (!ctx) {
      await signOutAndGoToLogin();
      return null;
    }

    if (!isRoleAllowedOnPage(ctx.role, currentPageFileName)) {
      const page = homePageForRole(ctx.role);
      if (page && page !== currentPageFileName) {
        goTo(page);
      } else {
        await signOutAndGoToLogin();
      }
      return null;
    }

    return ctx;
  } catch (error) {
    console.error('requireAuth error:', error);
    await signOutAndGoToLogin();
    return null;
  }
}

export function onAuthStateChange(callback) {
  return supabase.auth.onAuthStateChange((_event, session) => {
    callback(session);
  });
}
