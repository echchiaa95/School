// ============================================================================
// modules/supabase.js
// ONE Supabase client for the whole app. Every other module imports THIS.
//
// SECURITY — READ BEFORE EDITING:
// - Only SUPABASE_URL and SUPABASE_ANON_KEY belong here.
// - The anon key is DESIGNED to be public (it is shipped to every browser);
//   real protection comes from PostgreSQL Row Level Security (RLS) and the
//   SECURITY DEFINER RPC functions defined in phase2_schema.sql — not from
//   hiding this key.
// - SUPABASE_SERVICE_ROLE_KEY must NEVER appear in this file, in any other
//   file under this app, in localStorage/sessionStorage, in a URL, or
//   anywhere reachable from GitHub Pages. It only ever lives inside a
//   Supabase Edge Function's server-side environment (Phase 3 §2 / v1.1 §1).
// ============================================================================

// TODO (deployment step, not a code change): replace with your project's
// values, or better, inject them at build/deploy time so this file never
// hard-codes a specific project if the repo is public.
const SUPABASE_URL = 'https://YOUR-PROJECT-REF.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR-ANON-PUBLIC-KEY';

// supabase-js is loaded globally via the CDN script tag in every HTML page
// (see index.html) — no bundler needed, works as-is on GitHub Pages.
export const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});
