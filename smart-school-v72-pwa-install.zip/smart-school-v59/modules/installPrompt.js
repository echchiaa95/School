// ============================================================================
// modules/installPrompt.js — Phase 71
// زر "📲 حمّل التطبيق" احترافي:
// - أندرويد/كروم/إيدج: يلتقط beforeinstallprompt ويُطلق التثبيت الأصلي مباشرة.
// - آيفون (Safari): لا يوجد API للتثبيت التلقائي (قيد نظام iOS) — تظهر نافذة
//   بتعليمات مصوَّرة (خطوة بخطوة) لإضافة الأيقونة للشاشة الرئيسية يدويًا.
// - يختفي تلقائيًا إن كان التطبيق مثبَّتًا بالفعل (display-mode: standalone).
// ============================================================================

let deferredPrompt = null;
let styleInjected = false;

function isStandalone() {
  return window.matchMedia?.('(display-mode: standalone)')?.matches
    || window.navigator.standalone === true; // iOS Safari القديم
}

function isIOS() {
  return /iphone|ipad|ipod/i.test(navigator.userAgent)
    || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1); // iPadOS الحديث
}

function injectStyleOnce() {
  if (styleInjected || document.getElementById('install-prompt-style')) return;
  styleInjected = true;
  const style = document.createElement('style');
  style.id = 'install-prompt-style';
  style.textContent = `
    .install-fab{position:fixed;inset-inline-start:18px;bottom:24px;z-index:9997;display:flex;align-items:center;gap:8px;
      padding:12px 18px;border-radius:999px;border:0;cursor:pointer;font-family:var(--ss-font,inherit);font-weight:800;
      font-size:13.5px;color:#fff;background:linear-gradient(135deg,var(--ss-navy-600,#1d4265),var(--ss-navy-800,#10293f));
      box-shadow:var(--ss-shadow-lg,0 18px 48px rgba(11,31,51,.18));transition:transform .18s var(--ss-ease,ease)}
    .install-fab:hover{transform:translateY(-2px)}
    .install-fab:active{transform:scale(.95)}
    .install-fab .badge-dot{width:8px;height:8px;border-radius:50%;background:var(--ss-gold-500,#c9a227)}
    .install-overlay{position:fixed;inset:0;z-index:10002;background:rgba(11,31,51,.6);display:flex;align-items:center;
      justify-content:center;padding:16px;backdrop-filter:blur(3px)}
    .install-modal{width:min(380px,100%);max-height:88vh;overflow:auto;background:var(--ss-surface,#fff);
      border-radius:var(--ss-radius,18px);padding:22px 20px;box-shadow:var(--ss-shadow-lg,0 18px 48px rgba(11,31,51,.2));
      direction:rtl;font-family:var(--ss-font,inherit);text-align:center}
    .install-modal .app-icon{width:72px;height:72px;border-radius:20px;margin:0 auto 12px;display:block;
      box-shadow:0 8px 20px rgba(11,31,51,.25)}
    .install-modal h3{margin:0 0 4px;font-size:18px;color:var(--ss-navy-700,#16334e)}
    .install-modal p.sub{margin:0 0 16px;color:var(--ss-muted,#5b6b7c);font-size:13px}
    .install-steps{text-align:start;background:#f8fafc;border-radius:12px;padding:14px 16px;margin-bottom:16px}
    .install-steps li{margin-bottom:10px;font-size:13.5px;line-height:1.6;color:var(--ss-ink,#14212e)}
    .install-steps li:last-child{margin-bottom:0}
    .install-steps b{color:var(--ss-navy-700,#16334e)}
    .install-primary-btn{width:100%;padding:12px;border-radius:var(--ss-radius,16px);border:0;font-weight:800;
      font-size:14.5px;color:#fff;cursor:pointer;background:linear-gradient(135deg,var(--ss-navy-700,#16334e),var(--ss-navy-500,#25517b));
      margin-bottom:8px}
    .install-close-btn{width:100%;padding:10px;border-radius:var(--ss-radius-sm,10px);border:0;background:var(--ss-bg,#eef2f7);
      color:var(--ss-navy-700,#16334e);font-weight:700;cursor:pointer;font-size:13.5px}
  `;
  document.head.appendChild(style);
}

function buildModal({ showInstallBtn, onInstallClick }) {
  const overlay = document.createElement('div');
  overlay.className = 'install-overlay';
  const iosSteps = `
    <ol class="install-steps">
      <li>1️⃣ اضغط على زر <b>المشاركة</b> ⬆️ أسفل شاشة Safari</li>
      <li>2️⃣ اختر <b>"إضافة إلى الشاشة الرئيسية"</b> (Add to Home Screen)</li>
      <li>3️⃣ اضغط <b>"إضافة"</b> أعلى الشاشة — ستظهر الأيقونة كتطبيق عادي 🎉</li>
    </ol>`;
  const androidSteps = `
    <ol class="install-steps">
      <li>1️⃣ اضغط الزر أدناه لبدء التثبيت</li>
      <li>2️⃣ أكِّد بالضغط على <b>"تثبيت"</b> في النافذة التي تظهر</li>
      <li>3️⃣ ستظهر الأيقونة في قائمة تطبيقاتك مباشرة 🎉</li>
    </ol>`;
  overlay.innerHTML = `
    <div class="install-modal" role="dialog" aria-modal="true">
      <img class="app-icon" src="assets/icons/icon-192.png" alt="أيقونة التطبيق">
      <h3>تثبيت التطبيق</h3>
      <p class="sub">أضف المنصة كتطبيق مستقل على هاتفك — وصول أسرع وتجربة أفضل.</p>
      ${showInstallBtn ? androidSteps : iosSteps}
      ${showInstallBtn ? '<button type="button" class="install-primary-btn" id="install-do-btn">📲 تثبيت الآن</button>' : ''}
      <button type="button" class="install-close-btn" id="install-close-btn">إغلاق</button>
    </div>`;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  overlay.querySelector('#install-close-btn').addEventListener('click', () => overlay.remove());
  overlay.querySelector('#install-do-btn')?.addEventListener('click', async () => {
    overlay.remove();
    await onInstallClick?.();
  });
}

/** يُسجِّل sw.js بصمت إن لم يكن مسجَّلًا بعد — شرط أساسي لدى Chrome/Android
 *  لإطلاق beforeinstallprompt، بمعزل عن اشتراك الإشعارات (pushNotifications.js
 *  يُسجِّل نفس الملف لاحقًا عند التفعيل — التسجيل المتكرر لنفس النطاق آمن). */
function ensureServiceWorkerRegistered() {
  if (!('serviceWorker' in navigator)) return;
  navigator.serviceWorker.register('./sw.js', { scope: './' }).catch(() => { /* غير حرج لعمل الصفحة */ });
}

/** يُدرج زر "تحميل التطبيق" في الصفحة إن كان التثبيت ممكنًا/مفيدًا. */
export function mountInstallPrompt() {
  ensureServiceWorkerRegistered();
  if (isStandalone()) return; // مثبَّت بالفعل — لا داعي للزر
  if (document.getElementById('install-fab-btn')) return;

  injectStyleOnce();

  const fab = document.createElement('button');
  fab.id = 'install-fab-btn';
  fab.className = 'install-fab';
  fab.type = 'button';
  fab.innerHTML = '<span class="badge-dot"></span> 📲 حمّل التطبيق';

  fab.addEventListener('click', () => {
    buildModal({
      showInstallBtn: !!deferredPrompt && !isIOS(),
      onInstallClick: async () => {
        if (!deferredPrompt) return;
        deferredPrompt.prompt();
        try { await deferredPrompt.userChoice; } catch { /* تجاهل */ }
        deferredPrompt = null;
        fab.remove();
      },
    });
  });

  document.body.appendChild(fab);

  window.addEventListener('appinstalled', () => { fab.remove(); });
}

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
});
