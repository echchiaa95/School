import { requireAuth, logout } from './auth.js?v=30';
import {
  el, esc, fmtDate, fmtDateTime, fmtTime, toast, confirmDialog,
  loadingHtml, emptyHtml, errorHtml, initPageHeader, showView, statCard,
  armViewHistory, armErrorBoundary, showInitError,
} from './ui.js?v=30';
import {
  driverContext, getActiveTrip, startTrip, endTrip, recordTripEvent,
  listBusStudentsOrdered, setDriverPassengerOrder, listRoutes, myTrips, getSchoolProfile, driverLookupBadge, isDebug,
} from './school.js?v=30';
import { startGpsTracking, stopGpsTracking, onGpsStatus, isGpsTracking, probeGps } from './gps.js?v=30';
import { startQrScanner, stopQrScanner } from './qrScanner.js?v=30';

let ctx = null;
let dctx = null;       // fn_driver_context jsonb
let activeTrip = null; // fn_get_active_trip jsonb
let busStudents = [];
let passengerOrderMode = true;
const dbg = (...a) => { if (isDebug()) console.log(...a); };

const DIRECTION_AR = { pickup: 'ذهاب', dropoff: 'عودة' };

// ---- Bus + trip state -------------------------------------------------------
async function loadContext() {
  const busCard = el('bus-card');
  const res = await driverContext();
  if (!res.ok) { busCard.innerHTML = errorHtml(res.error); return false; }
  dctx = res.data;
  if (!dctx) {
    busCard.innerHTML = errorHtml('لا يوجد ملف سائق مرتبط بهذا الحساب. تواصل مع إدارة المؤسسة.');
    return false;
  }
  if (!dctx.bus_id) {
    busCard.innerHTML = `<div class="panel">
      <div class="empty-state">لم يتم إسناد حافلة إليك بعد. تواصل مع إدارة المؤسسة.</div>
    </div>`;
    return false;
  }
  busCard.innerHTML = `<div class="panel">
    <div class="detail-row"><strong>الحافلة</strong><span>${esc(dctx.bus_code || '—')}</span></div>
    <div class="detail-row"><strong>اللوحة</strong><span>${esc(dctx.bus_plate || '—')}</span></div>
    <div class="detail-row"><strong>السعة</strong><span>${dctx.bus_capacity ?? '—'}</span></div>
  </div>`;
  return true;
}

async function refreshTrip() {
  const res = await getActiveTrip();
  activeTrip = res.ok ? res.data : null;
  const startPanel = el('trip-start-panel');
  const activePanel = el('trip-active-panel');
  if (activeTrip) {
    startPanel.hidden = true;
    activePanel.hidden = false;
    el('trip-info').innerHTML = `
      <div class="detail-row"><strong>المسار</strong><span>${esc(activeTrip.route_name || 'بدون مسار')}</span></div>
      <div class="detail-row"><strong>الاتجاه</strong><span>${DIRECTION_AR[activeTrip.direction] || esc(activeTrip.direction)}</span></div>
      <div class="detail-row"><strong>بدأت في</strong><span>${fmtDateTime(activeTrip.started_at)}</span></div>
      <div class="detail-row"><strong>الأحداث المسجلة</strong><span>${(activeTrip.events || []).length}</span></div>`;
    // item 25: resume tracking if the page was reloaded mid-trip; never
    // start it for any other reason.
    if (!isGpsTracking()) startGpsTracking(activeTrip.trip_id);
  } else {
    startPanel.hidden = false;
    activePanel.hidden = true;
    stopGpsTracking();
  }
  await loadBusStudents();
}

function renderGpsStatus(status) {
  const host = el('gps-status');
  if (!host) return;
  if (status.state === 'active') {
    host.innerHTML = `<span class="badge badge-green">🟢 GPS نشط</span>
      <span class="time">آخر تحديث: ${fmtTime(status.recordedAt)}${status.accuracy ? ` · دقة ~${Math.round(status.accuracy)}م` : ''}</span>`;
  } else if (status.state === 'error') {
    host.innerHTML = `<span class="badge badge-red">🔴 GPS غير متاح</span> <span class="time">${esc(status.message || '')}</span>`;
  } else {
    host.innerHTML = '';
  }
}
onGpsStatus(renderGpsStatus);

async function loadRoutesInto() {
  const select = el('trip-route');
  const res = await listRoutes();
  const routes = res.ok ? (res.data || []) : [];
  select.innerHTML = '<option value="">بدون مسار محدد</option>'
    + routes.filter((r) => r.is_active !== false)
      .map((r) => `<option value="${r.id}">${esc(r.name)}</option>`).join('');
}

function mapsLink(lat, lng) {
  return (lat != null && lng != null) ? `https://www.google.com/maps?q=${lat},${lng}` : null;
}

function renderTripCounts() {
  const host = el('trip-counts');
  if (!host) return;
  if (!activeTrip || !busStudents.length) { host.innerHTML = ''; return; }
  const total = busStudents.length;
  const boarded = busStudents.filter((s) => s.boarded_at).length;
  const dropped = busStudents.filter((s) => s.alighted_at).length;
  const notBoarded = total - boarded;
  host.innerHTML = statCard(total, 'العدد الكلي')
    + statCard(boarded, 'صعد', 'tone-green')
    + statCard(notBoarded, 'لم يصعد', notBoarded ? 'tone-gold' : '')
    + statCard(dropped, 'نزل', 'tone-green');
  if (total > 0 && dropped === total) {
    host.innerHTML += `<div class="full" style="grid-column:1/-1; text-align:center; margin-top:6px;"><span class="badge badge-green">✅ الرحلة مكتملة</span></div>`;
  }
}

function renderBusStudentsHost() {
  const host = el('bus-students');
  if (!host) return;
  if (!busStudents.length) {
    host.innerHTML = emptyHtml('لا يوجد تلاميذ مسندون إلى هذه الحافلة.');
    renderTripCounts();
    return;
  }
  host.innerHTML = busStudents.map((s, i) => {
    const boarded = !!s.boarded_at;
    const alighted = !!s.alighted_at;
    const lat = s.student_latitude ?? s.stop_latitude;
    const lng = s.student_longitude ?? s.stop_longitude;
    const mapUrl = mapsLink(lat, lng);
    return `<div class="detail-row passenger-row" data-passenger-id="${s.student_id}" style="flex-wrap:wrap; gap:6px;">
      <div class="passenger-order-controls" style="display:flex!important;visibility:visible!important;" aria-label="تغيير ترتيب الراكب"><button type="button" class="order-move-btn" data-order="up" data-student="${s.student_id}" ${i===0?'disabled':''}>↑</button><button type="button" class="order-move-btn" data-order="down" data-student="${s.student_id}" ${i===busStudents.length-1?'disabled':''}>↓</button></div>
      <div style="flex:1; min-width:150px;">
        <strong>${i + 1} — ${esc(s.full_name)}</strong>
        <div style="font-size:.8em; color:var(--muted);">${esc(s.student_number || '')} · صعود: ${esc(s.pickup_stop || '—')} · نزول: ${esc(s.dropoff_stop || '—')}</div>
        ${mapUrl ? `<a href="${mapUrl}" target="_blank" rel="noopener" style="font-size:.8em;">📍 فتح الموقع في Google Maps</a>` : ''}
      </div>
      ${boarded ? `<span class="badge badge-green">صعد ${fmtTime(s.boarded_at)}</span>` : ''}
      ${alighted ? `<span class="badge badge-blue">نزل ${fmtTime(s.alighted_at)}</span>` : ''}
      ${activeTrip ? `
        ${!boarded ? `<button type="button" class="att-btn" data-act="board" data-student="${s.student_id}">تسجيل الصعود</button>` : ''}
        ${boarded && !alighted ? `<button type="button" class="att-btn" data-act="alight" data-student="${s.student_id}">تسجيل النزول</button>` : ''}
      ` : ''}
    </div>`;
  }).join('');

  host.querySelectorAll('[data-order]').forEach((b) => b.addEventListener('click', () => {
    const i = busStudents.findIndex((x) => x.student_id === b.dataset.student);
    if (i < 0) return;
    const j = b.dataset.order === 'up' ? i - 1 : i + 1;
    if (j < 0 || j >= busStudents.length) return;
    [busStudents[i], busStudents[j]] = [busStudents[j], busStudents[i]];
    renderBusStudentsHost();
  }));

  host.querySelectorAll('[data-act]').forEach((b) => {
    b.addEventListener('click', async () => {
      const tripId = activeTrip?.trip_id;
      const studentId = b.dataset.student;
      const action = b.dataset.act;
      if (!tripId || !studentId) { toast('لا توجد رحلة نشطة حاليًا.', 'error'); return; }
      b.disabled = true;
      dbg(`[DRIVER ${action === 'board' ? 'BOARD' : 'ALIGHT'}] trip=${tripId} student=${studentId}`);
      try {
        const res = await recordTripEvent(tripId, studentId, action);
        if (!res.ok) { dbg('[DRIVER TRIP ERROR]', res.error, res.kind || ''); toast(res.error, 'error'); return; }
        toast(action === 'board' ? 'تم تسجيل الصعود' : 'تم تسجيل النزول', 'success');
        await refreshTrip();
      } finally {
        if (b.isConnected) b.disabled = false;
      }
    });
  });
  renderTripCounts();
}

async function loadBusStudents() {
  const host = el('bus-students');
  const summary = el('route-summary');
  if (!dctx?.bus_id) { host.innerHTML = emptyHtml('لا توجد حافلة مسندة.'); summary.hidden = true; return; }
  host.innerHTML = loadingHtml();
  summary.hidden = false;
  summary.innerHTML = `
    <div class="detail-row"><span class="k">الحافلة</span><span class="v">${esc(dctx.bus_code || '—')}</span></div>
    <div class="detail-row"><span class="k">رقم اللوحة</span><span class="v">${esc(dctx.bus_plate || '—')}</span></div>
    <div class="detail-row"><span class="k">المسار</span><span class="v">${esc(activeTrip?.route_name || 'بدون مسار محدد')}</span></div>
    <div class="detail-row"><span class="k">الاتجاه</span><span class="v">${activeTrip ? (DIRECTION_AR[activeTrip.direction] || esc(activeTrip.direction)) : '—'}</span></div>
    <div class="detail-row"><span class="k">التاريخ</span><span class="v">${fmtDate(activeTrip?.started_at || new Date())}</span></div>`;
  const res = await listBusStudentsOrdered(dctx.bus_id, activeTrip?.trip_id || null);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  busStudents = res.data || [];
  renderBusStudentsHost();
}

const orderToggle = el('passenger-order-toggle');
const orderSave = el('passenger-order-save');
const orderHelp = el('passenger-order-help');
if (orderToggle) orderToggle.style.display = 'none';
if (orderHelp) orderHelp.hidden = false;
if (orderSave) orderSave.addEventListener('click', async () => {
  if (!dctx?.bus_id) return;
  orderSave.disabled = true;
  try {
    const res = await setDriverPassengerOrder(dctx.bus_id, busStudents.map((s) => s.student_id));
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast('تم حفظ ترتيب الركاب.', 'success');
    // Re-render from the server after save so the ordering controls remain
    // visible and the displayed order is the persisted order.
    await loadBusStudents();
  } finally { orderSave.disabled = false; }
});

// ---- QR scan (item 11-13, 26): server-side membership check via
// fn_driver_lookup_badge — the driver never gets raw student/badge table
// access, only what belongs to their own active trip. ----------------------
function renderScanResult(student) {
  const host = el('scan-result');
  const boarded = !!student.boarded_at;
  const dropped = !!student.dropped_at;
  host.innerHTML = `<div class="panel">
    <div style="display:flex; gap:10px; align-items:center;">
      <div class="avatar">${student.photo_url ? `<img src="${esc(student.photo_url)}" alt="">` : '👤'}</div>
      <div><strong>${esc(student.full_name)}</strong><div class="time">${esc(student.student_number || '')} — ${esc(student.class_name || '')}</div></div>
    </div>
    <div style="margin-top:10px;">
      ${boarded ? `<span class="badge badge-green">صعد ${fmtTime(student.boarded_at)}</span>` : '<span class="badge">⚪ لم يصعد</span>'}
      ${dropped ? `<span class="badge badge-blue">نزل ${fmtTime(student.dropped_at)}</span>` : ''}
    </div>
    <div style="display:flex; gap:8px; margin-top:10px;">
      ${!boarded ? `<button type="button" class="quick-action-btn" id="scan-board-btn" style="flex:1;">تسجيل الصعود</button>` : ''}
      ${boarded && !dropped ? `<button type="button" class="quick-action-btn secondary" id="scan-alight-btn" style="flex:1;">تسجيل النزول</button>` : ''}
    </div>
  </div>`;
  if (!boarded) el('scan-board-btn').addEventListener('click', () => doTripAction(student.trip_id, student.student_id, 'board', () => startScan()));
  if (boarded && !dropped) el('scan-alight-btn').addEventListener('click', () => doTripAction(student.trip_id, student.student_id, 'alight', () => startScan()));
}

async function doTripAction(tripId, studentId, action, afterOk) {
  dbg(`[DRIVER ${action === 'board' ? 'BOARD' : 'ALIGHT'}] trip=${tripId} student=${studentId}`);
  const res = await recordTripEvent(tripId, studentId, action);
  if (!res.ok) { dbg('[DRIVER TRIP ERROR]', res.error, res.kind || ''); toast(res.error, 'error'); return; }
  dbg('[DRIVER TRIP] event recorded');
  toast(action === 'board' ? 'تم تسجيل الصعود' : 'تم تسجيل النزول', 'success');
  await refreshTrip();
  afterOk && afterOk();
}

function startScan() {
  const qrError = el('qr-error');
  qrError.hidden = true;
  el('scan-result').innerHTML = '';
  startQrScanner(
    el('qr-video'), el('qr-canvas'),
    async (decodedText) => {
      const res = await driverLookupBadge(decodedText.trim());
      if (!res.ok) {
        el('scan-result').innerHTML = `<div class="empty-state" style="color:#dc2626;">${esc(res.error)}</div>`;
        setTimeout(startScan, 1500); // resume scanning after showing the error briefly
        return;
      }
      renderScanResult(res.data);
    },
    (reason) => {
      qrError.hidden = false;
      qrError.textContent = reason === 'PERMISSION_DENIED' ? 'تم رفض إذن الكاميرا.' : 'الكاميرا غير متوفرة على هذا الجهاز.';
    }
  );
}

// ---- Manual selection (item 14): restricted to the CURRENT trip roster
// (busStudents), which fn_list_bus_students_ordered already scopes to this
// driver's own bus — never the whole school's students. ---------------------
function renderManualList(filter = '') {
  const host = el('manual-list');
  const q = filter.trim().toLowerCase();
  const rows = busStudents.filter((s) => !q || s.full_name.toLowerCase().includes(q) || (s.student_number || '').includes(q));
  host.innerHTML = rows.length
    ? rows.map((s) => `<div class="history-item" data-pick="${s.student_id}" style="cursor:pointer;">
        <div class="avatar">${s.photo_url ? `<img src="${esc(s.photo_url)}" alt="">` : '👤'}</div>
        <div style="flex:1;"><strong>${esc(s.full_name)}</strong><div class="time">${esc(s.student_number || '')} · ${esc(s.pickup_stop || '')}</div></div>
        ${s.boarded_at ? '<span class="badge badge-green">صعد</span>' : ''}${s.alighted_at ? '<span class="badge badge-blue">نزل</span>' : ''}
      </div>`).join('')
    : emptyHtml('لا يوجد تلاميذ مطابقون.');
  host.querySelectorAll('[data-pick]').forEach((it) => it.addEventListener('click', () => {
    const s = busStudents.find((x) => x.student_id === it.dataset.pick);
    if (s) renderManualSelected(s);
  }));
}

function renderManualSelected(s) {
  const host = el('manual-selected');
  const boarded = !!s.boarded_at;
  const dropped = !!s.alighted_at;
  host.innerHTML = `<div class="panel">
    <div style="display:flex; gap:10px; align-items:center;">
      <div class="avatar">${s.photo_url ? `<img src="${esc(s.photo_url)}" alt="">` : '👤'}</div>
      <div><strong>${esc(s.full_name)}</strong><div class="time">${esc(s.student_number || '')} · نقطة التوقف: ${esc(s.pickup_stop || '—')}</div></div>
    </div>
    <div style="margin-top:8px;">
      ${boarded ? `<span class="badge badge-green">صعد ${fmtTime(s.boarded_at)}</span>` : '<span class="badge">⚪ لم يصعد</span>'}
      ${dropped ? `<span class="badge badge-blue">نزل ${fmtTime(s.alighted_at)}</span>` : ''}
    </div>
    <div style="display:flex; gap:8px; margin-top:10px;">
      ${!boarded ? `<button type="button" class="quick-action-btn" id="manual-board-btn" style="flex:1;">تسجيل الصعود</button>` : ''}
      ${boarded && !dropped ? `<button type="button" class="quick-action-btn secondary" id="manual-alight-btn" style="flex:1;">تسجيل النزول</button>` : ''}
    </div>
  </div>`;
  if (!boarded) el('manual-board-btn').addEventListener('click', () => doTripAction(activeTrip.trip_id, s.student_id, 'board', () => { renderManualList(el('manual-search').value); host.innerHTML = ''; }));
  if (boarded && !dropped) el('manual-alight-btn').addEventListener('click', () => doTripAction(activeTrip.trip_id, s.student_id, 'alight', () => { renderManualList(el('manual-search').value); host.innerHTML = ''; }));
}

async function loadHistory() {
  const host = el('trips-list');
  host.innerHTML = loadingHtml();
  const res = await myTrips(30);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد رحلات سابقة.'); return; }
  host.innerHTML = `<div class="data-table-wrap"><table class="data-table"><thead><tr>
    <th>التاريخ</th><th>الاتجاه</th><th>المسار</th><th>الحالة</th><th>البداية</th><th>النهاية</th><th>الأحداث</th>
  </tr></thead><tbody>${rows.map((t) => `<tr>
    <td>${fmtDate(t.trip_date)}</td>
    <td>${DIRECTION_AR[t.direction] || esc(t.direction || '—')}</td>
    <td>${esc(t.route_name || '—')}</td>
    <td><span class="badge ${t.status === 'completed' ? 'badge-green' : t.status === 'active' ? 'badge-gold' : 'badge-red'}">${
      t.status === 'completed' ? 'مكتملة' : t.status === 'active' ? 'نشطة' : 'ملغاة'}</span></td>
    <td>${fmtTime(t.started_at)}</td>
    <td>${t.ended_at ? fmtTime(t.ended_at) : '—'}</td>
    <td>${t.events_count ?? 0}</td>
  </tr>`).join('')}</tbody></table></div>`;
}

// ---- Init -------------------------------------------------------------------
(async () => {
  try {
    armErrorBoundary();
    ctx = await requireAuth('driver.html');
    if (!ctx) return;
    armViewHistory('home');
    document.getElementById('app-body').hidden = false;

    const schoolRes = await getSchoolProfile(ctx.schoolId);
    await initPageHeader(ctx, schoolRes.ok ? schoolRes.data?.name : null, logout);

    document.querySelectorAll('[data-go]').forEach((b) => {
      b.addEventListener('click', () => {
        showView(b.dataset.go);
        if (b.dataset.go === 'history') loadHistory();
      });
    });
    document.querySelectorAll('[data-back]').forEach((b) => {
      b.addEventListener('click', () => showView('home'));
    });

    el('trip-start').addEventListener('click', async () => {
      const gate = el('gps-required-panel');
      gate.hidden = true;
      el('trip-start').disabled = true;
      // Phase 25 §15: GPS is MANDATORY — a trip that cannot be tracked is
      // never started. OS/browser permission can never be bypassed; we only
      // refuse to start without it and show how to fix it.
      const probe = await probeGps();
      if (!probe.ok) {
        el('trip-start').disabled = false;
        gate.hidden = false;
        return;
      }
      const res = await startTrip(el('trip-route').value || null, el('trip-direction').value);
      el('trip-start').disabled = false;
      if (!res.ok) { toast(res.error, 'error'); return; }
      toast('بدأت الرحلة', 'success');
      refreshTrip(); // ACTIVE-trip resume logic starts watchPosition (§16)
    });
    el('gps-retry').addEventListener('click', () => el('trip-start').click());
    el('gps-settings').addEventListener('click', () =>
      toast('فعّل الموقع من إعدادات المتصفح/الهاتف ثم اضغط إعادة المحاولة.', 'info'));

    el('trip-end').addEventListener('click', async () => {
      if (!activeTrip) return;
      const ok = await confirmDialog('هل تريد إنهاء الرحلة الحالية؟');
      if (!ok) return;
      const res = await endTrip(activeTrip.trip_id);
      if (!res.ok) { toast(res.error, 'error'); return; }
      toast('انتهت الرحلة', 'success');
      refreshTrip();
    });

    el('open-scan-btn').addEventListener('click', () => { showView('scan'); startScan(); });
    el('scan-back').addEventListener('click', () => { stopQrScanner(); showView('home'); });
    el('open-manual-btn').addEventListener('click', () => {
      showView('manual');
      el('manual-search').value = '';
      el('manual-selected').innerHTML = '';
      renderManualList('');
    });
    el('manual-search').addEventListener('input', (e) => renderManualList(e.target.value));

    const ok = await loadContext();
    if (ok) {
      await loadRoutesInto();
      await refreshTrip();
    }
  } catch (error) {
    console.error('driver console init error:', error);
    showInitError(error);
  }
})();
