// ============================================================================
// modules/students.js
// PHASE 4 — data access for the Guard console.
//
// Every query here goes through the SAME `supabase` client used everywhere
// else in the app (modules/supabase.js, untouched). Real authorization is
// still entirely enforced by Postgres RLS (phase2_schema.sql): a guard can
// only ever see students/badges/status rows within their own school,
// exactly as already defined — nothing here grants new access, it just
// reads what RLS already allows for the 'guard' role.
//
// This module intentionally selects ONLY the fields the Guard console
// needs to display (name, photo, class, enrollment/status) — it never
// fetches address/latitude/longitude/phone/financial data, even though
// some of those are technically visible to guard/admin elsewhere in the
// schema. "Don't expose sensitive data the screen doesn't need" is a
// UI-level discipline on top of RLS, not a replacement for it.
// ============================================================================

import { supabase } from './supabase.js?v=30';

/** @typedef {'AUTHORIZED'|'UNAUTHORIZED'|'ABSENT_INACTIVE'|'UNKNOWN_ERROR'} CheckResult */

/**
 * Classify a resolved student into the four Guard-console outcomes and
 * shape a small, display-ready object. Never includes sensitive fields.
 */
export function classifyStudent(student, badgeStatus, enrollment) {
  if (student.deleted_at) {
    return { resultType: 'UNAUTHORIZED', reason: 'STUDENT_INACTIVE', student: null };
  }
  if (badgeStatus && badgeStatus !== 'ACTIVE') {
    return { resultType: 'UNAUTHORIZED', reason: 'BADGE_' + badgeStatus, student: null };
  }
  if (!enrollment || enrollment.status !== 'ACTIVE') {
    return {
      resultType: 'ABSENT_INACTIVE',
      reason: 'NO_ACTIVE_ENROLLMENT',
      student: {
        id: student.id,
        fullName: student.full_name,
        studentNumber: student.student_number,
        photoUrl: student.photo_url,
        className: null,
        level: null,
      },
    };
  }
  return {
    resultType: 'AUTHORIZED',
    reason: null,
    student: {
      id: student.id,
      fullName: student.full_name,
      studentNumber: student.student_number,
      photoUrl: student.photo_url,
      className: enrollment.classes?.name ?? null,
      level: enrollment.classes?.level ?? null,
    },
  };
}

async function fetchActiveEnrollment(studentId) {
  const { data, error } = await supabase
    .from('student_enrollments')
    .select('status, classes(name, level)')
    .eq('student_id', studentId)
    .eq('status', 'ACTIVE')
    .maybeSingle();
  if (error) {
    console.error('fetchActiveEnrollment error:', error);
    return null;
  }
  return data;
}

async function fetchCurrentStatus(studentId) {
  const { data, error } = await supabase
    .from('student_status')
    .select('status, activity, updated_at')
    .eq('student_id', studentId)
    .maybeSingle();
  if (error) {
    console.error('fetchCurrentStatus error:', error);
    return null;
  }
  return data;
}

/**
 * Resolve a scanned badge token to a display-ready result.
 * @param {string} token - decoded QR text (expected to be the badge's secure_token UUID)
 * @returns {Promise<{resultType: CheckResult, reason: string|null, student: object|null}>}
 */
export async function lookupByBadgeToken(token) {
  try {
    const { data: badge, error: badgeError } = await supabase
      .from('student_badges')
      .select('status, student_id, students(id, full_name, student_number, photo_url, deleted_at)')
      .eq('secure_token', token)
      .maybeSingle();

    if (badgeError) {
      console.error('lookupByBadgeToken badge error:', badgeError);
      return { resultType: 'UNKNOWN_ERROR', reason: 'LOOKUP_FAILED', student: null };
    }
    if (!badge || !badge.students) {
      return { resultType: 'UNKNOWN_ERROR', reason: 'UNKNOWN_BADGE', student: null };
    }

    const student = badge.students;
    const enrollment = await fetchActiveEnrollment(student.id);
    const result = classifyStudent(student, badge.status, enrollment);

    if (result.resultType === 'AUTHORIZED') {
      const status = await fetchCurrentStatus(student.id);
      result.liveStatus = status; // { status, activity, updated_at } | null — informational only
    }
    return { ...result, studentId: student.id };
  } catch (err) {
    console.error('lookupByBadgeToken unexpected error:', err);
    return { resultType: 'UNKNOWN_ERROR', reason: 'UNEXPECTED', student: null };
  }
}

/**
 * Same classification, but starting from an already-known student_id
 * (used by manual search results, where we already have the row).
 */
export async function lookupByStudentId(studentId) {
  try {
    const { data: student, error: studentError } = await supabase
      .from('students')
      .select('id, full_name, student_number, photo_url, deleted_at')
      .eq('id', studentId)
      .maybeSingle();

    if (studentError || !student) {
      return { resultType: 'UNKNOWN_ERROR', reason: 'UNKNOWN_STUDENT', student: null, studentId };
    }

    const { data: badge } = await supabase
      .from('student_badges')
      .select('id, status')
      .eq('student_id', studentId)
      .eq('status', 'ACTIVE')
      .maybeSingle();

    const enrollment = await fetchActiveEnrollment(studentId);
    const result = classifyStudent(student, badge?.status ?? null, enrollment);
    result.activeBadgeId = badge?.id ?? null; // NEW: used by badge management actions

    if (result.resultType === 'AUTHORIZED') {
      const status = await fetchCurrentStatus(studentId);
      result.liveStatus = status;
    }
    return { ...result, studentId };
  } catch (err) {
    console.error('lookupByStudentId unexpected error:', err);
    return { resultType: 'UNKNOWN_ERROR', reason: 'UNEXPECTED', student: null, studentId };
  }
}

/**
 * Manual search by name or student number. Returns lightweight rows for a
 * result list — full detail is fetched via lookupByStudentId() on tap.
 */
export async function searchStudents(query) {
  const trimmed = query.trim();
  if (!trimmed) return [];

  const { data, error } = await supabase
    .from('students')
    .select('id, full_name, student_number, photo_url')
    .is('deleted_at', null)
    .or(`full_name.ilike.%${trimmed}%,student_number.ilike.%${trimmed}%`)
    .order('full_name')
    .limit(20);

  if (error) {
    console.error('searchStudents error:', error);
    return [];
  }
  return data || [];
}

/**
 * Log one control check for the Guard's history (Phase 4 §8).
 * Best-effort: a logging failure never blocks the guard from seeing the
 * result they already have on screen.
 */
export async function logGuardCheck({ schoolId, studentId, method, result }) {
  const { error } = await supabase.from('guard_checks').insert({
    school_id: schoolId,
    student_id: studentId ?? null,
    method,
    result,
  });
  if (error) {
    console.error('logGuardCheck error:', error);
  }
}

/**
 * Recent checks performed by ANY guard/admin at this school (for the
 * history list). Joins in just enough student info to display a name.
 */
export async function getRecentChecks(limit = 15) {
  const { data, error } = await supabase
    .from('guard_checks')
    .select('id, method, result, created_at, students(full_name, student_number)')
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) {
    console.error('getRecentChecks error:', error);
    return [];
  }
  return data || [];
}

// ============================================================================
// PHASE 4.1 additions below. Same file, same client, same RLS — no new RPC,
// no new table. Reuses classifyStudent() so the roster/class views and the
// scan/search detail views can never disagree about a student's status.
// ============================================================================

/**
 * Classes for the current academic year (falls back to all classes if no
 * academic_years row is marked is_current — defensive, shouldn't normally
 * happen), each annotated with its ACTIVE-enrollment student count.
 * Two queries total, not one-per-class.
 */
export async function listClasses() {
  let yearId = null;
  const { data: year } = await supabase
    .from('academic_years')
    .select('id')
    .eq('is_current', true)
    .maybeSingle();
  if (year) yearId = year.id;

  let classQuery = supabase.from('classes').select('id, name, level, academic_year_id').order('name');
  if (yearId) classQuery = classQuery.eq('academic_year_id', yearId);

  const { data: classes, error: classesError } = await classQuery;
  if (classesError || !classes || classes.length === 0) {
    if (classesError) console.error('listClasses error:', classesError);
    return [];
  }

  const classIds = classes.map((c) => c.id);
  const { data: enrollments, error: enrollError } = await supabase
    .from('student_enrollments')
    .select('class_id')
    .eq('status', 'ACTIVE')
    .in('class_id', classIds);

  if (enrollError) console.error('listClasses enrollment count error:', enrollError);

  const counts = {};
  (enrollments || []).forEach((e) => {
    counts[e.class_id] = (counts[e.class_id] || 0) + 1;
  });

  return classes.map((c) => ({
    id: c.id,
    name: c.name,
    level: c.level,
    academicYearId: c.academic_year_id,
    studentCount: counts[c.id] || 0,
  }));
}

/**
 * The Guard roster view's main query: optional free-text search, optional
 * class filter, optional status filter — all against the existing
 * RLS-protected tables, batched (no N+1).
 *
 * NOTE (documented limitation, intentional per Phase 4.1 scope): when no
 * classId is given, results are capped at `limit` rows for performance
 * (never "load the whole school on every keystroke"); a statusFilter is
 * then applied to that page client-side, so it narrows what's shown rather
 * than searching the full roster for that status. Pick a class filter (or
 * a name/number search) to narrow the base set first for exhaustive results.
 *
 * @param {{query?: string, classId?: string, statusFilter?: string, limit?: number}} options
 */
export async function filterStudents(options = {}) {
  const { query = '', classId = null, statusFilter = null, limit = 40 } = options;
  const trimmedQuery = query.trim();

  let studentRows = [];
  let classInfoByStudentId = {}; // pre-filled when classId is given

  if (classId) {
    const { data: enrollments, error } = await supabase
      .from('student_enrollments')
      .select('student_id, classes(name, level), students(id, full_name, student_number, photo_url, deleted_at)')
      .eq('class_id', classId)
      .eq('status', 'ACTIVE');

    if (error) {
      console.error('filterStudents (by class) error:', error);
      return [];
    }
    (enrollments || []).forEach((e) => {
      if (!e.students) return;
      classInfoByStudentId[e.student_id] = { status: 'ACTIVE', classes: e.classes };
      studentRows.push(e.students);
    });
    if (trimmedQuery) {
      const q = trimmedQuery.toLowerCase();
      studentRows = studentRows.filter(
        (s) => s.full_name.toLowerCase().includes(q) || (s.student_number || '').toLowerCase().includes(q)
      );
    }
  } else {
    let studentQuery = supabase
      .from('students')
      .select('id, full_name, student_number, photo_url, deleted_at')
      .is('deleted_at', null)
      .order('full_name')
      .limit(limit);

    if (trimmedQuery) {
      studentQuery = studentQuery.or(
        `full_name.ilike.%${trimmedQuery}%,student_number.ilike.%${trimmedQuery}%`
      );
    }

    const { data, error } = await studentQuery;
    if (error) {
      console.error('filterStudents error:', error);
      return [];
    }
    studentRows = data || [];

    const ids = studentRows.map((s) => s.id);
    if (ids.length > 0) {
      const { data: enrollments } = await supabase
        .from('student_enrollments')
        .select('student_id, status, classes(name, level)')
        .eq('status', 'ACTIVE')
        .in('student_id', ids);
      (enrollments || []).forEach((e) => {
        classInfoByStudentId[e.student_id] = e;
      });
    }
  }

  const ids = studentRows.map((s) => s.id);
  let badgeByStudentId = {};
  if (ids.length > 0) {
    const { data: badges } = await supabase
      .from('student_badges')
      .select('student_id, status')
      .eq('status', 'ACTIVE')
      .in('student_id', ids);
    (badges || []).forEach((b) => {
      badgeByStudentId[b.student_id] = b.status;
    });
  }

  let results = studentRows.map((s) => {
    const classification = classifyStudent(s, badgeByStudentId[s.id] ?? null, classInfoByStudentId[s.id] ?? null);
    return { ...classification, studentId: s.id };
  });

  if (statusFilter) {
    results = results.filter((r) => r.resultType === statusFilter);
  }
  return results;
}

/** Convenience wrapper: the full roster (first `limit` students), unfiltered. */
export async function listStudents(limit = 40) {
  return filterStudents({ limit });
}

/** Alias kept for Phase 4.1's requested naming — same behavior as lookupByStudentId. */
export async function getStudent(studentId) {
  return lookupByStudentId(studentId);
}

// ============================================================================
// PHASE 4.1 (Guard General Foundation) additions below.
// All three of these call RPC functions that ALREADY EXIST in
// phase2_schema.sql — nothing new was added to the database. See the
// delivery report for exactly which functions and why no new SQL was
// needed for these three actions.
// ============================================================================

/** School name for the Dashboard header. Read-only, RLS already scopes it. */
export async function getSchoolName(schoolId) {
  const { data, error } = await supabase.from('schools').select('name').eq('id', schoolId).maybeSingle();
  if (error) {
    console.error('getSchoolName error:', error);
    return null;
  }
  return data?.name ?? null;
}

/**
 * Academic years of the caller's own school (RLS scopes the query).
 * Used by the class-creation form and to explain the "create a year first"
 * dependency when the school has none.
 */
export async function listAcademicYears() {
  const { data, error } = await supabase
    .from('academic_years')
    .select('id, name, is_current')
    .order('is_current', { ascending: false });
  if (error) {
    console.error('listAcademicYears error:', error);
    return [];
  }
  return data || [];
}

/** Create an academic year via fn_create_academic_year (server-side auth). */
export async function createAcademicYear({ schoolId, name, isCurrent }) {
  const { data, error } = await supabase.rpc('fn_create_academic_year', {
    p_school_id: schoolId,
    p_name: (name || '').trim(),
    p_is_current: !!isCurrent,
  });
  if (error) {
    console.error('createAcademicYear error:', error);
    return { ok: false, error: mapRpcError(error.message) };
  }
  return { ok: true, yearId: data };
}

/** Create a class/section via fn_create_class (school derived server-side). */
export async function createClass({ academicYearId, name, level }) {
  const { data, error } = await supabase.rpc('fn_create_class', {
    p_academic_year_id: academicYearId,
    p_name: (name || '').trim(),
    p_level: (level || '').trim() || null,
  });
  if (error) {
    console.error('createClass error:', error);
    return { ok: false, error: mapRpcError(error.message) };
  }
  return { ok: true, classId: data };
}

/** Map known server-side RPC error codes to clear Arabic messages.
 * PHASE 15 FIX: delegates to the SHARED, complete mapper in school.js
 * (which knows DUPLICATE_STUDENT_NUMBER, SCHOOL/CLASS/YEAR mismatches,
 * assignment errors, ...). The old local table was missing the duplicate
 * student-number mapping, which is why users saw the generic message.
 * The technical detail always stays in console (logged by the caller). */
import {
  call,
  isDebug,
  mapRpcError as mapRpcErrorShared,
} from './school.js?v=30';
function mapRpcError(message) {
  return mapRpcErrorShared(message);
}

/**
 * Register a new student. PHASE 16: the student number is generated
 * atomically server-side per school. The caller never supplies a number.
 * Authorization and school context are checked by PostgreSQL/RPC.
 */
export async function registerStudent({ fullName, classId, academicYearId, birthDate, gender }) {
  // PHASE 17: fn_register_student_auto_number is now self-contained and
  // returns student_id + student_number directly — no second query needed.
  const { data, error } = await supabase.rpc('fn_register_student_auto_number', {
    p_full_name: fullName,
    p_class_id: classId,
    p_academic_year_id: academicYearId,
    p_birth_date: birthDate || null,
    p_gender: gender || null,
  });
  if (error) {
    console.error('registerStudent error:', error);
    return { ok: false, error: mapRpcError(error.message) };
  }
  const row = Array.isArray(data) ? data[0] : data;
  return { ok: true, studentId: row?.student_id ?? null, studentNumber: row?.student_number ?? null };
}

// Badge lifecycle — routed through the central call() so failures get the
// classified error + [RPC ERROR] diagnostics like every other RPC. Params
// match phase18 signatures exactly; RPCs and permissions are unchanged.
const dbg = (...a) => { if (isDebug()) console.log(...a); };

/** Issue a first badge. PHASE 4.2: routed through fn_guard_issue_badge (checks students.badge.issue). */
export async function issueBadge(studentId) {
  dbg('[BADGE ISSUE] student=', studentId);
  const res = await call('fn_guard_issue_badge', { p_student_id: studentId });
  return res.ok ? { ok: true, badgeId: res.data } : res;
}

/** Reissue. PHASE 4.2: routed through fn_guard_reissue_badge (checks students.badge.reissue). */
export async function reissueBadge(studentId, reason) {
  dbg('[BADGE REISSUE] student=', studentId);
  const res = await call('fn_guard_reissue_badge', { p_student_id: studentId, p_reason: reason || null });
  return res.ok ? { ok: true, badgeId: res.data } : res;
}

/** Suspend. PHASE 4.2: routed through fn_guard_suspend_badge (checks students.badge.suspend). */
export async function suspendBadge(badgeId, newStatus, reason) {
  dbg('[BADGE SUSPEND] badge=', badgeId);
  const res = await call('fn_guard_suspend_badge', { p_badge_id: badgeId, p_new_status: newStatus, p_reason: reason || null });
  return res.ok ? { ok: true } : res;
}
