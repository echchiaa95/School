import { requireAuth, logout } from './auth.js';
import {
  el, esc, fmtDate, fmtDateTime, fmtMoney, attStatusAr, toast,
  loadingHtml, emptyHtml, errorHtml, initPageHeader, showView,
  armViewHistory, armErrorBoundary, showInitError,
} from './ui.js';
import {
  myChildren, getStudentAttendance, listStudentGrades,
  studentTransportInfo, childPayments, listMyNotifications,
  markNotificationRead, unreadNotificationsCount, getSchoolProfile,
  getMyChildBadge, getChildBusEta, getMyChildMedicalInfo, setMyChildMedicalInfo,
  requestEarlyDismissal, listMyEarlyDismissalRequests,
} from './school.js';
import { renderBadgeCard } from './badgeCard.js';

let ctx = null;
let children = [];
let currentChild = null;
let schoolProfile = null; // cached fn_get_school_profile jsonb (name + logo for the badge card)
let etaPollTimer = null; // live ETA — cleared on tab switch / child change

const REL_AR = { father: 'الأب', mother: 'الأم', guardian: 'ولي الأمر' };

// ---- Children list ----------------------------------------------------------
async function loadChildren() {
  const host = el('children-list');
  host.innerHTML = loadingHtml();
  const res = await myChildren();
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  children = res.data || [];
  if (!children.length) {
    host.innerHTML = emptyHtml('لا يوجد أبناء مرتبطون بهذا الحساب. تواصل مع إدارة المؤسسة.');
    return;
  }
  host.innerHTML = `<div class="modules-grid">${children.map((c) => `
    <button type="button" class="module-card" data-child="${c.student_id}">
      ${c.photo_url
        ? `<img src="${esc(c.photo_url)}" alt="" style="width:48px; height:48px; border-radius:50%; object-fit:cover;" />`
        : '<span class="module-icon">🎓</span>'}
      ${esc(c.full_name)}
      <span class="badge badge-blue">${esc(c.class_name || 'بدون قسم')}${c.level ? ' — ' + esc(c.level) : ''}</span>
    </button>`).join('')}</div>`;
  host.querySelectorAll('[data-child]').forEach((b) => {
    b.addEventListener('click', () => openChild(b.dataset.child));
  });
}

// ---- Child detail -----------------------------------------------------------
function openChild(studentId) {
  currentChild = children.find((c) => c.student_id === studentId) || null;
  if (!currentChild) return;
  el('child-header').innerHTML = `<div class="panel">
    <div style="display:flex; gap:12px; align-items:center; margin-bottom:8px;">
      ${currentChild.photo_url
        ? `<img src="${esc(currentChild.photo_url)}" alt="" style="width:56px; height:56px; border-radius:50%; object-fit:cover;">`
        : `<div style="width:56px; height:56px; border-radius:50%; background:#e5e7eb; display:flex; align-items:center; justify-content:center; font-size:24px;">👤</div>`}
      <div>
        <strong style="font-size:16px;">${esc(currentChild.full_name)}</strong>
        <div class="time">${esc(currentChild.student_number || '—')}</div>
      </div>
    </div>
    <div class="detail-row"><strong>القسم</strong><span>${esc(currentChild.class_name || '—')}${currentChild.level ? ' — ' + esc(currentChild.level) : ''}</span></div>
    <div class="detail-row"><strong>صلة القرابة</strong><span>${REL_AR[currentChild.relationship] || esc(currentChild.relationship || '—')}</span></div>
  </div>`;
  showView('child');
  switchTab('attendance');
}

function switchTab(tab) {
  stopEtaPolling();
  document.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('[data-tab-panel]').forEach((p) => { p.hidden = p.dataset.tabPanel !== tab; });
  if (tab === 'attendance') { loadAttendance(); loadEarlyDismissal(); }
  if (tab === 'grades') loadGrades();
  if (tab === 'transport') loadTransport();
  if (tab === 'payments') loadPayments();
  if (tab === 'badge') loadBadge();
  if (tab === 'medical') loadMedical();
}

// ---- Badge/QR (items 23-24): same real QR already in student_badges,
// via fn_parent_get_child_badge — never regenerated, just reused. -----------
// ---- 🏥 السجل الطبي الطارئ (ميزة جديدة): يملأه ولي الأمر، ويظهر فقط عند
// مسح QR الطالب الحقيقي من طرف الحارس في حالة طارئة. -----------------------
async function loadMedical() {
  const host = el('child-medical');
  host.innerHTML = loadingHtml();
  const res = await getMyChildMedicalInfo(currentChild.student_id);
  const m = res.ok ? (res.data || [])[0] || {} : {};
  host.innerHTML = `
    <p style="font-size:12px; color:#6b7280; margin-bottom:10px;">
      هذه المعلومات تظهر فقط لموظفي المؤسسة عند مسح بطاقة QR الحقيقية لابنكم في حالة طارئة — وليست ظاهرة في أي مكان آخر.
    </p>
    <label>الحساسية (إن وجدت)<textarea id="med-allergies" class="search-input" rows="2"></textarea></label>
    <label>دواء طارئ (الاسم والجرعة إن وجد)<textarea id="med-medication" class="search-input" rows="2"></textarea></label>
    <label>اسم جهة الاتصال في حالة الطوارئ<input type="text" id="med-contact-name" class="search-input"></label>
    <label>هاتف جهة الاتصال في حالة الطوارئ<input type="tel" id="med-contact-phone" class="search-input"></label>
    <label>ملاحظات إضافية<textarea id="med-notes" class="search-input" rows="2"></textarea></label>
    <button type="button" class="primary-btn" id="med-save-btn" style="margin-top:8px;">حفظ</button>
    ${m.updated_at ? `<p class="time" style="margin-top:6px;">آخر تحديث: ${fmtDateTime(m.updated_at)}</p>` : ''}`;
  el('med-allergies').value = m.allergies || '';
  el('med-medication').value = m.emergency_medication || '';
  el('med-contact-name').value = m.emergency_contact_name || '';
  el('med-contact-phone').value = m.emergency_contact_phone || '';
  el('med-notes').value = m.notes || '';
  el('med-save-btn').addEventListener('click', async () => {
    const saveRes = await setMyChildMedicalInfo(currentChild.student_id, {
      allergies: el('med-allergies').value.trim(),
      medication: el('med-medication').value.trim(),
      contactName: el('med-contact-name').value.trim(),
      contactPhone: el('med-contact-phone').value.trim(),
      notes: el('med-notes').value.trim(),
    });
    if (!saveRes.ok) { toast(saveRes.error, 'error'); return; }
    toast('تم الحفظ', 'success');
    loadMedical();
  });
}

async function loadBadge() {
  const host = el('child-badge');
  host.innerHTML = loadingHtml();
  const res = await getMyChildBadge(currentChild.student_id);
  const badge = res.ok ? (res.data || [])[0] : null;
  if (!res.ok || !badge) {
    host.innerHTML = emptyHtml('لا توجد بطاقة صادرة لهذا التلميذ بعد.');
    return;
  }
  host.innerHTML = '';
  await renderBadgeCard(host, {
    full_name: currentChild.full_name,
    student_number: currentChild.student_number,
    class_name: currentChild.class_name,
    photo_url: currentChild.photo_url,
    school_name: schoolProfile?.name,
    school_logo_url: schoolProfile?.logo_url,
  }, badge);
}

const DISMISSAL_STATUS_AR = { pending: 'قيد الانتظار', approved: 'تمت الموافقة ✅', rejected: 'مرفوض ❌' };

async function loadEarlyDismissal() {
  const host = el('early-dismissal-box');
  const res = await listMyEarlyDismissalRequests(currentChild.student_id);
  const rows = res.ok ? res.data || [] : [];
  const hasPendingToday = rows.some((r) => r.status === 'pending' && new Date(r.created_at).toDateString() === new Date().toDateString());
  host.innerHTML = `
    <div class="panel">
      <strong>🚪 استئذان مبكر</strong>
      ${hasPendingToday
        ? '<p class="time" style="margin-top:6px;">طلبكم لهذا اليوم قيد الانتظار حاليًا.</p>'
        : `<div style="margin-top:8px; display:flex; gap:8px;">
             <input type="text" id="dismissal-reason" class="search-input" placeholder="سبب الاستئذان" style="flex:1;">
             <button type="button" class="quick-action-btn" id="dismissal-send-btn">إرسال</button>
           </div>`}
      ${rows.length ? `<div style="margin-top:10px;">${rows.slice(0, 5).map((r) => `
        <div class="detail-row"><span class="time">${fmtDateTime(r.created_at)} — ${esc(r.reason)}</span><span class="badge ${
          r.status === 'approved' ? 'badge-green' : r.status === 'rejected' ? 'badge-red' : 'badge-gold'
        }">${DISMISSAL_STATUS_AR[r.status] || r.status}</span></div>`).join('')}</div>` : ''}
    </div>`;
  const sendBtn = el('dismissal-send-btn');
  if (sendBtn) sendBtn.addEventListener('click', async () => {
    const reason = el('dismissal-reason').value.trim();
    if (!reason) { toast('يرجى كتابة السبب', 'error'); return; }
    const sendRes = await requestEarlyDismissal(currentChild.student_id, reason);
    if (!sendRes.ok) { toast(sendRes.error, 'error'); return; }
    toast('تم إرسال الطلب', 'success');
    loadEarlyDismissal();
  });
}

async function loadAttendance() {
  const host = el('child-attendance');
  host.innerHTML = loadingHtml();
  const res = await getStudentAttendance(currentChild.student_id, el('att-from').value || null, el('att-to').value || null);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد سجلات حضور في هذه الفترة.'); return; }
  const counts = rows.reduce((acc, r) => { acc[r.status] = (acc[r.status] || 0) + 1; return acc; }, {});
  host.innerHTML = `
    <div class="stats-grid" style="margin-bottom:12px;">
      <div class="stat-card tone-green"><div class="stat-value">${counts.present || 0}</div><div class="stat-label">حاضر</div></div>
      <div class="stat-card tone-red"><div class="stat-value">${counts.absent || 0}</div><div class="stat-label">غائب</div></div>
      <div class="stat-card tone-gold"><div class="stat-value">${counts.late || 0}</div><div class="stat-label">متأخر</div></div>
      <div class="stat-card"><div class="stat-value">${counts.excused || 0}</div><div class="stat-label">مبرر</div></div>
    </div>
    <div class="data-table-wrap"><table class="data-table"><thead><tr><th>التاريخ</th><th>الحالة</th></tr></thead>
    <tbody>${rows.map((r) => `<tr><td>${fmtDate(r.att_date)}</td><td><span class="badge ${
      r.status === 'present' ? 'badge-green' : r.status === 'absent' ? 'badge-red' : r.status === 'late' ? 'badge-gold' : 'badge-blue'
    }">${attStatusAr(r.status)}</span></td></tr>`).join('')}</tbody></table></div>`;
}

async function loadGrades() {
  const host = el('child-grades');
  host.innerHTML = loadingHtml();
  const res = await listStudentGrades(currentChild.student_id);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد نقاط مسجلة بعد.'); return; }
  host.innerHTML = `<div class="data-table-wrap"><table class="data-table"><thead><tr>
    <th>المادة</th><th>الفترة</th><th>النوع</th><th>النقطة</th><th>التاريخ</th>
  </tr></thead><tbody>${rows.map((g) => `<tr>
    <td>${esc(g.subject_name || '—')}</td><td>${esc(g.period || '—')}</td>
    <td>${esc(g.grade_type || '—')}</td><td>${g.score}/${g.max_score ?? 20}</td>
    <td>${fmtDate(g.created_at)}</td>
  </tr>`).join('')}</tbody></table></div>`;
}

function stopEtaPolling() {
  if (etaPollTimer) { clearInterval(etaPollTimer); etaPollTimer = null; }
}

// ETA حي (ميزة تنافسية): تقدير تقريبي — مسافة خط مستقيم من آخر موقع GPS
// للحافلة إلى محطة التلميذ (أو المؤسسة إن كان قد صعد بالفعل)، وليس توجيهًا
// حقيقيًا عبر الطرقات، لذلك يُعرض دائمًا كـ"تقدير".
function etaCardHtml(d) {
  if (!d || !d.has_active_trip) {
    return '<div class="panel" style="margin-bottom:10px; text-align:center; color:#6b7280;">لا توجد رحلة نشطة حاليًا لهذه الحافلة.</div>';
  }
  const directionLabel = d.direction === 'dropoff' ? 'نحو المنزل' : (d.is_boarded ? 'نحو المؤسسة' : 'نحو نقطة الصعود');
  const alertBanner = d.not_boarded_alert
    ? `<div class="panel" style="margin-bottom:10px; text-align:center; background:#fef2f2; border:1px solid #fca5a5; color:#991b1b;">
        ⚠️ لم يصعد ابنكم الحافلة بعد رغم مرور وقت كافٍ منذ بداية الرحلة. يُرجى التواصل مع المؤسسة أو السائق للتأكد.
      </div>`
    : '';
  if (d.eta_minutes == null) {
    return alertBanner + `<div class="panel" style="margin-bottom:10px; text-align:center; color:#6b7280;">
      🚌 الرحلة جارية (${esc(directionLabel)}) — بانتظار تحديد موقع الحافلة...</div>`;
  }
  return alertBanner + `<div class="panel" style="margin-bottom:10px; text-align:center; ${d.is_stale ? 'opacity:.7;' : ''}">
    <div style="font-size:12px; color:#6b7280; margin-bottom:2px;">${esc(directionLabel)} — ${esc(d.target_label || '')}</div>
    <div style="font-size:28px; font-weight:700;">⏱️ ${d.eta_minutes} د</div>
    <div style="font-size:12px; color:#6b7280; margin-top:2px;">تقدير تقريبي (${d.distance_km} كم) — ${
      d.is_stale ? '⚠️ آخر تحديث قديم' : 'مباشر'
    }</div>
  </div>`;
}

async function refreshEta() {
  const host = el('child-eta');
  if (!host || !currentChild) return;
  const res = await getChildBusEta(currentChild.student_id);
  host.innerHTML = etaCardHtml(res.ok ? res.data?.[0] : null);
}

async function loadTransport() {
  const host = el('child-transport');
  host.innerHTML = loadingHtml();
  const res = await studentTransportInfo(currentChild.student_id);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const t = res.data;
  if (!t) { host.innerHTML = emptyHtml('هذا التلميذ غير مسجل في النقل المدرسي.'); return; }
  host.innerHTML = `
    <div id="child-eta"></div>
    <div class="detail-row"><strong>الحافلة</strong><span>${esc(t.bus_code || '—')}${t.bus_plate ? ' (' + esc(t.bus_plate) + ')' : ''}</span></div>
    <div class="detail-row"><strong>المسار</strong><span>${esc(t.route_name || '—')}</span></div>
    <div class="detail-row"><strong>محطة الصعود</strong><span>${esc(t.pickup_stop || '—')}</span></div>
    <div class="detail-row"><strong>محطة النزول</strong><span>${esc(t.dropoff_stop || '—')}</span></div>`;
  await refreshEta();
  stopEtaPolling();
  etaPollTimer = setInterval(refreshEta, 20000);
}

async function loadPayments() {
  const host = el('child-payments');
  host.innerHTML = loadingHtml();
  const res = await childPayments(currentChild.student_id);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد أداءات مسجلة.'); return; }
  const totalDue = rows.reduce((s, r) => s + Number(r.amount_due || 0), 0);
  const totalPaid = rows.reduce((s, r) => s + Number(r.amount_paid || 0), 0);
  host.innerHTML = `
    <div class="stats-grid" style="margin-bottom:12px;">
      <div class="stat-card"><div class="stat-value">${fmtMoney(totalDue)}</div><div class="stat-label">المستحق</div></div>
      <div class="stat-card tone-green"><div class="stat-value">${fmtMoney(totalPaid)}</div><div class="stat-label">المدفوع</div></div>
      <div class="stat-card tone-red"><div class="stat-value">${fmtMoney(totalDue - totalPaid)}</div><div class="stat-label">المتبقي</div></div>
    </div>
    <div class="data-table-wrap"><table class="data-table"><thead><tr>
      <th>نوع الرسوم</th><th>المستحق</th><th>المدفوع</th><th>التاريخ</th><th>الوصل</th>
    </tr></thead><tbody>${rows.map((p) => `<tr>
      <td>${esc(p.fee_type)}</td><td>${fmtMoney(p.amount_due)}</td><td>${fmtMoney(p.amount_paid)}</td>
      <td>${fmtDate(p.payment_date)}</td><td>${esc(p.receipt_no || '—')}</td>
    </tr>`).join('')}</tbody></table></div>`;
}

// ---- Notifications ----------------------------------------------------------
async function loadNotifications() {
  const host = el('notif-list');
  host.innerHTML = loadingHtml();
  const res = await listMyNotifications(50);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد إشعارات.'); refreshNotifBadge(); return; }
  host.innerHTML = rows.map((n) => `
    <div class="detail-row" data-notif="${n.id}" style="cursor:pointer; ${n.is_read ? 'opacity:.65;' : 'font-weight:600;'}">
      <div style="flex:1;">
        <div>${esc(n.title)}</div>
        ${n.body ? `<div style="font-size:.85em; color:var(--muted);">${esc(n.body)}</div>` : ''}
      </div>
      <span class="badge badge-blue">${esc(n.type || '')}</span>
      <span style="font-size:.8em; color:var(--muted);">${fmtDateTime(n.created_at)}</span>
    </div>`).join('');
  host.querySelectorAll('[data-notif]').forEach((row) => {
    row.addEventListener('click', async () => {
      await markNotificationRead(row.dataset.notif);
      row.style.opacity = '.65';
      row.style.fontWeight = '400';
      refreshNotifBadge();
    });
  });
  refreshNotifBadge();
}

async function refreshNotifBadge() {
  const res = await unreadNotificationsCount();
  const badge = el('notif-count');
  if (!badge) return;
  const count = res.ok ? (res.data || 0) : 0;
  badge.hidden = !count;
  badge.textContent = count;
}

// ---- Init -------------------------------------------------------------------
(async () => {
  try {
    armErrorBoundary();
    ctx = await requireAuth('parent.html');
    if (!ctx) return;
    armViewHistory('home');
    document.getElementById('app-body').hidden = false;

    const schoolRes = await getSchoolProfile(ctx.schoolId);
    schoolProfile = schoolRes.ok ? schoolRes.data : null;
    await initPageHeader(ctx, schoolProfile?.name, logout);

    const today = new Date();
    const monthAgo = new Date(today.getTime() - 30 * 86400000);
    el('att-from').value = monthAgo.toISOString().slice(0, 10);
    el('att-to').value = today.toISOString().slice(0, 10);

    document.querySelectorAll('[data-back]').forEach((b) => {
      b.addEventListener('click', () => { stopEtaPolling(); showView('home'); });
    });
    document.querySelectorAll('[data-tab]').forEach((b) => {
      b.addEventListener('click', () => switchTab(b.dataset.tab));
    });
    el('att-reload').addEventListener('click', loadAttendance);
    el('notif-btn').addEventListener('click', () => { showView('notifications'); loadNotifications(); });

    await loadChildren();
    refreshNotifBadge();
  } catch (error) {
    console.error('parent portal init error:', error);
    showInitError(error);
  }
})();
