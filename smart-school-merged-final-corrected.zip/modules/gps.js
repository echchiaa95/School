// ============================================================================
// modules/gps.js
// Live GPS tracking for the driver during an ACTIVE trip only (item 25:
// never before "Start Trip", never after "End Trip" — this module has no
// way to run outside that window because startGpsTracking/stopGpsTracking
// are the only entry points and driverConsole.js only calls them there).
//
// PWA/browser limitation (item 43, stated plainly, not oversold): this uses
// navigator.geolocation.watchPosition(), which only keeps reporting while
// the tab/app is open and in the foreground (or briefly backgrounded,
// depending on the OS/browser). There is no reliable background tracking
// without a native app or a paid background-location service, and this
// project isn't adding a native app right now. When the page is
// backgrounded long enough that the browser suspends it, updates simply
// stop until it's foregrounded again — the UI must show "GPS غير متاح /
// آخر تحديث منذ X" rather than pretend it's still live.
// ============================================================================

import { recordGpsPing } from './school.js';

const MIN_INTERVAL_MS = 8000;   // don't send more than ~1 ping per 8s while stationary
const MIN_MOVE_METERS = 20;     // ...but send sooner if the bus clearly moved
const MIN_FLOOR_MS = 3000;      // hard floor so a fast-moving bus can't flood the network either

let watchId = null;
let lastSentAt = 0;
let lastSentPos = null;
let statusListeners = [];

function haversineMeters(a, b) {
  const R = 6371000;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const s = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

function notify(status) {
  statusListeners.forEach((fn) => fn(status));
}

/** Subscribe to status updates: {state:'active'|'error'|'stopped', accuracy?, recordedAt?, message?} */
export function onGpsStatus(fn) {
  statusListeners.push(fn);
  return () => { statusListeners = statusListeners.filter((f) => f !== fn); };
}

export function isGpsTracking() {
  return watchId != null;
}

/**
 * Item 15 — GPS is mandatory before a tracked trip may even be created.
 * One-shot check (does not start watchPosition): resolves true if a fix
 * was obtained, false otherwise (permission denied, unavailable, or
 * timed out). Never throws. Callers must NOT create the trip on false.
 */
export function requestGpsPermission() {
  return new Promise((resolve) => {
    if (!('geolocation' in navigator)) { resolve(false); return; }
    navigator.geolocation.getCurrentPosition(
      () => resolve(true),
      () => resolve(false),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 15000 }
    );
  });
}

/**
 * Start watching position and pushing pings for this trip. Safe to call
 * once per trip — calling again while already tracking is a no-op.
 */
export function startGpsTracking(tripId) {
  if (watchId != null) return;
  if (!('geolocation' in navigator)) {
    notify({ state: 'error', message: 'الجهاز لا يدعم تحديد الموقع.' });
    return;
  }

  watchId = navigator.geolocation.watchPosition(
    async (pos) => {
      const { latitude, longitude, accuracy, speed, heading } = pos.coords;
      const now = Date.now();
      const here = { lat: latitude, lng: longitude };
      const elapsed = now - lastSentAt;
      const moved = lastSentPos ? haversineMeters(lastSentPos, here) : Infinity;

      const shouldSend = elapsed >= MIN_INTERVAL_MS
        || (elapsed >= MIN_FLOOR_MS && moved >= MIN_MOVE_METERS);
      if (!shouldSend) {
        notify({ state: 'active', accuracy, recordedAt: new Date().toISOString(), pending: true });
        return;
      }

      lastSentAt = now;
      lastSentPos = here;
      const res = await recordGpsPing(tripId, latitude, longitude, accuracy, speed, heading);
      if (!res.ok) {
        notify({ state: 'error', message: res.error });
        return;
      }
      notify({ state: 'active', accuracy, recordedAt: new Date().toISOString() });
    },
    (err) => {
      notify({ state: 'error', message: err.code === err.PERMISSION_DENIED ? 'تم رفض إذن الموقع.' : 'تعذر تحديد الموقع.' });
    },
    { enableHighAccuracy: true, maximumAge: 4000, timeout: 15000 }
  );
}

/** Stop watching position (item 25: called on "End Trip"). */
export function stopGpsTracking() {
  if (watchId != null) {
    navigator.geolocation.clearWatch(watchId);
    watchId = null;
  }
  lastSentAt = 0;
  lastSentPos = null;
  notify({ state: 'stopped' });
}
