// ============================================================================
// modules/liveMap.js
// Admin live map — Phase 22/23 (bus tracking) + Phase 27 (general map mode).
// Leaflet/OSM (no Google Maps key in this project). Two modes:
//   A) GENERAL — 🏫 school + 🏠 all student homes with saved coordinates +
//      🚌 every bus in the fleet (live if on an active trip, greyed out
//      with "آخر موقع معروف" if idle but has a last known point, absent
//      from the map — but still listed below — if it has never reported).
//   B) FOCUS (tap a bus) — zooms in, highlights the home markers of the
//      students on THIS bus's current/active trip only, shows the bus
//      detail popup with [عرض الرحلة] / [سجل الرحلات], and (if the route
//      layer is on) draws the live route travelled so far.
// Data sources: fn_get_school_map_overview, fn_get_school_student_homes,
// fn_get_school_bus_stops, fn_get_all_buses_status, fn_get_active_bus_locations
// (Phase 27) + fn_list_bus_students_ordered, fn_list_bus_trips,
// fn_get_trip_route_history (existing). Realtime on bus_last_locations AND
// bus_trip_students (item 8 — passenger count must update without refresh),
// with a 12s poll as a fallback if Realtime isn't available on this project.
// ============================================================================

import { supabase } from './supabase.js';
import {
  getActiveBusLocations, getAllBusesStatus, listBusTrips, getTripRouteHistory,
  getSchoolMapOverview, getSchoolStudentHomes, getSchoolBusStops, listBusStudentsOrdered,
  getNonBoardingAlerts, getGeofenceEvents,
} from './school.js';
import { loadLeaflet } from './mapPicker.js';
import { esc, fmtTime, contactLinksHtml } from './ui.js';

const POLL_MS = 12000;
const STALE_MS = 75000; // 60-90s stale threshold, visually obvious

const DEFAULT_CENTER = [27.15, -13.2]; // fallback only if the school has no saved location

let map = null;
let busMarkers = {};   // bus_id -> L.marker
let homeMarkers = {};  // student_id -> L.marker
let stopMarkers = [];  // L.marker[]
let schoolMarker = null;
let routeLine = null;
let pollTimer = null;
let realtimeChannels = [];
let hostEl = null;

let state = {
  mode: 'general',          // 'general' | 'focus'
  focusedBusId: null,
  layers: { homes: true, buses: true, stops: false, route: false },
  schoolInfo: null,
  homes: [],                // full-school list, from fn_get_school_student_homes
  stops: [],
  focusStudentIds: new Set(), // student_ids on the focused bus's current trip (home highlight)
};

function timeAgoAr(iso) {
  if (!iso) return '—';
  const s = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `منذ ${s} ثانية`;
  const m = Math.floor(s / 60);
  if (m < 60) return `منذ ${m} دقيقة`;
  return `منذ ${Math.floor(m / 60)} ساعة`;
}

function isStale(recordedAt) {
  return !recordedAt || (Date.now() - new Date(recordedAt).getTime() > STALE_MS);
}

function busIcon(kind) {
  // kind: 'live' | 'stale' | 'idle'
  const style = kind === 'live' ? '' : 'filter:grayscale(1) opacity(0.65);';
  return window.L.divIcon({
    html: `<div style="font-size:26px; ${style}">🚌</div>`,
    className: '', iconSize: [30, 30], iconAnchor: [15, 15],
  });
}

function homeIcon(highlighted) {
  return window.L.divIcon({
    html: `<div style="font-size:${highlighted ? 24 : 18}px; ${highlighted ? '' : 'opacity:.75;'}">🏠</div>`,
    className: '', iconSize: [22, 22], iconAnchor: [11, 20],
  });
}

function schoolIcon() {
  return window.L.divIcon({
    html: `<div style="font-size:30px;">🏫</div>`,
    className: '', iconSize: [34, 34], iconAnchor: [17, 30],
  });
}

function stopIcon() {
  return window.L.divIcon({
    html: `<div style="font-size:18px;">📍</div>`,
    className: '', iconSize: [18, 18], iconAnchor: [9, 18],
  });
}

function busPopupHtml(row) {
  const passengers = row.total_students != null ? `${row.boarded_count ?? 0}/${row.total_students}` : '—';
  const connected = row.has_active_trip && !isStale(row.recorded_at);
  const gpsLine = !row.recorded_at
    ? 'لا يوجد بعد'
    : connected
      ? '<span style="color:#16a34a;">🟢 متصل</span>'
      : row.has_active_trip
        ? '<span style="color:#dc2626;">⚠️ غير محدَّث</span>'
        : `<span style="color:#6b7280;">⚪ آخر موقع معروف — ${timeAgoAr(row.recorded_at)}</span>`;
  return `<div style="min-width:200px; text-align:right;">
    <strong>${esc(row.bus_code || row.bus_plate || 'الحافلة')}</strong><br>
    الترقيم: ${esc(row.bus_plate || '—')}<br>
    السائق: ${esc(row.driver_name || 'بدون سائق')} ${contactLinksHtml(row.driver_phone)}<br>
    ${row.has_active_trip ? `الركاب: ${passengers}<br>الاتجاه: ${row.direction === 'pickup' ? 'نحو المؤسسة' : 'نحو المنزل'}<br>` : ''}
    ${row.speed != null ? `السرعة: ${Math.round(row.speed * 3.6)} كم/س<br>` : ''}
    GPS: ${gpsLine}<br>
    <div style="display:flex; gap:6px; margin-top:8px;">
      <button type="button" class="quick-action-btn" data-focus-bus="${row.bus_id}" style="padding:4px 10px; font-size:.85em;">عرض الرحلة</button>
      <button type="button" class="quick-action-btn secondary" data-history-bus="${row.bus_id}" data-label="${esc(row.bus_code || row.bus_plate || '')}" style="padding:4px 10px; font-size:.85em;">سجل الرحلات</button>
    </div>
  </div>`;
}

// ============================================================================
// Item 10 — single merged fleet list (replaces the old "متصلة"/"غير متصلة"
// split). One row per bus, one status per bus, always real data.
// ============================================================================
function busListHtml(rows) {
  const row = (r) => {
    const connected = r.has_active_trip && !isStale(r.recorded_at);
    const statusBadge = r.has_active_trip
      ? (connected ? '<span class="badge badge-green">🟢 نشطة</span>' : '<span class="badge badge-red">⚠️ رحلة بدون GPS حديث</span>')
      : (r.recorded_at ? `<span class="badge">⚪ آخر موقع: ${timeAgoAr(r.recorded_at)}</span>` : '<span class="badge">⚪ غير نشطة</span>');
    return `<div class="detail-row" style="flex-wrap:wrap; gap:6px;" data-bus-row="${r.bus_id}">
      <div style="flex:1; min-width:140px; cursor:pointer;" data-focus-bus="${r.bus_id}">
        <strong>${esc(r.bus_code || r.bus_plate || 'حافلة')}</strong> <span class="time">${esc(r.bus_plate || '')}</span><br>
        <span class="time">${esc(r.driver_name || 'بدون سائق')}</span> ${contactLinksHtml(r.driver_phone)}
      </div>
      ${r.has_active_trip && r.total_students != null ? `<span class="badge">👥 ${r.boarded_count ?? 0} ركاب</span>` : ''}
      ${statusBadge}
      <button type="button" class="quick-action-btn secondary" data-history-bus="${r.bus_id}" data-label="${esc(r.bus_code || r.bus_plate || '')}" style="padding:4px 10px; font-size:.85em;">سجل الرحلات</button>
    </div>`;
  };
  return `
    <p class="section-title" style="margin-top:14px;">🚌 قائمة الحافلات (${rows.length})</p>
    <div class="panel">${rows.length ? rows.map(row).join('') : '<div class="empty-state">لا توجد حافلات مسجّلة.</div>'}</div>`;
}

// ============================================================================
// Layer rendering
// ============================================================================

function renderSchoolMarker() {
  const s = state.schoolInfo;
  if (!s || s.latitude == null || s.longitude == null) return;
  if (schoolMarker) { map.removeLayer(schoolMarker); schoolMarker = null; }
  schoolMarker = window.L.marker([s.latitude, s.longitude], { icon: schoolIcon(), zIndexOffset: 1000 })
    .addTo(map)
    .bindPopup(`<strong>🏫 ${esc(s.name || 'المؤسسة')}</strong>${s.address ? `<br>${esc(s.address)}` : ''}`);
}

function renderStopsLayer() {
  stopMarkers.forEach((m) => map.removeLayer(m));
  stopMarkers = [];
  if (!state.layers.stops) return;
  state.stops.forEach((stop) => {
    if (stop.latitude == null || stop.longitude == null) return;
    const m = window.L.marker([stop.latitude, stop.longitude], { icon: stopIcon() })
      .addTo(map).bindTooltip(esc(stop.name || 'نقطة توقف'));
    stopMarkers.push(m);
  });
}

function renderHomesLayer() {
  const shouldShow = state.layers.homes;
  const visibleIds = new Set(
    state.mode === 'focus' && state.focusStudentIds.size
      ? state.homes.filter((h) => state.focusStudentIds.has(h.student_id)).map((h) => h.student_id)
      : state.homes.map((h) => h.student_id)
  );

  state.homes.forEach((h) => {
    const shouldExist = shouldShow && visibleIds.has(h.student_id) && h.latitude != null && h.longitude != null;
    const highlighted = state.mode === 'focus' && state.focusStudentIds.has(h.student_id);
    if (!shouldExist) {
      if (homeMarkers[h.student_id]) { map.removeLayer(homeMarkers[h.student_id]); delete homeMarkers[h.student_id]; }
      return;
    }
    const popup = `<div style="text-align:right;">🏠 <strong>${esc(h.full_name)}</strong>${h.class_name ? `<br>${esc(h.class_name)}` : ''}${h.location_label ? `<br><span style="color:#6b7280;">${esc(h.location_label)}</span>` : ''}</div>`;
    if (homeMarkers[h.student_id]) {
      homeMarkers[h.student_id].setIcon(homeIcon(highlighted));
      homeMarkers[h.student_id].setPopupContent(popup);
    } else {
      homeMarkers[h.student_id] = window.L.marker([h.latitude, h.longitude], { icon: homeIcon(highlighted) })
        .addTo(map).bindPopup(popup);
    }
  });
}

function wireBusPopupButtons(popupEl) {
  popupEl.querySelectorAll('[data-focus-bus]').forEach((b) => b.addEventListener('click', () => enterFocusMode(b.dataset.focusBus)));
  popupEl.querySelectorAll('[data-history-bus]').forEach((b) => b.addEventListener('click', () => openBusHistoryModal(b.dataset.historyBus, b.dataset.label)));
}

async function renderRouteLayer(activeRows) {
  if (routeLine) { map.removeLayer(routeLine); routeLine = null; }
  if (!state.layers.route || state.mode !== 'focus' || !state.focusedBusId) return;
  const busRow = activeRows.find((r) => r.bus_id === state.focusedBusId);
  if (!busRow || !busRow.trip_id) return;
  const histRes = await getTripRouteHistory(busRow.trip_id);
  const points = histRes.ok ? histRes.data || [] : [];
  if (!points.length) return;
  routeLine = window.L.polyline(points.map((p) => [p.latitude, p.longitude]), { color: '#2563eb', weight: 4 }).addTo(map);
}

// ============================================================================
// 📍 Geofencing (ميزة تنافسية جديدة) — سجل أحداث حيّ يشارك نفس دورة
// التحديث (12 ثانية) بدل مؤقت مستقل.
// ============================================================================
const GEOFENCE_LABELS = {
  SCHOOL_ENTER: { text: '🏫 دخلت محيط المؤسسة', tone: '#16a34a' },
  SCHOOL_EXIT: { text: '🏫 خرجت من محيط المؤسسة', tone: '#6b7280' },
  ROUTE_DEVIATION: { text: '⚠️ انحراف عن المسار المعتاد', tone: '#b91c1c' },
  ROUTE_BACK_ON_TRACK: { text: '✅ عادت إلى المسار', tone: '#16a34a' },
};

async function renderGeofenceEvents() {
  const host = document.getElementById('geofence-events-box');
  if (!host) return;
  const res = await getGeofenceEvents(10);
  const rows = res.ok ? res.data || [] : [];
  if (!rows.length) { host.innerHTML = ''; return; }
  host.innerHTML = `
    <div class="panel" style="margin-bottom:10px;">
      <strong>📍 أحداث النطاق الجغرافي (آخر ${rows.length})</strong>
      ${rows.map((r) => {
        const l = GEOFENCE_LABELS[r.event_type] || { text: r.event_type, tone: '#6b7280' };
        return `<div class="detail-row"><span style="color:${l.tone};">${esc(r.bus_code || '')} — ${l.text}</span><span class="time">${timeAgoAr(r.created_at)}</span></div>`;
      }).join('')}
    </div>`;
}

// ============================================================================
// تنبيه "لم يصعد الحافلة" (ميزة تنافسية جديدة) — قائمة مباشرة تشارك نفس
// دورة التحديث (12 ثانية + Realtime على bus_trip_students) بدل مؤقت مستقل.
// ============================================================================
async function renderNonBoardingAlerts() {
  const host = document.getElementById('non-boarding-alerts');
  if (!host) return;
  const res = await getNonBoardingAlerts();
  const rows = res.ok ? res.data || [] : [];
  if (!rows.length) { host.innerHTML = ''; return; }
  host.innerHTML = `
    <div class="panel" style="margin-bottom:10px; background:#fef2f2; border:1px solid #fca5a5;">
      <strong style="color:#991b1b;">⚠️ تنبيهات لم يصعد الحافلة (${rows.length})</strong>
      ${rows.map((r) => `<div class="detail-row" style="flex-wrap:wrap;">
        <span><strong>${esc(r.full_name)}</strong> — ${esc(r.class_name || '')}</span>
        <span class="time">${esc(r.bus_code || '')} / ${esc(r.pickup_stop || '')}</span>
        <span class="badge badge-red">${r.reason === 'BUS_PASSED_STOP' ? 'الحافلة تجاوزت محطته' : `منذ ${r.minutes_since_start} د`}</span>
      </div>`).join('')}
    </div>`;
}

// ============================================================================
// Core refresh — merges fn_get_all_buses_status (full fleet incl. idle
// buses, item 3) with fn_get_active_bus_locations (richer active-trip
// data) and redraws markers in place (never rebuilds the whole map).
// ============================================================================
async function refresh() {
  const [activeRes, allRes] = await Promise.all([getActiveBusLocations(), getAllBusesStatus()]);
  const activeRows = activeRes.ok ? activeRes.data || [] : [];
  const allRows = allRes.ok ? allRes.data || [] : [];

  const byBus = new Map(activeRows.map((r) => [r.bus_id, r]));
  // Merge: prefer the richer active-trip row when present, else the
  // fleet-status row (which now also carries latitude/longitude, item 3 fix).
  const merged = allRows.map((b) => byBus.get(b.bus_id) || {
    bus_id: b.bus_id, bus_code: b.bus_code, bus_plate: b.bus_plate,
    trip_id: b.trip_id, direction: b.direction, driver_name: b.driver_name, driver_phone: b.driver_phone,
    recorded_at: b.recorded_at, latitude: b.latitude, longitude: b.longitude,
    has_active_trip: b.has_active_trip, total_students: null, boarded_count: null,
  }).map((r) => ({ ...r, has_active_trip: r.has_active_trip ?? true }));

  const container = document.getElementById('live-map-empty');
  const anyBusOnMap = merged.some((r) => r.latitude != null && r.longitude != null);
  if (container) container.hidden = anyBusOnMap;

  if (state.layers.buses) {
    const seen = new Set();
    merged.forEach((row) => {
      if (row.latitude == null || row.longitude == null) return;
      // In focus mode, only the focused bus stays on the map (item 4B: "focus" removes clutter).
      if (state.mode === 'focus' && row.bus_id !== state.focusedBusId) return;
      seen.add(row.bus_id);
      const kind = row.has_active_trip ? (isStale(row.recorded_at) ? 'stale' : 'live') : 'idle';
      const html = busPopupHtml(row);
      if (busMarkers[row.bus_id]) {
        busMarkers[row.bus_id].setLatLng([row.latitude, row.longitude]);
        busMarkers[row.bus_id].setIcon(busIcon(kind));
        busMarkers[row.bus_id].setPopupContent(html);
      } else {
        busMarkers[row.bus_id] = window.L.marker([row.latitude, row.longitude], { icon: busIcon(kind) })
          .addTo(map).bindPopup(html);
        busMarkers[row.bus_id].on('popupopen', (e) => wireBusPopupButtons(e.popup.getElement()));
      }
    });
    Object.keys(busMarkers).forEach((busId) => {
      if (!seen.has(busId)) { map.removeLayer(busMarkers[busId]); delete busMarkers[busId]; }
    });
  } else {
    Object.values(busMarkers).forEach((m) => map.removeLayer(m));
    busMarkers = {};
  }

  renderHomesLayer();
  await renderRouteLayer(activeRows);
  await renderNonBoardingAlerts();
  await renderGeofenceEvents();

  const listHost = document.getElementById('live-map-buslist');
  if (listHost && state.mode === 'general') {
    listHost.innerHTML = busListHtml(merged);
    listHost.querySelectorAll('[data-focus-bus]').forEach((b) => b.addEventListener('click', () => enterFocusMode(b.dataset.focusBus)));
    listHost.querySelectorAll('[data-history-bus]').forEach((b) => b.addEventListener('click', () => openBusHistoryModal(b.dataset.historyBus, b.dataset.label)));
  }

  return merged;
}

// ============================================================================
// Focus mode (item 4B) — zoom to the bus, highlight only its current trip's
// students' homes, keep the map uncluttered.
// ============================================================================
async function enterFocusMode(busId) {
  state.mode = 'focus';
  state.focusedBusId = busId;
  state.focusStudentIds = new Set();

  const activeRes = await getActiveBusLocations();
  const activeRow = (activeRes.ok ? activeRes.data || [] : []).find((r) => r.bus_id === busId);

  if (activeRow && activeRow.trip_id) {
    const studentsRes = await listBusStudentsOrdered(busId, activeRow.trip_id);
    (studentsRes.ok ? studentsRes.data || [] : []).forEach((s) => state.focusStudentIds.add(s.student_id));
  }

  updateFocusBar();
  const merged = await refresh();
  const focused = merged.find((r) => r.bus_id === busId);
  if (focused && focused.latitude != null) {
    map.setView([focused.latitude, focused.longitude], 15);
    if (busMarkers[busId]) busMarkers[busId].openPopup();
  }
}

function exitFocusMode() {
  state.mode = 'general';
  state.focusedBusId = null;
  state.focusStudentIds = new Set();
  updateFocusBar();
  refresh();
  if (state.schoolInfo && state.schoolInfo.latitude != null) {
    map.setView([state.schoolInfo.latitude, state.schoolInfo.longitude], 12);
  } else {
    map.setView(DEFAULT_CENTER, 12);
  }
}

function updateFocusBar() {
  const bar = document.getElementById('live-map-focus-bar');
  if (!bar) return;
  bar.hidden = state.mode !== 'focus';
}

// ============================================================================
// Item 5 — layer toggle buttons.
// ============================================================================
function wireLayerToggles() {
  hostEl.querySelectorAll('[data-layer]').forEach((btn) => {
    const key = btn.dataset.layer;
    btn.classList.toggle('active', !!state.layers[key]);
    btn.addEventListener('click', () => {
      state.layers[key] = !state.layers[key];
      btn.classList.toggle('active', state.layers[key]);
      if (key === 'stops') renderStopsLayer();
      else refresh();
    });
  });
}

// ============================================================================
// Item 11/13 — per-bus trip history + historical route replay (unchanged
// behaviour from Phase 22/23, kept as-is).
// ============================================================================

function fmtDur(startIso, endIso) {
  if (!startIso || !endIso) return '—';
  const mins = Math.round((new Date(endIso) - new Date(startIso)) / 60000);
  return mins < 60 ? `${mins} دقيقة` : `${Math.floor(mins / 60)} س ${mins % 60} د`;
}

export async function openBusHistoryModal(busId, busLabel) {
  const overlay = document.createElement('div');
  overlay.className = 'map-picker-overlay';
  overlay.innerHTML = `
    <div class="map-picker-sheet" style="max-width:560px;">
      <div class="map-picker-header"><strong>عرض الرحلة — ${esc(busLabel || '')}</strong><button type="button" class="icon-btn" id="bh-close">✕</button></div>
      <select id="bh-trip-select" class="search-input" style="width:100%; margin-bottom:8px;"><option>جارٍ التحميل...</option></select>
      <div id="bh-info" class="panel" style="margin-bottom:8px;"></div>
      <div id="bh-map" style="width:100%; height:min(45vh, 320px); border-radius:10px; background:#e5e7eb;"></div>
    </div>`;
  document.body.appendChild(overlay);
  overlay.querySelector('#bh-close').addEventListener('click', () => overlay.remove());

  const tripsRes = await listBusTrips(busId, 30);
  const trips = tripsRes.ok ? tripsRes.data || [] : [];
  const select = overlay.querySelector('#bh-trip-select');
  select.innerHTML = trips.length
    ? trips.map((t) => `<option value="${t.trip_id}">${new Date(t.started_at).toLocaleString('ar')} — ${t.direction === 'pickup' ? 'نحو المؤسسة' : 'نحو المنزل'} (${t.status})</option>`).join('')
    : '<option value="">لا توجد رحلات سابقة لهذه الحافلة.</option>';

  await loadLeaflet();
  const hmap = window.L.map('bh-map').setView(DEFAULT_CENTER, 12);
  window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 19 }).addTo(hmap);
  let polyline = null;

  async function loadSelectedTrip() {
    const tripId = select.value;
    const info = overlay.querySelector('#bh-info');
    if (!tripId) { info.innerHTML = ''; return; }
    const trip = trips.find((t) => t.trip_id === tripId);
    info.innerHTML = `
      <div class="detail-row"><span class="k">التاريخ</span><span class="v">${new Date(trip.started_at).toLocaleDateString('ar')}</span></div>
      <div class="detail-row"><span class="k">البداية</span><span class="v">${new Date(trip.started_at).toLocaleTimeString('ar')}</span></div>
      <div class="detail-row"><span class="k">النهاية</span><span class="v">${trip.ended_at ? new Date(trip.ended_at).toLocaleTimeString('ar') : 'الرحلة جارية'}</span></div>
      <div class="detail-row"><span class="k">المدة</span><span class="v">${fmtDur(trip.started_at, trip.ended_at)}</span></div>
      <div class="detail-row"><span class="k">السائق</span><span class="v">${esc(trip.driver_name || '—')}</span></div>
      <div class="detail-row"><span class="k">الاتجاه</span><span class="v">${trip.direction === 'pickup' ? 'نحو المؤسسة' : 'نحو المنزل'}</span></div>
      <div class="detail-row"><span class="k">عدد الركاب</span><span class="v">${trip.passenger_count ?? 0}</span></div>`;

    const histRes = await getTripRouteHistory(tripId);
    const points = histRes.ok ? histRes.data || [] : [];
    if (polyline) { hmap.removeLayer(polyline); polyline = null; }
    if (!points.length) {
      info.innerHTML += '<p class="empty-state" style="margin-top:8px;">لا توجد بيانات GPS لهذه الرحلة.</p>';
      return;
    }
    const latlngs = points.map((p) => [p.latitude, p.longitude]);
    polyline = window.L.polyline(latlngs, { color: '#2563eb', weight: 4 }).addTo(hmap);
    window.L.circleMarker(latlngs[0], { color: '#16a34a', radius: 7 }).addTo(hmap).bindTooltip('البداية');
    window.L.circleMarker(latlngs[latlngs.length - 1], { color: '#dc2626', radius: 7 }).addTo(hmap).bindTooltip('النهاية');
    hmap.fitBounds(polyline.getBounds(), { padding: [20, 20] });
    setTimeout(() => hmap.invalidateSize(), 50);
  }
  select.addEventListener('change', loadSelectedTrip);
  if (trips.length) loadSelectedTrip();
  setTimeout(() => hmap.invalidateSize(), 60);
}

// ============================================================================
// Entry point
// ============================================================================
export async function renderLiveMap(container) {
  hostEl = container;
  state = { mode: 'general', focusedBusId: null, layers: { homes: true, buses: true, stops: false, route: false }, schoolInfo: null, homes: [], stops: [], focusStudentIds: new Set() };
  busMarkers = {}; homeMarkers = {}; stopMarkers = []; schoolMarker = null; routeLine = null;

  container.innerHTML = `
    <div id="live-map-focus-bar" hidden style="display:flex; align-items:center; gap:8px; margin-bottom:8px;">
      <button type="button" class="quick-action-btn secondary" id="live-map-exit-focus">🔙 الخريطة العامة</button>
      <span class="time">وضع تفاصيل الحافلة</span>
    </div>
    <div class="layer-toggles" style="display:flex; gap:6px; flex-wrap:wrap; margin-bottom:8px;">
      <button type="button" class="quick-action-btn secondary" data-layer="homes" style="padding:4px 10px; font-size:.85em;">🏠 المنازل</button>
      <button type="button" class="quick-action-btn secondary" data-layer="buses" style="padding:4px 10px; font-size:.85em;">🚌 الحافلات</button>
      <button type="button" class="quick-action-btn secondary" data-layer="stops" style="padding:4px 10px; font-size:.85em;">📍 نقاط التوقف</button>
      <button type="button" class="quick-action-btn secondary" data-layer="route" style="padding:4px 10px; font-size:.85em;">➖ المسار</button>
    </div>
    <div id="live-map" style="width:100%; height:min(60vh, 420px); border-radius:10px; background:#e5e7eb;"></div>
    <p class="empty-state" id="live-map-empty" style="margin-top:8px;">لا توجد حافلة في الموقع بعد.</p>
    <div id="live-map-buslist"></div>`;

  try {
    await loadLeaflet();
  } catch {
    container.innerHTML = '<div class="empty-state">تعذر تحميل الخريطة (تحقق من الاتصال بالإنترنت).</div>';
    return () => {};
  }

  const [overviewRes, homesRes, stopsRes] = await Promise.all([
    getSchoolMapOverview(), getSchoolStudentHomes(), getSchoolBusStops(),
  ]);
  state.schoolInfo = overviewRes.ok ? (overviewRes.data || [])[0] || null : null;
  state.homes = homesRes.ok ? homesRes.data || [] : [];
  state.stops = stopsRes.ok ? stopsRes.data || [] : [];

  const center = state.schoolInfo && state.schoolInfo.latitude != null
    ? [state.schoolInfo.latitude, state.schoolInfo.longitude] : DEFAULT_CENTER;
  map = window.L.map('live-map').setView(center, 12);
  window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 19 }).addTo(map);
  setTimeout(() => map.invalidateSize(), 50);

  renderSchoolMarker();
  renderStopsLayer();
  wireLayerToggles();
  container.querySelector('#live-map-exit-focus').addEventListener('click', exitFocusMode);

  await refresh();
  pollTimer = setInterval(refresh, POLL_MS);

  // Best-effort Realtime on both GPS pings (position) AND boarding/dropoff
  // (passenger count, item 8) — a project without Realtime enabled simply
  // never fires these and the 12s poll above keeps everything correct.
  realtimeChannels = [
    supabase.channel('bus-locations-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'bus_last_locations' }, () => refresh())
      .subscribe(),
    supabase.channel('bus-trip-students-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'bus_trip_students' }, () => refresh())
      .subscribe(),
  ];

  return function cleanupLiveMap() {
    if (pollTimer) clearInterval(pollTimer);
    realtimeChannels.forEach((ch) => supabase.removeChannel(ch));
    realtimeChannels = [];
    if (map) { map.remove(); map = null; }
    busMarkers = {}; homeMarkers = {}; stopMarkers = []; schoolMarker = null; routeLine = null;
  };
}
