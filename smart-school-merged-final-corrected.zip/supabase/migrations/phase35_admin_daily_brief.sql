-- ============================================================================
-- PHASE 35 — لوحة "صباح اليوم" للمدير (ميزة تنافسية جديدة)
-- Purely additive: one brand-new function, no existing table/function touched.
-- Aggregates four things the admin currently has to open four separate
-- screens to see, into one JSONB payload for a single opening dashboard:
--   - غياب اليوم (attendance_records, status='absent', att_date=today)
--   - حافلات متأخرة (ACTIVE trips running longer than LATE_MINUTES)
--   - بطاقات معلّقة (student_badges.status = 'SUSPENDED')
--   - حوادث مفتوحة (incidents.status = 'open')
-- Each list is capped (top 10) — this is a glance dashboard, not a report;
-- the admin can still open the full screen for any of the four via the
-- existing views.
-- ============================================================================
create or replace function fn_get_admin_daily_brief()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_late_minutes constant int := 45;
  v_result jsonb;
  v_absences jsonb;
  v_late_buses jsonb;
  v_suspended_badges jsonb;
  v_open_incidents jsonb;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director', 'superadmin') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  select coalesce(jsonb_agg(x), '[]'::jsonb) into v_absences from (
    select s.id as student_id, s.full_name, c.name as class_name
    from attendance_records ar
    join students s on s.id = ar.student_id
    left join classes c on c.id = ar.class_id
    where ar.school_id = v_school_id and ar.att_date = current_date and ar.status = 'absent'
    order by s.full_name
    limit 10
  ) x;

  select coalesce(jsonb_agg(x), '[]'::jsonb) into v_late_buses from (
    select b.code as bus_code,
           case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup' else 'dropoff' end as direction,
           (extract(epoch from (now() - t.starts_at))::int / 60) as minutes_since_start
    from bus_trips t
    join buses b on b.id = t.bus_id
    where t.school_id = v_school_id and t.status = 'ACTIVE'::trip_status
      and now() - t.starts_at > (v_late_minutes || ' minutes')::interval
    order by t.starts_at
    limit 10
  ) x;

  select coalesce(jsonb_agg(x), '[]'::jsonb) into v_suspended_badges from (
    select s.id as student_id, s.full_name, sb.created_at
    from student_badges sb
    join students s on s.id = sb.student_id
    join classes c on c.id = (select se.class_id from student_enrollments se
                               where se.student_id = s.id and se.status = 'ACTIVE' limit 1)
    where c.school_id = v_school_id and sb.status = 'SUSPENDED'::badge_status
    order by sb.created_at desc
    limit 10
  ) x;

  select coalesce(jsonb_agg(x), '[]'::jsonb) into v_open_incidents from (
    select i.id, i.title, i.type, i.occurred_at, s.full_name as student_name
    from incidents i
    join students s on s.id = i.student_id
    where i.school_id = v_school_id and i.status = 'open'
    order by i.occurred_at desc
    limit 10
  ) x;

  v_result := jsonb_build_object(
    'generated_at', now(),
    'absences', jsonb_build_object('count', jsonb_array_length(v_absences), 'items', v_absences),
    'late_buses', jsonb_build_object('count', jsonb_array_length(v_late_buses), 'items', v_late_buses),
    'suspended_badges', jsonb_build_object('count', jsonb_array_length(v_suspended_badges), 'items', v_suspended_badges),
    'open_incidents', jsonb_build_object('count', jsonb_array_length(v_open_incidents), 'items', v_open_incidents)
  );
  return v_result;
end;
$$;
revoke all on function fn_get_admin_daily_brief() from public;
grant execute on function fn_get_admin_daily_brief() to authenticated;
