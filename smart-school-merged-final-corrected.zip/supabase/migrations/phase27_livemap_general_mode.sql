-- ============================================================================
-- PHASE 27 — LIVE MAP GENERAL MODE (spec items 1-6)
-- Purely additive: no DROP TABLE, no TRUNCATE, no unconditional DELETE.
-- Only fn_get_all_buses_status is redefined (CREATE OR REPLACE, same
-- purpose, extended return columns) to fix a real bug: it never returned
-- a last-known GPS point for buses with no ACTIVE trip right now, because
-- it joined bus_last_locations on trip_id = t.id, which is NULL for an
-- idle bus and therefore never matches (item 3 requires exactly this:
-- idle buses shown grey with their last known point, not hidden).
-- Every other function here is brand new (fn_get_school_map_overview,
-- fn_get_school_student_homes, fn_get_school_bus_stops).
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1) fn_get_school_map_overview — school marker (🏫) for the general map.
--    Admin/superadmin of that school only (same scoping pattern as the rest
--    of the live-tracking RPCs in phase22/23).
-- ----------------------------------------------------------------------------
create or replace function fn_get_school_map_overview()
returns table(
  school_id uuid, name text, logo_url text,
  latitude double precision, longitude double precision,
  address text, city text
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director', 'superadmin') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select s.id, s.name, s.logo_url, s.latitude, s.longitude, s.address, s.city
  from schools s
  where s.id = v_school_id;
end;
$$;
revoke all on function fn_get_school_map_overview() from public;
grant execute on function fn_get_school_map_overview() to authenticated;


-- ----------------------------------------------------------------------------
-- 2) fn_get_school_student_homes — item 2: ALL students of the school who
--    already have a saved home location (students.latitude/longitude), not
--    just the ones on a currently active trip. Only students actively
--    enrolled in the current academic year (mirrors listClasses/
--    filterStudents convention elsewhere in the codebase) and not
--    soft-deleted. Students without coordinates are simply absent from the
--    result — the frontend must never invent a marker for them (item 2).
-- ----------------------------------------------------------------------------
create or replace function fn_get_school_student_homes()
returns table(
  student_id uuid, full_name text, student_number text,
  class_name text, latitude double precision, longitude double precision,
  location_label text
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director', 'superadmin') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select s.id, s.full_name, s.student_number, c.name,
         s.latitude, s.longitude, s.location_label
  from students s
  join student_enrollments se on se.student_id = s.id and se.status = 'ACTIVE'
  join classes c on c.id = se.class_id
  join academic_years ay on ay.id = c.academic_year_id and ay.is_current = true
  where c.school_id = v_school_id
    and s.deleted_at is null
    and s.latitude is not null
    and s.longitude is not null;
end;
$$;
revoke all on function fn_get_school_student_homes() from public;
grant execute on function fn_get_school_student_homes() to authenticated;


-- ----------------------------------------------------------------------------
-- 3) fn_get_school_bus_stops — item 5, "📍 نقاط التوقف" layer: every stop
--    belonging to the school that has coordinates. Real data only.
-- ----------------------------------------------------------------------------
create or replace function fn_get_school_bus_stops()
returns table(stop_id uuid, name text, latitude double precision, longitude double precision)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director', 'superadmin') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select bs.id, bs.name, bs.latitude, bs.longitude
  from bus_stops bs
  where bs.school_id = v_school_id
    and bs.latitude is not null
    and bs.longitude is not null;
end;
$$;
revoke all on function fn_get_school_bus_stops() from public;
grant execute on function fn_get_school_bus_stops() to authenticated;


-- ----------------------------------------------------------------------------
-- 4) fn_get_all_buses_status — BUGFIX + extension (item 3). Same signature/
--    purpose as phase23, CREATE OR REPLACE only:
--      - real bug fixed: bus_last_locations now joined on bus_id alone, so
--        an idle bus (no ACTIVE trip, t.id is null) still gets its last
--        known point instead of never joining at all;
--      - new columns: latitude/longitude of that last point, and
--        is_from_active_trip so the frontend can tell "🟢 Live" (has an
--        active trip AND a recent point) apart from "⚪ آخر موقع معروف"
--        (a point exists but there's no active trip right now) apart from
--        "no marker at all" (no point ever recorded).
-- ----------------------------------------------------------------------------
drop function if exists fn_get_all_buses_status();

create function fn_get_all_buses_status()
returns table(
  bus_id uuid, bus_code text, bus_plate text,
  has_active_trip boolean, trip_id uuid, direction text,
  driver_name text, recorded_at timestamptz,
  latitude double precision, longitude double precision,
  is_from_active_trip boolean
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director', 'superadmin') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select b.id, b.code, b.plate_number,
         t.id is not null, t.id,
         case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup'
              when t.direction = 'TO_HOME'::trip_direction then 'dropoff' else null end,
         p.full_name, ll.recorded_at,
         ll.latitude, ll.longitude,
         (t.id is not null and ll.trip_id = t.id)
  from buses b
  left join bus_trips t on t.bus_id = b.id and t.status = 'ACTIVE'::trip_status
  left join bus_last_locations ll on ll.bus_id = b.id
  left join drivers d on d.id = coalesce(t.driver_id, b.driver_id)
  left join profiles p on p.id = d.profile_id
  where b.school_id = v_school_id
  order by b.code;
end;
$$;
revoke all on function fn_get_all_buses_status() from public;
grant execute on function fn_get_all_buses_status() to authenticated;
