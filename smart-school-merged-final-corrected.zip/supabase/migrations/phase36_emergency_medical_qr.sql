-- ============================================================================
-- PHASE 36 — 🏥 السجل الطبي الطارئ عبر QR (ميزة تنافسية جديدة)
-- Purely additive: one new table, three new functions. No existing table
-- or function touched. No DROP TABLE/TRUNCATE.
--
-- Design:
--   - New table `student_medical_info` — one row per student. RLS enabled
--     with NO policies at all (deny-by-default for every direct client
--     query); every read/write goes through a SECURITY DEFINER function
--     below. This is deliberately stricter than most tables in this
--     project because it holds health data.
--   - The PARENT is the one who fills it in (they know the real allergy/
--     medication/contact details) via fn_parent_set_child_medical_info /
--     fn_parent_get_child_medical_info (fn_is_parent_of — same helper
--     used everywhere else for parent-scoped access).
--   - Guard/driver/teacher access is ON-DEMAND ONLY, by scanning the
--     student's EXISTING real QR (badge secure_token) — never shown by
--     default alongside a normal scan result, only when the staff member
--     explicitly asks for it in an emergency
--     (fn_get_student_medical_by_badge_token). Same ACTIVE-only badge
--     validation as every other QR-consuming function in this project
--     (fn_driver_lookup_badge, lookupByBadgeToken/classifyStudent).
-- ============================================================================
create table if not exists student_medical_info (
  student_id uuid primary key references students(id) on delete cascade,
  allergies text,
  emergency_medication text,
  emergency_contact_name text,
  emergency_contact_phone text,
  notes text,
  updated_at timestamptz not null default now(),
  updated_by uuid references profiles(id)
);
alter table student_medical_info enable row level security;
-- Deliberately no policies — every access goes through the functions below.

create or replace function fn_parent_get_child_medical_info(p_student_id uuid)
returns table(
  allergies text, emergency_medication text,
  emergency_contact_name text, emergency_contact_phone text,
  notes text, updated_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not fn_is_parent_of(p_student_id) then
    raise exception 'PERMISSION_DENIED';
  end if;
  return query
  select m.allergies, m.emergency_medication, m.emergency_contact_name,
         m.emergency_contact_phone, m.notes, m.updated_at
  from student_medical_info m
  where m.student_id = p_student_id;
end;
$$;
revoke all on function fn_parent_get_child_medical_info(uuid) from public;
grant execute on function fn_parent_get_child_medical_info(uuid) to authenticated;


create or replace function fn_parent_set_child_medical_info(
  p_student_id uuid, p_allergies text, p_emergency_medication text,
  p_emergency_contact_name text, p_emergency_contact_phone text, p_notes text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not fn_is_parent_of(p_student_id) then
    raise exception 'PERMISSION_DENIED';
  end if;

  insert into student_medical_info (
    student_id, allergies, emergency_medication,
    emergency_contact_name, emergency_contact_phone, notes, updated_at, updated_by
  ) values (
    p_student_id, nullif(trim(coalesce(p_allergies, '')), ''), nullif(trim(coalesce(p_emergency_medication, '')), ''),
    nullif(trim(coalesce(p_emergency_contact_name, '')), ''), nullif(trim(coalesce(p_emergency_contact_phone, '')), ''),
    nullif(trim(coalesce(p_notes, '')), ''), now(), auth.uid()
  )
  on conflict (student_id) do update set
    allergies = excluded.allergies,
    emergency_medication = excluded.emergency_medication,
    emergency_contact_name = excluded.emergency_contact_name,
    emergency_contact_phone = excluded.emergency_contact_phone,
    notes = excluded.notes,
    updated_at = now(),
    updated_by = auth.uid();
end;
$$;
revoke all on function fn_parent_set_child_medical_info(uuid, text, text, text, text, text) from public;
grant execute on function fn_parent_set_child_medical_info(uuid, text, text, text, text, text) to authenticated;


-- On-demand emergency lookup by the SAME real QR/badge token already used
-- everywhere else (student_badges.secure_token) — no second QR, no new
-- code to scan. Any authenticated school staff member (guard/teacher/
-- driver/admin) of the SAME school as the student may call this; it does
-- NOT require any special "medical" permission grant, because in a real
-- emergency nobody should be blocked by a missing permission row — the
-- barrier is deliberately "you must possess and scan the physical badge",
-- not a configurable permission.
create or replace function fn_get_student_medical_by_badge_token(p_secure_token uuid)
returns table(
  full_name text, student_number text,
  allergies text, emergency_medication text,
  emergency_contact_name text, emergency_contact_phone text, notes text
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_badge record;
  v_student record;
  v_caller_school uuid;
begin
  select sb.student_id, sb.status into v_badge
  from student_badges sb where sb.secure_token = p_secure_token;

  if v_badge.student_id is null then raise exception 'INVALID_QR'; end if;
  if v_badge.status <> 'ACTIVE'::badge_status then raise exception 'BADGE_NOT_ACTIVE'; end if;

  select s.full_name, s.student_number, se.class_id
    into v_student
  from students s
  left join student_enrollments se on se.student_id = s.id and se.status = 'ACTIVE'
  where s.id = v_badge.student_id and s.deleted_at is null;
  if v_student.full_name is null then raise exception 'STUDENT_NOT_FOUND'; end if;

  select c.school_id into v_caller_school
  from classes c
  where c.id = v_student.class_id;

  if v_caller_school is null or not fn_is_school_member(v_caller_school) then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select v_student.full_name, v_student.student_number,
         m.allergies, m.emergency_medication, m.emergency_contact_name,
         m.emergency_contact_phone, m.notes
  from student_medical_info m
  where m.student_id = v_badge.student_id;

  if not found then
    return query select v_student.full_name, v_student.student_number,
      null::text, null::text, null::text, null::text, null::text;
  end if;
end;
$$;
revoke all on function fn_get_student_medical_by_badge_token(uuid) from public;
grant execute on function fn_get_student_medical_by_badge_token(uuid) to authenticated;
