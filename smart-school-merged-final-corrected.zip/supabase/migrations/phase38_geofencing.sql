-- ============================================================================
-- PHASE 38 — 📍 Geofencing (ميزة تنافسية جديدة)
-- Purely additive: 2 new columns (ALTER TABLE ADD COLUMN IF NOT EXISTS,
-- both with safe defaults — no existing row breaks), 1 new table, 2 new
-- helper functions, and fn_record_gps_ping recreated with the SAME
-- signature (CREATE OR REPLACE) plus the detection logic appended at the
-- end — every existing call site keeps working unchanged. No DROP TABLE,
-- no TRUNCATE.
--
-- Two independent checks, both evaluated on every real GPS ping (the
-- existing fn_record_gps_ping — no new trigger, no new infra):
--   1) SCHOOL geofence — simple point/radius (haversine) around
--      schools.latitude/longitude, radius = schools.geofence_radius_m
--      (default 300m, editable per school).
--   2) ROUTE corridor — distance from the bus's current point to the
--      route's own path (the straight segments between its stops, in
--      sequence_order), radius = bus_routes.corridor_width_m (default
--      400m, editable per route). No PostGIS in this stack, so the
--      corridor uses a local equirectangular (flat-earth) projection
--      centered on the route's first stop — accurate enough at the
--      few-kilometer scale of a single school route, not meant for
--      long-haul geodesic precision. This is a labeled approximation,
--      same honesty standard as the ETA feature (phase33).
-- An event is only logged on a STATE TRANSITION (inside->outside or vice
-- versa), never on every ping, comparing the previous ping (still visible
-- as the pre-upsert row in bus_last_locations) to the new one — this
-- keeps the log meaningful instead of one row per GPS update.
-- ============================================================================

alter table schools add column if not exists geofence_radius_m integer not null default 300;
alter table bus_routes add column if not exists corridor_width_m integer not null default 400;

create table if not exists geofence_events (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references schools(id) on delete cascade,
  bus_id uuid not null references buses(id) on delete cascade,
  trip_id uuid references bus_trips(id) on delete set null,
  event_type text not null check (event_type in ('SCHOOL_ENTER', 'SCHOOL_EXIT', 'ROUTE_DEVIATION', 'ROUTE_BACK_ON_TRACK')),
  latitude double precision not null,
  longitude double precision not null,
  distance_m numeric,
  created_at timestamptz not null default now()
);
create index if not exists ix_geofence_events_school on geofence_events (school_id, created_at desc);
create index if not exists ix_geofence_events_bus on geofence_events (bus_id, created_at desc);
alter table geofence_events enable row level security;
-- No policies — read only via fn_get_geofence_events below.

create or replace function fn_haversine_km(p_lat1 double precision, p_lng1 double precision, p_lat2 double precision, p_lng2 double precision)
returns numeric
language sql
immutable
as $$
  select 6371 * 2 * asin(sqrt(
    sin(radians(p_lat2 - p_lat1) / 2) ^ 2 +
    cos(radians(p_lat1)) * cos(radians(p_lat2)) * sin(radians(p_lng2 - p_lng1) / 2) ^ 2
  ));
$$;

-- Minimum distance (meters) from a point to a route's path (the polyline
-- through its stops, in sequence_order). NULL if the route has fewer than
-- 2 stops with coordinates (nothing to compare against).
create or replace function fn_min_distance_to_route_m(p_route_id uuid, p_lat double precision, p_lng double precision)
returns numeric
language plpgsql
stable
as $$
declare
  v_ref_lat double precision;
  v_ref_lng double precision;
  v_px double precision; -- point, projected meters
  v_py double precision;
  v_prev_x double precision;
  v_prev_y double precision;
  v_has_prev boolean := false;
  v_min_dist numeric := null;
  v_seg_dist numeric;
  v_stop record;
  v_cur_x double precision;
  v_cur_y double precision;
  v_t double precision;
  v_dx double precision; v_dy double precision;
begin
  select bs.latitude, bs.longitude into v_ref_lat, v_ref_lng
  from bus_route_stops brs join bus_stops bs on bs.id = brs.stop_id
  where brs.route_id = p_route_id and bs.latitude is not null and bs.longitude is not null
  order by brs.sequence_order limit 1;
  if v_ref_lat is null then return null; end if;

  v_px := (p_lng - v_ref_lng) * 111320 * cos(radians(v_ref_lat));
  v_py := (p_lat - v_ref_lat) * 110540;

  for v_stop in
    select bs.latitude, bs.longitude
    from bus_route_stops brs join bus_stops bs on bs.id = brs.stop_id
    where brs.route_id = p_route_id and bs.latitude is not null and bs.longitude is not null
    order by brs.sequence_order
  loop
    v_cur_x := (v_stop.longitude - v_ref_lng) * 111320 * cos(radians(v_ref_lat));
    v_cur_y := (v_stop.latitude - v_ref_lat) * 110540;

    if v_has_prev then
      v_dx := v_cur_x - v_prev_x; v_dy := v_cur_y - v_prev_y;
      if v_dx = 0 and v_dy = 0 then
        v_seg_dist := sqrt((v_px - v_cur_x) ^ 2 + (v_py - v_cur_y) ^ 2);
      else
        v_t := ((v_px - v_prev_x) * v_dx + (v_py - v_prev_y) * v_dy) / (v_dx ^ 2 + v_dy ^ 2);
        v_t := greatest(0, least(1, v_t));
        v_seg_dist := sqrt((v_px - (v_prev_x + v_t * v_dx)) ^ 2 + (v_py - (v_prev_y + v_t * v_dy)) ^ 2);
      end if;
      if v_min_dist is null or v_seg_dist < v_min_dist then v_min_dist := v_seg_dist; end if;
    end if;

    v_prev_x := v_cur_x; v_prev_y := v_cur_y; v_has_prev := true;
  end loop;

  return v_min_dist; -- meters (projection is already in meters)
end;
$$;


create or replace function fn_record_gps_ping(
  p_trip_id uuid, p_latitude double precision, p_longitude double precision,
  p_accuracy double precision default null, p_speed double precision default null, p_heading double precision default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_trip bus_trips%rowtype;
  v_driver_id uuid;
  v_old record;
  v_school record;
  v_route_id uuid;
  v_old_school_km numeric; v_new_school_km numeric;
  v_old_route_m numeric; v_new_route_m numeric;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select d.id into v_driver_id from drivers d
  where d.profile_id = auth.uid() and d.deleted_at is null limit 1;
  if v_driver_id is null then raise exception 'NOT_A_DRIVER'; end if;

  select * into v_trip from bus_trips where id = p_trip_id;
  if v_trip.id is null or v_trip.driver_id <> v_driver_id then
    raise exception 'PERMISSION_DENIED';
  end if;
  if v_trip.status <> 'ACTIVE'::trip_status then
    raise exception 'TRIP_NOT_ACTIVE';
  end if;

  if p_latitude < -90 or p_latitude > 90 or p_longitude < -180 or p_longitude > 180 then
    raise exception 'INVALID_COORDINATES';
  end if;

  -- Item (new, geofencing) — capture the PREVIOUS ping before it's overwritten.
  select ll.latitude, ll.longitude into v_old from bus_last_locations ll where ll.bus_id = v_trip.bus_id;

  insert into bus_trip_locations (trip_id, driver_id, bus_id, school_id, latitude, longitude, accuracy, speed, heading)
  values (p_trip_id, v_driver_id, v_trip.bus_id, v_trip.school_id, p_latitude, p_longitude, p_accuracy, p_speed, p_heading);

  insert into bus_last_locations (bus_id, trip_id, driver_id, school_id, latitude, longitude, accuracy, speed, heading, recorded_at)
  values (v_trip.bus_id, p_trip_id, v_driver_id, v_trip.school_id, p_latitude, p_longitude, p_accuracy, p_speed, p_heading, now())
  on conflict (bus_id) do update
    set trip_id = excluded.trip_id, driver_id = excluded.driver_id,
        latitude = excluded.latitude, longitude = excluded.longitude,
        accuracy = excluded.accuracy, speed = excluded.speed, heading = excluded.heading,
        recorded_at = excluded.recorded_at;

  -- Geofencing (only meaningful once we have a previous point to compare against).
  if v_old.latitude is not null then
    select s.latitude, s.longitude, s.geofence_radius_m into v_school from schools s where s.id = v_trip.school_id;
    if v_school.latitude is not null then
      v_old_school_km := fn_haversine_km(v_old.latitude, v_old.longitude, v_school.latitude, v_school.longitude);
      v_new_school_km := fn_haversine_km(p_latitude, p_longitude, v_school.latitude, v_school.longitude);
      if (v_old_school_km * 1000 > v_school.geofence_radius_m) <> (v_new_school_km * 1000 > v_school.geofence_radius_m) then
        insert into geofence_events (school_id, bus_id, trip_id, event_type, latitude, longitude, distance_m)
        values (v_trip.school_id, v_trip.bus_id, p_trip_id,
                case when v_new_school_km * 1000 <= v_school.geofence_radius_m then 'SCHOOL_ENTER' else 'SCHOOL_EXIT' end,
                p_latitude, p_longitude, round((v_new_school_km * 1000)::numeric, 1));
      end if;
    end if;

    v_route_id := v_trip.route_id;
    if v_route_id is not null then
      v_old_route_m := fn_min_distance_to_route_m(v_route_id, v_old.latitude, v_old.longitude);
      v_new_route_m := fn_min_distance_to_route_m(v_route_id, p_latitude, p_longitude);
      if v_old_route_m is not null and v_new_route_m is not null then
        declare v_corridor int;
        begin
          select corridor_width_m into v_corridor from bus_routes where id = v_route_id;
          if (v_old_route_m > v_corridor) <> (v_new_route_m > v_corridor) then
            insert into geofence_events (school_id, bus_id, trip_id, event_type, latitude, longitude, distance_m)
            values (v_trip.school_id, v_trip.bus_id, p_trip_id,
                    case when v_new_route_m <= v_corridor then 'ROUTE_BACK_ON_TRACK' else 'ROUTE_DEVIATION' end,
                    p_latitude, p_longitude, round(v_new_route_m, 1));
          end if;
        end;
      end if;
    end if;
  end if;
end;
$$;
revoke all on function fn_record_gps_ping(uuid, double precision, double precision, double precision, double precision, double precision) from public;
grant execute on function fn_record_gps_ping(uuid, double precision, double precision, double precision, double precision, double precision) to authenticated;


-- Admin-facing read of recent geofence events for the school (live panel,
-- same polling pattern as the rest of the live-tracking screen).
create or replace function fn_get_geofence_events(p_limit int default 20)
returns table(
  id uuid, bus_id uuid, bus_code text, event_type text,
  distance_m numeric, latitude double precision, longitude double precision, created_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director', 'superadmin') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select g.id, g.bus_id, b.code, g.event_type, g.distance_m, g.latitude, g.longitude, g.created_at
  from geofence_events g
  join buses b on b.id = g.bus_id
  where g.school_id = v_school_id
  order by g.created_at desc
  limit least(coalesce(p_limit, 20), 50);
end;
$$;
revoke all on function fn_get_geofence_events(int) from public;
grant execute on function fn_get_geofence_events(int) to authenticated;
