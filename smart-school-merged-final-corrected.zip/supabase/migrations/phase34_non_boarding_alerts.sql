-- ============================================================================
-- PHASE 34 — تنبيه "لم يصعد الحافلة" (ميزة تنافسية جديدة)
-- Purely additive: fn_get_child_bus_eta gets 2 new output columns (its
-- signature changes, so DROP+CREATE like the project's own precedent in
-- phase23/27/32 for the same reason); fn_get_non_boarding_alerts is brand
-- new. No table changed, no DROP TABLE/TRUNCATE anywhere.
--
-- Two independent signals, used at two different scopes:
--   1) TIME_THRESHOLD (used for BOTH the parent's own child and the admin
--      list): the TO_SCHOOL trip has been running longer than
--      ALERT_MINUTES (20) and the child still has no boarded_at. Simple,
--      robust, works even with a single stop on the route.
--   2) BUS_PASSED_STOP (admin list only — needs comparing across several
--      students on the same route, which only makes sense in an
--      aggregate/admin view): another student on the SAME route whose
--      pickup stop sequence is LATER than this child's stop has already
--      boarded on this trip. A bus can only reach a later stop by first
--      passing through the earlier one, so if a later student is aboard
--      and this one isn't, the bus already passed this child's stop
--      without them — a much earlier and more precise signal than a
--      fixed time threshold, using data (bus_route_stops.sequence_order,
--      boarding events) that already exists.
-- ============================================================================

drop function if exists fn_get_child_bus_eta(uuid);

create function fn_get_child_bus_eta(p_student_id uuid)
returns table(
  has_active_trip boolean,
  direction text,
  target_label text,
  is_boarded boolean,
  is_dropped boolean,
  bus_latitude double precision, bus_longitude double precision,
  target_latitude double precision, target_longitude double precision,
  distance_km numeric,
  eta_minutes int,
  speed_kmh numeric,
  recorded_at timestamptz,
  is_stale boolean,
  not_boarded_alert boolean,
  alert_reason text
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_sta record;
  v_trip record;
  v_bts record;
  v_school record;
  v_ll record;
  v_target_lat double precision;
  v_target_lng double precision;
  v_target_label text;
  v_dist_km numeric;
  v_speed_kmh numeric;
  v_earth_radius_km constant numeric := 6371;
  v_alert_minutes constant int := 20; -- same threshold as fn_get_non_boarding_alerts
  v_not_boarded_alert boolean := false;
  v_alert_reason text := null;
begin
  if not fn_is_parent_of(p_student_id) then
    raise exception 'PERMISSION_DENIED';
  end if;

  select sta.bus_id, sta.pickup_stop_id, sta.dropoff_stop_id, sta.route_id
    into v_sta
  from student_transport_assignments sta
  join academic_years ay on ay.id = sta.academic_year_id and ay.is_current = true
  where sta.student_id = p_student_id and sta.is_active = true
  limit 1;

  if v_sta.bus_id is null then
    return query select false, null::text, null::text, null::boolean, null::boolean,
      null::double precision, null::double precision, null::double precision, null::double precision,
      null::numeric, null::int, null::numeric, null::timestamptz, null::boolean, false, null::text;
    return;
  end if;

  select t.id as trip_id, t.direction, t.school_id, t.starts_at
    into v_trip
  from bus_trips t
  where t.bus_id = v_sta.bus_id and t.status = 'ACTIVE'::trip_status
  order by t.starts_at desc
  limit 1;

  if v_trip.trip_id is null then
    return query select false, null::text, null::text, null::boolean, null::boolean,
      null::double precision, null::double precision, null::double precision, null::double precision,
      null::numeric, null::int, null::numeric, null::timestamptz, null::boolean, false, null::text;
    return;
  end if;

  select bts.boarded_at, bts.dropped_at into v_bts
  from bus_trip_students bts
  where bts.trip_id = v_trip.trip_id and bts.student_id = p_student_id;

  -- Item (new) — non-boarding alert, TO_SCHOOL trips only.
  if v_trip.direction = 'TO_SCHOOL'::trip_direction and v_bts.boarded_at is null
     and now() - v_trip.starts_at > (v_alert_minutes || ' minutes')::interval then
    v_not_boarded_alert := true;
    v_alert_reason := 'TIME_THRESHOLD';
  end if;

  select s.name, s.latitude, s.longitude into v_school from schools s where s.id = v_trip.school_id;

  if v_trip.direction = 'TO_HOME'::trip_direction then
    select bs.name, bs.latitude, bs.longitude into v_target_label, v_target_lat, v_target_lng
    from bus_stops bs where bs.id = v_sta.dropoff_stop_id;
  else -- TO_SCHOOL
    if v_bts.boarded_at is not null then
      v_target_label := coalesce(v_school.name, 'المؤسسة');
      v_target_lat := v_school.latitude; v_target_lng := v_school.longitude;
    else
      select bs.name, bs.latitude, bs.longitude into v_target_label, v_target_lat, v_target_lng
      from bus_stops bs where bs.id = v_sta.pickup_stop_id;
    end if;
  end if;

  if v_target_lat is null or v_target_lng is null then
    return query select true, (case when v_trip.direction = 'TO_HOME'::trip_direction then 'dropoff' else 'pickup' end),
      v_target_label, (v_bts.boarded_at is not null), (v_bts.dropped_at is not null),
      null::double precision, null::double precision, v_target_lat, v_target_lng,
      null::numeric, null::int, null::numeric, null::timestamptz, null::boolean,
      v_not_boarded_alert, v_alert_reason;
    return;
  end if;

  select ll.latitude, ll.longitude, ll.speed, ll.recorded_at into v_ll
  from bus_last_locations ll where ll.bus_id = v_sta.bus_id;

  if v_ll.latitude is null or v_ll.longitude is null then
    return query select true, (case when v_trip.direction = 'TO_HOME'::trip_direction then 'dropoff' else 'pickup' end),
      v_target_label, (v_bts.boarded_at is not null), (v_bts.dropped_at is not null),
      null::double precision, null::double precision, v_target_lat, v_target_lng,
      null::numeric, null::int, null::numeric, null::timestamptz, null::boolean,
      v_not_boarded_alert, v_alert_reason;
    return;
  end if;

  v_dist_km := v_earth_radius_km * 2 * asin(sqrt(
    sin(radians(v_target_lat - v_ll.latitude) / 2) ^ 2 +
    cos(radians(v_ll.latitude)) * cos(radians(v_target_lat)) *
    sin(radians(v_target_lng - v_ll.longitude) / 2) ^ 2
  ));

  v_speed_kmh := coalesce(v_ll.speed, 0) * 3.6;
  if v_speed_kmh < 5 then v_speed_kmh := 18; end if;
  v_speed_kmh := least(greatest(v_speed_kmh, 8), 60);

  return query select
    true,
    (case when v_trip.direction = 'TO_HOME'::trip_direction then 'dropoff' else 'pickup' end),
    v_target_label,
    (v_bts.boarded_at is not null), (v_bts.dropped_at is not null),
    v_ll.latitude, v_ll.longitude, v_target_lat, v_target_lng,
    round(v_dist_km::numeric, 2),
    ceil(((v_dist_km * 1.3) / v_speed_kmh) * 60)::int,
    round(v_speed_kmh, 1),
    v_ll.recorded_at,
    (v_ll.recorded_at is null or now() - v_ll.recorded_at > interval '90 seconds'),
    v_not_boarded_alert, v_alert_reason;
end;
$$;
revoke all on function fn_get_child_bus_eta(uuid) from public;
grant execute on function fn_get_child_bus_eta(uuid) to authenticated;


-- ----------------------------------------------------------------------------
-- fn_get_non_boarding_alerts — admin-wide list, across every bus currently
-- on a TO_SCHOOL trip, of assigned students who have not boarded yet and
-- either signal above applies. BUS_PASSED_STOP takes priority in the
-- returned reason when both are true (it is the more precise/earlier one).
-- ----------------------------------------------------------------------------
create or replace function fn_get_non_boarding_alerts()
returns table(
  student_id uuid, full_name text, class_name text,
  bus_id uuid, bus_code text, route_name text, pickup_stop text,
  trip_id uuid, minutes_since_start int, reason text
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_alert_minutes constant int := 20;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director', 'superadmin') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select
    s.id, s.full_name, c.name,
    b.id, b.code, r.name, bs.name,
    t.id,
    extract(epoch from (now() - t.starts_at))::int / 60,
    case when exists (
      select 1
      from bus_trip_students bts2
      join student_transport_assignments sta2
        on sta2.student_id = bts2.student_id and sta2.route_id = sta.route_id and sta2.is_active
      join bus_route_stops brs_other
        on brs_other.route_id = sta.route_id and brs_other.stop_id = sta2.pickup_stop_id
      join bus_route_stops brs_target
        on brs_target.route_id = sta.route_id and brs_target.stop_id = sta.pickup_stop_id
      where bts2.trip_id = t.id and bts2.boarded_at is not null
        and brs_other.sequence_order > brs_target.sequence_order
    ) then 'BUS_PASSED_STOP' else 'TIME_THRESHOLD' end
  from bus_trips t
  join buses b on b.id = t.bus_id
  join student_transport_assignments sta on sta.bus_id = t.bus_id and sta.is_active = true
  join academic_years ay on ay.id = sta.academic_year_id and ay.is_current = true
  join students s on s.id = sta.student_id and s.deleted_at is null
  left join student_enrollments se on se.student_id = s.id and se.status = 'ACTIVE'
  left join classes c on c.id = se.class_id
  left join bus_routes r on r.id = sta.route_id
  left join bus_stops bs on bs.id = sta.pickup_stop_id
  where t.school_id = v_school_id
    and t.status = 'ACTIVE'::trip_status
    and t.direction = 'TO_SCHOOL'::trip_direction
    and not exists (
      select 1 from bus_trip_students bts
      where bts.trip_id = t.id and bts.student_id = s.id and bts.boarded_at is not null
    )
    and (
      now() - t.starts_at > (v_alert_minutes || ' minutes')::interval
      or exists (
        select 1
        from bus_trip_students bts2
        join student_transport_assignments sta2
          on sta2.student_id = bts2.student_id and sta2.route_id = sta.route_id and sta2.is_active
        join bus_route_stops brs_other
          on brs_other.route_id = sta.route_id and brs_other.stop_id = sta2.pickup_stop_id
        join bus_route_stops brs_target
          on brs_target.route_id = sta.route_id and brs_target.stop_id = sta.pickup_stop_id
        where bts2.trip_id = t.id and bts2.boarded_at is not null
          and brs_other.sequence_order > brs_target.sequence_order
      )
    )
  order by t.starts_at;
end;
$$;
revoke all on function fn_get_non_boarding_alerts() from public;
grant execute on function fn_get_non_boarding_alerts() to authenticated;
