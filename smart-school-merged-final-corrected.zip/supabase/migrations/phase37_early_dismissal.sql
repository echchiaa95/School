-- ============================================================================
-- PHASE 37 — 📝 استئذان مبكر رقمي (ميزة تنافسية جديدة)
-- Purely additive: one new table, three new functions. No existing table
-- or function touched. No DROP TABLE/TRUNCATE.
--
-- Flow: parent submits a request (reason, no time picker needed — it's for
-- "right now") -> guard/admin sees it in a live pending list and approves
-- or rejects -> both sides can see the final status. Every transition is
-- audited (fn_safe_audit) same as every other administrative action in
-- this project. No paper, no ambiguity about who approved what and when.
-- ============================================================================
create table if not exists early_dismissal_requests (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references schools(id) on delete cascade,
  student_id uuid not null references students(id) on delete cascade,
  requested_by uuid not null references profiles(id),
  reason text not null,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  decided_by uuid references profiles(id),
  decided_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists ix_early_dismissal_school_status on early_dismissal_requests (school_id, status, created_at desc);
create index if not exists ix_early_dismissal_student on early_dismissal_requests (student_id, created_at desc);
alter table early_dismissal_requests enable row level security;
-- No policies — every access goes through the SECURITY DEFINER functions below.


create or replace function fn_parent_request_early_dismissal(p_student_id uuid, p_reason text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_class_id uuid;
  v_reason text;
  v_id uuid;
begin
  if not fn_is_parent_of(p_student_id) then
    raise exception 'PERMISSION_DENIED';
  end if;
  v_reason := nullif(trim(coalesce(p_reason, '')), '');
  if v_reason is null then raise exception 'REASON_REQUIRED'; end if;

  select se.class_id into v_class_id from student_enrollments se where se.student_id = p_student_id and se.status = 'ACTIVE' limit 1;
  select c.school_id into v_school_id from classes c where c.id = v_class_id;
  if v_school_id is null then raise exception 'INVALID_STUDENT'; end if;

  if exists (
    select 1 from early_dismissal_requests
    where student_id = p_student_id and status = 'pending' and created_at::date = current_date
  ) then
    raise exception 'REQUEST_ALREADY_PENDING';
  end if;

  insert into early_dismissal_requests (school_id, student_id, requested_by, reason)
  values (v_school_id, p_student_id, auth.uid(), v_reason)
  returning id into v_id;

  perform fn_safe_audit(v_school_id, 'EARLY_DISMISSAL_REQUESTED', 'early_dismissal_requests', v_id, null,
    jsonb_build_object('student_id', p_student_id, 'reason', v_reason));
  return v_id;
end;
$$;
revoke all on function fn_parent_request_early_dismissal(uuid, text) from public;
grant execute on function fn_parent_request_early_dismissal(uuid, text) to authenticated;


create or replace function fn_list_my_early_dismissal_requests(p_student_id uuid)
returns table(id uuid, reason text, status text, decided_at timestamptz, created_at timestamptz)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not fn_is_parent_of(p_student_id) then
    raise exception 'PERMISSION_DENIED';
  end if;
  return query
  select e.id, e.reason, e.status, e.decided_at, e.created_at
  from early_dismissal_requests e
  where e.student_id = p_student_id
  order by e.created_at desc
  limit 20;
end;
$$;
revoke all on function fn_list_my_early_dismissal_requests(uuid) from public;
grant execute on function fn_list_my_early_dismissal_requests(uuid) to authenticated;


-- Guard/admin — pending queue for the school (live list, same polling
-- pattern used by the non-boarding alerts / live map panels).
create or replace function fn_list_pending_early_dismissals()
returns table(
  id uuid, student_id uuid, full_name text, class_name text,
  reason text, requested_by_name text, created_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director', 'superadmin', 'guard') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select e.id, s.id, s.full_name, c.name, e.reason, p.full_name, e.created_at
  from early_dismissal_requests e
  join students s on s.id = e.student_id
  left join student_enrollments se on se.student_id = s.id and se.status = 'ACTIVE'
  left join classes c on c.id = se.class_id
  left join profiles p on p.id = e.requested_by
  where e.school_id = v_school_id and e.status = 'pending'
  order by e.created_at;
end;
$$;
revoke all on function fn_list_pending_early_dismissals() from public;
grant execute on function fn_list_pending_early_dismissals() to authenticated;


create or replace function fn_decide_early_dismissal(p_request_id uuid, p_approve boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_current_status text;
begin
  select e.school_id, e.status into v_school_id, v_current_status
  from early_dismissal_requests e where e.id = p_request_id;
  if v_school_id is null then raise exception 'INVALID_REQUEST'; end if;

  if not exists (
    select 1 from user_roles ur where ur.profile_id = auth.uid() and ur.school_id = v_school_id
      and ur.role in ('admin', 'director', 'superadmin', 'guard')
  ) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if v_current_status <> 'pending' then raise exception 'REQUEST_ALREADY_DECIDED'; end if;

  update early_dismissal_requests set
    status = case when p_approve then 'approved' else 'rejected' end,
    decided_by = auth.uid(), decided_at = now()
  where id = p_request_id;

  perform fn_safe_audit(v_school_id,
    case when p_approve then 'EARLY_DISMISSAL_APPROVED' else 'EARLY_DISMISSAL_REJECTED' end,
    'early_dismissal_requests', p_request_id, null, jsonb_build_object('approved', p_approve));
end;
$$;
revoke all on function fn_decide_early_dismissal(uuid, boolean) from public;
grant execute on function fn_decide_early_dismissal(uuid, boolean) to authenticated;
