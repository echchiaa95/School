-- ============================================================================
-- PHASE 30 — إتمام "معلومات المؤسسة" (26-32)
-- Purely additive: no DROP TABLE, no TRUNCATE, no unconditional DELETE.
--
-- Audit of the existing system found MOST of 26-32 already done correctly:
--   26/27 (audit log) -> comprehensive already (issue/reissue/suspend badge,
--     lessons, attendance, grades, payments, trips, boarding/dropoff via
--     fn_record_trip_event's STUDENT_BOARDED/STUDENT_DROPPED_OFF, account
--     creation via the create-staff-account Edge Function) + correctly
--     scoped (fn_get_school_audit = own school only, fn_superadmin_get_
--     audit_logs = all schools). Genuinely missing: Login/Logout — added
--     below (fn_log_auth_event).
--   28 (add lesson) -> UI let the admin pick ANY teacher regardless of the
--     chosen subject, and the server never checked the teacher was even
--     linked to that subject. Fixed below: fn_list_teachers_by_subject
--     (new) + a teacher_subjects membership check added to fn_add_lesson/
--     fn_update_lesson (same signatures, CREATE OR REPLACE).
--   29 (4 morning + 4 afternoon) -> already exactly this, untouched.
--   30/31 (school website) -> field + save already existed, but no normali-
--     zation (bare "example.ma" was stored as-is) and no protocol safety
--     check. Fixed below: fn_normalize_website_url, wired into
--     fn_update_school (same signature, CREATE OR REPLACE).
--   32 (badge uses the correct school's own data via school_id) -> already
--     correct; not touched.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- Item 26/27 — Login/Logout audit trail.
-- ----------------------------------------------------------------------------
create or replace function fn_log_auth_event(p_event text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_action text;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  v_action := case lower(trim(coalesce(p_event, '')))
                when 'login' then 'LOGIN'
                when 'logout' then 'LOGOUT'
                else null end;
  if v_action is null then raise exception 'INVALID_EVENT'; end if;

  select school_id into v_school_id from user_roles where profile_id = auth.uid() limit 1;

  perform fn_safe_audit(
    coalesce(v_school_id, '00000000-0000-0000-0000-000000000000'::uuid),
    v_action, 'profiles', auth.uid(), null, jsonb_build_object('profile_id', auth.uid())
  );
end;
$$;
revoke all on function fn_log_auth_event(text) from public;
grant execute on function fn_log_auth_event(text) to authenticated;


-- ----------------------------------------------------------------------------
-- Item 28 — teachers filtered by subject (client dropdown) + server-side
-- enforcement in fn_add_lesson / fn_update_lesson.
-- ----------------------------------------------------------------------------
create or replace function fn_list_teachers_by_subject(p_subject_id uuid)
returns table(teacher_id uuid, full_name text)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select s.school_id into v_school_id from subjects s where s.id = p_subject_id;
  if v_school_id is null then raise exception 'INVALID_SUBJECT'; end if;
  if not (fn_is_school_staff(v_school_id) or fn_has_permission('schedule.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select t.id, p.full_name
  from teacher_subjects ts
  join teachers t on t.id = ts.teacher_id and t.school_id = v_school_id and t.deleted_at is null
  join profiles p on p.id = t.profile_id
  where ts.subject_id = p_subject_id
  order by p.full_name;
end;
$$;
revoke all on function fn_list_teachers_by_subject(uuid) from public;
grant execute on function fn_list_teachers_by_subject(uuid) to authenticated;


create or replace function fn_add_lesson(
  p_class_id uuid, p_weekday smallint, p_period smallint,
  p_subject_id uuid, p_teacher_id uuid default null, p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_year_id uuid;
  v_tt_id uuid;
  v_teacher uuid;
  v_weekday smallint;
  v_start time;
  v_end time;
  v_entry_id uuid;
  v_cfg record;
  v_max_period int;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select c.school_id, c.academic_year_id into v_school_id, v_year_id
  from classes c where c.id = p_class_id;
  if v_school_id is null then raise exception 'INVALID_CLASS'; end if;

  if not (fn_is_school_staff(v_school_id) or fn_has_permission('schedule.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if not exists (select 1 from subjects s where s.id = p_subject_id and s.school_id = v_school_id) then
    raise exception 'INVALID_SUBJECT';
  end if;

  v_teacher := coalesce(p_teacher_id, (select c.teacher_id from classes c where c.id = p_class_id));
  if v_teacher is null then raise exception 'SCHEDULE_TEACHER_REQUIRED'; end if;
  if not exists (select 1 from teachers t where t.id = v_teacher and t.school_id = v_school_id and t.deleted_at is null) then
    raise exception 'INVALID_TEACHER';
  end if;
  -- Item 28: the teacher must actually be linked to this subject (unless
  -- falling back to the class's own homeroom teacher, which pre-dates the
  -- subject/teacher assignment feature and stays as-is for compatibility).
  if p_teacher_id is not null and not exists (
    select 1 from teacher_subjects ts where ts.teacher_id = v_teacher and ts.subject_id = p_subject_id
  ) then
    raise exception 'TEACHER_NOT_ASSIGNED_TO_SUBJECT';
  end if;

  if p_weekday is null or p_weekday < 0 or p_weekday > 6 then raise exception 'INVALID_WEEKDAY'; end if;
  v_weekday := p_weekday + 1;

  select * into v_cfg from school_period_configs where school_id = v_school_id;
  if v_cfg is null then
    v_cfg.morning_start := time '08:00'; v_cfg.morning_lesson_minutes := 60; v_cfg.morning_lessons := 4;
    v_cfg.afternoon_start := time '14:00'; v_cfg.afternoon_lesson_minutes := 60; v_cfg.afternoon_lessons := 4;
  end if;
  v_max_period := v_cfg.morning_lessons + v_cfg.afternoon_lessons;
  if p_period is null or p_period < 1 or p_period > v_max_period then
    raise exception 'INVALID_PERIOD';
  end if;

  if p_period <= v_cfg.morning_lessons then
    v_start := v_cfg.morning_start + ((p_period - 1) * (v_cfg.morning_lesson_minutes || ' minutes')::interval);
    v_end := v_start + (v_cfg.morning_lesson_minutes || ' minutes')::interval;
  else
    v_start := v_cfg.afternoon_start + ((p_period - v_cfg.morning_lessons - 1) * (v_cfg.afternoon_lesson_minutes || ' minutes')::interval);
    v_end := v_start + (v_cfg.afternoon_lesson_minutes || ' minutes')::interval;
  end if;

  select t.id into v_tt_id from timetables t
  where t.school_id = v_school_id and t.academic_year_id = v_year_id
  order by t.created_at limit 1;
  if v_tt_id is null then
    insert into timetables (school_id, academic_year_id, name)
    values (v_school_id, v_year_id, 'Default')
    returning id into v_tt_id;
  end if;

  if exists (select 1 from timetable_entries te where te.timetable_id = v_tt_id and te.class_id = p_class_id
             and te.weekday = v_weekday and coalesce(te.period, 1) = p_period) then
    raise exception 'CLASS_SLOT_TAKEN';
  end if;
  if exists (select 1 from timetable_entries te where te.timetable_id = v_tt_id and te.teacher_id = v_teacher
             and te.weekday = v_weekday and coalesce(te.period, 1) = p_period) then
    raise exception 'TEACHER_SCHEDULE_CONFLICT';
  end if;

  insert into timetable_entries (timetable_id, class_id, subject_id, teacher_id, weekday, starts_at, ends_at, period)
  values (v_tt_id, p_class_id, p_subject_id, v_teacher, v_weekday, v_start, v_end, p_period)
  returning id into v_entry_id;

  perform fn_safe_audit(v_school_id, 'LESSON_ADDED', 'timetable_entries', v_entry_id, null,
    jsonb_build_object('class_id', p_class_id, 'subject_id', p_subject_id, 'teacher_id', v_teacher,
                        'weekday', p_weekday, 'period', p_period));
  return v_entry_id;
end;
$$;
revoke all on function fn_add_lesson(uuid, smallint, smallint, uuid, uuid, text) from public;
grant execute on function fn_add_lesson(uuid, smallint, smallint, uuid, uuid, text) to authenticated;


create or replace function fn_update_lesson(
  p_entry_id uuid, p_weekday smallint, p_period smallint,
  p_subject_id uuid, p_teacher_id uuid default null, p_notes text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_class_id uuid;
  v_tt_id uuid;
  v_teacher uuid;
  v_weekday smallint;
  v_start time;
  v_end time;
  v_cfg record;
  v_max_period int;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select c.school_id, te.class_id, te.timetable_id
    into v_school_id, v_class_id, v_tt_id
  from timetable_entries te
  join classes c on c.id = te.class_id
  where te.id = p_entry_id;
  if v_school_id is null then raise exception 'INVALID_LESSON'; end if;

  if not (fn_is_school_staff(v_school_id) or fn_has_permission('schedule.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if not exists (select 1 from subjects s where s.id = p_subject_id and s.school_id = v_school_id) then
    raise exception 'INVALID_SUBJECT';
  end if;

  v_teacher := coalesce(p_teacher_id, (select c.teacher_id from classes c where c.id = v_class_id));
  if v_teacher is null then raise exception 'SCHEDULE_TEACHER_REQUIRED'; end if;
  if not exists (select 1 from teachers t where t.id = v_teacher and t.school_id = v_school_id and t.deleted_at is null) then
    raise exception 'INVALID_TEACHER';
  end if;
  if p_teacher_id is not null and not exists (
    select 1 from teacher_subjects ts where ts.teacher_id = v_teacher and ts.subject_id = p_subject_id
  ) then
    raise exception 'TEACHER_NOT_ASSIGNED_TO_SUBJECT';
  end if;

  if p_weekday is null or p_weekday < 0 or p_weekday > 6 then raise exception 'INVALID_WEEKDAY'; end if;
  v_weekday := p_weekday + 1;
  if p_period is null or p_period < 1 then raise exception 'INVALID_PERIOD'; end if;

  select * into v_cfg from school_period_configs where school_id = v_school_id;
  if v_cfg is null then
    v_cfg.morning_start := time '08:00'; v_cfg.morning_lesson_minutes := 60; v_cfg.morning_lessons := 4;
    v_cfg.afternoon_start := time '14:00'; v_cfg.afternoon_lesson_minutes := 60; v_cfg.afternoon_lessons := 4;
  end if;
  v_max_period := v_cfg.morning_lessons + v_cfg.afternoon_lessons;
  if p_period > v_max_period then raise exception 'INVALID_PERIOD'; end if;

  if p_period <= v_cfg.morning_lessons then
    v_start := v_cfg.morning_start + ((p_period - 1) * (v_cfg.morning_lesson_minutes || ' minutes')::interval);
    v_end := v_start + (v_cfg.morning_lesson_minutes || ' minutes')::interval;
  else
    v_start := v_cfg.afternoon_start + ((p_period - v_cfg.morning_lessons - 1) * (v_cfg.afternoon_lesson_minutes || ' minutes')::interval);
    v_end := v_start + (v_cfg.afternoon_lesson_minutes || ' minutes')::interval;
  end if;

  if exists (select 1 from timetable_entries te where te.id <> p_entry_id and te.timetable_id = v_tt_id
             and te.class_id = v_class_id and te.weekday = v_weekday and coalesce(te.period, 1) = p_period) then
    raise exception 'CLASS_SLOT_TAKEN';
  end if;
  if exists (select 1 from timetable_entries te where te.id <> p_entry_id and te.timetable_id = v_tt_id
             and te.teacher_id = v_teacher and te.weekday = v_weekday and coalesce(te.period, 1) = p_period) then
    raise exception 'TEACHER_SCHEDULE_CONFLICT';
  end if;

  update timetable_entries set
    subject_id = p_subject_id, teacher_id = v_teacher,
    weekday = v_weekday, period = p_period, starts_at = v_start, ends_at = v_end
  where id = p_entry_id;

  perform fn_safe_audit(v_school_id, 'LESSON_UPDATED', 'timetable_entries', p_entry_id, null,
    jsonb_build_object('class_id', v_class_id, 'subject_id', p_subject_id, 'teacher_id', v_teacher,
                        'weekday', p_weekday, 'period', p_period));
end;
$$;
revoke all on function fn_update_lesson(uuid, smallint, smallint, uuid, uuid, text) from public;
grant execute on function fn_update_lesson(uuid, smallint, smallint, uuid, uuid, text) to authenticated;


-- ----------------------------------------------------------------------------
-- Items 30-31 — website URL: normalize a bare domain to https://, reject
-- dangerous schemes (javascript:, data:, or anything not http/https).
-- Uses the EXISTING `website` column on schools (no new field).
-- ----------------------------------------------------------------------------
create or replace function fn_normalize_website_url(p_raw text)
returns text
language plpgsql
immutable
as $$
declare
  v text;
begin
  v := nullif(trim(coalesce(p_raw, '')), '');
  if v is null then return null; end if;

  -- Reject dangerous/unexpected schemes outright rather than trying to sanitize them.
  if v ~* '^(javascript|data|vbscript|file):' then
    raise exception 'INVALID_WEBSITE_URL';
  end if;

  -- Bare domain ("example.ma") -> prefix https://. Anything already
  -- starting with http:// or https:// is kept as-is (still subject to the
  -- dangerous-scheme check above, which runs first).
  if v !~* '^https?://' then
    v := 'https://' || v;
  end if;

  return v;
end;
$$;

create or replace function fn_update_school(p_school_id uuid, p_data jsonb)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not fn_is_school_staff(p_school_id) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if not exists (select 1 from schools where id = p_school_id) then
    raise exception 'INVALID_SCHOOL';
  end if;

  update schools set
    name          = coalesce(nullif(trim(coalesce(p_data->>'name', '')), ''), name),
    legal_name    = case when p_data ? 'legal_name'    then nullif(trim(p_data->>'legal_name'), '')    else legal_name end,
    logo_url      = case when p_data ? 'logo_url'      then nullif(trim(p_data->>'logo_url'), '')      else logo_url end,
    address       = case when p_data ? 'address'       then nullif(trim(p_data->>'address'), '')       else address end,
    city          = case when p_data ? 'city'          then nullif(trim(p_data->>'city'), '')          else city end,
    region        = case when p_data ? 'region'        then nullif(trim(p_data->>'region'), '')        else region end,
    phone         = case when p_data ? 'phone'         then nullif(trim(p_data->>'phone'), '')         else phone end,
    email         = case when p_data ? 'email'         then nullif(trim(p_data->>'email'), '')         else email end,
    website       = case when p_data ? 'website'       then fn_normalize_website_url(p_data->>'website') else website end,
    director_name = case when p_data ? 'director_name' then nullif(trim(p_data->>'director_name'), '') else director_name end,
    school_type   = case when p_data ? 'school_type'   then nullif(trim(p_data->>'school_type'), '')   else school_type end,
    ice           = case when p_data ? 'ice'           then nullif(trim(p_data->>'ice'), '')           else ice end,
    notes         = case when p_data ? 'notes'         then nullif(trim(p_data->>'notes'), '')         else notes end
  where id = p_school_id;

  perform fn_safe_audit(p_school_id, 'UPDATE_SCHOOL', 'schools', p_school_id, null, p_data);
end;
$$;
revoke all on function fn_update_school(uuid, jsonb) from public;
grant execute on function fn_update_school(uuid, jsonb) to authenticated;
