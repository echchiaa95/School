-- ============================================================================
-- PHASE 29 — BADGE/QR (spec items 18-24)
-- Purely additive: no DROP TABLE, no TRUNCATE, no unconditional DELETE.
--
-- Audit of the existing badge/QR system found items 18, 19, 20, 21, 22
-- already fully and correctly implemented in earlier phases:
--   18 (issue)        -> fn_guard_issue_badge   (phase18, idempotent, ACTIVE + real secure_token)
--   19 (QR validation)-> lookupByBadgeToken/classifyStudent (modules/students.js):
--                        any status other than ACTIVE is rejected, unknown
--                        token is rejected — SUSPENDED/EXPIRED/REPLACED/
--                        invalid all correctly refused.
--   20 (reissue)      -> fn_guard_reissue_badge (phase18): old badge ->
--                        REPLACED, new one -> ACTIVE with a fresh
--                        secure_token, so the old QR stops matching any
--                        row with status='ACTIVE' and is naturally refused
--                        by every validation path above.
--   21/22 (preview,   -> modules/badgeCard.js: real QR (qrcode lib, encodes
--   download, print)     secure_token), full-card screenshot (html2canvas),
--                        browser print/Save-as-PDF, all already wired into
--                        guard.html and admin.html.
--
-- The one real gap was items 23-24: fn_get_student_badge only grants
-- access to school staff / students.badge.view / students.badge.issue —
-- a parent has none of those, so the Parent console had NO way to fetch
-- its own child's badge at all. This adds a parent-scoped twin using the
-- SAME existing fn_is_parent_of() helper already used by fn_child_payments
-- (phase12), returning the exact same shape as fn_get_student_badge so
-- the frontend can reuse the existing renderBadgeCard() unchanged (item 23:
-- reuse the one real QR already in student_badges — never generate a
-- second one).
-- ============================================================================
create or replace function fn_parent_get_child_badge(p_student_id uuid)
returns table(id uuid, status text, secure_token uuid, created_at timestamptz)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not fn_is_parent_of(p_student_id) then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select sb.id, sb.status::text, sb.secure_token, sb.created_at
  from student_badges sb
  where sb.student_id = p_student_id
  order by sb.created_at desc
  limit 1;
end;
$$;
revoke all on function fn_parent_get_child_badge(uuid) from public;
grant execute on function fn_parent_get_child_badge(uuid) to authenticated;
