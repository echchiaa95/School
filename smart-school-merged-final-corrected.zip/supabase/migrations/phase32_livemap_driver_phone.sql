-- ============================================================================
-- PHASE 32 — driver phone on the live map (item 33 follow-up, optional
-- scope agreed with the user). Purely additive: same two functions,
-- CREATE OR REPLACE, one new column each (driver_phone). Nothing removed,
-- no DROP TABLE/TRUNCATE.
-- ============================================================================

drop function if exists fn_get_active_bus_locations();

create function fn_get_active_bus_locations()
returns table(
  bus_id uuid, bus_code text, bus_plate text,
  trip_id uuid, direction text, driver_name text, driver_phone text, route_name text,
  latitude double precision, longitude double precision,
  accuracy double precision, speed double precision, heading double precision,
  recorded_at timestamptz, trip_started_at timestamptz,
  total_students int, boarded_count int, dropped_count int
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director', 'superadmin') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select b.id, b.code, b.plate_number,
         t.id, case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup' else 'dropoff' end,
         p.full_name, p.phone, r.name,
         ll.latitude, ll.longitude, ll.accuracy, ll.speed, ll.heading, ll.recorded_at,
         t.starts_at,
         (select count(*) from student_transport_assignments sta where sta.bus_id = b.id and sta.is_active)::int,
         (select count(*) from bus_trip_students bts where bts.trip_id = t.id and bts.boarded_at is not null)::int,
         (select count(*) from bus_trip_students bts where bts.trip_id = t.id and bts.dropped_at is not null)::int
  from bus_trips t
  join buses b on b.id = t.bus_id
  left join bus_last_locations ll on ll.bus_id = b.id and ll.trip_id = t.id
  left join drivers d on d.id = t.driver_id
  left join profiles p on p.id = d.profile_id
  left join bus_routes r on r.id = t.route_id
  where t.school_id = v_school_id
    and t.status = 'ACTIVE'::trip_status
  order by t.starts_at desc;
end;
$$;
revoke all on function fn_get_active_bus_locations() from public;
grant execute on function fn_get_active_bus_locations() to authenticated;


drop function if exists fn_get_all_buses_status();

create function fn_get_all_buses_status()
returns table(
  bus_id uuid, bus_code text, bus_plate text,
  has_active_trip boolean, trip_id uuid, direction text,
  driver_name text, driver_phone text, recorded_at timestamptz,
  latitude double precision, longitude double precision,
  is_from_active_trip boolean
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director', 'superadmin') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select b.id, b.code, b.plate_number,
         t.id is not null, t.id,
         case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup'
              when t.direction = 'TO_HOME'::trip_direction then 'dropoff' else null end,
         p.full_name, p.phone, ll.recorded_at,
         ll.latitude, ll.longitude,
         (t.id is not null and ll.trip_id = t.id)
  from buses b
  left join bus_trips t on t.bus_id = b.id and t.status = 'ACTIVE'::trip_status
  left join bus_last_locations ll on ll.bus_id = b.id
  left join drivers d on d.id = coalesce(t.driver_id, b.driver_id)
  left join profiles p on p.id = d.profile_id
  where b.school_id = v_school_id
  order by b.code;
end;
$$;
revoke all on function fn_get_all_buses_status() from public;
grant execute on function fn_get_all_buses_status() to authenticated;
