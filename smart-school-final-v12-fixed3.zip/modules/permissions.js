// ============================================================================
// modules/permissions.js
// Client-side role routing and UI permission gating.
//
// This module grants no database access by itself. Real authorization remains
// in Supabase/Postgres (RLS, policies, and RPC functions). The role used here
// is always the role already loaded from user_roles by modules/auth.js.
// ============================================================================

import { supabase } from './supabase.js';

export const ROLES = Object.freeze({
  SUPERADMIN: 'superadmin',
  ADMIN: 'admin',
  GUARD: 'guard',
  TEACHER: 'teacher',
  DRIVER: 'driver',
  PARENT: 'parent',
});

const ROLE_HOME_PAGE = Object.freeze({
  [ROLES.SUPERADMIN]: 'superadmin.html',
  [ROLES.ADMIN]: 'admin.html',
  [ROLES.GUARD]: 'guard.html',
  [ROLES.TEACHER]: 'teacher.html',
  [ROLES.DRIVER]: 'driver.html',
  [ROLES.PARENT]: 'parent.html',
});

const PAGE_ALLOWED_ROLES = Object.freeze({
  'superadmin.html': [ROLES.SUPERADMIN],
  'admin.html': [ROLES.ADMIN],
  // PHASE 15: no standalone director page/role — director.html is a safe
  // redirect page (handles itself), admin.html is the only school console.
  'guard.html': [ROLES.GUARD],
  'teacher.html': [ROLES.TEACHER],
  'driver.html': [ROLES.DRIVER],
  'parent.html': [ROLES.PARENT],
});

export const ROLE_PRIORITY = Object.freeze([
  ROLES.SUPERADMIN,
  ROLES.ADMIN,
  ROLES.GUARD,
  ROLES.TEACHER,
  ROLES.DRIVER,
  ROLES.PARENT,
]);

let currentPermissionKeys = new Set();

// Phase 25: legacy 'director' rows in user_roles are institution managers —
// treat them exactly like 'admin' so old accounts keep admin.html access
// (no redirect loop, no lockout). Server-side checks are unchanged.
const LEGACY_ROLE_ALIASES = Object.freeze({ director: 'admin' });
const normRole = (r) => LEGACY_ROLE_ALIASES[r] || r;

export function homePageForRole(role) {
  return ROLE_HOME_PAGE[normRole(role)] ?? null;
}

export function isRoleAllowedOnPage(role, pageFileName) {
  const allowed = PAGE_ALLOWED_ROLES[pageFileName];
  return Array.isArray(allowed) && allowed.includes(normRole(role));
}

export function pickPrimaryRole(roleRows) {
  if (!Array.isArray(roleRows) || roleRows.length === 0) return null;

  for (const role of ROLE_PRIORITY) {
    const match = roleRows.find((row) => normRole(row?.role) === role && row?.school_id);
    if (match) return match;
  }
  return null;
}

/**
 * Initialize UI permissions from the DATABASE ONLY (fn_my_permissions):
 * superadmin/admin receive the full catalog server-side; other
 * roles (including Guard) receive exactly their user_permissions grants.
 * PHASE 12.1 HARDENING: on any RPC failure the set is EMPTY — no static
 * role-based fallback, so a Guard never gets implicit permissions from
 * client-side defaults. Server-side authorization is enforced in the
 * database for every actual read/write regardless.
 */
export async function loadMyPermissions(role) {
  try {
    const { data, error } = await supabase.rpc('fn_my_permissions');
    if (!error && Array.isArray(data)) {
      currentPermissionKeys = new Set(data);
      return new Set(currentPermissionKeys);
    }
    if (error) console.error('fn_my_permissions error:', error);
  } catch (error) {
    console.error('loadMyPermissions error:', error);
  }
  // No fallback grants: fail closed.
  currentPermissionKeys = new Set();
  return new Set(currentPermissionKeys);
}

export function hasPermission(permissionKey) {
  return currentPermissionKeys.has(permissionKey);
}

export function clearPermissions() {
  currentPermissionKeys = new Set();
}
