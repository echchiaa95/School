// ============================================================================
// modules/liveMap.js — Phase 25 (Batch 1)
// Admin/Director general live map. ONE school-scoped RPC (fn_get_map_overview)
// feeds everything: 🏫 school, 🏠 ALL student homes with real coordinates,
// 🚌 the FULL fleet (live active buses + "آخر موقع معروف" for idle buses),
// 📍 route stops, ➖ active-trip GPS polylines (bus_trip_locations).
// Layers are toggleable (🏠🚌📍➖). Clicking a bus opens a detail panel
// (mode B) with driver/trip/speed/passengers + its trip students, without
// rebuilding the map — markers move via setLatLng, popups via setPopupContent.
// Realtime on bus_last_locations + bus_trip_students; 12s polling fallback.
// ============================================================================

import { supabase } from './supabase.js';
import { getMapOverview, getTripRouteHistory, listBusTrips, listBusStudentsOrdered } from './school.js';
import { loadLeaflet } from './mapPicker.js';
import { esc } from './ui.js';

const POLL_MS = 12000;
const STALE_MS = 75000;

let map = null;
let layerGroups = {};      // key -> L.layerGroup (homes|buses|stops|routes)
let layerVisible = { homes: true, buses: true, stops: true, routes: true };
let schoolMarker = null;
let busMarkers = {};       // bus_id -> L.marker
let homeMarkers = {};      // student_id -> L.marker
let stopMarkers = [];      // L.marker[]
let routeLines = {};       // trip_id -> { line, points }
let busRows = [];          // latest overview.buses
let focusedBusId = null;
let focusedStudents = [];
let pollTimer = null;
let rtChannel = null;
let firstFitDone = false;
let refreshSeq = 0;

function timeAgoAr(iso) {
  if (!iso) return '—';
  const s = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `منذ ${s} ثانية`;
  const m = Math.floor(s / 60);
  if (m < 60) return `منذ ${m} دقيقة`;
  return `منذ ${Math.floor(m / 60)} ساعة`;
}

// ---------------------------------------------------------------- icons ----
function busIcon(row) {
  const live = row.has_active_trip && row.live &&
    (Date.now() - new Date(row.recorded_at).getTime() <= STALE_MS);
  const html = row.has_active_trip
    ? `<div style="position:relative;font-size:26px;filter:${live ? 'none' : 'grayscale(1) opacity(0.6)'};">🚌<span style="position:absolute;bottom:-2px;right:-2px;width:10px;height:10px;border-radius:50%;background:${live ? '#16a34a' : '#f59e0b'};border:2px solid #fff;"></span></div>`
    : `<div style="font-size:22px;filter:grayscale(1) opacity(0.55);">🚌</div>`;
  return window.L.divIcon({ html, className: '', iconSize: [30, 30], iconAnchor: [15, 15] });
}

function homeIcon() {
  return window.L.divIcon({ html: '<div style="font-size:16px;">🏠</div>', className: '', iconSize: [18, 18], iconAnchor: [9, 9] });
}
function stopIcon() {
  return window.L.divIcon({ html: '<div style="font-size:14px;">📍</div>', className: '', iconSize: [16, 16], iconAnchor: [8, 8] });
}

// ---------------------------------------------------------------- popup ----
function busPopupHtml(row) {
  const live = row.has_active_trip && row.live &&
    (Date.now() - new Date(row.recorded_at).getTime() <= STALE_MS);
  const passengers = row.has_active_trip && row.total_students != null
    ? `${row.boarded_count ?? 0} / ${row.total_students}` : '—';
  const dirAr = row.direction === 'pickup' ? 'ذهاب (نحو المؤسسة)'
    : row.direction === 'dropoff' ? 'إياب (نحو المنزل)' : '—';
  return `<div style="min-width:200px; text-align:right;">
    <strong>🚌 ${esc(row.bus_code || 'الحافلة')} — ${esc(row.bus_plate || '—')}</strong><br>
    السائق: ${esc(row.driver_name || 'بدون سائق')}<br>
    ${row.has_active_trip ? `الاتجاه: ${dirAr}<br>
    السرعة: ${row.speed != null ? Math.round(row.speed * 3.6) + ' كم/س' : '—'}<br>
    الركاب: 👥 ${passengers}${row.dropped_count ? ` (نزل: ${row.dropped_count})` : ''}<br>
    GPS: ${live ? '<span style="color:#16a34a;">🟢 متصل</span>' : '<span style="color:#dc2626;">⚠️ غير محدَّث</span>'}<br>
    آخر تحديث: ${row.recorded_at ? timeAgoAr(row.recorded_at) : 'لا يوجد بعد'}` :
    `<span style="color:#6b7280;">⚪ غير نشطة — آخر موقع معروف${row.recorded_at ? ` (${timeAgoAr(row.recorded_at)})` : ''}</span>`}
  </div>`;
}

// ------------------------------------------------------------ bus list -----
function renderBusList() {
  const host = document.getElementById('live-map-status');
  if (!host) return;
  if (!busRows.length) {
    host.innerHTML = '<p class="section-title" style="margin-top:14px;">🚌 قائمة الحافلات</p><div class="panel"><div class="empty-state">لا توجد حافلات مسجلة في هذه المؤسسة.</div></div>';
    return;
  }
  const row = (r) => {
    const live = r.has_active_trip && r.live &&
      (Date.now() - new Date(r.recorded_at).getTime() <= STALE_MS);
    const status = r.has_active_trip
      ? (live ? '<span class="badge" style="background:#dcfce7;color:#16a34a;">🟢 نشطة</span>'
              : '<span class="badge badge-blue">🟡 رحلة بدون GPS حديث</span>')
      : '<span class="badge" style="background:#f3f4f6;color:#6b7280;">⚪ غير نشطة</span>';
    return `<div class="detail-row" data-bus="${r.bus_id}" style="flex-wrap:wrap; gap:6px; cursor:pointer;">
      <div style="flex:1; min-width:150px;">
        <strong>🚌 ${esc(r.bus_code || 'حافلة')}</strong> <span class="time">${esc(r.bus_plate || '')}</span><br>
        <span class="time">${esc(r.driver_name || 'بدون سائق')}</span>
      </div>
      ${status}
      ${r.has_active_trip && r.total_students != null ? `<span class="badge">👥 ${r.boarded_count ?? 0}/${r.total_students} ركاب</span>` : ''}
    </div>`;
  };
  host.innerHTML = `<p class="section-title" style="margin-top:14px;">🚌 قائمة الحافلات (${busRows.length})</p>
    <div class="panel">${busRows.map(row).join('')}</div>`;
  host.querySelectorAll('[data-bus]').forEach((el) => {
    el.addEventListener('click', () => focusBus(el.dataset.bus));
  });
}

// --------------------------------------------------------- detail panel ----
async function renderDetailPanel() {
  const host = document.getElementById('live-map-detail');
  if (!host) return;
  const row = busRows.find((b) => b.bus_id === focusedBusId);
  if (!row) { host.innerHTML = ''; return; }
  const dirAr = row.direction === 'pickup' ? 'ذهاب' : row.direction === 'dropoff' ? 'إياب' : '—';
  const studentsHtml = row.has_active_trip
    ? (focusedStudents.length
        ? focusedStudents.map((s, i) => {
            const st = s.boarding_status || s.status; // ordered RPC returns status field
            const stAr = st === 'BOARDED' ? '🟢 صعد' : st === 'DROPPED' ? '🔵 نزل' : '🔴 لم يصعد';
            return `<div class="detail-row">
              <span class="k">#${i + 1} ${esc(s.full_name || '')}</span>
              <span class="v">${stAr}</span>
            </div>`;
          }).join('')
        : '<div class="empty-state">لا يوجد تلاميذ مرتبطون بهذه الرحلة.</div>')
    : '<div class="empty-state">الحافلة ليست في رحلة حاليًا.</div>';
  host.innerHTML = `<div class="panel" style="margin-top:10px; border:1px solid #2563eb33;">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <strong>🚌 ${esc(row.bus_code || 'الحافلة')} — ${esc(row.bus_plate || '—')}</strong>
      <button type="button" class="icon-btn" id="lm-unfocus">✕</button>
    </div>
    <div class="detail-row"><span class="k">السائق</span><span class="v">${esc(row.driver_name || '—')}</span></div>
    ${row.has_active_trip ? `
    <div class="detail-row"><span class="k">الرحلة</span><span class="v">🟢 نشطة · ${dirAr}</span></div>
    <div class="detail-row"><span class="k">السرعة</span><span class="v">${row.speed != null ? Math.round(row.speed * 3.6) + ' كم/س' : '—'}</span></div>
    <div class="detail-row"><span class="k">GPS</span><span class="v">${row.live ? '🟢 متصل' : '⚠️ غير محدَّث'}</span></div>
    <div class="detail-row"><span class="k">آخر تحديث</span><span class="v">${row.recorded_at ? timeAgoAr(row.recorded_at) : '—'}</span></div>
    <div class="detail-row"><span class="k">الركاب</span><span class="v">👥 ${row.boarded_count ?? 0} / ${row.total_students ?? '—'}</span></div>
    <p class="section-title" style="margin-top:8px;">التلاميذ المرتبطون بالرحلة</p>${studentsHtml}` :
    `<div class="detail-row"><span class="k">الحالة</span><span class="v">⚪ غير نشطة — آخر موقع معروف</span></div>`}
    <div style="display:flex; gap:8px; margin-top:10px;">
      <button type="button" class="quick-action-btn secondary" id="lm-history" style="flex:1;">سجل الرحلات</button>
      ${row.has_active_trip ? '<span class="badge badge-blue" style="align-self:center;">الموقع الحالي على الخريطة</span>' : ''}
    </div>
  </div>`;
  host.querySelector('#lm-unfocus').addEventListener('click', unfocusBus);
  host.querySelector('#lm-history').addEventListener('click', () =>
    openBusHistoryModal(row.bus_id, row.bus_code || row.bus_plate || 'الحافلة'));
}

async function focusBus(busId) {
  focusedBusId = busId;
  const row = busRows.find((b) => b.bus_id === busId);
  if (row && row.latitude != null && map) {
    map.setView([row.latitude, row.longitude], Math.max(map.getZoom(), 15), { animate: true });
    const m = busMarkers[busId];
    if (m) m.openPopup();
  }
  focusedStudents = [];
  if (row && row.has_active_trip && row.trip_id) {
    const res = await listBusStudentsOrdered(busId, row.trip_id);
    if (res.ok && res.data) focusedStudents = res.data;
  }
  await renderDetailPanel();
}

function unfocusBus() {
  focusedBusId = null;
  focusedStudents = [];
  renderDetailPanel();
}

// ------------------------------------------------------------- layers ------
function applyLayerVisibility() {
  if (!map) return;
  Object.entries(layerGroups).forEach(([key, group]) => {
    const have = map.hasLayer(group);
    if (layerVisible[key] && !have) group.addTo(map);
    if (!layerVisible[key] && have) map.removeLayer(group);
  });
  document.querySelectorAll('[data-layer]').forEach((btn) => {
    btn.style.opacity = layerVisible[btn.dataset.layer] ? '1' : '.45';
  });
}

function renderLayerBar() {
  const bar = document.getElementById('live-map-layers');
  if (!bar) return;
  const items = [
    ['homes', '🏠 المنازل'], ['buses', '🚌 الحافلات'],
    ['stops', '📍 نقاط التوقف'], ['routes', '➖ المسار'],
  ];
  bar.innerHTML = items.map(([k, label]) =>
    `<button type="button" data-layer="${k}" class="quick-action-btn secondary"
       style="padding:5px 10px; font-size:.82em; border-radius:999px;">${label}</button>`).join('');
  bar.querySelectorAll('[data-layer]').forEach((btn) => {
    btn.addEventListener('click', () => {
      layerVisible[btn.dataset.layer] = !layerVisible[btn.dataset.layer];
      applyLayerVisibility();
    });
  });
}

// -------------------------------------------------------------- refresh ----
async function refresh() {
  if (!map) return;
  const seq = ++refreshSeq;
  const res = await getMapOverview();
  if (!res.ok || !res.data) return; // keep last state; poll will retry
  if (seq !== refreshSeq || !map) return; // stale response after cleanup/reentry

  const ov = res.data;
  const L = window.L;

  // 🏫 school (once)
  if (!schoolMarker && ov.school && ov.school.latitude != null) {
    schoolMarker = L.marker([ov.school.latitude, ov.school.longitude], {
      icon: L.divIcon({ html: '<div style="font-size:28px;">🏫</div>', className: '', iconSize: [32, 32], iconAnchor: [16, 16] }),
    }).addTo(map).bindPopup(`<strong>${esc(ov.school.name || 'المؤسسة')}</strong><br>${esc(ov.school.location_label || '')}`);
  }

  // 🏠 homes — diff update, never fake markers
  const homes = ov.homes || [];
  const seenHomes = new Set();
  homes.forEach((h) => {
    seenHomes.add(h.student_id);
    const popup = `<strong>${esc(h.full_name)}</strong><br>${esc(h.class_name || '')}<br>${esc(h.location_label || '')}`;
    if (homeMarkers[h.student_id]) {
      homeMarkers[h.student_id].setLatLng([h.latitude, h.longitude]);
      homeMarkers[h.student_id].setPopupContent(popup);
    } else {
      homeMarkers[h.student_id] = L.marker([h.latitude, h.longitude], { icon: homeIcon() })
        .bindPopup(popup)
        .addTo(layerGroups.homes);
    }
  });
  Object.keys(homeMarkers).forEach((id) => {
    if (!seenHomes.has(id)) { layerGroups.homes.removeLayer(homeMarkers[id]); delete homeMarkers[id]; }
  });

  // 📍 stops (cheap, refresh each cycle)
  stopMarkers.forEach((m) => layerGroups.stops.removeLayer(m));
  stopMarkers = [];
  (ov.stops || []).forEach((s) => {
    const m = L.marker([s.latitude, s.longitude], { icon: stopIcon() })
      .bindPopup(`📍 <strong>${esc(s.name)}</strong><br>${esc(s.route_name || '')}`);
    m.addTo(layerGroups.stops);
    stopMarkers.push(m);
  });

  // 🚌 buses — move existing markers, don't rebuild the map
  busRows = ov.buses || [];
  const seenBuses = new Set();
  busRows.forEach((row) => {
    if (row.latitude == null || row.longitude == null) return;
    seenBuses.add(row.bus_id);
    const marker = busMarkers[row.bus_id];
    if (marker) {
      marker.setLatLng([row.latitude, row.longitude]);
      marker.setIcon(busIcon(row));
      marker.setPopupContent(busPopupHtml(row));
    } else {
      busMarkers[row.bus_id] = L.marker([row.latitude, row.longitude], { icon: busIcon(row) })
        .addTo(layerGroups.buses)
        .bindPopup(busPopupHtml(row))
        .on('click', () => focusBus(row.bus_id));
    }
  });
  Object.keys(busMarkers).forEach((id) => {
    if (!seenBuses.has(id)) {
      layerGroups.buses.removeLayer(busMarkers[id]);
      delete busMarkers[id];
      if (focusedBusId === id) focusedBusId = null;
    }
  });

  // ➖ active-trip polylines from real GPS history (bus_trip_locations)
  const activeTrips = busRows.filter((b) => b.has_active_trip && b.trip_id);
  const activeTripIds = new Set(activeTrips.map((b) => b.trip_id));
  Object.keys(routeLines).forEach((tid) => {
    if (!activeTripIds.has(tid)) { layerGroups.routes.removeLayer(routeLines[tid].line); delete routeLines[tid]; }
  });
  await Promise.all(activeTrips.map(async (b) => {
    const hist = await getTripRouteHistory(b.trip_id);
    if (!hist.ok || !hist.data || !hist.data.length || !map) return;
    const latlngs = hist.data.map((p) => [p.latitude, p.longitude]);
    const existing = routeLines[b.trip_id];
    if (existing) {
      existing.line.setLatLngs(latlngs);
      existing.points = latlngs.length;
    } else {
      const line = L.polyline(latlngs, { color: '#2563eb', weight: 4, opacity: 0.85 }).addTo(layerGroups.routes);
      routeLines[b.trip_id] = { line, points: latlngs.length };
    }
  }));

  // notes + list + detail
  const emptyEl = document.getElementById('live-map-empty');
  if (emptyEl) {
    const anyLive = busRows.some((b) => b.has_active_trip && b.live);
    const anyTripNoGps = busRows.some((b) => b.has_active_trip && !b.live);
    emptyEl.textContent = anyLive ? ''
      : anyTripNoGps ? 'يوجد رحلة نشطة لكن لم يصل أي موقع GPS بعد.'
      : 'لا توجد رحلات نشطة حاليًا — تُعرض المواقع المعروفة فقط.';
    emptyEl.hidden = !emptyEl.textContent;
  }
  renderBusList();
  await renderDetailPanel();

  // fit bounds once
  if (!firstFitDone) {
    firstFitDone = true;
    const pts = [];
    if (ov.school && ov.school.latitude != null) pts.push([ov.school.latitude, ov.school.longitude]);
    homes.forEach((h) => pts.push([h.latitude, h.longitude]));
    busRows.forEach((b) => { if (b.latitude != null) pts.push([b.latitude, b.longitude]); });
    if (pts.length > 1) map.fitBounds(L.latLngBounds(pts).pad(0.15));
    else if (pts.length === 1) map.setView(pts[0], 14);
    setTimeout(() => map && map.invalidateSize(), 60);
  }
}

// ----------------------------------------------------- route history -------
function fmtDur(a, b) {
  if (!a || !b) return '—';
  const mins = Math.round((new Date(b) - new Date(a)) / 60000);
  return mins < 60 ? `${mins} دقيقة` : `${Math.floor(mins / 60)} س ${mins % 60} د`;
}

export async function openBusHistoryModal(busId, busLabel) {
  const overlay = document.createElement('div');
  overlay.className = 'map-picker-overlay';
  overlay.innerHTML = `
    <div class="map-picker-sheet" style="max-width:560px;">
      <div class="map-picker-header"><strong>سجل الرحلات — ${esc(busLabel || '')}</strong><button type="button" class="icon-btn" id="bh-close">✕</button></div>
      <select id="bh-trip-select" class="search-input" style="width:100%; margin-bottom:8px;"><option>جارٍ التحميل...</option></select>
      <div id="bh-info" class="panel" style="margin-bottom:8px;"></div>
      <div id="bh-map" style="width:100%; height:min(45vh, 320px); border-radius:10px; background:#e5e7eb;"></div>
    </div>`;
  document.body.appendChild(overlay);
  overlay.querySelector('#bh-close').addEventListener('click', () => overlay.remove());

  const tripsRes = await listBusTrips(busId, 30);
  const trips = tripsRes.ok ? tripsRes.data || [] : [];
  const select = overlay.querySelector('#bh-trip-select');
  select.innerHTML = trips.length
    ? trips.map((t) => `<option value="${t.trip_id}">${new Date(t.started_at).toLocaleString('ar')} — ${t.direction === 'pickup' ? 'ذهاب' : 'إياب'} (${t.status === 'COMPLETED' ? 'مكتملة' : t.status})</option>`).join('')
    : '<option value="">لا توجد رحلات سابقة لهذه الحافلة.</option>';

  await loadLeaflet();
  const hmap = window.L.map('bh-map').setView([27.15, -13.2], 12);
  window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 19 }).addTo(hmap);
  let polyline = null;

  async function loadSelectedTrip() {
    const tripId = select.value;
    const info = overlay.querySelector('#bh-info');
    if (!tripId) { info.innerHTML = ''; return; }
    const trip = trips.find((t) => t.trip_id === tripId);
    info.innerHTML = `
      <div class="detail-row"><span class="k">التاريخ</span><span class="v">${new Date(trip.started_at).toLocaleDateString('ar')}</span></div>
      <div class="detail-row"><span class="k">الاتجاه</span><span class="v">${trip.direction === 'pickup' ? 'ذهاب' : 'إياب'}</span></div>
      <div class="detail-row"><span class="k">البداية</span><span class="v">${new Date(trip.started_at).toLocaleTimeString('ar')}</span></div>
      <div class="detail-row"><span class="k">النهاية</span><span class="v">${trip.ended_at ? new Date(trip.ended_at).toLocaleTimeString('ar') : 'الرحلة جارية'}</span></div>
      <div class="detail-row"><span class="k">المدة</span><span class="v">${fmtDur(trip.started_at, trip.ended_at)}</span></div>
      <div class="detail-row"><span class="k">عدد الركاب</span><span class="v">${trip.passenger_count ?? 0}</span></div>
      <div class="detail-row"><span class="k">الحالة</span><span class="v">${trip.status === 'COMPLETED' ? '✅ مكتملة' : esc(trip.status || '—')}</span></div>`;
    const histRes = await getTripRouteHistory(tripId);
    const points = histRes.ok ? histRes.data || [] : [];
    if (polyline) { hmap.removeLayer(polyline); polyline = null; }
    if (!points.length) {
      info.innerHTML += '<p class="empty-state" style="margin-top:8px;">لا توجد بيانات GPS لهذه الرحلة.</p>';
      return;
    }
    const latlngs = points.map((p) => [p.latitude, p.longitude]);
    polyline = window.L.polyline(latlngs, { color: '#2563eb', weight: 4 }).addTo(hmap);
    window.L.circleMarker(latlngs[0], { color: '#16a34a', radius: 7 }).addTo(hmap).bindTooltip('البداية');
    window.L.circleMarker(latlngs[latlngs.length - 1], { color: '#dc2626', radius: 7 }).addTo(hmap).bindTooltip('النهاية');
    hmap.fitBounds(polyline.getBounds(), { padding: [20, 20] });
    setTimeout(() => hmap.invalidateSize(), 50);
  }
  select.addEventListener('change', loadSelectedTrip);
  if (trips.length) loadSelectedTrip();
  setTimeout(() => hmap.invalidateSize(), 60);
}

// ---------------------------------------------------------------- entry ----
export async function renderLiveMap(container) {
  container.innerHTML = `
    <div id="live-map-layers" style="display:flex; gap:6px; flex-wrap:wrap; margin-bottom:8px;"></div>
    <div id="live-map" style="width:100%; height:min(60vh, 420px); border-radius:10px; background:#e5e7eb;"></div>
    <p class="empty-state" id="live-map-empty" style="margin-top:8px;" hidden></p>
    <div id="live-map-detail"></div>
    <div id="live-map-status"></div>`;
  try {
    await loadLeaflet();
  } catch {
    container.innerHTML = '<div class="empty-state">تعذر تحميل الخريطة (تحقق من الاتصال بالإنترنت).</div>';
    return () => {};
  }
  const L = window.L;
  map = L.map('live-map').setView([27.15, -13.2], 12);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 19 }).addTo(map);
  layerGroups = { homes: L.layerGroup().addTo(map), buses: L.layerGroup().addTo(map),
                  stops: L.layerGroup().addTo(map), routes: L.layerGroup().addTo(map) };
  renderLayerBar();
  applyLayerVisibility();
  setTimeout(() => map.invalidateSize(), 50);

  await refresh();
  pollTimer = setInterval(refresh, POLL_MS);

  // Best-effort Realtime: GPS pings AND boarding/dropoff (passenger counts
  // change live without refresh). Polling above is the guaranteed fallback.
  rtChannel = supabase
    .channel('map-overview-live')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'bus_last_locations' }, () => refresh())
    .on('postgres_changes', { event: '*', schema: 'public', table: 'bus_trip_students' }, () => refresh())
    .subscribe();

  return function cleanupLiveMap() {
    refreshSeq++;
    if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
    if (rtChannel) { supabase.removeChannel(rtChannel); rtChannel = null; }
    if (map) { map.remove(); map = null; }
    busMarkers = {}; homeMarkers = {}; stopMarkers = []; routeLines = {};
    schoolMarker = null; busRows = []; focusedBusId = null; focusedStudents = [];
    firstFitDone = false;
  };
}
