// ============================================================================
// modules/superadmin.js
// SuperAdmin platform management RPC wrappers.
// ============================================================================

import {
  supabase
} from './supabase.js';

/**
 * Create a full platform account (Email + Password) via the
 * create-platform-user Edge Function — SuperAdmin-only, enforced
 * server-side. schoolId and role are validated by the function itself;
 * the service-role key never touches the frontend.
 */
export async function createPlatformUser({ fullName, email, password, schoolId, role }) {
  try {
    const { data, error } = await supabase.functions.invoke('create-platform-user', {
      body: { fullName, email, password, schoolId, role },
    });

    if (error) {
      let message = 'تعذر إنشاء الحساب';
      try {
        const bodyText = await error.context?.text?.();
        const parsed = bodyText ? JSON.parse(bodyText) : null;
        if (parsed?.error) message = parsed.error;
      } catch {
        // Keep the generic message if the response body is unavailable.
      }
      return { ok: false, error: message };
    }

    if (!data?.ok) {
      return { ok: false, error: data?.error || 'تعذر إنشاء الحساب' };
    }
    return { ok: true, profileId: data.profileId, email: data.email };
  } catch (error) {
    console.error('createPlatformUser error:', error);
    return { ok: false, error: 'تعذر إنشاء الحساب' };
  }
}

/**  * Fetch enhanced platform-wide stats with role breakdowns.  * SuperAdmin-only RPC: fn_get_platform_stats_enhanced.  */
export async function getPlatformStatsEnhanced() {
  const {
    data,
    error
  } = await supabase.rpc('fn_get_platform_stats_enhanced');
  if (error) {
    console.error('getPlatformStatsEnhanced error:', error);
    return null;
  }
  return data?.[0] ?? null;
}

/**  * List every school (read-only via supabase.from).  * Falls back to supabase.from('schools') because fn_list_all_schools RPC  * is not available in the current Supabase deployment.  * RLS: p_schools_superadmin_read allows SuperAdmin SELECT.  */
export async function listAllSchools() {
  const {
    data,
    error
  } = await supabase.from('schools').select('id, name').order('name', {
    ascending: true
  });
  if (error) {
    console.error('listAllSchools error:', error);
    return [];
  }
  return (data || []).map((s) => ({
    school_id: s.id,
    school_name: s.name,
    admin_count: 0
  }));
}

/**  * Get detailed stats for one school.  * SuperAdmin-only RPC: fn_get_school_detail.  */
export async function getSchoolDetail(schoolId) {
  const {
    data,
    error
  } = await supabase.rpc('fn_get_school_detail', {
    p_school_id: schoolId
  });
  if (error) {
    console.error('getSchoolDetail error:', error);
    return null;
  }
  return data?.[0] ?? null;
}

/**
 * Create a new school via the EXISTING fn_create_school RPC (Phase 8).
 * The RPC itself re-verifies the superadmin role server-side via
 * auth.uid() — never a direct table insert from the frontend.
 */
export async function createSchool(name) {
  const trimmed = (name || '').trim();
  if (!trimmed) {
    return { ok: false, error: 'اسم المدرسة مطلوب.' };
  }

  const { data, error } = await supabase.rpc('fn_create_school', { p_name: trimmed });
  if (error) {
    console.error('createSchool error:', error);
    const msg = error.message || '';
    if (msg.includes('PERMISSION_DENIED')) {
      return { ok: false, error: 'ليس لديك صلاحية إنشاء المدارس.' };
    }
    if (msg.includes('SCHOOL_NAME_REQUIRED')) {
      return { ok: false, error: 'اسم المدرسة مطلوب.' };
    }
    if (msg.includes('NOT_AUTHENTICATED')) {
      return { ok: false, error: 'يجب تسجيل الدخول.' };
    }
    return { ok: false, error: 'تعذر إنشاء المدرسة، حاول مرة أخرى.' };
  }
  return { ok: true, schoolId: data };
}

/**  * List admin/director accounts for a specific school (read-only via supabase.from).  * Falls back to supabase.from('user_roles') because fn_list_school_admins RPC  * is not available in the current Supabase deployment.  * RLS: p_user_roles_superadmin_read allows SuperAdmin SELECT.  */
export async function listSchoolAdmins(schoolId) {
  const {
    data,
    error
  } = await supabase.from('user_roles').select('role, profile_id, profiles(full_name, user_number, is_disabled)').eq('school_id', schoolId).in('role', ['admin', 'director']);
  if (error) {
    console.error('listSchoolAdmins error:', error);
    return [];
  }
  return (data || []).map((r) => ({
    full_name: r.profiles?.full_name || '—',
    user_number: r.profiles?.user_number || '—',
    role: r.role,
    is_disabled: r.profiles?.is_disabled ?? false,
  }));
}

/**  * Get full detail for one user across all schools.  * SuperAdmin-only RPC: fn_get_user_detail.  */
export async function getUserDetail(profileId) {
  const {
    data,
    error
  } = await supabase.rpc('fn_get_user_detail', {
    p_profile_id: profileId
  });
  if (error) {
    console.error('getUserDetail error:', error);
    return null;
  }
  return data?.[0] ?? null;
}

/**  * Enable or disable any user account.  * SuperAdmin-only RPC: fn_superadmin_set_profile_status.  * Prevents disabling the last superadmin.  */
export async function setProfileStatus(profileId, isDisabled) {
  const {
    error
  } = await supabase.rpc('fn_superadmin_set_profile_status', {
    p_profile_id: profileId,
    p_is_disabled: isDisabled,
  });
  if (error) {
    console.error('setProfileStatus error:', error);
    return {
      ok: false,
      error: error.message
    };
  }
  return {
    ok: true
  };
}

/**  * List all role assignments for a user.  * SuperAdmin-only RPC: fn_superadmin_list_user_roles.  */
export async function listUserRoles(profileId) {
  const {
    data,
    error
  } = await supabase.rpc('fn_superadmin_list_user_roles', {
    p_profile_id: profileId
  });
  if (error) {
    console.error('listUserRoles error:', error);
    return [];
  }
  return data || [];
}

/**  * Assign a role to a user.  * SuperAdmin-only RPC: fn_superadmin_assign_role.  * Prevents duplicates. Only superadmin can assign superadmin role.  */
export async function assignRole(profileId, schoolId, role) {
  const {
    error
  } = await supabase.rpc('fn_superadmin_assign_role', {
    p_profile_id: profileId,
    p_school_id: schoolId,
    p_role: role,
  });
  if (error) {
    console.error('assignRole error:', error);
    return {
      ok: false,
      error: error.message
    };
  }
  return {
    ok: true
  };
}

/**  * Remove a role from a user.  * SuperAdmin-only RPC: fn_superadmin_remove_role.  * Prevents removing the last superadmin.  */
export async function removeRole(profileId, schoolId, role) {
  const {
    error
  } = await supabase.rpc('fn_superadmin_remove_role', {
    p_profile_id: profileId,
    p_school_id: schoolId,
    p_role: role,
  });
  if (error) {
    console.error('removeRole error:', error);
    return {
      ok: false,
      error: error.message
    };
  }
  return {
    ok: true
  };
}

/**  * Get global audit logs (paginated).  * SuperAdmin-only RPC: fn_superadmin_get_audit_logs.  */
export async function getAuditLogs(limit, offset) {
  const {
    data,
    error
  } = await supabase.rpc('fn_superadmin_get_audit_logs', {
    p_limit: limit || 50,
    p_offset: offset || 0,
  });
  if (error) {
    console.error('getAuditLogs error:', error);
    return [];
  }
  return data || [];
}

/**  * Get total audit log count for pagination.  * SuperAdmin-only RPC: fn_superadmin_get_audit_count.  */
export async function getAuditCount() {
  const {
    data,
    error
  } = await supabase.rpc('fn_superadmin_get_audit_count');
  if (error) {
    console.error('getAuditCount error:', error);
    return 0;
  }
  return data || 0;
}

/**  * Check whether the current user is a superadmin (lightweight client hint).  * The real enforcement is still server-side in every RPC.  */
export async function isSuperadmin() {
  const {
    data,
    error
  } = await supabase.rpc('fn_is_superadmin');
  if (error) {
    console.error('isSuperadmin error:', error);
    return false;
  }
  return !!data;
}
