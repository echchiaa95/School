-- ============================================================================
-- PHASE 25 — TRANSPORT / LIVE MAP / PARENT / AUDIT / SCHEDULE / SCHOOL INFO
-- ADDITIVE & SAFE: no DROP TABLE, no TRUNCATE, no unguarded DELETE.
-- Every function is security definer with server-side role/school checks.
-- This file is appended batch by batch; section markers keep it navigable.
-- ============================================================================

-- ============================================================================
-- SECTION 1 (BATCH 1 — LIVE MAP): fn_get_map_overview
-- One school-scoped call that returns everything the Admin/Director general
-- map needs:
--   * school marker (schools.latitude/longitude/location_label, Phase 20)
--   * ALL student homes of the school that already have coordinates
--     (students.latitude/longitude/location_label — NO fake markers, and the
--     locations never travel to any other school: resolved via user_roles)
--   * the FULL fleet: active-trip buses with live position + real passenger
--     counts, and inactive buses with their LAST KNOWN location only
--   * route stops that have coordinates (bus_stops.latitude/longitude)
-- Roles: admin/director of the school only. SuperAdmin has no school context
-- here (the live map is a per-school screen); drivers/parents use their own
-- scoped RPCs (fn_driver_context / fn_my_children). Home locations are
-- therefore protected server-side, not by hiding markers in JS.
-- ============================================================================
create or replace function fn_get_map_overview()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_result jsonb;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director')
  limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  select jsonb_build_object(
    'school', (
      select jsonb_build_object(
        'name', s.name, 'latitude', s.latitude,
        'longitude', s.longitude, 'location_label', s.location_label
      )
      from schools s where s.id = v_school_id
    ),
    'homes', coalesce((
      select jsonb_agg(jsonb_build_object(
               'student_id', st.id, 'full_name', st.full_name,
               'class_name', cls.name, 'latitude', st.latitude,
               'longitude', st.longitude, 'location_label', st.location_label
             ) order by st.full_name)
      from students st
      left join student_enrollments se
        on se.student_id = st.id and se.status = 'ACTIVE'
      left join classes cls on cls.id = se.class_id
      where st.school_id = v_school_id
        and st.deleted_at is null
        and st.latitude is not null
        and st.longitude is not null
      limit 1500
    ), '[]'::jsonb),
    'buses', coalesce((
      select jsonb_agg(jsonb_build_object(
               'bus_id', b.id, 'bus_code', b.code, 'bus_plate', b.plate_number,
               'driver_name', prof.full_name,
               'has_active_trip', t.id is not null,
               'trip_id', t.id,
               'direction', case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup'
                                 when t.direction = 'TO_HOME'::trip_direction then 'dropoff'
                                 else null end,
               'latitude', coalesce(ll_trip.latitude, ll_last.latitude),
               'longitude', coalesce(ll_trip.longitude, ll_last.longitude),
               'speed', ll_trip.speed,
               'recorded_at', coalesce(ll_trip.recorded_at, ll_last.recorded_at),
               'live', ll_trip.recorded_at is not null,
               'total_students', case when t.id is not null then
                 (select count(*) from student_transport_assignments sta
                   where sta.bus_id = b.id and sta.is_active)::int
                 else null end,
               'boarded_count', case when t.id is not null then
                 (select count(*) from bus_trip_students bts
                   where bts.trip_id = t.id and bts.boarded_at is not null)::int
                 else null end,
               'dropped_count', case when t.id is not null then
                 (select count(*) from bus_trip_students bts
                   where bts.trip_id = t.id and bts.dropped_at is not null)::int
                 else null end
             ) order by b.code)
      from buses b
      left join bus_trips t on t.bus_id = b.id and t.status = 'ACTIVE'::trip_status
      left join bus_last_locations ll_trip on ll_trip.bus_id = b.id and ll_trip.trip_id = t.id
      left join lateral (
        select ll.latitude, ll.longitude, ll.recorded_at
        from bus_last_locations ll
        where ll.bus_id = b.id
        order by ll.recorded_at desc
        limit 1
      ) ll_last on t.id is null
      left join drivers d on d.id = coalesce(t.driver_id, b.driver_id)
      left join profiles prof on prof.id = d.profile_id
      where b.school_id = v_school_id
    ), '[]'::jsonb),
    'stops', coalesce((
      select jsonb_agg(jsonb_build_object(
               'stop_id', bs.id, 'name', bs.name,
               'latitude', bs.latitude, 'longitude', bs.longitude,
               'route_name', br.name
             ) order by br.name, rs.sequence_order)
      from bus_route_stops rs
      join bus_stops bs on bs.id = rs.stop_id
      join bus_routes br on br.id = rs.route_id
      where br.school_id = v_school_id
        and bs.latitude is not null
        and bs.longitude is not null
    ), '[]'::jsonb)
  ) into v_result;

  return v_result;
end;
$$;
revoke all on function fn_get_map_overview() from public;
grant execute on function fn_get_map_overview() to authenticated;


-- ============================================================================
-- SECTION 2 (BATCH 3): fn_get_student_badge — allow the student's OWN parent
-- (§23: parent sees the SAME official QR). Same signature → OR REPLACE.
-- Depends on: parent_students/parents (Phase 2), fn_is_school_staff (Phase 12).
-- ============================================================================
create or replace function fn_get_student_badge(p_student_id uuid)
returns table(id uuid, status text, secure_token uuid, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
declare v_school_id uuid;
begin
  select school_id into v_school_id from students where id = p_student_id and deleted_at is null;
  if v_school_id is null then raise exception 'INVALID_STUDENT'; end if;
  if not (fn_is_school_staff(v_school_id)
          or fn_has_permission('students.badge.view', v_school_id)
          or fn_has_permission('students.badge.issue', v_school_id)
          or exists (select 1 from parent_students ps join parents pa on pa.id = ps.parent_id
                     where pa.profile_id = auth.uid() and ps.student_id = p_student_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;
  return query select sb.id, sb.status::text, sb.secure_token, sb.created_at
    from student_badges sb where sb.student_id = p_student_id
    order by sb.created_at desc limit 1;
end; $$;
revoke all on function fn_get_student_badge(uuid) from public;
grant execute on function fn_get_student_badge(uuid) to authenticated;

-- ============================================================================
-- SECTION 3 (BATCH 6): schools.website guard — normalize + reject dangerous
-- schemes server-side (§31). Depends on schools.website (Phase 12). ADDITIVE.
-- ============================================================================
create or replace function fn_schools_website_guard() returns trigger
language plpgsql as $$
begin
  if new.website is not null then
    new.website := btrim(new.website);
    if new.website = '' then new.website := null;
    else
      if new.website ~* '^(javascript|data|vbscript|file):' then
        raise exception 'INVALID_WEBSITE';
      end if;
      if new.website !~ '^[a-z][a-z0-9+.-]*://' then new.website := 'https://' || new.website; end if;
    end if;
  end if;
  return new;
end; $$;
drop trigger if exists trg_schools_website_guard on schools;
create trigger trg_schools_website_guard before insert or update of website on schools
  for each row execute function fn_schools_website_guard();

-- ============================================================================
-- SECTION 4 (BATCH 1+, SuperAdmin): fn_get_map_overview NOW takes an optional
-- p_school_id. SuperAdmin (no fixed school) MUST pass a school — he may list
-- all his schools via the existing superadmin RPCs and pick one. Admin/Director
-- are ALWAYS pinned to their own school (the parameter is ignored for them),
-- so no cross-school leak is possible. Signature changed → DROP of the OLD
-- signature only (allowed), not a data DROP.
-- ============================================================================
drop function if exists fn_get_map_overview();
create or replace function fn_get_map_overview(p_school_id uuid default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_school_id uuid;
  v_super boolean;
  v_result jsonb;
begin
  select exists (select 1 from user_roles where profile_id = auth.uid() and role = 'superadmin')
    into v_super;
  if v_super then
    if p_school_id is null then raise exception 'SCHOOL_REQUIRED'; end if;
    if not exists (select 1 from schools where id = p_school_id) then
      raise exception 'SCHOOL_NOT_FOUND';
    end if;
    v_school_id := p_school_id;          -- explicit, user-chosen school
  else
    select ur.school_id into v_school_id from user_roles ur
    where ur.profile_id = auth.uid() and ur.role in ('admin', 'director') limit 1;
    if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;
  end if;

  select jsonb_build_object(
    'school', (
      select jsonb_build_object('name', s.name, 'latitude', s.latitude,
               'longitude', s.longitude, 'location_label', s.location_label)
      from schools s where s.id = v_school_id),
    'homes', coalesce((
      select jsonb_agg(jsonb_build_object(
               'student_id', st.id, 'full_name', st.full_name, 'class_name', cls.name,
               'latitude', st.latitude, 'longitude', st.longitude,
               'location_label', st.location_label) order by st.full_name)
      from students st
      left join student_enrollments se on se.student_id = st.id and se.status = 'ACTIVE'
      left join classes cls on cls.id = se.class_id
      where st.school_id = v_school_id and st.deleted_at is null
        and st.latitude is not null and st.longitude is not null
      limit 1500), '[]'::jsonb),
    'buses', coalesce((
      select jsonb_agg(jsonb_build_object(
               'bus_id', b.id, 'bus_code', b.code, 'bus_plate', b.plate_number,
               'driver_name', prof.full_name, 'has_active_trip', t.id is not null,
               'trip_id', t.id,
               'direction', case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup'
                                 when t.direction = 'TO_HOME'::trip_direction then 'dropoff' else null end,
               'latitude', coalesce(ll_trip.latitude, ll_last.latitude),
               'longitude', coalesce(ll_trip.longitude, ll_last.longitude),
               'speed', ll_trip.speed,
               'recorded_at', coalesce(ll_trip.recorded_at, ll_last.recorded_at),
               'live', ll_trip.recorded_at is not null,
               'total_students', case when t.id is not null then
                 (select count(*) from student_transport_assignments sta
                   where sta.bus_id = b.id and sta.is_active)::int else null end,
               'boarded_count', case when t.id is not null then
                 (select count(*) from bus_trip_students bts
                   where bts.trip_id = t.id and bts.boarded_at is not null)::int else null end,
               'dropped_count', case when t.id is not null then
                 (select count(*) from bus_trip_students bts
                   where bts.trip_id = t.id and bts.dropped_at is not null)::int else null end
             ) order by b.code)
      from buses b
      left join bus_trips t on t.bus_id = b.id and t.status = 'ACTIVE'::trip_status
      left join bus_last_locations ll_trip on ll_trip.bus_id = b.id and ll_trip.trip_id = t.id
      left join lateral (
        select ll.latitude, ll.longitude, ll.recorded_at from bus_last_locations ll
        where ll.bus_id = b.id order by ll.recorded_at desc limit 1
      ) ll_last on t.id is null
      left join drivers d on d.id = coalesce(t.driver_id, b.driver_id)
      left join profiles prof on prof.id = d.profile_id
      where b.school_id = v_school_id), '[]'::jsonb),
    'stops', coalesce((
      select jsonb_agg(jsonb_build_object(
               'stop_id', bs.id, 'name', bs.name, 'latitude', bs.latitude,
               'longitude', bs.longitude, 'route_name', br.name)
             order by br.name, rs.sequence_order)
      from bus_route_stops rs
      join bus_stops bs on bs.id = rs.stop_id
      join bus_routes br on br.id = rs.route_id
      where br.school_id = v_school_id
        and bs.latitude is not null and bs.longitude is not null), '[]'::jsonb)
  ) into v_result;
  return v_result;
end; $$;
revoke all on function fn_get_map_overview(uuid) from public;
grant execute on function fn_get_map_overview(uuid) to authenticated;

-- ============================================================================
-- SECTION 5 (BATCH 5): comprehensive Audit Log (§26-27).
-- Depends on audit_logs (Phase 2: school_id, user_id, action, entity,
-- entity_id, old_data jsonb, new_data jsonb, created_at). ADMIN sees his
-- school via fn_get_school_audit (existing); SUPERADMIN sees ALL schools via
-- fn_superadmin_get_audit_logs (existing). Trigger loop applies ONLY to
-- tables that actually exist (information_schema check) — nothing assumed.
-- Never logs secrets: secure_token stripped for student_badges; passwords
-- live in auth.users and are never touched here.
-- ============================================================================
create or replace function fn_audit_row() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  v_row jsonb; v_old jsonb; v_new jsonb; v_school uuid;
begin
  v_row := case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end;
  v_old := case when tg_op in ('UPDATE','DELETE') then to_jsonb(old) else null end;
  v_new := case when tg_op in ('INSERT','UPDATE') then to_jsonb(new) else null end;
  if tg_table_name = 'student_badges' then
    v_old := case when v_old is null then null else v_old - 'secure_token' end;
    v_new := case when v_new is null then null else v_new - 'secure_token' end;
  end if;
  v_school := nullif(v_row ->> 'school_id', '')::uuid; -- most audited tables carry school_id
  if v_school is null and v_row ? 'student_id' then
    select school_id into v_school from students where id = (v_row ->> 'student_id')::uuid;
  end if;
  insert into audit_logs (school_id, user_id, action, entity, entity_id, old_data, new_data)
  values (v_school, auth.uid(), tg_op, tg_table_name,
          nullif(v_row ->> 'id', '')::uuid, v_old, v_new);
  return coalesce(new, old);
end; $$;

do $$
declare t text;
begin
  foreach t in array array['students','payments','user_roles','buses','bus_routes',
    'teachers','drivers','parents','guards','classes','subjects','timetable_entries',
    'attendance_records','bus_trips','bus_trip_students','student_badges','student_enrollments'] loop
    if exists (select 1 from information_schema.tables
               where table_schema = 'public' and table_name = t) then
      execute format('drop trigger if exists trg_audit_%I on %I;', t, t);
      execute format('create trigger trg_audit_%I after insert or update or delete on %I
                      for each row execute function fn_audit_row();', t, t);
    end if;
  end loop;
end $$;
