// ============================================================================
// modules/badgeCard.js
// Shared "student ID badge" rendering: QR code + printable card.
// Used by both guard.html (issue/reissue/suspend flow, already wired to
// fn_guard_issue_badge/reissue/suspend via students.js) and admin.html
// (Student Profile). No new backend permission model — this only renders
// what fn_get_student_badge / issueBadge / reissueBadge already return.
// ============================================================================

import { esc } from './ui.js?v=19';

let html2canvasPromise = null;
function loadHtml2Canvas() {
  if (window.html2canvas) return Promise.resolve();
  if (html2canvasPromise) return html2canvasPromise;
  html2canvasPromise = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js';
    s.onload = () => resolve();
    s.onerror = () => reject(new Error('HTML2CANVAS_LOAD_FAILED'));
    document.head.appendChild(s);
  });
  return html2canvasPromise;
}
let qrLibPromise = null;
function loadQrLib() {
  if (window.QRCode) return Promise.resolve();
  if (qrLibPromise) return qrLibPromise;
  qrLibPromise = new Promise((resolve, reject) => {
    const urls = [
      'https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js',
      'https://cdnjs.cloudflare.com/ajax/libs/qrcode/1.5.3/qrcode.min.js',
      'https://unpkg.com/qrcode@1.5.3/build/qrcode.min.js',
    ];
    let i = 0;
    const tryNext = () => {
      if (window.QRCode) { resolve(); return; }
      if (i >= urls.length) { reject(new Error('QR_LIB_LOAD_FAILED')); return; }
      const s = document.createElement('script');
      s.src = urls[i++];
      s.onload = () => window.QRCode ? resolve() : tryNext();
      s.onerror = tryNext;
      document.head.appendChild(s);
    };
    tryNext();
  });
  return qrLibPromise;
}

const STATUS_AR = {
  ACTIVE: 'سارية', SUSPENDED: 'موقوفة', LOST: 'مفقودة',
  EXPIRED: 'منتهية', REPLACED: 'مستبدلة',
};

/**
 * Render a printable, downloadable ID-card panel with a real QR code
 * encoding the badge's secure_token, into `container` (an existing DOM
 * element). Includes the school logo (schools.logo_url — already an
 * existing, editable field), the student's photo (students.photo_url),
 * class and year — everything the badge already has data for.
 * @param {HTMLElement} container
 * @param {{full_name:string, student_number:string, class_name?:string, year_name?:string, photo_url?:string, school_name?:string, school_logo_url?:string}} student
 * @param {{status:string, secure_token:string}} badge
 */
export async function renderBadgeCard(container, student, badge) {
  const cardId = 'badge-card-' + Math.random().toString(36).slice(2, 8);
  container.innerHTML = `
    <div class="panel" id="${cardId}" style="text-align:center; max-width:320px; margin:0 auto;">
      ${student.school_logo_url ? `<img src="${esc(student.school_logo_url)}" alt="" style="max-height:44px; margin-bottom:6px;">` : ''}
      <div style="font-weight:700; font-size:14px;">${esc(student.school_name || '')}</div>
      <div style="font-size:11px; letter-spacing:1px; color:#6b7280;">بطاقة الطالب</div>
      ${student.photo_url
        ? `<img src="${esc(student.photo_url)}" alt="" style="width:76px; height:76px; border-radius:50%; object-fit:cover; margin:8px auto; display:block; border:2px solid #e5e7eb;">`
        : `<div style="width:76px; height:76px; border-radius:50%; background:#e5e7eb; margin:8px auto; display:flex; align-items:center; justify-content:center; font-size:28px;">👤</div>`}
      <div style="font-weight:800; font-size:18px;">${esc(student.full_name)}</div>
      <div style="color:#6b7280; font-size:13px;">#${esc(student.student_number || '')} ${student.class_name ? '— ' + esc(student.class_name) : ''}</div>
      ${student.year_name ? `<div style="color:#6b7280; font-size:12px;">${esc(student.year_name)}</div>` : ''}
      <div class="qr-holder" style="display:flex; justify-content:center; margin:12px 0;"><div class="loading-state">جارٍ إنشاء QR...</div></div>
      <div class="badge badge-${badge.status === 'ACTIVE' ? 'green' : 'red'}">${esc(STATUS_AR[badge.status] || badge.status)}</div>
    </div>
    <div style="display:flex; gap:8px; margin-top:10px;">
      <button type="button" class="quick-action-btn secondary" id="${cardId}-download" style="flex:1;">⬇️ تحميل البطاقة</button>
      <button type="button" class="quick-action-btn secondary" id="${cardId}-print" style="flex:1;">🖨️ طباعة</button>
    </div>`;

  const holder = container.querySelector('.qr-holder');
  let qrCanvas = null;
  try {
    if (!badge?.secure_token) throw new Error('BADGE_TOKEN_MISSING');
    await loadQrLib();
    qrCanvas = document.createElement('canvas');
    await window.QRCode.toCanvas(qrCanvas, String(badge.secure_token), { width: 160, margin: 1 });
    holder.innerHTML = '';
    holder.appendChild(qrCanvas);
    dbg(`[QR] rendered for badge ${badge.id} (status=${badge.status})`);
  } catch (e) {
    if (isDebug()) console.error(`[QR ERROR] badge=${badge?.id || '—'} reason=${e?.message || e}`);
    holder.innerHTML = '<div class="empty-state">تعذر إنشاء رمز QR (تحقق من الاتصال بالإنترنت).</div>';
  }

  container.querySelector(`#${cardId}-print`).addEventListener('click', () => {
    const printWin = window.open('', '_blank', 'width=400,height=600');
    if (!printWin) { alert('اسمح بالنوافذ المنبثقة للطباعة.'); return; }
    const clone = container.querySelector(`#${cardId}`).cloneNode(true);
    const canvas = clone.querySelector('canvas');
    if (canvas) {
      const img = document.createElement('img');
      try { img.src = canvas.toDataURL('image/png'); } catch { img.alt = 'QR'; }
      img.width = 160; img.height = 160; img.style.display = 'block'; img.style.margin = '12px auto';
      canvas.replaceWith(img);
    }
    printWin.document.write(`<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8">
      <title>بطاقة التلميذ</title>
      <style>body{font-family:sans-serif; text-align:center; padding:20px;}
      .card{border:2px solid #111827; border-radius:12px; padding:16px; max-width:300px; margin:0 auto;}</style>
      </head><body>${clone.outerHTML}</body></html>`);
    printWin.document.close();
    printWin.focus();
    setTimeout(() => printWin.print(), 500);
  });

  // "Download" — a full screenshot of the card (logo + photo + text + QR),
  // not just the QR, per instruction. html2canvas (CDN, no key, same
  // loading pattern as the QR library) rasterizes the actual card DOM
  // node. Cross-origin images (school logo / student photo, both served
  // from Supabase Storage's public bucket) need CORS-safe loading, so we
  // set crossOrigin on them before capturing; if a given image's server
  // doesn't send the right CORS headers, html2canvas taints just that
  // image (drawn blank) rather than failing the whole capture — the QR
  // and text still come through, which is why "طباعة" (real browser
  // print → Save as PDF) remains offered right next to it as a
  // guaranteed-correct fallback.
  container.querySelector(`#${cardId}-download`).addEventListener('click', async () => {
    const btn = container.querySelector(`#${cardId}-download`);
    const original = btn.textContent;
    btn.textContent = 'جارٍ التجهيز...';
    btn.disabled = true;
    try {
      await loadHtml2Canvas();
      const cardEl = container.querySelector(`#${cardId}`);
      cardEl.querySelectorAll('img').forEach((img) => { img.crossOrigin = 'anonymous'; });
      const canvas = await window.html2canvas(cardEl, { backgroundColor: '#ffffff', scale: 2, useCORS: true });
      const a = document.createElement('a');
      a.href = canvas.toDataURL('image/png');
      a.download = `badge-${student.student_number || 'student'}.png`;
      a.click();
    } catch (e) {
      console.error('Badge download failed:', e);
      alert('تعذر تحميل البطاقة كاملة، جرّب زر الطباعة (حفظ كـ PDF).');
    } finally {
      btn.textContent = original;
      btn.disabled = false;
    }
  });
}
