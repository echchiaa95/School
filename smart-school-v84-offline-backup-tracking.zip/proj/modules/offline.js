// ============================================================================
// modules/offline.js — Phase 81: وضع عدم الاتصال
// - كشف الاتصال (online/offline + فحص دوري خفيف)
// - شارة اتصال ثابتة أعلى الشاشة (🟢 متصل / 🟠 دون اتصال + عدد المعلّق)
// - طابور عمليات محلي (localStorage) يُزامَن تلقائيًا عند عودة الاتصال
// - كاش قراءة للبيانات المهمة (تُعرض عند الانقطاع مع شارة «بيانات مخزّنة»)
// ============================================================================

import { supabase } from './supabase.js';

const OUTBOX_KEY = 'ss_offline_outbox_v1';
const CACHE_PREFIX = 'ss_cache_v1_';
const FLUSH_INTERVAL_MS = 30000;

let badgeEl = null;
let flushTimer = null;
let flushing = false;
const listeners = new Set();

// ---------------------------------------------------------------- اتصال ----
export function isOnline() {
  return navigator.onLine !== false;
}

export function onConnectivityChange(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

function notifyListeners() {
  const online = isOnline();
  listeners.forEach((fn) => { try { fn(online); } catch { } });
  updateBadge();
}

// ---------------------------------------------------------------- شارة -----
export function mountConnectivityBadge() {
  if (badgeEl || !document.body) return;
  badgeEl = document.createElement('div');
  badgeEl.id = 'ss-offline-badge';
  badgeEl.style.cssText = 'position:fixed;top:8px;inset-inline-start:50%;transform:translateX(50%);z-index:9998;' +
    'padding:6px 14px;border-radius:999px;font-size:.8rem;font-weight:800;font-family:Tajawal,sans-serif;' +
    'box-shadow:0 4px 14px rgba(0,0,0,.25);transition:all .3s;pointer-events:none;';
  document.body.appendChild(badgeEl);
  updateBadge();
}

function outboxCount() {
  return getOutbox().length + getGpsPending().length;
}

function updateBadge() {
  if (!badgeEl) return;
  const online = isOnline();
  const pending = outboxCount();
  if (!online) {
    badgeEl.style.display = 'block';
    badgeEl.style.background = '#b45309';
    badgeEl.style.color = '#fff';
    badgeEl.textContent = '🟠 وضع عدم الاتصال' + (pending ? ` — ${pending} عملية معلّقة` : ' — تُحفظ محليًا');
  } else if (pending) {
    badgeEl.style.display = 'block';
    badgeEl.style.background = '#1d4ed8';
    badgeEl.style.color = '#fff';
    badgeEl.textContent = `🔄 جارٍ مزامنة ${pending} عملية معلّقة…`;
  } else {
    badgeEl.style.display = 'none';
  }
}

// ---------------------------------------------------------------- طابور ----
function getOutbox() {
  try { return JSON.parse(localStorage.getItem(OUTBOX_KEY) || '[]'); }
  catch { return []; }
}
function setOutbox(items) {
  try { localStorage.setItem(OUTBOX_KEY, JSON.stringify(items.slice(-300))); } catch { }
}

/**
 * أضف عملية إلى الطابور (تُنفَّذ تلقائيًا عند عودة الاتصال).
 * kind: 'rpc' (افتراضي) — fn/params تُرسل كما هي؛ 'insert' — إدراج صف في جدول.
 */
export function enqueue(fnName, params, label) {
  const items = getOutbox();
  items.push({
    id: 'q' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    kind: 'rpc',
    fn: fnName, params: params || {}, label: label || fnName,
    createdAt: new Date().toISOString(),
  });
  setOutbox(items);
  updateBadge();
  return items.length;
}

/** طابور إدراج مباشر في جدول (للعمليات التي لا تمر عبر RPC مثل سجلات الحارس). */
export function enqueueInsert(table, row, label) {
  const items = getOutbox();
  items.push({
    id: 'q' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    kind: 'insert', table, row, label: label || table,
    createdAt: new Date().toISOString(),
  });
  setOutbox(items);
  updateBadge();
}

export function getOutboxSize() {
  return getOutbox().length + getGpsPending().length;
}

/** نفّذ RPC مع سقوط تلقائي إلى الطابور عند انقطاع الشبكة فقط. */
export async function callQueued(fnName, params, label) {
  if (!isOnline()) {
    enqueue(fnName, params, label);
    return { ok: true, queued: true };
  }
  try {
    const { error } = await supabase.rpc(fnName, params || {});
    if (error) {
      const msg = String(error.message || '');
      if (/Failed to fetch|NetworkError|fetch failed|Network request failed|ERR_INTERNET|timeout/i.test(msg)) {
        enqueue(fnName, params, label);
        return { ok: true, queued: true };
      }
      return { ok: false, error: msg };
    }
    return { ok: true };
  } catch (e) {
    enqueue(fnName, params, label);
    return { ok: true, queued: true };
  }
}

// ------------------------------------------------------------- GPS معلّق ---
const GPS_KEY = 'ss_gps_pending_v1';
const GPS_MAX = 800;

export function getGpsPending() {
  try { return JSON.parse(localStorage.getItem(GPS_KEY) || '[]'); }
  catch { return []; }
}
export function queueGpsPing(ping) {
  const arr = getGpsPending();
  arr.push(ping);
  // احتفظ بالأحدث فقط عند الامتلاء
  while (arr.length > GPS_MAX) arr.shift();
  try { localStorage.setItem(GPS_KEY, JSON.stringify(arr)); } catch { }
  updateBadge();
}
function setGpsPending(arr) {
  try { localStorage.setItem(GPS_KEY, JSON.stringify(arr)); } catch { }
}

async function flushGpsPending() {
  const arr = getGpsPending();
  if (!arr.length) return;
  const batch = arr.slice(0, 100);
  const { error } = await supabase.rpc('fn_sync_gps_pings', { p_pings: batch });
  if (error) {
    const msg = String(error.message || '');
    if (/Failed to fetch|NetworkError|fetch failed|Network request failed|ERR_INTERNET|timeout/i.test(msg)) return; // لا يزال مقطوعًا
    // خطأ منطقي (دالة غير موجودة بعد / صلاحية): لا نحذف — يبقى للمحاولة لاحقًا
    return;
  }
  setGpsPending(arr.slice(batch.length));
  if (arr.length > batch.length) return flushGpsPending();
}

// ---------------------------------------------------------------- مزامنة ---
export async function flushOutbox() {
  if (flushing || !isOnline()) return;
  flushing = true;
  try {
    await flushGpsPending();
    let items = getOutbox();
    while (items.length && isOnline()) {
      const item = items[0];
      let error;
      if (item.kind === 'insert') {
        ({ error } = await supabase.from(item.table).insert(item.row));
      } else {
        ({ error } = await supabase.rpc(item.fn, item.params || {}));
      }
      if (error) {
        const msg = String(error.message || '');
        if (/Failed to fetch|NetworkError|fetch failed|Network request failed|ERR_INTERNET|timeout/i.test(msg)) break;
        // فشل منطقي (رحلة منتهية، صلاحية…): أزل من الطابور حتى لا يعلق للأبد
        items = items.slice(1);
        setOutbox(items);
        continue;
      }
      items = items.slice(1);
      setOutbox(items);
    }
  } finally {
    flushing = false;
    updateBadge();
  }
}

// ---------------------------------------------------------------- كاش ------
export function cacheSet(key, data) {
  try {
    localStorage.setItem(CACHE_PREFIX + key, JSON.stringify({ at: new Date().toISOString(), data }));
  } catch { }
}
export function cacheGet(key, maxAgeMs) {
  try {
    const raw = localStorage.getItem(CACHE_PREFIX + key);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (maxAgeMs && (Date.now() - new Date(parsed.at).getTime()) > maxAgeMs) return null;
    return parsed;
  } catch { return null; }
}

// ---------------------------------------------------------------- بدء ------
let booted = false;
export function initOffline() {
  if (booted) return;
  booted = true;
  mountConnectivityBadge();
  window.addEventListener('online', () => { notifyListeners(); flushOutbox(); });
  window.addEventListener('offline', notifyListeners);
  flushTimer = setInterval(() => { if (isOnline()) flushOutbox(); }, FLUSH_INTERVAL_MS);
  // محاولة أولى بعد الإقلاع
  setTimeout(() => { if (isOnline()) flushOutbox(); }, 4000);
}
