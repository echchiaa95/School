-- ============================================================================
-- phase75_student_staff_lastseen.sql
-- نفّذ هذا الملف مرة واحدة في Supabase SQL Editor (بعد phase74).
--
-- 1) التلميذ: عمودا health_status (الحالة الصحية) و massar_number (رقم مسار)
--    + تمديد fn_register_student_auto_number و fn_get_student_full
--    + RPC جديد fn_update_student_profile (تعديل ملف التلميذ من المدير).
-- 2) حضور الموظفين: عمود declared_hours (عدد الساعات المصرَّح به يدويًا من
--    الحارس/المدير) + RPC جديد fn_mark_staff_attendance_hours + تحديث
--    التقارير لتجمع الساعات المصرَّحة مع المحسوبة.
-- 3) آخر ظهور: عمود profiles.last_seen_at + fn_touch_last_seen (نبضة من
--    التطبيق) + fn_list_school_accounts_last_seen (المدير يرى آخر ظهور
--    لكل حسابات الموظفين وأولياء الأمور).
--
-- 100% إضافي: ADD COLUMN IF NOT EXISTS + CREATE OR REPLACE فقط.
-- ============================================================================

-- ═══════════════════════════ 1) ملف التلميذ ═══════════════════════════

alter table public.students add column if not exists health_status text;
alter table public.students add column if not exists massar_number text;

-- تمديد التسجيل: نفس الدالة مع معاملين اختياريين جديدين في النهاية.
drop function if exists public.fn_register_student_auto_number(text, uuid, uuid, date, text);
drop function if exists public.fn_register_student_auto_number(text, uuid, uuid, date, text, text, text);

create function public.fn_register_student_auto_number(
  p_full_name text,
  p_class_id uuid,
  p_academic_year_id uuid,
  p_birth_date date default null,
  p_gender text default null,
  p_health_status text default null,
  p_massar_number text default null
)
returns table(student_id uuid, student_number text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_class_year uuid;
  v_role text;
  v_next bigint;
  v_student_number text;
  v_student_id uuid;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  if p_full_name is null or btrim(p_full_name) = '' then
    raise exception 'STUDENT_NAME_REQUIRED';
  end if;

  select c.school_id, c.academic_year_id
    into v_school_id, v_class_year
  from classes c
  where c.id = p_class_id;

  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;

  if not exists (
    select 1 from academic_years ay
    where ay.id = p_academic_year_id
      and ay.school_id = v_school_id
  ) then
    raise exception 'ACADEMIC_YEAR_SCHOOL_MISMATCH';
  end if;

  v_role := fn_resolve_my_role(v_school_id);
  if v_role is null then
    raise exception 'PERMISSION_DENIED: no role in this school';
  end if;

  if v_role = 'admin' then
    null;
  elsif v_role = 'guard' then
    if not fn_has_permission('students.create', v_school_id) then
      raise exception 'PERMISSION_DENIED: missing students.create';
    end if;
  else
    raise exception 'PERMISSION_DENIED: role % cannot register students', v_role;
  end if;

  perform pg_advisory_xact_lock(hashtextextended(v_school_id::text, 0));

  select coalesce(max(st.student_number::bigint), 0)
    into v_next
  from students st
  where st.school_id = v_school_id
    and st.student_number ~ '^[0-9]+$';

  insert into school_student_number_counters (school_id, next_number)
  values (v_school_id, v_next)
  on conflict (school_id) do nothing;

  update school_student_number_counters c
     set next_number = greatest(c.next_number, v_next) + 1,
         updated_at = now()
   where c.school_id = v_school_id
  returning c.next_number into v_next;

  v_student_number := v_next::text;

  begin
    insert into students (
      school_id, full_name, student_number, birth_date, gender,
      health_status, massar_number
    ) values (
      v_school_id, btrim(p_full_name), v_student_number, p_birth_date, p_gender,
      nullif(btrim(coalesce(p_health_status, '')), ''),
      nullif(btrim(coalesce(p_massar_number, '')), '')
    )
    returning id into v_student_id;
  exception
    when unique_violation then
      raise exception 'DUPLICATE_STUDENT_NUMBER';
    when others then
      raise exception 'STUDENT_INSERT_FAILED: %', sqlerrm;
  end;

  begin
    insert into student_enrollments (student_id, school_id, class_id, academic_year_id, status)
    values (v_student_id, v_school_id, p_class_id, p_academic_year_id, 'ACTIVE');
  exception
    when others then
      raise exception 'ENROLLMENT_INSERT_FAILED: %', sqlerrm;
  end;

  perform fn_write_audit(
    v_school_id,
    'STUDENT_REGISTERED',
    'students',
    v_student_id,
    null,
    jsonb_build_object(
      'student_number', v_student_number,
      'class_id', p_class_id,
      'academic_year_id', p_academic_year_id,
      'registered_by', auth.uid(),
      'registered_by_role', v_role
    )
  );

  return query select v_student_id, v_student_number;
end;
$$;

revoke all on function public.fn_register_student_auto_number(text, uuid, uuid, date, text, text, text) from public;
grant execute on function public.fn_register_student_auto_number(text, uuid, uuid, date, text, text, text) to authenticated;

-- تعديل ملف التلميذ (المدير دائمًا / الحارس بصلاحية students.create)
create or replace function public.fn_update_student_profile(
  p_student_id uuid,
  p_full_name text default null,
  p_birth_date date default null,
  p_gender text default null,
  p_health_status text default null,
  p_massar_number text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select school_id into v_school_id from public.students
  where id = p_student_id and deleted_at is null;
  if v_school_id is null then
    raise exception 'INVALID_STUDENT';
  end if;

  v_role := public.fn_resolve_my_role(v_school_id);
  if v_role = 'admin' or v_role = 'director' then
    null;
  elsif v_role = 'guard' and public.fn_has_permission('students.create', v_school_id) then
    null;
  else
    raise exception 'PERMISSION_DENIED';
  end if;

  if p_full_name is not null and btrim(p_full_name) = '' then
    raise exception 'STUDENT_NAME_REQUIRED';
  end if;

  update public.students set
    full_name     = coalesce(nullif(btrim(coalesce(p_full_name, '')), ''), full_name),
    birth_date    = coalesce(p_birth_date, birth_date),
    gender        = coalesce(p_gender, gender),
    health_status = case when p_health_status is null then health_status
                         else nullif(btrim(p_health_status), '') end,
    massar_number = case when p_massar_number is null then massar_number
                         else nullif(btrim(p_massar_number), '') end
  where id = p_student_id;

  perform public.fn_write_audit(
    v_school_id, 'STUDENT_PROFILE_UPDATED', 'students', p_student_id,
    null,
    jsonb_build_object(
      'full_name', p_full_name, 'birth_date', p_birth_date, 'gender', p_gender,
      'health_status', p_health_status, 'massar_number', p_massar_number
    )
  );

  return jsonb_build_object('ok', true, 'student_id', p_student_id);
end;
$$;

grant execute on function public.fn_update_student_profile(uuid, text, date, text, text, text) to authenticated;

-- إرجاع الحقلين الجديدين في ملف التلميذ الكامل
create or replace function fn_get_student_full(p_student_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_result jsonb;
begin
  select school_id into v_school_id from students where id = p_student_id;
  if v_school_id is null then raise exception 'INVALID_STUDENT'; end if;
  if not (fn_is_school_member(v_school_id) or fn_is_parent_of(p_student_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  select jsonb_build_object(
    'student_id', st.id,
    'full_name', st.full_name,
    'student_number', st.student_number,
    'photo_url', st.photo_url,
    'birth_date', st.birth_date,
    'gender', st.gender,
    'health_status', st.health_status,
    'massar_number', st.massar_number,
    'is_active', st.deleted_at is null,
    'address', st.address,
    'latitude', st.latitude,
    'longitude', st.longitude,
    'location_label', st.location_label,
    'class_id', (select se.class_id from student_enrollments se
                 where se.student_id = st.id and se.status = 'ACTIVE' limit 1),
    'class_name', (select c.name from student_enrollments se
                   join classes c on c.id = se.class_id
                   where se.student_id = st.id and se.status = 'ACTIVE' limit 1),
    'level', (select c.level from student_enrollments se
              join classes c on c.id = se.class_id
              where se.student_id = st.id and se.status = 'ACTIVE' limit 1),
    'year_name', (select ay.label from student_enrollments se
                  join classes c on c.id = se.class_id
                  join academic_years ay on ay.id = c.academic_year_id
                  where se.student_id = st.id and se.status = 'ACTIVE' limit 1),
    'badge_id', (select sb.id from student_badges sb
                 where sb.student_id = st.id order by sb.created_at desc limit 1),
    'badge_status', (select sb.status::text from student_badges sb
                     where sb.student_id = st.id order by sb.created_at desc limit 1),
    'attendance_30d', (select jsonb_build_object(
                         'present', count(*) filter (where ar.status = 'present'),
                         'absent', count(*) filter (where ar.status = 'absent'),
                         'late', count(*) filter (where ar.status = 'late'),
                         'excused', count(*) filter (where ar.status = 'excused'))
                       from attendance_records ar
                       where ar.student_id = st.id
                         and ar.att_date >= current_date - 30),
    'open_incidents', (select count(*) from incidents i
                       where i.student_id = st.id and i.status = 'open'),
    'parents', coalesce((select jsonb_agg(jsonb_build_object(
                   'name', p.full_name, 'phone', p.phone, 'relationship', ps.relationship))
                 from parent_students ps
                 join parents pa on pa.id = ps.parent_id
                 join profiles p on p.id = pa.profile_id
                 where ps.student_id = st.id), '[]'::jsonb),
    'transport', fn_student_transport_info(st.id)
  ) into v_result
  from students st
  where st.id = p_student_id;

  return v_result;
end;
$$;
revoke all on function fn_get_student_full(uuid) from public;
grant execute on function fn_get_student_full(uuid) to authenticated;

-- ═══════════════════ 2) حضور الموظفين بالساعات ═══════════════════

-- ساعات مصرَّح بها يدويًا (الحارس/المدير يحدد عدد ساعات اليوم)
alter table public.staff_attendance
  add column if not exists declared_hours numeric;

-- تسجيل حضور موظف مع عدد الساعات (upsert على نفس اليوم)
create or replace function public.fn_mark_staff_attendance_hours(
  p_profile_id uuid,
  p_work_date date,
  p_status text,
  p_hours numeric default null,
  p_notes text default null
)
returns public.staff_attendance
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_row public.staff_attendance;
begin
  v_school_id := public.fn_staff_school_id(p_profile_id);
  if v_school_id is null then
    raise exception 'STAFF_NOT_FOUND';
  end if;
  if not public.fn_is_school_manager(v_school_id) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if p_status not in ('PRESENT','ABSENT','LATE','HALF_DAY','LEAVE') then
    raise exception 'INVALID_STATUS';
  end if;
  if p_hours is not null and (p_hours < 0 or p_hours > 24) then
    raise exception 'INVALID_HOURS';
  end if;

  insert into public.staff_attendance (
    school_id, profile_id, work_date, status, declared_hours, notes, recorded_by
  ) values (
    v_school_id, p_profile_id, p_work_date, p_status,
    case when p_status = 'ABSENT' then 0 else p_hours end,
    p_notes, auth.uid()
  )
  on conflict (profile_id, work_date) do update
    set status = excluded.status,
        declared_hours = excluded.declared_hours,
        notes = excluded.notes,
        recorded_by = excluded.recorded_by,
        updated_at = now()
  returning * into v_row;

  perform public.fn_safe_audit(
    v_school_id, 'STAFF_ATTENDANCE_MARKED', 'staff_attendance', v_row.id,
    null, to_jsonb(v_row)
  );

  return v_row;
end;
$$;

grant execute on function public.fn_mark_staff_attendance_hours(uuid, date, text, numeric, text) to authenticated;

-- التقارير تجمع الساعات المصرَّحة أولًا ثم المحسوبة من الدخول/الخروج
create or replace function public.fn_get_staff_attendance_report(
  p_profile_id uuid,
  p_from date,
  p_to date
)
returns table (
  work_date date,
  status text,
  check_in_at timestamptz,
  check_out_at timestamptz,
  hours_worked numeric,
  notes text
)
language sql
security definer
set search_path = public
as $$
  select sa.work_date, sa.status, sa.check_in_at, sa.check_out_at,
         coalesce(sa.declared_hours, sa.hours_worked) as hours_worked,
         sa.notes
  from public.staff_attendance sa
  where sa.profile_id = p_profile_id
    and sa.work_date between p_from and p_to
    and public.fn_is_school_manager(sa.school_id)
  order by sa.work_date desc;
$$;

create or replace function public.fn_get_school_attendance_summary(
  p_school_id uuid,
  p_from date,
  p_to date
)
returns table (
  profile_id uuid,
  full_name text,
  role text,
  employment_type text,
  present_days bigint,
  absent_days bigint,
  late_days bigint,
  total_hours numeric
)
language sql
security definer
set search_path = public
as $$
  select
    s.profile_id, s.full_name, s.role, s.employment_type,
    count(*) filter (where sa.status = 'PRESENT') as present_days,
    count(*) filter (where sa.status = 'ABSENT') as absent_days,
    count(*) filter (where sa.status = 'LATE') as late_days,
    coalesce(sum(coalesce(sa.declared_hours, sa.hours_worked)), 0) as total_hours
  from public.fn_list_school_staff(p_school_id) s
  left join public.staff_attendance sa
    on sa.profile_id = s.profile_id
    and sa.work_date between p_from and p_to
  group by s.profile_id, s.full_name, s.role, s.employment_type
  order by s.full_name;
$$;

grant execute on function public.fn_get_staff_attendance_report(uuid, date, date) to authenticated;
grant execute on function public.fn_get_school_attendance_summary(uuid, date, date) to authenticated;

-- ═══════════════════════ 3) آخر ظهور في التطبيق ═══════════════════════

alter table public.profiles
  add column if not exists last_seen_at timestamptz;

-- نبضة: يستدعيها التطبيق دوريًا لأي مستخدم مسجَّل (لا تكشف أي بيانات)
create or replace function public.fn_touch_last_seen()
returns void
language sql
security definer
set search_path = public
as $$
  update public.profiles
  set last_seen_at = now()
  where id = auth.uid()
    and (last_seen_at is null or last_seen_at < now() - interval '2 minutes');
$$;

grant execute on function public.fn_touch_last_seen() to authenticated;

-- المدير/مدير المؤسسة: آخر ظهور لكل حسابات المدرسة (موظفون + أولياء أمور)
create or replace function public.fn_list_school_accounts_last_seen(p_school_id uuid)
returns table (
  profile_id uuid,
  full_name text,
  role text,
  phone text,
  last_seen_at timestamptz
)
language sql
security definer
set search_path = public
as $$
  select s.profile_id, s.full_name, s.role, s.phone, p.last_seen_at
  from public.fn_list_school_staff(p_school_id) s
  join public.profiles p on p.id = s.profile_id
  where public.fn_is_school_manager(p_school_id)
  union all
  select p2.id, p2.full_name, 'parent', p2.phone, p2.last_seen_at
  from public.parents pa
  join public.profiles p2 on p2.id = pa.profile_id
  where pa.school_id = p_school_id
    and pa.deleted_at is null
    and public.fn_is_school_manager(p_school_id)
  order by 5 desc nulls last, 2;
$$;

grant execute on function public.fn_list_school_accounts_last_seen(uuid) to authenticated;
