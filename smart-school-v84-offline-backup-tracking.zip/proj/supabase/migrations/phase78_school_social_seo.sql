-- ============================================================================
-- phase78_school_social_seo.sql
-- نفّذ هذا الملف مرة واحدة في Supabase SQL Editor (بعد phase77).
--
-- 1) schools: حقول التواصل الاجتماعي + شعار نصي قصير (tagline)
--    facebook_url / instagram_url / tiktok_url / youtube_url / whatsapp_number
-- 2) إضافتها للقائمة البيضاء في fn_update_school
-- 3) إرجاعها ضمن fn_get_public_school_page (بيانات عامة آمنة)
--
-- 100% إضافي: ADD COLUMN IF NOT EXISTS + CREATE OR REPLACE فقط.
-- ============================================================================

alter table public.schools add column if not exists tagline text;
alter table public.schools add column if not exists facebook_url text;
alter table public.schools add column if not exists instagram_url text;
alter table public.schools add column if not exists tiktok_url text;
alter table public.schools add column if not exists youtube_url text;
alter table public.schools add column if not exists whatsapp_number text;

-- fn_update_school: نفس التوقيع مع توسيع القائمة البيضاء
create or replace function public.fn_update_school(p_school_id uuid, p_data jsonb)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not fn_is_school_staff(p_school_id) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if not exists (select 1 from schools where id = p_school_id) then
    raise exception 'INVALID_SCHOOL';
  end if;

  update schools set
    name          = coalesce(nullif(trim(coalesce(p_data->>'name', '')), ''), name),
    legal_name    = case when p_data ? 'legal_name'    then nullif(trim(p_data->>'legal_name'), '')    else legal_name end,
    logo_url      = case when p_data ? 'logo_url'      then nullif(trim(p_data->>'logo_url'), '')      else logo_url end,
    address       = case when p_data ? 'address'       then nullif(trim(p_data->>'address'), '')       else address end,
    city          = case when p_data ? 'city'          then nullif(trim(p_data->>'city'), '')          else city end,
    region        = case when p_data ? 'region'        then nullif(trim(p_data->>'region'), '')        else region end,
    phone         = case when p_data ? 'phone'         then nullif(trim(p_data->>'phone'), '')         else phone end,
    email         = case when p_data ? 'email'         then nullif(trim(p_data->>'email'), '')         else email end,
    website       = case when p_data ? 'website'       then nullif(trim(p_data->>'website'), '')       else website end,
    director_name = case when p_data ? 'director_name' then nullif(trim(p_data->>'director_name'), '') else director_name end,
    school_type   = case when p_data ? 'school_type'   then nullif(trim(p_data->>'school_type'), '')   else school_type end,
    ice           = case when p_data ? 'ice'           then nullif(trim(p_data->>'ice'), '')           else ice end,
    notes         = case when p_data ? 'notes'         then nullif(trim(p_data->>'notes'), '')         else notes end,
    description   = case when p_data ? 'description'   then nullif(trim(p_data->>'description'), '')   else description end,
    tagline       = case when p_data ? 'tagline'       then nullif(trim(p_data->>'tagline'), '')       else tagline end,
    facebook_url  = case when p_data ? 'facebook_url'  then nullif(trim(p_data->>'facebook_url'), '')  else facebook_url end,
    instagram_url = case when p_data ? 'instagram_url' then nullif(trim(p_data->>'instagram_url'), '') else instagram_url end,
    tiktok_url    = case when p_data ? 'tiktok_url'    then nullif(trim(p_data->>'tiktok_url'), '')    else tiktok_url end,
    youtube_url   = case when p_data ? 'youtube_url'   then nullif(trim(p_data->>'youtube_url'), '')   else youtube_url end,
    whatsapp_number = case when p_data ? 'whatsapp_number' then nullif(trim(p_data->>'whatsapp_number'), '') else whatsapp_number end
  where id = p_school_id;

  perform fn_safe_audit(p_school_id, 'UPDATE_SCHOOL', 'schools', p_school_id, null, p_data);
end;
$$;

revoke all on function public.fn_update_school(uuid, jsonb) from public;
grant execute on function public.fn_update_school(uuid, jsonb) to authenticated;

-- fn_get_public_school_page: إرجاع الحقول الاجتماعية ضمن البيانات العامة
create or replace function public.fn_get_public_school_page(p_school_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school jsonb;
  v_posts jsonb;
begin
  select jsonb_build_object(
    'id', s.id,
    'name', s.name,
    'legal_name', s.legal_name,
    'logo_url', s.logo_url,
    'school_type', s.school_type,
    'tagline', s.tagline,
    'description', s.description,
    'address', s.address,
    'city', s.city,
    'region', s.region,
    'phone', s.phone,
    'email', s.email,
    'latitude', s.latitude,
    'longitude', s.longitude,
    'location_label', s.location_label,
    'facebook_url', s.facebook_url,
    'instagram_url', s.instagram_url,
    'tiktok_url', s.tiktok_url,
    'youtube_url', s.youtube_url,
    'whatsapp_number', s.whatsapp_number
  ) into v_school
  from public.schools s
  where s.id = p_school_id;

  if v_school is null then
    raise exception 'INVALID_SCHOOL';
  end if;

  select coalesce(jsonb_agg(jsonb_build_object(
    'id', sp.id,
    'title', sp.title,
    'body', sp.body,
    'image_url', sp.image_url,
    'kind', sp.kind,
    'published_at', sp.published_at
  ) order by sp.published_at desc), '[]'::jsonb)
  into v_posts
  from public.school_posts sp
  where sp.school_id = p_school_id
    and sp.is_published
    and sp.deleted_at is null;

  return jsonb_build_object('school', v_school, 'posts', v_posts);
end;
$$;

revoke all on function public.fn_get_public_school_page(uuid) from public;
grant execute on function public.fn_get_public_school_page(uuid) to anon, authenticated;

-- ============================================================================
-- END OF PHASE 78
-- ============================================================================
