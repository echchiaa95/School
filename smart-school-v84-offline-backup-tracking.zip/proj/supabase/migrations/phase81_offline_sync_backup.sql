-- ============================================================================
-- phase81_offline_sync_backup.sql
-- نفّذ هذا الملف مرة واحدة في Supabase SQL Editor (بعد phase80).
--
-- 1) fn_sync_gps_pings — مزامنة نقاط GPS المخزّنة محليًا أثناء انقطاع
--    الإنترنت (تُقبل ضمن نافذة الرحلة حتى لو انتهت الرحلة أثناء الانقطاع).
-- 2) fn_export_school_backup — تصدير كل بيانات المؤسسة كملف JSON.
-- 3) fn_import_school_backup — استرجاع النسخة (إدراج غير الموجود فقط،
--    مع فرض school_id الخاص بالمؤسسة — لا يمكن استيراد بيانات مؤسسة أخرى).
--
-- 100% إضافي: دوال جديدة فقط + GRANT.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1) مزامنة نقاط GPS المؤجّلة (وضع عدم الاتصال)
--    p_pings: [{"trip_id","latitude","longitude","accuracy","speed","heading","recorded_at"}]
-- ----------------------------------------------------------------------------
create or replace function public.fn_sync_gps_pings(p_pings jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_driver_id uuid;
  v_ping jsonb;
  v_trip bus_trips%rowtype;
  v_recorded timestamptz;
  v_lat double precision;
  v_lng double precision;
  v_inserted int := 0;
  v_rejected int := 0;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select d.id into v_driver_id from drivers d
  where d.profile_id = auth.uid() and d.deleted_at is null limit 1;
  if v_driver_id is null then raise exception 'NOT_A_DRIVER'; end if;

  if p_pings is null or jsonb_typeof(p_pings) <> 'array' then
    raise exception 'INVALID_PAYLOAD';
  end if;

  for v_ping in select * from jsonb_array_elements(p_pings)
  loop
    begin
      select * into v_trip from bus_trips where id = (v_ping->>'trip_id')::uuid;
      if v_trip.id is null or v_trip.driver_id <> v_driver_id then
        v_rejected := v_rejected + 1; continue;
      end if;

      v_lat := (v_ping->>'latitude')::double precision;
      v_lng := (v_ping->>'longitude')::double precision;
      if v_lat is null or v_lng is null
         or v_lat < -90 or v_lat > 90 or v_lng < -180 or v_lng > 180 then
        v_rejected := v_rejected + 1; continue;
      end if;

      v_recorded := coalesce(nullif(v_ping->>'recorded_at', '')::timestamptz, now());

      -- نافذة القبول: من بداية الرحلة (بهامش 10 دقائق) حتى نهايتها + 6 ساعات
      -- سماحية (رحلة انتهت أثناء انقطاع الاتصال ما تزال نقاطها صالحة).
      if v_trip.starts_at is not null
         and (v_recorded < v_trip.starts_at - interval '10 minutes'
              or v_recorded > coalesce(v_trip.ends_at, now()) + interval '6 hours') then
        v_rejected := v_rejected + 1; continue;
      end if;

      insert into bus_trip_locations
        (trip_id, driver_id, bus_id, school_id, latitude, longitude, accuracy, speed, heading, recorded_at)
      values
        (v_trip.id, v_driver_id, v_trip.bus_id, v_trip.school_id, v_lat, v_lng,
         nullif(v_ping->>'accuracy','')::double precision,
         nullif(v_ping->>'speed','')::double precision,
         nullif(v_ping->>'heading','')::double precision,
         v_recorded);

      -- آخر موقع معروف: لا نرجع بالساعة إلى الوراء
      insert into bus_last_locations
        (bus_id, trip_id, driver_id, school_id, latitude, longitude, accuracy, speed, heading, recorded_at)
      values
        (v_trip.bus_id, v_trip.id, v_driver_id, v_trip.school_id, v_lat, v_lng,
         nullif(v_ping->>'accuracy','')::double precision,
         nullif(v_ping->>'speed','')::double precision,
         nullif(v_ping->>'heading','')::double precision,
         v_recorded)
      on conflict (bus_id) do update
        set trip_id = excluded.trip_id, driver_id = excluded.driver_id,
            latitude = excluded.latitude, longitude = excluded.longitude,
            accuracy = excluded.accuracy, speed = excluded.speed,
            heading = excluded.heading, recorded_at = excluded.recorded_at
        where excluded.recorded_at > bus_last_locations.recorded_at;

      v_inserted := v_inserted + 1;
    exception when others then
      v_rejected := v_rejected + 1;
    end;
  end loop;

  return jsonb_build_object('inserted', v_inserted, 'rejected', v_rejected);
end;
$$;

revoke all on function public.fn_sync_gps_pings(jsonb) from public;
grant execute on function public.fn_sync_gps_pings(jsonb) to authenticated;

-- ----------------------------------------------------------------------------
-- 1ب) fn_get_map_overview — إضافة heading (سهم اتجاه الحافلة على الخريطة)
-- ----------------------------------------------------------------------------
create or replace function fn_get_map_overview(p_school_id uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_school_id uuid;
  v_super boolean;
  v_result jsonb;
begin
  select exists (select 1 from user_roles where profile_id = auth.uid() and role = 'superadmin')
    into v_super;
  if v_super then
    if p_school_id is null then raise exception 'SCHOOL_REQUIRED'; end if;
    if not exists (select 1 from schools where id = p_school_id) then
      raise exception 'SCHOOL_NOT_FOUND';
    end if;
    v_school_id := p_school_id;
  else
    select ur.school_id into v_school_id from user_roles ur
    where ur.profile_id = auth.uid() and ur.role in ('admin', 'director') limit 1;
    if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;
  end if;

  select jsonb_build_object(
    'school', (
      select jsonb_build_object('name', s.name, 'latitude', s.latitude,
               'longitude', s.longitude, 'location_label', s.location_label)
      from schools s where s.id = v_school_id),
    'homes', coalesce((
      select jsonb_agg(jsonb_build_object(
               'student_id', st.id, 'full_name', st.full_name, 'class_name', cls.name,
               'latitude', st.latitude, 'longitude', st.longitude,
               'location_label', st.location_label) order by st.full_name)
      from students st
      left join student_enrollments se on se.student_id = st.id and se.status = 'ACTIVE'
      left join classes cls on cls.id = se.class_id
      where st.school_id = v_school_id and st.deleted_at is null
        and st.latitude is not null and st.longitude is not null
      limit 1500), '[]'::jsonb),
    'buses', coalesce((
      select jsonb_agg(jsonb_build_object(
               'bus_id', b.id, 'bus_code', b.code, 'bus_plate', b.plate_number,
               'driver_name', prof.full_name, 'has_active_trip', t.id is not null,
               'trip_id', t.id,
               'direction', case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup'
                                 when t.direction = 'TO_HOME'::trip_direction then 'dropoff' else null end,
               'latitude', coalesce(ll_trip.latitude, ll_last.latitude),
               'longitude', coalesce(ll_trip.longitude, ll_last.longitude),
               'speed', coalesce(ll_trip.speed, ll_last.speed),
               'heading', coalesce(ll_trip.heading, ll_last.heading),
               'recorded_at', coalesce(ll_trip.recorded_at, ll_last.recorded_at),
               'live', ll_trip.recorded_at is not null,
               'total_students', case when t.id is not null then
                 (select count(*) from student_transport_assignments sta
                   where sta.bus_id = b.id and sta.is_active)::int else null end,
               'boarded_count', case when t.id is not null then
                 (select count(*) from bus_trip_students bts
                   where bts.trip_id = t.id and bts.boarded_at is not null)::int else null end,
               'dropped_count', case when t.id is not null then
                 (select count(*) from bus_trip_students bts
                   where bts.trip_id = t.id and bts.dropped_at is not null)::int else null end
             ) order by b.code)
      from buses b
      left join bus_trips t on t.bus_id = b.id and t.status = 'ACTIVE'::trip_status
      left join bus_last_locations ll_trip on ll_trip.bus_id = b.id and ll_trip.trip_id = t.id
      left join lateral (
        select ll.latitude, ll.longitude, ll.recorded_at, ll.speed, ll.heading
        from bus_last_locations ll
        where ll.bus_id = b.id order by ll.recorded_at desc limit 1
      ) ll_last on t.id is null
      left join drivers d on d.id = coalesce(t.driver_id, b.driver_id)
      left join profiles prof on prof.id = d.profile_id
      where b.school_id = v_school_id), '[]'::jsonb),
    'stops', coalesce((
      select jsonb_agg(jsonb_build_object(
               'stop_id', bs.id, 'name', bs.name, 'latitude', bs.latitude,
               'longitude', bs.longitude, 'route_name', br.name)
             order by br.name, rs.sequence_order)
      from bus_route_stops rs
      join bus_stops bs on bs.id = rs.stop_id
      join bus_routes br on br.id = rs.route_id
      where br.school_id = v_school_id
        and bs.latitude is not null and bs.longitude is not null), '[]'::jsonb)
  ) into v_result;
  return v_result;
end; $$;
revoke all on function fn_get_map_overview(uuid) from public;
grant execute on function fn_get_map_overview(uuid) to authenticated;

-- ----------------------------------------------------------------------------
-- 2) تصدير نسخة احتياطية كاملة لبيانات المؤسسة (JSON)
-- ----------------------------------------------------------------------------
create or replace function public.fn_export_school_backup(p_school_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_tables text[] := array[
    'academic_years','classes','students','student_enrollments',
    'subjects','school_period_configs','timetables','timetable_entries',
    'buses','bus_routes','bus_stops','bus_route_stops','student_transport_assignments',
    'attendance_records','student_grades','payments',
    'expense_categories','expenses','incidents','guard_checks','staff_attendance',
    'notifications','school_posts',
    'bus_trips','bus_trip_students','bus_trip_locations','bus_last_locations',
    'school_student_number_counters'
  ];
  v_t text;
  v_rows jsonb;
  v_data jsonb := '{}'::jsonb;
  v_has_school boolean;
  v_has_deleted boolean;
begin
  -- تحديد المؤسسة والصلاحية
  if fn_is_superadmin() and p_school_id is not null then
    v_school_id := p_school_id;
  else
    select ur.school_id into v_school_id from user_roles ur
    where ur.profile_id = auth.uid() and ur.role in ('admin','director') limit 1;
  end if;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  foreach v_t in array v_tables loop
    if to_regclass('public.' || v_t) is null then continue; end if;

    select exists (select 1 from information_schema.columns
                   where table_schema='public' and table_name=v_t and column_name='school_id')
      into v_has_school;
    if not v_has_school then continue; end if;

    select exists (select 1 from information_schema.columns
                   where table_schema='public' and table_name=v_t and column_name='deleted_at')
      into v_has_deleted;

    execute format(
      'select coalesce(jsonb_agg(to_jsonb(t)), ''[]''::jsonb) from public.%I t
       where t.school_id = $1' || case when v_has_deleted then ' and t.deleted_at is null' else '' end,
      v_t)
      into v_rows using v_school_id;

    v_data := v_data || jsonb_build_object(v_t, v_rows);
  end loop;

  perform fn_safe_audit(v_school_id, 'EXPORT_BACKUP', 'schools', v_school_id, null, null);

  return jsonb_build_object(
    'app', 'smart-school',
    'backup_version', 1,
    'exported_at', now(),
    'school_id', v_school_id,
    'school', (select to_jsonb(s) from schools s where s.id = v_school_id),
    'tables', v_data
  );
end;
$$;

revoke all on function public.fn_export_school_backup(uuid) from public;
grant execute on function public.fn_export_school_backup(uuid) to authenticated;

-- ----------------------------------------------------------------------------
-- 3) استرجاع النسخة الاحتياطية — إدراج الصفوف غير الموجودة فقط
--    (on conflict do nothing: لا يمسّ البيانات الحالية أبدًا)
--    school_id يُفرض من حساب المستخدِم — لا يمكن استيراد بيانات مؤسسة أخرى.
-- ----------------------------------------------------------------------------
create or replace function public.fn_import_school_backup(p_data jsonb, p_school_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_order text[] := array[
    'academic_years','subjects','classes','students','student_enrollments',
    'school_period_configs','buses','bus_routes','bus_stops','bus_route_stops',
    'student_transport_assignments','timetables','timetable_entries',
    'expense_categories','payments','expenses','school_posts','notifications',
    'attendance_records','student_grades','incidents','guard_checks','staff_attendance',
    'bus_trips','bus_trip_students','bus_trip_locations','bus_last_locations',
    'school_student_number_counters'
  ];
  v_t text;
  v_rows jsonb;
  v_src jsonb;
  v_inserted int;
  v_results jsonb := '{}'::jsonb;
begin
  if fn_is_superadmin() and p_school_id is not null then
    v_school_id := p_school_id;
  else
    select ur.school_id into v_school_id from user_roles ur
    where ur.profile_id = auth.uid() and ur.role in ('admin','director') limit 1;
  end if;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  if p_data is null or jsonb_typeof(p_data) <> 'object' then
    raise exception 'INVALID_BACKUP_FILE';
  end if;
  if coalesce(p_data->>'app', '') <> 'smart-school' then
    raise exception 'INVALID_BACKUP_FILE';
  end if;

  v_src := coalesce(p_data->'tables', p_data);

  foreach v_t in array v_order loop
    v_rows := v_src -> v_t;
    if v_rows is null or jsonb_typeof(v_rows) <> 'array' then continue; end if;
    if to_regclass('public.' || v_t) is null then continue; end if;

    -- فرض school_id على كل صف — حماية من الاستيراد العابر للمؤسسات
    select coalesce(jsonb_agg(r || jsonb_build_object('school_id', v_school_id::text)), '[]'::jsonb)
      into v_rows from jsonb_array_elements(v_rows) r;

    begin
      execute format(
        'insert into public.%I select * from jsonb_populate_recordset(null::public.%I, $1)
         on conflict do nothing', v_t, v_t)
        using v_rows;
      get diagnostics v_inserted = row_count;
      v_results := v_results || jsonb_build_object(v_t, v_inserted);
    exception when others then
      v_results := v_results || jsonb_build_object(v_t, 'خطأ: ' || left(SQLERRM, 120));
    end;
  end loop;

  perform fn_safe_audit(v_school_id, 'IMPORT_BACKUP', 'schools', v_school_id, null,
                        jsonb_build_object('tables', v_results));

  return jsonb_build_object('ok', true, 'results', v_results);
end;
$$;

revoke all on function public.fn_import_school_backup(jsonb, uuid) from public;
grant execute on function public.fn_import_school_backup(jsonb, uuid) to authenticated;

-- ============================================================================
-- END OF PHASE 81
-- ============================================================================
