-- ============================================================================
-- phase77_school_website.sql
-- نفّذ هذا الملف مرة واحدة في Supabase SQL Editor (بعد phase76).
--
-- موقع المؤسسة العام (صفحة هبوط خاصة بكل مؤسسة):
-- 1) schools.description — نبذة عامة تظهر في الموقع (تُضاف لقائمة fn_update_school).
-- 2) school_posts — إعلانات وتدوينات المؤسسة (لا وصول مباشر؛ RPC فقط).
-- 3) fn_get_public_school_page — بيانات الموقع العامة (متاحة لـ anon بدون تسجيل).
-- 4) fn_list_school_posts / fn_save_school_post / fn_delete_school_post — إدارة
--    المحتوى (مدير المؤسسة/المدير/المدير العام فقط).
--
-- الرابط العام يُولَّد تلقائيًا: school.html?id=<school_id>
-- 100% إضافي: جدول جديد + ADD COLUMN IF NOT EXISTS + CREATE OR REPLACE فقط.
-- ============================================================================

-- ═══════════════════ 1) نبذة المؤسسة العامة ═══════════════════

alter table public.schools add column if not exists description text;

-- إعادة إنشاء fn_update_school بنفس التوقيع مع إضافة description للقائمة البيضاء
create or replace function public.fn_update_school(p_school_id uuid, p_data jsonb)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not fn_is_school_staff(p_school_id) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if not exists (select 1 from schools where id = p_school_id) then
    raise exception 'INVALID_SCHOOL';
  end if;

  update schools set
    name          = coalesce(nullif(trim(coalesce(p_data->>'name', '')), ''), name),
    legal_name    = case when p_data ? 'legal_name'    then nullif(trim(p_data->>'legal_name'), '')    else legal_name end,
    logo_url      = case when p_data ? 'logo_url'      then nullif(trim(p_data->>'logo_url'), '')      else logo_url end,
    address       = case when p_data ? 'address'       then nullif(trim(p_data->>'address'), '')       else address end,
    city          = case when p_data ? 'city'          then nullif(trim(p_data->>'city'), '')          else city end,
    region        = case when p_data ? 'region'        then nullif(trim(p_data->>'region'), '')        else region end,
    phone         = case when p_data ? 'phone'         then nullif(trim(p_data->>'phone'), '')         else phone end,
    email         = case when p_data ? 'email'         then nullif(trim(p_data->>'email'), '')         else email end,
    website       = case when p_data ? 'website'       then nullif(trim(p_data->>'website'), '')       else website end,
    director_name = case when p_data ? 'director_name' then nullif(trim(p_data->>'director_name'), '') else director_name end,
    school_type   = case when p_data ? 'school_type'   then nullif(trim(p_data->>'school_type'), '')   else school_type end,
    ice           = case when p_data ? 'ice'           then nullif(trim(p_data->>'ice'), '')           else ice end,
    notes         = case when p_data ? 'notes'         then nullif(trim(p_data->>'notes'), '')         else notes end,
    description   = case when p_data ? 'description'   then nullif(trim(p_data->>'description'), '')   else description end
  where id = p_school_id;

  perform fn_safe_audit(p_school_id, 'UPDATE_SCHOOL', 'schools', p_school_id, null, p_data);
end;
$$;

revoke all on function public.fn_update_school(uuid, jsonb) from public;
grant execute on function public.fn_update_school(uuid, jsonb) to authenticated;

-- ═══════════════════ 2) جدول منشورات الموقع ═══════════════════

create table if not exists public.school_posts (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  title text not null,
  body text,
  image_url text,
  kind text not null default 'post'
    check (kind in ('announcement', 'post')),
  is_published boolean not null default true,
  published_at timestamptz not null default now(),
  created_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create index if not exists idx_school_posts_school
  on public.school_posts (school_id, is_published, published_at desc);

-- RLS مفعَّل بلا أي سياسة: لا وصول مباشر من العملاء إطلاقًا — القراءة العامة
-- والإدارة تمرّان حصريًا عبر دوال SECURITY DEFINER أدناه.
alter table public.school_posts enable row level security;

-- ═══════════════════ 3) البيانات العامة للموقع ═══════════════════
-- متاحة للزائر بدون تسجيل (anon) — تُرجع فقط الحقول العامة الآمنة
-- (لا notes ولا ice ولا أي بيانات داخلية) + المنشورات المنشورة فقط.
create or replace function public.fn_get_public_school_page(p_school_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school jsonb;
  v_posts jsonb;
begin
  select jsonb_build_object(
    'id', s.id,
    'name', s.name,
    'legal_name', s.legal_name,
    'logo_url', s.logo_url,
    'school_type', s.school_type,
    'description', s.description,
    'address', s.address,
    'city', s.city,
    'region', s.region,
    'phone', s.phone,
    'email', s.email,
    'latitude', s.latitude,
    'longitude', s.longitude,
    'location_label', s.location_label
  ) into v_school
  from public.schools s
  where s.id = p_school_id;

  if v_school is null then
    raise exception 'INVALID_SCHOOL';
  end if;

  select coalesce(jsonb_agg(jsonb_build_object(
    'id', sp.id,
    'title', sp.title,
    'body', sp.body,
    'image_url', sp.image_url,
    'kind', sp.kind,
    'published_at', sp.published_at
  ) order by sp.published_at desc), '[]'::jsonb)
  into v_posts
  from public.school_posts sp
  where sp.school_id = p_school_id
    and sp.is_published
    and sp.deleted_at is null;

  return jsonb_build_object('school', v_school, 'posts', v_posts);
end;
$$;

revoke all on function public.fn_get_public_school_page(uuid) from public;
grant execute on function public.fn_get_public_school_page(uuid) to anon, authenticated;

-- ═══════════════════ 4) إدارة المحتوى (المدير فقط) ═══════════════════

-- قائمة كل المنشورات (بما فيها غير المنشورة) للوحة الإدارة
create or replace function public.fn_list_school_posts(p_school_id uuid)
returns table (
  id uuid,
  title text,
  body text,
  image_url text,
  kind text,
  is_published boolean,
  published_at timestamptz,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
begin
  if not (
    public.fn_resolve_my_role(p_school_id) in ('admin', 'director')
    or public.fn_is_superadmin()
  ) then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select sp.id, sp.title, sp.body, sp.image_url, sp.kind,
         sp.is_published, sp.published_at, sp.created_at
  from public.school_posts sp
  where sp.school_id = p_school_id
    and sp.deleted_at is null
  order by sp.created_at desc;
end;
$$;

grant execute on function public.fn_list_school_posts(uuid) to authenticated;

-- إنشاء/تعديل منشور (p_post_id = null → إنشاء جديد)
create or replace function public.fn_save_school_post(
  p_post_id uuid,
  p_title text,
  p_body text default null,
  p_image_url text default null,
  p_kind text default 'post',
  p_is_published boolean default true
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_id uuid;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  if p_title is null or btrim(p_title) = '' then
    raise exception 'TITLE_REQUIRED';
  end if;
  if p_kind not in ('announcement', 'post') then
    raise exception 'INVALID_KIND';
  end if;

  if p_post_id is null then
    v_school_id := public.fn_my_primary_school();
    if v_school_id is null then
      raise exception 'NO_SCHOOL_CONTEXT';
    end if;
  else
    select sp.school_id into v_school_id
    from public.school_posts sp
    where sp.id = p_post_id and sp.deleted_at is null;
    if v_school_id is null then
      raise exception 'POST_NOT_FOUND';
    end if;
  end if;

  if not (
    public.fn_resolve_my_role(v_school_id) in ('admin', 'director')
    or public.fn_is_superadmin()
  ) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if p_post_id is null then
    insert into public.school_posts
      (school_id, title, body, image_url, kind, is_published, published_at, created_by)
    values (
      v_school_id, btrim(p_title), nullif(btrim(coalesce(p_body, '')), ''),
      nullif(btrim(coalesce(p_image_url, '')), ''),
      p_kind, coalesce(p_is_published, true), now(), auth.uid()
    )
    returning id into v_id;
  else
    update public.school_posts set
      title = btrim(p_title),
      body = nullif(btrim(coalesce(p_body, '')), ''),
      image_url = nullif(btrim(coalesce(p_image_url, '')), ''),
      kind = p_kind,
      is_published = coalesce(p_is_published, true),
      published_at = case when coalesce(p_is_published, true) and not is_published
                          then now() else published_at end,
      updated_at = now()
    where id = p_post_id
    returning id into v_id;
  end if;

  perform public.fn_safe_audit(
    v_school_id,
    case when p_post_id is null then 'SCHOOL_POST_CREATED' else 'SCHOOL_POST_UPDATED' end,
    'school_posts', v_id, null,
    jsonb_build_object('title', btrim(p_title), 'kind', p_kind, 'is_published', p_is_published)
  );

  return v_id;
end;
$$;

grant execute on function public.fn_save_school_post(uuid, text, text, text, text, boolean) to authenticated;

-- حذف منشور (حذف ناعم)
create or replace function public.fn_delete_school_post(p_post_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select sp.school_id into v_school_id
  from public.school_posts sp
  where sp.id = p_post_id and sp.deleted_at is null;
  if v_school_id is null then
    raise exception 'POST_NOT_FOUND';
  end if;
  if not (
    public.fn_resolve_my_role(v_school_id) in ('admin', 'director')
    or public.fn_is_superadmin()
  ) then
    raise exception 'PERMISSION_DENIED';
  end if;

  update public.school_posts set deleted_at = now(), updated_at = now()
  where id = p_post_id;

  perform public.fn_safe_audit(
    v_school_id, 'SCHOOL_POST_DELETED', 'school_posts', p_post_id, null, null
  );
end;
$$;

grant execute on function public.fn_delete_school_post(uuid) to authenticated;

-- ============================================================================
-- END OF PHASE 77
-- ============================================================================
