-- ============================================================================
-- Phase 74 — join_requests: طلبات انضمام المؤسسات من صفحة الهبوط (landing.html)
-- نفّذ هذا الملف مرة واحدة في Supabase SQL Editor.
--
-- الأمان: أي زائر (حتى بدون حساب) يستطيع الإدراج فقط (INSERT) — لا قراءة ولا
-- تعديل ولا حذف من الواجهة العمومية. الاطلاع على الطلبات يتم من لوحة Supabase
-- (Table Editor) أو بدور superadmin.
-- ============================================================================

create table if not exists public.join_requests (
  id             uuid primary key default gen_random_uuid(),
  school_name    text not null,
  city           text not null,
  contact_name   text not null,
  phone          text not null,
  email          text,
  students_count text,
  message        text,
  status         text not null default 'NEW' check (status in ('NEW','CONTACTED','ACCEPTED','REJECTED')),
  created_at     timestamptz not null default now()
);

alter table public.join_requests enable row level security;

-- الزائر العمومي (anon) والمستخدم المسجَّل: إدراج فقط، بدون أي قراءة.
drop policy if exists join_requests_public_insert on public.join_requests;
create policy join_requests_public_insert
  on public.join_requests for insert
  to anon, authenticated
  with check (true);

-- قراءة/تدبير الطلبات للـ superadmin فقط (إن وُجدت الدالة).
do $$
begin
  if exists (select 1 from pg_proc where proname = 'is_superadmin') then
    execute $p$
      drop policy if exists join_requests_superadmin_all on public.join_requests;
      create policy join_requests_superadmin_all
        on public.join_requests for all
        to authenticated
        using (public.is_superadmin())
        with check (public.is_superadmin());
    $p$;
  end if;
end $$;

comment on table public.join_requests is 'طلبات انضمام المؤسسات الواردة من صفحة الهبوط';
