# Smart School Platform

نظام إدارة مدرسي ذكي.

## الإصلاحات في هذه النسخة (v59)
- إصلاح عرض الأقسام في كشوف النتائج لحساب مدير المؤسسة
- phase57: دالة fn_report_classes تعمل مع المدير عبر schools/staff/user_profiles
- grades-report.html: معالجة الأخطاء وعرض سبب الخطأ الحقيقي

## إضافة جديدة (Phase 59) — حضور الموظفين
- **يجب تنفيذ** `supabase/migrations/phase59_staff_attendance.sql` في Supabase SQL Editor قبل استعمال هذه الميزة.
- بعد التنفيذ: في لوحة المدير ← الحضور ← اختر "👥 الموظفون (حضور الطاقم)" من قائمة القسم.
- التفاصيل الكاملة في `phase59-summary.md`.
