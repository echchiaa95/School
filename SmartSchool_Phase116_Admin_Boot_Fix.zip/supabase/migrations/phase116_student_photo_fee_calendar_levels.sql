-- Phase 116: Student photo RPC + level-aware fee plans + student annual fee calendar.
-- Additive migration. Keeps existing fee-plan and ledger records.

-- 1) Student photo RPC: exact parameter names used by modules/school.js.
CREATE OR REPLACE FUNCTION public.fn_update_student_photo(
  p_student_id uuid,
  p_photo_url text
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_id uuid;
  v_role text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  IF p_student_id IS NULL THEN RAISE EXCEPTION 'INVALID_STUDENT'; END IF;

  SELECT s.school_id INTO v_school_id
  FROM public.students s
  WHERE s.id = p_student_id AND s.deleted_at IS NULL;
  IF v_school_id IS NULL THEN RAISE EXCEPTION 'INVALID_STUDENT'; END IF;

  v_role := public.fn_resolve_my_role(v_school_id);
  IF NOT (
    v_role = 'admin'
    OR public.fn_has_permission('students.photo.manage', v_school_id)
    OR public.fn_is_school_staff(v_school_id)
  ) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  IF p_photo_url IS NOT NULL AND (
    length(trim(p_photo_url)) = 0
    OR p_photo_url NOT LIKE '%/storage/v1/object/public/student-photos/%'
  ) THEN
    RAISE EXCEPTION 'INVALID_STUDENT_PHOTO_URL';
  END IF;

  UPDATE public.students
  SET photo_url = NULLIF(trim(p_photo_url), ''), updated_at = now()
  WHERE id = p_student_id AND school_id = v_school_id;

  PERFORM public.fn_safe_audit(
    v_school_id, 'STUDENT_PHOTO_UPDATED', 'students', p_student_id,
    NULL, jsonb_build_object('photo_url', p_photo_url, 'updated_by', auth.uid())
  );
END;
$$;
REVOKE ALL ON FUNCTION public.fn_update_student_photo(uuid,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_update_student_photo(uuid,text) TO authenticated;

-- 2) Empty levels array means the fee applies to every level.
ALTER TABLE public.school_fee_plans
  ADD COLUMN IF NOT EXISTS levels text[] NOT NULL DEFAULT '{}'::text[];

CREATE OR REPLACE FUNCTION public.fn_school_fee_plans_v2()
RETURNS TABLE(
  id uuid, fee_type text, price numeric, billing_period text,
  effective_from date, effective_to date, is_active boolean, levels text[]
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_school uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  v_school := public.fn_my_primary_school();
  IF v_school IS NULL OR NOT (
    public.fn_is_school_staff(v_school) OR public.fn_has_permission('finance.view',v_school)
    OR public.fn_has_permission('finance.manage',v_school)
  ) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;

  RETURN QUERY
  SELECT p.id,p.fee_type,p.price,p.billing_period,p.effective_from,
         p.effective_to,p.is_active,COALESCE(p.levels,'{}'::text[])
  FROM public.school_fee_plans p
  WHERE p.school_id=v_school
  ORDER BY p.fee_type,p.effective_from DESC;
END;
$$;

CREATE OR REPLACE FUNCTION public.fn_school_fee_plan_upsert_v2(
  p_fee_type text,
  p_price numeric,
  p_billing_period text DEFAULT 'monthly',
  p_effective_from date DEFAULT current_date,
  p_effective_to date DEFAULT NULL,
  p_is_active boolean DEFAULT true,
  p_levels text[] DEFAULT '{}'::text[]
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_school uuid; v_id uuid; v_levels text[];
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  v_school := public.fn_my_primary_school();
  IF v_school IS NULL OR NOT (
    public.fn_is_school_staff(v_school) OR public.fn_has_permission('finance.manage',v_school)
  ) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  IF p_fee_type NOT IN ('واجب التمدرس','واجب النقل','واجب التسجيل') THEN RAISE EXCEPTION 'INVALID_FEE_TYPE'; END IF;
  IF p_price IS NULL OR p_price < 0 THEN RAISE EXCEPTION 'INVALID_FEE_PRICE'; END IF;
  IF p_billing_period NOT IN ('monthly','annual','one_time') THEN RAISE EXCEPTION 'INVALID_BILLING_PERIOD'; END IF;
  IF p_effective_to IS NOT NULL AND p_effective_to < COALESCE(p_effective_from,current_date) THEN RAISE EXCEPTION 'INVALID_EFFECTIVE_PERIOD'; END IF;

  SELECT COALESCE(array_agg(DISTINCT btrim(x) ORDER BY btrim(x)), '{}'::text[])
  INTO v_levels
  FROM unnest(COALESCE(p_levels,'{}'::text[])) AS x
  WHERE btrim(x) <> '';

  IF cardinality(v_levels) > 0 AND EXISTS (
    SELECT 1 FROM unnest(v_levels) l
    WHERE NOT EXISTS (
      SELECT 1 FROM public.classes c
      WHERE c.school_id=v_school AND lower(btrim(c.level))=lower(btrim(l))
    )
  ) THEN RAISE EXCEPTION 'INVALID_FEE_LEVEL'; END IF;

  -- Preserve historical plans; close only overlapping plans with the same fee and exact level scope.
  UPDATE public.school_fee_plans p
  SET is_active=false, updated_at=now()
  WHERE p.school_id=v_school AND p.fee_type=p_fee_type AND p.is_active
    AND COALESCE(p.levels,'{}'::text[])=v_levels
    AND p.effective_from <= COALESCE(p_effective_from,current_date)
    AND (p.effective_to IS NULL OR p.effective_to >= COALESCE(p_effective_from,current_date));

  INSERT INTO public.school_fee_plans(
    school_id,fee_type,price,billing_period,effective_from,effective_to,is_active,created_by,levels
  ) VALUES (
    v_school,p_fee_type,p_price,p_billing_period,COALESCE(p_effective_from,current_date),
    p_effective_to,COALESCE(p_is_active,true),auth.uid(),v_levels
  ) RETURNING id INTO v_id;

  PERFORM public.fn_safe_audit(v_school,'FEE_PLAN_CREATED','school_fee_plans',v_id,NULL,
    jsonb_build_object('fee_type',p_fee_type,'price',p_price,'billing_period',p_billing_period,'levels',v_levels));
  RETURN v_id;
END;
$$;

-- 3) Level-aware obligation generation. Existing obligations are never duplicated.
CREATE OR REPLACE FUNCTION public.fn_generate_student_fee_obligations(
  p_student_id uuid, p_academic_year_id uuid
) RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public
AS $$
DECLARE
  v_school uuid; v_transport boolean; v_year_start date; v_year_end date; v_enrolled date;
  v_level text; v_plan record; v_month date; v_start date; v_end date; v_key text;
  v_disc uuid; v_kind text; v_value numeric; v_discount numeric; v_due numeric;
  v_count integer:=0;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  SELECT school_id,uses_transport INTO v_school,v_transport
  FROM public.students WHERE id=p_student_id AND deleted_at IS NULL;
  IF v_school IS NULL THEN RAISE EXCEPTION 'INVALID_STUDENT'; END IF;
  IF NOT (public.fn_is_school_staff(v_school) OR public.fn_has_permission('finance.manage',v_school)
          OR public.fn_has_permission('finance.view',v_school)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  SELECT starts_on,ends_on INTO v_year_start,v_year_end
  FROM public.academic_years WHERE id=p_academic_year_id AND school_id=v_school;
  IF v_year_start IS NULL OR v_year_end IS NULL THEN RAISE EXCEPTION 'INVALID_ACADEMIC_YEAR'; END IF;
  SELECT min(se.enrolled_on),c.level INTO v_enrolled,v_level
  FROM public.student_enrollments se JOIN public.classes c ON c.id=se.class_id
  WHERE se.student_id=p_student_id AND se.school_id=v_school
    AND se.academic_year_id=p_academic_year_id AND se.status='ACTIVE'
  GROUP BY c.level ORDER BY min(se.enrolled_on) LIMIT 1;
  IF v_enrolled IS NULL THEN RAISE EXCEPTION 'ACTIVE_ENROLLMENT_REQUIRED'; END IF;

  FOR v_plan IN
    SELECT p.* FROM public.school_fee_plans p
    WHERE p.school_id=v_school AND p.is_active
      AND p.effective_from<=v_year_end
      AND COALESCE(p.effective_to,v_year_end)>=GREATEST(v_year_start,v_enrolled)
      AND (cardinality(COALESCE(p.levels,'{}'::text[]))=0 OR v_level=ANY(p.levels))
    ORDER BY p.effective_from
  LOOP
    IF v_plan.fee_type='واجب النقل' AND NOT v_transport THEN CONTINUE; END IF;
    IF v_plan.billing_period='monthly' AND v_plan.fee_type IN ('واجب التمدرس','واجب النقل') THEN
      v_month:=date_trunc('month',GREATEST(v_year_start,v_enrolled))::date;
      WHILE v_month<=v_year_end LOOP
        v_start:=GREATEST(v_month,v_year_start,v_enrolled,v_plan.effective_from);
        v_end:=LEAST((v_month+interval '1 month - 1 day')::date,v_year_end,COALESCE(v_plan.effective_to,v_year_end));
        IF v_start<=v_end THEN
          v_key:=to_char(v_month,'YYYY-MM'); v_disc:=NULL; v_kind:=NULL; v_value:=NULL;
          SELECT id,discount_kind,discount_value INTO v_disc,v_kind,v_value
          FROM public.student_fee_discounts
          WHERE school_id=v_school AND student_id=p_student_id AND fee_type=v_plan.fee_type AND is_active
            AND effective_from<=v_end AND COALESCE(effective_to,v_end)>=v_start
          ORDER BY effective_from DESC,created_at DESC LIMIT 1;
          v_discount:=CASE WHEN v_kind='percent' THEN round(v_plan.price*v_value/100,2)
                           WHEN v_kind='amount' THEN least(v_plan.price,v_value) ELSE 0 END;
          v_due:=greatest(0,v_plan.price-v_discount);
          INSERT INTO public.student_fee_obligations(
            school_id,student_id,academic_year_id,fee_type,period_key,period_start,period_end,
            list_amount,discount_amount,amount_due,discount_id,status
          ) VALUES (
            v_school,p_student_id,p_academic_year_id,v_plan.fee_type,v_key,v_start,v_end,
            v_plan.price,v_discount,v_due,v_disc,CASE WHEN v_due=0 THEN 'waived' ELSE 'unpaid' END
          ) ON CONFLICT(student_id,academic_year_id,fee_type,period_key) DO NOTHING;
          IF FOUND THEN v_count:=v_count+1; END IF;
        END IF;
        v_month:=(v_month+interval '1 month')::date;
      END LOOP;
    ELSIF v_plan.fee_type='واجب التسجيل' AND v_plan.billing_period IN ('annual','one_time') THEN
      v_key:=CASE WHEN v_plan.billing_period='one_time' THEN 'lifetime' ELSE 'annual' END;
      IF v_key='lifetime' AND EXISTS(
        SELECT 1 FROM public.student_fee_obligations
        WHERE student_id=p_student_id AND fee_type='واجب التسجيل' AND period_key='lifetime'
      ) THEN CONTINUE; END IF;
      v_disc:=NULL; v_kind:=NULL; v_value:=NULL;
      SELECT id,discount_kind,discount_value INTO v_disc,v_kind,v_value
      FROM public.student_fee_discounts
      WHERE school_id=v_school AND student_id=p_student_id AND fee_type='واجب التسجيل' AND is_active
        AND effective_from<=v_year_end AND COALESCE(effective_to,v_year_end)>=v_year_start
      ORDER BY effective_from DESC,created_at DESC LIMIT 1;
      v_discount:=CASE WHEN v_kind='percent' THEN round(v_plan.price*v_value/100,2)
                       WHEN v_kind='amount' THEN least(v_plan.price,v_value) ELSE 0 END;
      v_due:=greatest(0,v_plan.price-v_discount);
      INSERT INTO public.student_fee_obligations(
        school_id,student_id,academic_year_id,fee_type,period_key,period_start,period_end,
        list_amount,discount_amount,amount_due,discount_id,status
      ) VALUES (
        v_school,p_student_id,p_academic_year_id,'واجب التسجيل',v_key,v_year_start,v_year_end,
        v_plan.price,v_discount,v_due,v_disc,CASE WHEN v_due=0 THEN 'waived' ELSE 'unpaid' END
      ) ON CONFLICT(student_id,academic_year_id,fee_type,period_key) DO NOTHING;
      IF FOUND THEN v_count:=v_count+1; END IF;
    END IF;
  END LOOP;
  RETURN v_count;
END;
$$;

-- 4) Level-aware fee quote. A plan with no levels remains a school-wide default.
CREATE OR REPLACE FUNCTION public.fn_student_fee_quote_v2(
  p_student_id uuid, p_fee_type text, p_on_date date DEFAULT current_date
) RETURNS TABLE(
  list_price numeric, discount_amount numeric, final_amount numeric,
  discount_reason text, billing_period text, applicable_levels text[]
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_school uuid; v_level text; v_price numeric; v_period text;
        v_levels text[]; v_discount numeric:=0; v_reason text; v_kind text; v_value numeric;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  SELECT s.school_id INTO v_school FROM public.students s
  WHERE s.id=p_student_id AND s.deleted_at IS NULL;
  IF v_school IS NULL THEN RAISE EXCEPTION 'INVALID_STUDENT'; END IF;
  IF NOT (public.fn_is_school_staff(v_school) OR public.fn_has_permission('finance.view',v_school)
          OR public.fn_has_permission('finance.manage',v_school)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;

  SELECT c.level INTO v_level
  FROM public.student_enrollments se
  JOIN public.classes c ON c.id=se.class_id
  WHERE se.student_id=p_student_id AND se.school_id=v_school AND se.status='ACTIVE'
  ORDER BY se.created_at DESC LIMIT 1;

  SELECT p.price,p.billing_period,p.levels
  INTO v_price,v_period,v_levels
  FROM public.school_fee_plans p
  WHERE p.school_id=v_school AND p.fee_type=p_fee_type AND p.is_active
    AND p.effective_from<=COALESCE(p_on_date,current_date)
    AND (p.effective_to IS NULL OR p.effective_to>=COALESCE(p_on_date,current_date))
    AND (cardinality(COALESCE(p.levels,'{}'::text[]))=0 OR v_level=ANY(p.levels))
  ORDER BY CASE WHEN cardinality(COALESCE(p.levels,'{}'::text[]))=0 THEN 1 ELSE 0 END,
           p.effective_from DESC LIMIT 1;

  IF v_price IS NULL THEN
    RETURN QUERY SELECT 0::numeric,0::numeric,0::numeric,NULL::text,'monthly'::text,'{}'::text[];
    RETURN;
  END IF;

  SELECT d.discount_kind,d.discount_value,d.reason INTO v_kind,v_value,v_reason
  FROM public.student_fee_discounts d
  WHERE d.school_id=v_school AND d.student_id=p_student_id AND d.fee_type=p_fee_type AND d.is_active
    AND d.effective_from<=COALESCE(p_on_date,current_date)
    AND (d.effective_to IS NULL OR d.effective_to>=COALESCE(p_on_date,current_date))
  ORDER BY d.created_at DESC LIMIT 1;

  IF v_kind='amount' THEN v_discount:=LEAST(v_price,v_value);
  ELSIF v_kind='percent' THEN v_discount:=round(v_price*v_value/100,2); END IF;
  RETURN QUERY SELECT v_price,v_discount,GREATEST(0,v_price-v_discount),v_reason,
                      COALESCE(v_period,'monthly'),COALESCE(v_levels,'{}'::text[]);
END;
$$;

-- 5) Student fee calendar data, grouped by actual ledger obligations.
CREATE OR REPLACE FUNCTION public.fn_student_fee_calendar(p_student_id uuid)
RETURNS TABLE(
  obligation_id uuid, academic_year_id uuid, fee_type text, period_key text,
  period_start date, period_end date, list_amount numeric, discount_amount numeric,
  amount_due numeric, amount_paid numeric, remaining numeric, status text,
  paid_transactions jsonb
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_school uuid; v_year uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  SELECT s.school_id INTO v_school FROM public.students s
  WHERE s.id=p_student_id AND s.deleted_at IS NULL;
  IF v_school IS NULL THEN RAISE EXCEPTION 'INVALID_STUDENT'; END IF;
  IF NOT (public.fn_is_school_staff(v_school) OR public.fn_has_permission('finance.view',v_school)
          OR public.fn_has_permission('finance.manage',v_school)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  SELECT se.academic_year_id INTO v_year
  FROM public.student_enrollments se
  WHERE se.student_id=p_student_id AND se.school_id=v_school AND se.status='ACTIVE'
  ORDER BY se.created_at DESC LIMIT 1;

  RETURN QUERY
  SELECT o.id,o.academic_year_id,o.fee_type,o.period_key,o.period_start,o.period_end,
         o.list_amount,o.discount_amount,o.amount_due,o.amount_paid,
         GREATEST(0,o.amount_due-o.amount_paid),o.status,
         COALESCE((
           SELECT jsonb_agg(jsonb_build_object(
             'amount',a.amount,'paid_on',t.paid_on,'method',t.method,
             'receipt_no',t.receipt_no,'transaction_id',t.id
           ) ORDER BY t.paid_on)
           FROM public.student_fee_payment_allocations a
           JOIN public.student_fee_payment_transactions t ON t.id=a.transaction_id
           WHERE a.obligation_id=o.id
         ),'[]'::jsonb)
  FROM public.student_fee_obligations o
  WHERE o.student_id=p_student_id AND o.school_id=v_school
    AND (v_year IS NULL OR o.academic_year_id=v_year)
  ORDER BY o.period_start,o.fee_type;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_school_fee_plans_v2() FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.fn_school_fee_plan_upsert_v2(text,numeric,text,date,date,boolean,text[]) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.fn_student_fee_quote_v2(uuid,text,date) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.fn_student_fee_calendar(uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_school_fee_plans_v2() TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_school_fee_plan_upsert_v2(text,numeric,text,date,date,boolean,text[]) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_student_fee_quote_v2(uuid,text,date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_student_fee_calendar(uuid) TO authenticated;

NOTIFY pgrst, 'reload schema';


-- Reassert the expected one-folder object path: <school_uuid>/<student_uuid>.<ext>.
DROP POLICY IF EXISTS p_student_photos_staff_write ON storage.objects;
CREATE POLICY p_student_photos_staff_write ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (
  bucket_id='student-photos'
  AND COALESCE(array_length(storage.foldername(name),1),0)=1
  AND (storage.foldername(name))[1] ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  AND public.fn_is_school_staff(((storage.foldername(name))[1])::uuid)
  AND split_part(storage.filename(name),'.',1) ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  AND EXISTS (
    SELECT 1 FROM public.students s
    WHERE s.id::text=split_part(storage.filename(name),'.',1)
      AND s.school_id::text=(storage.foldername(name))[1]
      AND s.deleted_at IS NULL
  )
);

DROP POLICY IF EXISTS p_student_photos_staff_update ON storage.objects;
CREATE POLICY p_student_photos_staff_update ON storage.objects
FOR UPDATE TO authenticated
USING (
  bucket_id='student-photos'
  AND COALESCE(array_length(storage.foldername(name),1),0)=1
  AND (storage.foldername(name))[1] ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  AND public.fn_is_school_staff(((storage.foldername(name))[1])::uuid)
  AND EXISTS (
    SELECT 1 FROM public.students s
    WHERE s.id::text=split_part(storage.filename(name),'.',1)
      AND s.school_id::text=(storage.foldername(name))[1]
      AND s.deleted_at IS NULL
  )
)
WITH CHECK (
  bucket_id='student-photos'
  AND COALESCE(array_length(storage.foldername(name),1),0)=1
  AND (storage.foldername(name))[1] ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  AND public.fn_is_school_staff(((storage.foldername(name))[1])::uuid)
  AND EXISTS (
    SELECT 1 FROM public.students s
    WHERE s.id::text=split_part(storage.filename(name),'.',1)
      AND s.school_id::text=(storage.foldername(name))[1]
      AND s.deleted_at IS NULL
  )
);

NOTIFY pgrst, 'reload schema';
