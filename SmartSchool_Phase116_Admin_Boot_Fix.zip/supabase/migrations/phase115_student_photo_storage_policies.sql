-- Phase 115: Student photo Storage policy repair
-- Run in Supabase SQL Editor as project owner.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('student-photos', 'student-photos', true, 20971520,
        array['image/jpeg','image/png','image/webp'])
on conflict (id) do update
set public = true,
    file_size_limit = excluded.file_size_limit,
    allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists p_student_photos_public_read on storage.objects;
create policy p_student_photos_public_read
on storage.objects for select
using (bucket_id = 'student-photos');

drop policy if exists p_student_photos_staff_write on storage.objects;
create policy p_student_photos_staff_write
on storage.objects for insert to authenticated
with check (
  bucket_id = 'student-photos'
  and array_length(storage.foldername(name), 1) >= 2
  and public.fn_is_school_staff((storage.foldername(name))[1]::uuid)
  and exists (
    select 1 from public.students s
    where s.id = split_part(storage.filename(name), '.', 1)::uuid
      and s.school_id = (storage.foldername(name))[1]::uuid
      and s.deleted_at is null
  )
);

drop policy if exists p_student_photos_staff_update on storage.objects;
create policy p_student_photos_staff_update
on storage.objects for update to authenticated
using (
  bucket_id = 'student-photos'
  and public.fn_is_school_staff((storage.foldername(name))[1]::uuid)
)
with check (
  bucket_id = 'student-photos'
  and public.fn_is_school_staff((storage.foldername(name))[1]::uuid)
);
