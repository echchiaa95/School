# Phase 115 — Student module hotfix

- Replaced the discount form's lexical selection variable with `window.__pickedDiscountStudentId`; selection is cleared whenever the search text changes, preventing stale IDs and eliminating the reported ReferenceError when the current assets are deployed.
- Bumped the admin console module URL from `v=95.1` to `v=115.0` so browsers request the corrected module rather than reuse the old script URL.
- Added a browser `Image`/canvas fallback when `createImageBitmap` cannot decode a phone gallery image.
- Improved photo upload diagnostics for missing bucket, Storage RLS, size, decode, and RPC failures.
- Added an idempotent Storage policy migration for the `student-photos` bucket.
- Fixed age display for infants under one year (age 0 is no longer treated as missing).

## Deployment
1. Upload/replace the complete project contents, not only the ZIP file.
2. Run `supabase/migrations/phase115_student_photo_storage_policies.sql` in Supabase SQL Editor.
3. Open `admin.html` with a hard refresh; the module URL now uses `v=115.0`.
4. Test with an ordinary JPG/PNG photo and confirm a student discount selection.

## Validation
JavaScript syntax checks and ZIP integrity checks are performed for this package. A live Supabase upload cannot be verified without access to the project's authenticated database and Storage.

## Phase 116 — Photo RPC, fee calendar, and level-based fee plans
- Added `phase116_student_photo_fee_calendar_levels.sql` to publish the exact `fn_update_student_photo(p_student_id uuid, p_photo_url text)` RPC used by the browser client.
- Added level scope to fee plans. An empty level selection means all levels; one or more selected levels scope the plan to those classes.
- Added level-aware quote and obligation-generation RPCs while preserving existing obligations and payment history.
- Added a student annual fee calendar based on actual ledger obligations and allocated transactions, with paid / unpaid / partial / future states and month detail cards.
- Updated the admin module cache key to `v=116.0`.

## Phase 116 deployment
1. Run `supabase/migrations/phase116_student_photo_fee_calendar_levels.sql` in Supabase SQL Editor after Phase 115.
2. Deploy the complete project files to the GitHub repository.
3. Confirm `admin.html` references `modules/adminConsole.js?v=116.0`.
4. Test a student photo upload, create a fee plan for multiple levels, and inspect a student fee calendar.

Note: Existing fee obligations are intentionally not recalculated by this migration; this protects previously recorded payments. New obligations generated after the migration use the student's current class level.
