# Phase 114 — Student profile, photo upload, and discount picker fixes

## Frontend changes
- Fixed `pickedDiscountStudent` being swallowed by a literal `\\n` inside a JavaScript comment; discount selection now has a real initialized variable.
- Student roster now displays active class, academic level, and age when date of birth exists.
- Student detail calculates age from the date of birth and shows an institutional birthday greeting on the birthday.
- Parent child profile fetches the authorized student detail and displays age; on the child's birthday it shows a dismissible celebration dialog with a parent-facing message.
- Photo upload now resets file inputs after selection, handles supported original formats without mislabeling them as JPEG, and shows actionable Storage/RPC error details instead of a generic failure.

## Validation
- `node --check` passed for `adminConsole.js`, `students.js`, `photoUpload.js`, and `parentConsole.js`.
- Vite production build was not run because `node_modules` is not present in this archive/runtime.
- No live Supabase changes were applied. Existing Storage bucket and RLS policies remain prerequisites for photo upload; detailed errors are now surfaced to identify a missing bucket or permission.
