-- Phase 121: edit an existing fee plan in place from the Admin fee-plan editor.
-- Existing payment rows and fee-obligation snapshots are intentionally untouched.
CREATE OR REPLACE FUNCTION public.fn_school_fee_plan_update_v1(
  p_plan_id uuid,
  p_price numeric,
  p_billing_period text DEFAULT 'monthly',
  p_effective_from date DEFAULT current_date,
  p_effective_to date DEFAULT NULL,
  p_is_active boolean DEFAULT true,
  p_levels text[] DEFAULT '{}'::text[]
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public
AS $$
DECLARE
  v_school uuid;
  v_plan public.school_fee_plans%ROWTYPE;
  v_levels text[];
  v_from date := COALESCE(p_effective_from, current_date);
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  v_school := public.fn_my_primary_school();
  IF v_school IS NULL OR NOT (
    public.fn_is_school_staff(v_school) OR public.fn_has_permission('finance.manage',v_school)
  ) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  SELECT * INTO v_plan
  FROM public.school_fee_plans
  WHERE id = p_plan_id AND school_id = v_school
  FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'FEE_PLAN_NOT_FOUND'; END IF;

  IF p_price IS NULL OR p_price < 0 THEN RAISE EXCEPTION 'INVALID_FEE_PRICE'; END IF;
  IF p_billing_period NOT IN ('monthly','annual','one_time') THEN RAISE EXCEPTION 'INVALID_BILLING_PERIOD'; END IF;
  IF p_effective_to IS NOT NULL AND p_effective_to < v_from THEN RAISE EXCEPTION 'INVALID_EFFECTIVE_PERIOD'; END IF;

  SELECT COALESCE(array_agg(DISTINCT btrim(x) ORDER BY btrim(x)), '{}'::text[])
  INTO v_levels
  FROM unnest(COALESCE(p_levels,'{}'::text[])) AS x
  WHERE btrim(x) <> '';

  IF cardinality(v_levels) > 0 AND EXISTS (
    SELECT 1 FROM unnest(v_levels) l
    WHERE NOT EXISTS (
      SELECT 1 FROM public.classes c
      WHERE c.school_id=v_school AND lower(btrim(c.level))=lower(btrim(l))
    )
  ) THEN RAISE EXCEPTION 'INVALID_FEE_LEVEL'; END IF;

  -- Do not silently overlap another plan with the same fee and level scope.
  IF EXISTS (
    SELECT 1 FROM public.school_fee_plans p
    WHERE p.school_id=v_school AND p.id<>p_plan_id
      AND p.fee_type=v_plan.fee_type
      AND COALESCE(p.levels,'{}'::text[])=v_levels
      AND p.is_active=COALESCE(p_is_active,true)
      AND daterange(p.effective_from, COALESCE(p.effective_to + 1, 'infinity'::date), '[)')
          && daterange(v_from, COALESCE(p_effective_to + 1, 'infinity'::date), '[)')
  ) THEN RAISE EXCEPTION 'FEE_PLAN_PERIOD_OVERLAP'; END IF;

  UPDATE public.school_fee_plans
  SET price=p_price,
      billing_period=p_billing_period,
      effective_from=v_from,
      effective_to=p_effective_to,
      is_active=COALESCE(p_is_active,true),
      levels=v_levels,
      updated_at=now()
  WHERE id=p_plan_id AND school_id=v_school;

  PERFORM public.fn_safe_audit(
    v_school, 'FEE_PLAN_UPDATED', 'school_fee_plans', p_plan_id,
    jsonb_build_object('price',v_plan.price,'billing_period',v_plan.billing_period,
      'effective_from',v_plan.effective_from,'effective_to',v_plan.effective_to,
      'is_active',v_plan.is_active,'levels',COALESCE(v_plan.levels,'{}'::text[])),
    jsonb_build_object('price',p_price,'billing_period',p_billing_period,
      'effective_from',v_from,'effective_to',p_effective_to,
      'is_active',COALESCE(p_is_active,true),'levels',v_levels)
  );
  RETURN p_plan_id;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_school_fee_plan_update_v1(uuid,numeric,text,date,date,boolean,text[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_school_fee_plan_update_v1(uuid,numeric,text,date,date,boolean,text[]) TO authenticated;
