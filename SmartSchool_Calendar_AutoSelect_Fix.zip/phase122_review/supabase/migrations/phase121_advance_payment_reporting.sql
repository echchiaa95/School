-- Phase 121: make legacy payments visible in fee-ledger reports and advance-payment selection.
-- Read-only reconciliation: does not rewrite, duplicate, or delete historical payment rows.

CREATE OR REPLACE FUNCTION public.fn_list_student_fee_obligations(p_student_id uuid)
RETURNS TABLE(
  obligation_id uuid, fee_type text, period_key text, period_start date,
  list_amount numeric, discount_amount numeric, amount_due numeric,
  amount_paid numeric, remaining numeric, status text
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_school uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  SELECT school_id INTO v_school FROM public.students
  WHERE id=p_student_id AND deleted_at IS NULL;
  IF v_school IS NULL THEN RAISE EXCEPTION 'STUDENT_NOT_FOUND'; END IF;
  IF NOT (public.fn_is_school_staff(v_school)
      OR public.fn_has_permission('finance.view',v_school)
      OR public.fn_has_permission('finance.manage',v_school)) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  RETURN QUERY
  SELECT o.id,o.fee_type,o.period_key,o.period_start,o.list_amount,o.discount_amount,o.amount_due,
         paid.paid_value,
         GREATEST(0,o.amount_due-paid.paid_value),
         CASE WHEN o.amount_due<=0 THEN 'waived'
              WHEN paid.paid_value>=o.amount_due THEN 'paid'
              WHEN paid.paid_value>0 THEN 'partial' ELSE 'unpaid' END::text
  FROM public.student_fee_obligations o
  LEFT JOIN LATERAL (
    SELECT SUM(a.amount)::numeric AS allocated
    FROM public.student_fee_payment_allocations a
    JOIN public.student_fee_payment_transactions tx ON tx.id=a.transaction_id
    WHERE a.obligation_id=o.id AND tx.school_id=v_school
  ) alloc ON TRUE
  LEFT JOIN LATERAL (
    SELECT p.amount_paid::numeric AS legacy_paid
    FROM public.payments p
    WHERE p.student_id=o.student_id
      AND p.month=EXTRACT(MONTH FROM o.period_start)::integer
      AND p.year=EXTRACT(YEAR FROM o.period_start)::integer
      AND COALESCE(p.school_id,v_school)=v_school
      AND CASE
        WHEN lower(trim(COALESCE(p.fee_type,''))) IN ('شهرية','شهري','mensuel','monthly') THEN 'واجب التمدرس'
        WHEN trim(COALESCE(p.fee_type,''))='' THEN 'واجب التمدرس'
        ELSE trim(p.fee_type)
      END=o.fee_type
    ORDER BY p.created_at DESC LIMIT 1
  ) legacy ON TRUE
  CROSS JOIN LATERAL (
    SELECT CASE
      WHEN alloc.allocated IS NOT NULL OR legacy.legacy_paid IS NOT NULL
        THEN COALESCE(alloc.allocated,0)+COALESCE(legacy.legacy_paid,0)
      ELSE o.amount_paid
    END::numeric AS paid_value
  ) paid
  WHERE o.student_id=p_student_id AND o.school_id=v_school
  ORDER BY o.period_start DESC,o.fee_type;
END;
$$;

CREATE OR REPLACE FUNCTION public.fn_report_fee_obligations(
  p_academic_year_id uuid DEFAULT NULL,p_class_id uuid DEFAULT NULL,
  p_fee_type text DEFAULT NULL,p_status text DEFAULT NULL,
  p_from date DEFAULT NULL,p_to date DEFAULT NULL
)
RETURNS TABLE(
  obligation_id uuid,student_id uuid,student_name text,student_number text,
  class_id uuid,class_name text,fee_type text,period_key text,period_start date,
  period_end date,list_amount numeric,discount_amount numeric,amount_due numeric,
  amount_paid numeric,remaining numeric,status text,uses_transport boolean
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_school uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  v_school:=public.fn_my_primary_school();
  IF v_school IS NULL OR NOT (
    public.fn_is_school_staff(v_school)
    OR public.fn_has_permission('finance.view',v_school)
    OR public.fn_has_permission('reports.view',v_school)
  ) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;

  RETURN QUERY
  SELECT o.id,o.student_id,st.full_name,st.student_number,en.class_id,
         COALESCE(c.name,'بدون قسم'),o.fee_type,o.period_key,o.period_start,o.period_end,
         o.list_amount,o.discount_amount,o.amount_due,paid.paid_value,
         GREATEST(0,o.amount_due-paid.paid_value),
         CASE WHEN o.amount_due<=0 THEN 'waived'
              WHEN paid.paid_value>=o.amount_due THEN 'paid'
              WHEN paid.paid_value>0 THEN 'partial' ELSE 'unpaid' END::text,
         st.uses_transport
  FROM public.student_fee_obligations o
  JOIN public.students st ON st.id=o.student_id
  LEFT JOIN LATERAL (
    SELECT se.class_id FROM public.student_enrollments se
    WHERE se.student_id=st.id AND se.academic_year_id=o.academic_year_id
      AND se.school_id=v_school ORDER BY se.created_at DESC LIMIT 1
  ) en ON TRUE
  LEFT JOIN public.classes c ON c.id=en.class_id
  LEFT JOIN LATERAL (
    SELECT SUM(a.amount)::numeric AS allocated
    FROM public.student_fee_payment_allocations a
    JOIN public.student_fee_payment_transactions tx ON tx.id=a.transaction_id
    WHERE a.obligation_id=o.id AND tx.school_id=v_school
  ) alloc ON TRUE
  LEFT JOIN LATERAL (
    SELECT p.amount_paid::numeric AS legacy_paid
    FROM public.payments p
    WHERE p.student_id=o.student_id
      AND p.month=EXTRACT(MONTH FROM o.period_start)::integer
      AND p.year=EXTRACT(YEAR FROM o.period_start)::integer
      AND COALESCE(p.school_id,v_school)=v_school
      AND CASE
        WHEN lower(trim(COALESCE(p.fee_type,''))) IN ('شهرية','شهري','mensuel','monthly') THEN 'واجب التمدرس'
        WHEN trim(COALESCE(p.fee_type,''))='' THEN 'واجب التمدرس'
        ELSE trim(p.fee_type)
      END=o.fee_type
    ORDER BY p.created_at DESC LIMIT 1
  ) legacy ON TRUE
  CROSS JOIN LATERAL (
    SELECT CASE WHEN alloc.allocated IS NOT NULL OR legacy.legacy_paid IS NOT NULL
                  THEN COALESCE(alloc.allocated,0)+COALESCE(legacy.legacy_paid,0)
                ELSE o.amount_paid END::numeric AS paid_value
  ) paid
  WHERE o.school_id=v_school
    AND (p_academic_year_id IS NULL OR o.academic_year_id=p_academic_year_id)
    AND (p_class_id IS NULL OR en.class_id=p_class_id)
    AND (p_fee_type IS NULL OR o.fee_type=p_fee_type)
    AND (p_status IS NULL OR
      CASE WHEN o.amount_due<=0 THEN 'waived'
           WHEN paid.paid_value>=o.amount_due THEN 'paid'
           WHEN paid.paid_value>0 THEN 'partial' ELSE 'unpaid' END=p_status)
    AND (p_from IS NULL OR o.period_start>=p_from)
    AND (p_to IS NULL OR o.period_start<=p_to)
  ORDER BY o.period_start DESC,st.full_name;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_list_student_fee_obligations(uuid) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.fn_report_fee_obligations(uuid,uuid,text,text,date,date) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_list_student_fee_obligations(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_report_fee_obligations(uuid,uuid,text,text,date,date) TO authenticated;
NOTIFY pgrst,'reload schema';

-- Calendar now combines historical legacy payments with any later ledger allocations
-- instead of allowing one source to mask the other.
CREATE OR REPLACE FUNCTION public.fn_student_fee_calendar(p_student_id uuid)
RETURNS TABLE(
  obligation_id uuid, academic_year_id uuid, fee_type text, period_key text,
  period_start date, period_end date, list_amount numeric, discount_amount numeric,
  amount_due numeric, amount_paid numeric, remaining numeric, status text,
  paid_transactions jsonb
)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=public
AS $$
DECLARE
  v_school uuid;
  v_year uuid;
  v_year_start date;
  v_year_end date;
  v_enrolled date;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;

  SELECT s.school_id INTO v_school
  FROM public.students s
  WHERE s.id=p_student_id AND s.deleted_at IS NULL;
  IF v_school IS NULL THEN RAISE EXCEPTION 'INVALID_STUDENT'; END IF;

  IF NOT (public.fn_is_school_staff(v_school)
      OR public.fn_has_permission('finance.view',v_school)
      OR public.fn_has_permission('finance.manage',v_school)) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  SELECT se.academic_year_id INTO v_year
  FROM public.student_enrollments se
  WHERE se.student_id=p_student_id AND se.school_id=v_school
    AND se.status::text='ACTIVE'
  ORDER BY se.created_at DESC LIMIT 1;

  IF v_year IS NULL THEN
    RETURN;
  END IF;

  SELECT ay.starts_on, ay.ends_on INTO v_year_start,v_year_end
  FROM public.academic_years ay
  WHERE ay.id=v_year AND ay.school_id=v_school;
  IF v_year_start IS NULL OR v_year_end IS NULL THEN
    RAISE EXCEPTION 'INVALID_ACADEMIC_YEAR';
  END IF;

  -- The student's financial calendar starts at their first ACTIVE enrollment
  -- date in the selected academic year, never at the academic-year start.
  SELECT min(se.enrolled_on) INTO v_enrolled
  FROM public.student_enrollments se
  WHERE se.student_id=p_student_id
    AND se.school_id=v_school
    AND se.academic_year_id=v_year
    AND se.status::text='ACTIVE';

  IF v_enrolled IS NULL THEN
    RETURN;
  END IF;

  PERFORM public.fn_generate_student_fee_obligations(p_student_id,v_year);

  RETURN QUERY
  SELECT
    o.id, o.academic_year_id, o.fee_type, o.period_key,
    o.period_start, o.period_end, o.list_amount, o.discount_amount,
    o.amount_due,
    paid.paid_value::numeric,
    GREATEST(0,o.amount_due-paid.paid_value)::numeric,
    CASE
      WHEN o.amount_due<=0 THEN 'waived'
      WHEN o.period_start>CURRENT_DATE AND paid.paid_value<=0 THEN 'future'
      WHEN paid.paid_value>=o.amount_due THEN 'paid'
      WHEN paid.paid_value>0 THEN 'partial'
      ELSE 'unpaid'
    END::text,
    (CASE WHEN legacy.id IS NOT NULL THEN jsonb_build_array(jsonb_build_object(
        'amount',legacy.amount_paid,'paid_on',legacy.paid_on,'method',legacy.method,
        'receipt_no',legacy.receipt_no,'transaction_id',legacy.id,'source','legacy'))
      ELSE '[]'::jsonb END) || COALESCE(alloc.txns,'[]'::jsonb)
  FROM public.student_fee_obligations o
  LEFT JOIN LATERAL (
    SELECT SUM(a.amount)::numeric AS paid_total,
      jsonb_agg(jsonb_build_object('amount',a.amount,'paid_on',t.paid_on,
        'method',t.method,'receipt_no',t.receipt_no,'transaction_id',t.id)
        ORDER BY t.paid_on) AS txns
    FROM public.student_fee_payment_allocations a
    JOIN public.student_fee_payment_transactions t ON t.id=a.transaction_id
    WHERE a.obligation_id=o.id
  ) alloc ON TRUE
  LEFT JOIN LATERAL (
    SELECT p.* FROM public.payments p
    WHERE p.student_id=o.student_id
      AND p.month=EXTRACT(MONTH FROM o.period_start)::integer
      AND p.year=EXTRACT(YEAR FROM o.period_start)::integer
      AND COALESCE(p.school_id,v_school)=v_school
      AND CASE
        WHEN lower(trim(COALESCE(p.fee_type,''))) IN ('شهرية','شهري','mensuel','monthly') THEN 'واجب التمدرس'
        WHEN trim(COALESCE(p.fee_type,''))='' THEN 'واجب التمدرس'
        ELSE trim(p.fee_type)
      END = o.fee_type
    ORDER BY p.created_at DESC LIMIT 1
  ) legacy ON TRUE
  CROSS JOIN LATERAL (
    SELECT CASE
      WHEN alloc.paid_total IS NOT NULL OR legacy.amount_paid IS NOT NULL
        THEN COALESCE(alloc.paid_total,0)+COALESCE(legacy.amount_paid,0)
      ELSE o.amount_paid
    END::numeric AS paid_value
  ) paid
  WHERE o.student_id=p_student_id AND o.school_id=v_school
    AND o.academic_year_id=v_year
    AND o.period_start >= v_enrolled

  UNION ALL

  SELECT NULL::uuid,v_year,
    CASE WHEN lower(trim(COALESCE(p.fee_type,''))) IN ('شهرية','شهري','mensuel','monthly')
      THEN 'واجب التمدرس' ELSE COALESCE(NULLIF(trim(p.fee_type),''),'واجب التمدرس') END::text,
    to_char(make_date(p.year,p.month,1),'YYYY-MM'),
    make_date(p.year,p.month,1),
    (make_date(p.year,p.month,1)+interval '1 month - 1 day')::date,
    p.amount_due::numeric,0::numeric,p.amount_due::numeric,p.amount_paid::numeric,
    GREATEST(0,p.amount_due-p.amount_paid)::numeric,
    CASE WHEN p.amount_paid>=p.amount_due THEN 'paid'
      WHEN p.amount_paid>0 THEN 'partial'
      WHEN make_date(p.year,p.month,1)>CURRENT_DATE THEN 'future'
      ELSE 'unpaid' END::text,
    CASE WHEN p.amount_paid>0 THEN jsonb_build_array(jsonb_build_object(
      'amount',p.amount_paid,'paid_on',p.paid_on,'method',p.method,
      'receipt_no',p.receipt_no,'transaction_id',p.id,'source','legacy'))
      ELSE '[]'::jsonb END
  FROM public.payments p
  WHERE p.student_id=p_student_id
    AND COALESCE(p.school_id,v_school)=v_school
    AND make_date(p.year,p.month,1) BETWEEN GREATEST(v_year_start,v_enrolled) AND v_year_end
    AND NOT EXISTS (
      SELECT 1 FROM public.student_fee_obligations o
      WHERE o.student_id=p_student_id AND o.academic_year_id=v_year
        AND o.period_key=to_char(make_date(p.year,p.month,1),'YYYY-MM')
        AND o.period_start >= v_enrolled
        AND o.fee_type=CASE
          WHEN lower(trim(COALESCE(p.fee_type,''))) IN ('شهرية','شهري','mensuel','monthly') THEN 'واجب التمدرس'
          WHEN trim(COALESCE(p.fee_type,''))='' THEN 'واجب التمدرس'
          ELSE trim(p.fee_type) END
    )
  ORDER BY period_start,fee_type;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_student_fee_calendar(uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_student_fee_calendar(uuid) TO authenticated;
NOTIFY pgrst,'reload schema';
