-- Phase 123: safely edit unified-ledger payments and preserve an audit trail.
CREATE TABLE IF NOT EXISTS public.student_fee_payment_audit (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), school_id uuid NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
 transaction_id uuid NOT NULL, actor_id uuid NOT NULL REFERENCES auth.users(id), reason text NOT NULL,
 old_values jsonb NOT NULL, new_values jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.student_fee_payment_audit ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.student_fee_payment_audit FROM PUBLIC,anon,authenticated;

CREATE OR REPLACE FUNCTION public.fn_fee_payment_update(
 p_transaction_id uuid, p_amount numeric, p_method text, p_paid_on date,
 p_receipt_no text, p_notes text, p_reason text
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_school uuid; v_student uuid; v_old record; v_total_due numeric:=0; v_left numeric; v_take numeric;
 v_alloc record; v_old_values jsonb; v_new_values jsonb;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
 IF p_amount IS NULL OR p_amount<=0 THEN RAISE EXCEPTION 'INVALID_PAYMENT_AMOUNT'; END IF;
 IF NULLIF(btrim(p_reason),'') IS NULL THEN RAISE EXCEPTION 'EDIT_REASON_REQUIRED'; END IF;
 SELECT * INTO v_old FROM public.student_fee_payment_transactions WHERE id=p_transaction_id FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'PAYMENT_NOT_FOUND'; END IF;
 v_school:=v_old.school_id; v_student:=v_old.student_id;
 IF NOT (public.fn_is_school_staff(v_school) OR public.fn_has_permission('finance.manage',v_school)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
 IF NOT EXISTS(SELECT 1 FROM public.student_fee_payment_allocations WHERE transaction_id=p_transaction_id) THEN RAISE EXCEPTION 'PAYMENT_HAS_NO_ALLOCATIONS'; END IF;
 PERFORM 1 FROM public.student_fee_obligations o JOIN public.student_fee_payment_allocations a ON a.obligation_id=o.id WHERE a.transaction_id=p_transaction_id ORDER BY o.id FOR UPDATE OF o;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('obligation_id',a.obligation_id,'amount',a.amount) ORDER BY o.period_start,o.fee_type),'[]'::jsonb)
 INTO v_old_values FROM public.student_fee_payment_allocations a JOIN public.student_fee_obligations o ON o.id=a.obligation_id WHERE a.transaction_id=p_transaction_id;
 -- Restore the old allocations first; then reallocate this edited transaction against the same obligations.
 UPDATE public.student_fee_obligations o SET amount_paid=GREATEST(0,o.amount_paid-a.amount),
  status=CASE WHEN GREATEST(0,o.amount_paid-a.amount)<=0 THEN CASE WHEN o.amount_due=0 THEN 'waived' ELSE 'unpaid' END WHEN GREATEST(0,o.amount_paid-a.amount)>=o.amount_due THEN 'paid' ELSE 'partial' END, updated_at=now()
 FROM public.student_fee_payment_allocations a WHERE a.transaction_id=p_transaction_id AND o.id=a.obligation_id;
 SELECT COALESCE(sum(o.amount_due-o.amount_paid),0) INTO v_total_due FROM public.student_fee_payment_allocations a JOIN public.student_fee_obligations o ON o.id=a.obligation_id WHERE a.transaction_id=p_transaction_id;
 IF p_amount>v_total_due THEN RAISE EXCEPTION 'PAYMENT_EXCEEDS_REMAINING'; END IF;
 DELETE FROM public.student_fee_payment_allocations WHERE transaction_id=p_transaction_id;
 v_left:=p_amount;
 FOR v_alloc IN SELECT o.id,o.amount_due,o.amount_paid FROM public.student_fee_obligations o
  WHERE o.id IN (SELECT (x.item->>'obligation_id')::uuid FROM jsonb_array_elements(v_old_values) AS x(item))
  ORDER BY o.period_start,o.fee_type FOR UPDATE
 LOOP
  EXIT WHEN v_left<=0;
  v_take:=LEAST(v_left,GREATEST(0,v_alloc.amount_due-v_alloc.amount_paid));
  IF v_take>0 THEN
   INSERT INTO public.student_fee_payment_allocations(school_id,transaction_id,obligation_id,amount) VALUES(v_school,p_transaction_id,v_alloc.id,v_take);
   UPDATE public.student_fee_obligations SET amount_paid=amount_paid+v_take,status=CASE WHEN amount_paid+v_take>=amount_due THEN 'paid' ELSE 'partial' END,updated_at=now() WHERE id=v_alloc.id;
   v_left:=v_left-v_take;
  END IF;
 END LOOP;
 IF v_left>0.005 THEN RAISE EXCEPTION 'PAYMENT_REALLOCATION_FAILED'; END IF;
 UPDATE public.student_fee_payment_transactions SET amount=p_amount,method=NULLIF(btrim(p_method),''),paid_on=COALESCE(p_paid_on,CURRENT_DATE),receipt_no=NULLIF(btrim(p_receipt_no),''),notes=NULLIF(btrim(p_notes),'' ) WHERE id=p_transaction_id;
 SELECT jsonb_build_object('amount',p_amount,'method',p_method,'paid_on',COALESCE(p_paid_on,CURRENT_DATE),'receipt_no',p_receipt_no,'notes',p_notes,
  'allocations',(SELECT COALESCE(jsonb_agg(jsonb_build_object('obligation_id',obligation_id,'amount',amount)),'[]'::jsonb) FROM public.student_fee_payment_allocations WHERE transaction_id=p_transaction_id)) INTO v_new_values;
 INSERT INTO public.student_fee_payment_audit(school_id,transaction_id,actor_id,reason,old_values,new_values)
 VALUES(v_school,p_transaction_id,auth.uid(),btrim(p_reason),jsonb_build_object('amount',v_old.amount,'method',v_old.method,'paid_on',v_old.paid_on,'receipt_no',v_old.receipt_no,'notes',v_old.notes,'allocations',v_old_values),v_new_values);
 RETURN p_transaction_id;
END $$;
REVOKE ALL ON FUNCTION public.fn_fee_payment_update(uuid,numeric,text,date,text,text,text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_fee_payment_update(uuid,numeric,text,date,text,text,text) TO authenticated;

CREATE OR REPLACE FUNCTION public.fn_list_guard_fee_transactions(p_limit integer DEFAULT 500)
RETURNS TABLE(payment_id uuid,student_id uuid,student_name text,payment_date date,fee_type text,amount_paid numeric,amount_due numeric,method text,receipt_no text,notes text)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public AS $$
DECLARE v_school uuid;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
 v_school:=public.fn_my_primary_school();
 IF NOT (public.fn_has_permission('finance.view',v_school) OR public.fn_has_permission('finance.manage',v_school) OR public.fn_is_school_staff(v_school)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
 RETURN QUERY SELECT tx.id,tx.student_id,s.full_name::text,tx.paid_on,string_agg(DISTINCT o.fee_type,'، ' ORDER BY o.fee_type),tx.amount,NULL::numeric,tx.method,tx.receipt_no,tx.notes
 FROM public.student_fee_payment_transactions tx JOIN public.students s ON s.id=tx.student_id AND s.school_id=v_school
 LEFT JOIN public.student_fee_payment_allocations a ON a.transaction_id=tx.id LEFT JOIN public.student_fee_obligations o ON o.id=a.obligation_id
 WHERE tx.school_id=v_school GROUP BY tx.id,tx.student_id,s.full_name,tx.paid_on,tx.amount,tx.method,tx.receipt_no,tx.notes
 ORDER BY tx.paid_on DESC,tx.created_at DESC LIMIT GREATEST(1,LEAST(COALESCE(p_limit,500),2000));
END $$;
REVOKE ALL ON FUNCTION public.fn_list_guard_fee_transactions(integer) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_list_guard_fee_transactions(integer) TO authenticated;
