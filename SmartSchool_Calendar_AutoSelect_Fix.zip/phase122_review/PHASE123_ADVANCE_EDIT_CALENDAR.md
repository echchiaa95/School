# Phase 123 — Edit advance payments and pay from student calendar

## Included
- Adds a dedicated `fn_fee_payment_update` RPC for unified-ledger transactions.
- The RPC restores the old allocations, recalculates the payment against the same obligation months in chronological order, and writes an audit record with old/new values and the mandatory edit reason.
- Adds an “Edit advance” action to unified-ledger payments.
- Adds a “Record payment for this month” action to unpaid/partially-paid obligations in the student monthly calendar. It selects the current student, fee type, one-month advance mode, and month in the finance form; the operator reviews the preview and submits.
- Extends `fn_list_guard_fee_transactions` with `student_id` while preserving existing return columns plus the new field.

## Apply
Review and apply `supabase/migrations/phase123_advance_payment_edit.sql` in the intended Supabase project. The migration is additive and is not executed by the application or workflow automatically.

## Important limits
- Editing a ledger transaction reallocates only across the obligations that were part of that transaction originally. It does not silently redirect money to unrelated months or fee types.
- The calendar action preselects the student/type/month and opens the one-month advance preview; the user must review and submit the payment.
- Legacy `payments` rows are unchanged and continue using their existing correction/audit workflow.

## Validation
- JavaScript syntax and existing unit tests checked after changes.
- No live Supabase migration execution or production browser test was performed.
