# Phase 121 — Advance payments and legacy reporting reconciliation

## Included
- Adds an ordinary / advance-payment selector to the finance payment form.
- Advance mode asks for the number of months and the first billing month.
- It lazily refreshes the student's fee calendar, selects open obligations for the same fee type only, and allocates one payment transaction in chronological month order through the existing batch-payment RPC.
- The preview uses each obligation's remaining amount after discounts; partial payments are allocated sequentially and cannot exceed the selected months' outstanding total.
- The latest-payments panel now displays both legacy `payments` rows and new ledger transactions.
- Migration `phase121_advance_payment_reporting.sql` makes the obligation list and finance reports see matching legacy payments so the same month is not presented as unpaid merely because it has no ledger allocation.

## Safety / limitations
- No historical payment rows are rewritten, deleted, or duplicated by this migration.
- The existing legacy overpayment surplus is NOT automatically moved to future months. The system cannot safely infer whether an overpayment was intended as an advance without an explicit reconciliation decision. The new advance mode allocates newly recorded payments to the chosen months.
- The migration does not execute itself. Apply it to the intended Supabase project after reviewing it.
- The existing batch RPC performs the write atomically and checks the outstanding amount again server-side.

## Validation performed
- `node --check modules/adminConsole.js` — passed.
- `node --test tests/reportsAnalytics.test.mjs` — 23/23 passed.
- SQL was reviewed statically; no live Supabase database was available in this session, so migration execution and production RPC behavior remain unverified.
