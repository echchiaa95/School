"""E2E: admin.html reports center in real Chromium with a MOCKED Supabase client.
All fixtures below are SYNTHETIC test data that live only in this test file."""
import json, re, sys, threading, http.server, socketserver, functools, os
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
PORT = 8765
Handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
socketserver.TCPServer.allow_reuse_address = True
srv = socketserver.TCPServer(('127.0.0.1', PORT), functools.partial(Q, directory=ROOT))
threading.Thread(target=srv.serve_forever, daemon=True).start()

TUI, TRN = 'واجب التمدرس', 'واجب النقل'
def ob(oid, sid, num, name, cls, fee, ps, lst, disc, due, paid, st):
    return dict(obligation_id=oid, student_id=sid, student_name=name, student_number=num, class_id='c-' + cls, class_name=cls,
                fee_type=fee, period_key=ps[:7], period_start=ps, period_end=ps, list_amount=lst, discount_amount=disc,
                amount_due=due, amount_paid=paid, remaining=max(0, due - paid), status=st, uses_transport=False)
LEDGER = [
 ob('o1','s1','S1','تلميذ 1','A1',TUI,'2026-09-01',500,100,400,400,'paid'),
 ob('o2','s1','S1','تلميذ 1','A1',TUI,'2026-10-01',400,0,400,400,'paid'),
 ob('o3','s1','S1','تلميذ 1','A1',TUI,'2026-11-01',400,0,400,0,'unpaid'),
 ob('o4','s2','S2','تلميذ 2','A1',TUI,'2026-09-01',500,0,500,200,'partial'),
 ob('o5','s2','S2','تلميذ 2','A1',TUI,'2026-10-01',500,0,500,0,'unpaid'),
 ob('o6','s3','S3','تلميذ 3','A2',TUI,'2026-09-01',500,0,500,500,'paid'),
 ob('o7','s3','S3','تلميذ 3','A2',TRN,'2026-10-01',150,0,150,0,'unpaid'),
 ob('o8','s4','S4','تلميذ 4','B1',TUI,'2026-09-01',500,0,500,0,'unpaid'),
 ob('o9','s1','S1','تلميذ 1','A1',TUI,'2027-01-01',400,0,400,0,'unpaid'),
 ob('o10','s5','S5','تلميذ 5','B1',TUI,'2026-09-01',500,500,0,0,'waived'),
]
def lg(pid, num, name, cls, fee, m, y, due, paid, pdate=None):
    return dict(payment_id=pid, student_id='x'+num, student_name=name, student_number=num, class_name=cls, fee_type=fee,
                billing_month=m, billing_year=y, amount_due=due, amount_paid=paid, remaining=max(0,due-paid), payment_date=pdate, method='cash' if paid else None, receipt_no=None)
LEGACY = [lg('g1','S1','تلميذ 1','A1','شهرية',10,2026,400,400,'2026-10-05'),   # overlaps ledger o2 -> must NOT be counted twice
          lg('g2','S7','تلميذ 7','B1','شهرية',8,2026,300,0)]                  # legacy only, aged > 90 days
ATT = [dict(student_name='تلميذ 1', student_number='S1', class_name='A1', att_date=f'2026-11-0{d}', status='absent') for d in (2,3,4)] \
    + [dict(student_name='تلميذ 1', student_number='S1', class_name='A1', att_date=f'2026-11-0{d}', status='present') for d in (5,6)] \
    + [dict(student_name='تلميذ 2', student_number='S2', class_name='A1', att_date=f'2026-11-0{d}', status='present') for d in (2,3,4,5)] \
    + [dict(student_name='تلميذ 2', student_number='S2', class_name='A1', att_date='2026-11-06', status='late')] \
    + [dict(student_name='تلميذ 3', student_number='S3', class_name='A2', att_date=f'2026-11-0{d}', status='excused') for d in (2,3)]
EXP = [dict(category='كهرباء', amount=1000, expense_date='2026-10-05', description='', recorder_name='م'),
       dict(category='أجور', amount=3000, expense_date='2026-09-10', description='', recorder_name='م'),
       dict(category='كهرباء', amount=500, expense_date='2026-11-05', description='', recorder_name='م')]
INC = [dict(incident_id='i1', student_id='s1', student_name='تلميذ 1', type='تأخر', title='ت', occurred_at='2026-11-02T08:00:00Z', action_taken='', status='open'),
       dict(incident_id='i2', student_id='s1', student_name='تلميذ 1', type='تأخر', title='ت', occurred_at='2026-11-03T08:00:00Z', action_taken='إنذار', status='closed'),
       dict(incident_id='i3', student_id='s2', student_name='تلميذ 2', type='عنف', title='ع', occurred_at='2026-11-04T08:00:00Z', action_taken='', status='open')]
CLASSES = [dict(class_id='c-A1', class_name='A1', year_name='2026/2027'), dict(class_id='c-A2', class_name='A2', year_name='2026/2027'), dict(class_id='c-B1', class_name='B1', year_name='2026/2027')]

STUB = r"""
window.__rpc = [];
const FX = %s;
const res = (data)=>({data, error:null});
function chain(data){ const o={}; const m=['select','eq','is','in','order','limit','or','neq','gte','lte','ilike','range','not','match','filter'];
  m.forEach(k=>o[k]=()=>o); o.maybeSingle=()=>Promise.resolve({data:Array.isArray(data)?data[0]||null:data,error:null}); o.single=o.maybeSingle;
  o.then=(f,r)=>Promise.resolve({data,error:null}).then(f,r); return o; }
window.supabase = { createClient: ()=>({
  auth:{ getSession:async()=>({data:{session:{user:{id:'u1'}}},error:null}), getUser:async()=>({data:{user:{id:'u1'}},error:null}),
         onAuthStateChange:()=>({data:{subscription:{unsubscribe(){}}}}), signOut:async()=>({error:null}) },
  from:(t)=>{ const T={profiles:[{id:'u1',full_name:'مدير الاختبار',phone:null,avatar_url:null,is_disabled:false}], user_roles:[{school_id:'s1',role:'admin'}],
        students:[ {id:'s1',full_name:'تلميذ 1',student_number:'S1'},{id:'s2',full_name:'تلميذ 2',student_number:'S2'},{id:'s3',full_name:'تلميذ 3',student_number:'S3'},{id:'s4',full_name:'تلميذ 4',student_number:'S4'},{id:'s6',full_name:'تلميذ 6',student_number:'S6'},{id:'s8',full_name:'تلميذ 8',student_number:'S8'} ],
        student_enrollments:[ {student_id:'s1',status:'ACTIVE',classes:{name:'A1',level:'1'}},{student_id:'s2',status:'ACTIVE',classes:{name:'A1',level:'1'}},{student_id:'s3',status:'ACTIVE',classes:{name:'A2',level:'1'}},{student_id:'s4',status:'ACTIVE',classes:{name:'B1',level:'2'}},{student_id:'s6',status:'ACTIVE',classes:{name:'B1',level:'2'}} ],
        student_badges:[]};
        return chain(T[t]||[]); },
  rpc: async (name,p)=>{ window.__rpc.push([name,p||{}]);
    switch(name){
      case 'fn_resolve_school_domain': return res([{school_id:'s1',school_name:'مؤسسة الاختبار'}]);
      case 'fn_get_school_profile': return res({name:'مؤسسة الاختبار',logo_url:null});
      case 'fn_list_my_academic_years': return res([{year_id:'y1',year_name:'2026/2027',is_current:true,is_disabled:false,class_count:3}]);
      case 'fn_list_my_classes': return res(FX.classes);
      case 'fn_report_payments': return res(FX.legacy);
      case 'fn_report_fee_obligations': { let r=FX.ledger; if(p&&p.p_class_id) r=r.filter(x=>x.class_id===p.p_class_id); if(p&&p.p_fee_type) r=r.filter(x=>x.fee_type===p.p_fee_type); if(p&&p.p_status) r=r.filter(x=>x.status===p.p_status); return res(r); }
      case 'fn_report_attendance': { if(p && p.p_from && p.p_from>'2026-11-30') return res([]); const inr = FX.att.filter(x=>(!p.p_from||x.att_date>=p.p_from)&&(!p.p_to||x.att_date<=p.p_to)); return res(inr); }
      case 'fn_list_expenses': return res(FX.exp);
      case 'fn_list_incidents': return res(FX.inc);
      case 'fn_report_student_fee_discounts': return res([]);
      default: return res([]);
    } } }) };
""" % json.dumps(dict(ledger=LEDGER, legacy=LEGACY, att=ATT, exp=EXP, inc=INC, classes=CLASSES), ensure_ascii=False)

def digits(s):  # normalise Arabic-Indic digits and separators
    tr = str.maketrans('٠١٢٣٤٥٦٧٨٩٬٫', '0123456789,.')
    return s.translate(tr)
def num(s):
    m = re.search(r'\d[\d.,]*', digits(s))
    if not m: return float('nan')
    t = m.group(0).rstrip('.,')
    parts = re.split(r'[.,]', t)
    if len(parts) > 1 and len(parts[-1]) == 3: return float(''.join(parts))      # thousands separators
    if len(parts) > 1: return float(''.join(parts[:-1]) + '.' + parts[-1])      # decimal part
    return float(t)

results = []
def check(name, cond, detail=''):
    results.append((name, bool(cond), detail)); print(('PASS ' if cond else 'FAIL ') + name + (f'  [{detail}]' if detail and not cond else ''))

def open_reports(p, lang='ar', viewport=(1280, 900)):
    ctx = p.chromium.launch().new_context(viewport={'width': viewport[0], 'height': viewport[1]}, locale='ar-MA', accept_downloads=True)
    ctx.add_init_script(f"try{{localStorage.setItem('ss_lang','{lang}')}}catch(e){{}}")
    page = ctx.new_page()
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' and 'Failed to load resource' not in m.text else None)
    def route(r):
        u = r.request.url
        if 'supabase-js' in u: return r.fulfill(body=STUB, content_type='application/javascript')
        if '127.0.0.1' in u: return r.continue_()
        if 'xlsx' in u: return r.abort()
        return r.abort()
    page.route('**/*', route)
    page.clock.set_fixed_time('2026-11-16T10:00:00')
    page.goto(f'http://127.0.0.1:{PORT}/admin.html')
    page.wait_for_selector('[data-go="reports"]', state='visible', timeout=15000)
    page.locator('[data-go="reports"]').first.click()
    page.wait_for_selector('#rc-dashboard .rc-kpis', timeout=15000)
    return ctx, page, errors

def set_filters(page, **kw):
    for k, v in kw.items():
        page.evaluate("([id,v])=>{const e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('change',{bubbles:true}))}", [k, v])
    page.wait_for_timeout(900)

def kpi(page, label):
    return page.locator('.rc-kpi', has_text=label).first.inner_text()

with sync_playwright() as p:
    ctx, page, errors = open_reports(p)
    # --- structure / legacy ids
    ids = ['rp-overview','rp-payments','rp-unpaid','rp-payment-summary','rp-fee-obligations','rp-discounts','rp-attendance','rp-incidents','rp-students','rp-expenses']
    check('10 report cards with original ids kept', all(page.locator('#' + i).count() == 1 for i in ids))
    # --- Scenario B: range includes the Aug legacy line and the Jan future line
    set_filters(page, **{'rp-from': '2026-08-01', 'rp-to': '2027-01-31'})
    t = page.locator('#rc-dashboard').inner_text()
    check('due = 4,050 (legacy duplicate counted once, waived excluded)', num(kpi(page, 'إجمالي المستحقات').split('\n')[1]) == 4050, kpi(page, 'إجمالي المستحقات'))
    check('collected = 1,500', num(kpi(page, 'إجمالي التحصيل').split('\n')[1]) == 1500, kpi(page, 'إجمالي التحصيل'))
    check('debt = 2,150 (partial remains a debt) / 5 debtors', num(kpi(page, 'الديون المتبقية').split('\n')[1]) == 2150 and '5' in kpi(page, 'الديون المتبقية'), kpi(page, 'الديون المتبقية'))
    check('collection rate = 41.1%', '41.1' in digits(kpi(page, 'نسبة التحصيل')), kpi(page, 'نسبة التحصيل'))
    check('discounts = 100 / 1 beneficiary (not subtracted twice)', num(kpi(page, 'إجمالي التخفيضات').split('\n')[1]) == 100, kpi(page, 'إجمالي التخفيضات'))
    check('expenses = 4,500', num(kpi(page, 'إجمالي المصاريف').split('\n')[1]) == 4500, kpi(page, 'إجمالي المصاريف'))
    check('attendance rate = 58.3%', '58.3' in digits(kpi(page, 'نسبة الحضور')), kpi(page, 'نسبة الحضور'))
    check('expected (future) shown separately = 400', 'متوقع' in t and '400' in digits(t.split('متوقع')[1][:80]), t[:0])
    check('top-10 debtor #1 is student 2 with 800', digits(page.locator('.rc-table tbody tr').first.inner_text()).replace(',', '').find('800') >= 0 and 'تلميذ 2' in page.locator('.rc-table tbody tr').first.inner_text())
    check('class-debt alert for A1', 'A1' in page.locator('.rc-alerts').inner_text())
    check('absence-threshold alert shown (student with 3 unexcused)', 'غيابات غير مبررة' in page.locator('.rc-alerts').inner_text())
    check('no collection-drop alert without a comparable previous period', 'انخفضت نسبة التحصيل' not in t)
    check('legacy/ledger overlap noted once', 'تم احتسابها مرة واحدة' in t)
    check('previous-period deltas are "not comparable" (no prior data), not 0%', 'غير قابلة للمقارنة' in t)
    # --- filters
    set_filters(page, **{'rp-class': 'c-A2'})
    check('class filter A2 -> due 650', num(kpi(page, 'إجمالي المستحقات').split('\n')[1]) == 650, kpi(page, 'إجمالي المستحقات'))
    set_filters(page, **{'rp-class': '', 'rp-fee': 'واجب النقل'})
    check('fee-type filter transport -> due 150', num(kpi(page, 'إجمالي المستحقات').split('\n')[1]) == 150, kpi(page, 'إجمالي المستحقات'))
    set_filters(page, **{'rp-fee': '', 'rp-pay': 'unpaid'})
    check('payment-state filter unpaid -> due 1,850', num(kpi(page, 'إجمالي المستحقات').split('\n')[1]) == 1850, kpi(page, 'إجمالي المستحقات'))
    set_filters(page, **{'rp-pay': '', 'rp-to': '2026-11-16'})
    check('without future dates there is no "expected" line', 'متوقع' not in page.locator('#rc-dashboard').inner_text())
    set_filters(page, **{'rp-to': '2027-01-31'})
    # --- drill-down from KPI -> report modal, same numbers
    page.locator('.rc-kpi', has_text='الديون المتبقية').click()
    page.wait_for_selector('#smart-report-modal table.data-table')
    rows = page.locator('#smart-report-modal tbody tr').count()
    summ = page.locator('#report-summary').inner_text()
    check('impayés report: 6 open lines from both sources (matches debtors/debt on dashboard)', rows == 6, str(rows))
    check('impayés report total debt = dashboard (2,150), 5 debtors, 1 partial', [num(x) for x in summ.split('\n') if re.search(r'\d', x)] == [6, 5, 2150, 1], summ)
    # sort
    page.locator('#smart-report-modal th[data-sort="7"]').click()
    vals = [num(x) for x in page.locator('#smart-report-modal tbody tr td:nth-child(8)').all_inner_texts()]
    check('column sort ascending works', vals == sorted(vals), str(vals))
    page.locator('#smart-report-modal th[data-sort="7"]').click()
    vals = [num(x) for x in page.locator('#smart-report-modal tbody tr td:nth-child(8)').all_inner_texts()]
    check('column sort descending works', vals == sorted(vals, reverse=True), str(vals))
    check('active filters chips shown', 'الفترة' in page.locator('#report-chips').inner_text())
    # Excel export gets summary sheet with filters (intercept exportToExcel by stubbing XLSX)
    page.evaluate("""window.XLSX={utils:{book_new:()=>({sheets:[]}),aoa_to_sheet:a=>({aoa:a}),book_append_sheet:(wb,ws,n)=>wb.sheets.push([n,ws.aoa])},writeFile:(wb,f)=>{window.__xl={wb,f};}}""")
    page.locator('#rp-excel').click(); page.wait_for_timeout(600)
    xl = page.evaluate('window.__xl')
    check('Excel export has data sheet + summary sheet with filters', xl and len(xl['wb']['sheets']) == 2 and any('الفترة' in str(r) for r in xl['wb']['sheets'][1][1]), json.dumps(xl, ensure_ascii=False)[:200])
    check('Excel data rows match the screen (6)', xl and len(xl['wb']['sheets'][0][1]) - 1 == 6)
    # print
    popup = None
    with ctx.expect_page() as pg:
        page.locator('#rp-pdf').click()
    popup = pg.value; popup.wait_for_load_state()
    pt = popup.content()
    check('print window: school name, period, user, timestamp, rows', all(x in pt for x in ['مؤسسة الاختبار', '2026-08-01', 'مدير الاختبار', 'تاريخ ووقت الإنشاء']) and pt.count('<tr>') == 7)
    check('print window keeps RTL in Arabic', 'dir="rtl"' in pt)
    popup.close()
    page.locator('[data-report-close]').click()
    # synthèse agrees with dashboard
    page.locator('#rp-payment-summary').click(); page.wait_for_selector('#smart-report-modal table.data-table')
    vals = [num(x) for x in page.locator('#report-summary').inner_text().split('\n') if re.search(r'\d', x)]
    check('synthèse totals equal dashboard (4050 / 1500 / 2150 / 100)', vals == [4050, 1500, 2150, 100], str(vals))
    page.locator('[data-report-close]').click()
    # legacy report buttons still work
    for bid in ['rp-payments', 'rp-fee-obligations', 'rp-discounts', 'rp-attendance', 'rp-expenses', 'rp-incidents', 'rp-students']:
        page.locator('#' + bid).click()
        try:
            page.wait_for_selector('#smart-report-modal', timeout=6000); ok = True
        except Exception: ok = False
        check(f'existing report {bid} still opens', ok)
        page.evaluate("document.querySelector('[data-report-close]')&&document.querySelector('[data-report-close]').click()")
    # --- homogeneity: the 3 line-based reports + synthèse share base, period format, money format and totals
    heads = {}; firsts = {}
    def open_rep(bid):
        page.locator('#' + bid).click(); page.wait_for_selector('#smart-report-modal table.data-table')
    def vals(): return [num(x) for x in page.locator('#report-summary').inner_text().split('\n') if re.search(r'\d', x)]
    for bid in ['rp-payments', 'rp-unpaid', 'rp-fee-obligations']:
        open_rep(bid)
        heads[bid] = page.locator('#smart-report-modal thead th').all_inner_texts()
        firsts[bid] = page.locator('#smart-report-modal tbody tr').first.locator('td').all_inner_texts()
        if bid == 'rp-payments':
            check('journal now includes ledger payments: 4 rows (not legacy-only)', page.locator('#smart-report-modal tbody tr').count() == 4, str(page.locator('#smart-report-modal tbody tr').count()))
            check('journal totals: 4 payments / due 1,800 / collected 1,500 / remaining 300', vals()[:4] == [4, 1800, 1500, 300], str(vals()))
        if bid == 'rp-fee-obligations':
            check('obligations report on unified lines: 11 rows (10 + 1 waived shown as معفى)', page.locator('#smart-report-modal tbody tr').count() == 11 and 'معفى' in page.locator('#smart-report-modal tbody').inner_text())
            check('obligations totals = dashboard (10 / list 4,150 / discounts 100 / due 4,050 / paid 1,500 / debt 2,150 / expected 400 / transport 0)', vals()[:8] == [10, 4150, 100, 4050, 1500, 2150, 400, 0], str(vals()))
        page.evaluate("document.querySelector('[data-report-close]').click()")
    clean = lambda hs: [re.sub(r'[↕▲▼\s]+$', '', h).strip() for h in hs]
    base = ['التلميذ', 'رقم التلميذ', 'القسم', 'نوع الرسوم', 'الفترة']
    check('same first 5 columns in journal / impayés / obligations', all(clean(heads[b])[:5] == base for b in heads), str({b: clean(heads[b])[:5] for b in heads}))
    check('period shown as MM/YYYY in all three', all(re.fullmatch(r'\d{2}/\d{4}', firsts[b][4].strip()) for b in firsts), str({b: firsts[b][4] for b in firsts}))
    check('money columns formatted with the currency in all three', all('د.م.' in firsts[b][5] for b in firsts), str({b: firsts[b][5] for b in firsts}))
        # --- UI-2: students KPI, data-quality alert, per-report summaries / charts / share
    page.locator('[data-report-close]').count() and page.evaluate("document.querySelector('[data-report-close]')&&document.querySelector('[data-report-close]').click()")
    set_filters(page, **{'rp-from': '2026-08-01', 'rp-to': '2027-01-31'})
    check('active students KPI = 5 (6 students, 1 without active enrollment)', num(kpi(page, 'التلاميذ النشطون').split('\n')[1]) == 5, kpi(page, 'التلاميذ النشطون'))
    check('data-quality alert: 1 active student without any fee line', 'بلا أي مستحقات' in page.locator('.rc-alerts').inner_text() and '1 تلميذاً نشطاً' in page.locator('.rc-alerts').inner_text(), page.locator('.rc-alerts').inner_text()[:300])
    def open_report(bid):
        page.locator('#' + bid).click(); page.wait_for_selector('#smart-report-modal table.data-table')
    def sumvals():
        return [num(x) for x in page.locator('#report-summary').inner_text().split('\n') if re.search(r'\d', x)]
    open_report('rp-expenses')
    st = page.locator('#report-summary').inner_text()
    check('expenses report: count 3, total 4,500, top category أجور', sumvals()[:2] == [3, 4500] and 'أجور' in st, st)
    check('expenses report: 3 charts rendered', page.locator('#report-charts .rc-card').count() == 3)
    first = page.locator('#report-charts .rc-card').first.locator('.rc-hbar').first.inner_text()
    check('expenses chart: biggest bar is أجور 3,000', 'أجور' in first and num(first.split('\n')[-1]) == 3000, first)
    page.locator('#report-search').fill('كهرباء'); page.wait_for_timeout(300)
    first = page.locator('#report-charts .rc-card').first.locator('.rc-hbar').first.inner_text()
    check('charts follow the search filter (only كهرباء 1,500 left)', 'كهرباء' in first and num(first.split('\n')[-1]) == 1500 and page.locator('#report-charts .rc-card').first.locator('.rc-hbar').count() == 1, first)
    page.evaluate("document.querySelector('[data-report-close]').click()")
    open_report('rp-incidents')
    check('incidents report summary: 3 total, 2 students, 1 repeat, 2 open, 2 without action', sumvals()[:5] == [3, 2, 1, 2, 2], page.locator('#report-summary').inner_text())
    check('incidents report: 4 charts', page.locator('#report-charts .rc-card').count() == 4)
    page.evaluate("document.querySelector('[data-report-close]').click()")
    open_report('rp-students')
    check('students report summary: 6 / 5 active / 1 inactive / 3 classes', sumvals()[:4] == [6, 5, 1, 3], page.locator('#report-summary').inner_text())
    page.evaluate("document.querySelector('[data-report-close]').click()")
    open_report('rp-unpaid')
    check('impayés: 3 charts, class chart leads with A1 1,200', page.locator('#report-charts .rc-card').count() == 3 and 'A1' in page.locator('#report-charts .rc-card').first.locator('.rc-hbar').first.inner_text())
    page.evaluate("window.__shared=null; navigator.share=async(d)=>{window.__shared={title:d.title,text:d.text,files:(d.files||[]).map(f=>f.name)}}; navigator.canShare=()=>true;")
    page.locator('#rp-share').click(); page.wait_for_timeout(500)
    sh = page.evaluate('window.__shared')
    check('share: title, filters, summary figures, generator and CSV file', sh and 'Liste des impayés' in sh['title'] and 'الفترة' in sh['text'] and 'مدير الاختبار' in sh['text'] and '2.150' in sh['text'].replace(',', '.') and sh['files'] == ['unpaid-list.csv'], json.dumps(sh, ensure_ascii=False)[:300])
    page.evaluate("document.querySelector('[data-report-close]').click()")
    check('no JS errors (AR)', not errors, '; '.join(errors)[:300])
    # mobile
    page.set_viewport_size({'width': 390, 'height': 800}); page.wait_for_timeout(300)
    overflow = page.evaluate("document.documentElement.scrollWidth > window.innerWidth + 2")
    check('mobile 390px: no horizontal page overflow', not overflow, str(page.evaluate('document.documentElement.scrollWidth')))
    page.screenshot(path='/home/claude/shot_mobile_ar.png', full_page=False)
    page.set_viewport_size({'width': 1280, 'height': 900}); page.wait_for_timeout(300)
    page.locator('#rc-dashboard').screenshot(path='/home/claude/shot_dash_ar.png')
    ctx.browser.close()

    # --- French / LTR
    ctx, page, errors = open_reports(p, lang='fr')
    set_filters(page, **{'rp-from': '2026-08-01', 'rp-to': '2027-01-31'})
    check('FR: html dir=ltr lang=fr', page.evaluate("document.documentElement.dir==='ltr' && document.documentElement.lang==='fr'"))
    ft = page.locator('#rc-dashboard').inner_text()
    check('FR: dashboard texts in French (no Arabic left in dashboard)', 'Tableau de bord' in ft and not re.search(r'[\u0600-\u06FF]', ft.replace('تلميذ', '').replace('أجور', '').replace('كهرباء', '')), str(re.findall(r'[\u0600-\u06FF]+', ft)[:8]))
    check('FR: filters/cards translated', 'Année scolaire' in page.locator('.rc-filters').inner_text() and 'Rapport de présence' in page.locator('.rpt-grid').inner_text())
    page.locator('#rp-unpaid').click(); page.wait_for_selector('#smart-report-modal table.data-table')
    with ctx.expect_page() as pg: page.locator('#rp-pdf').click()
    pop = pg.value; pop.wait_for_load_state()
    check('FR print: dir=ltr', 'dir="ltr"' in pop.content())
    page.evaluate("document.querySelector('[data-report-close]').click()")
    page.locator('#rp-expenses').click(); page.wait_for_selector('#smart-report-modal table.data-table'); page.wait_for_timeout(500)
    chips = page.locator('#report-chips').inner_text(); ch = page.locator('#report-charts').inner_text(); sm = page.locator('#report-summary').inner_text()
    check('FR modal: chips in French', 'Période' in chips and 'Toutes' not in chips.replace('Toutes les périodes', ''), chips)
    check('FR modal: chart titles + summary labels translated', 'Dépenses par catégorie' in ch and 'Nombre de dépenses' in sm, (ch + sm)[:300])
    check('FR modal: share button translated', 'Partager' in page.locator('#rp-share').inner_text())
    check('no JS errors (FR)', not errors, '; '.join(errors)[:300])
    page.screenshot(path='/home/claude/shot_dash_fr.png')
    ctx.browser.close()

# --- No-data behaviour
with sync_playwright() as p:
    ctx, page, errors = open_reports(p)
    set_filters(page, **{'rp-from': '2020-01-01', 'rp-to': '2020-01-31'})
    t = page.locator('#rc-dashboard').inner_text()
    check('empty period: no invented numbers, "no data" messages, no alerts', 'لا توجد تنبيهات' in t and 'لا توجد توصيات' in t and num(kpi(page, 'إجمالي المستحقات').split('\n')[1]) != num(kpi(page, 'إجمالي المستحقات').split('\n')[1]) or '—' in kpi(page, 'إجمالي المستحقات'), kpi(page, 'إجمالي المستحقات'))
    ctx.browser.close()

fails = [r for r in results if not r[1]]
print(f'\n{len(results)-len(fails)}/{len(results)} passed')
sys.exit(1 if fails else 0)
