// Unit tests for modules/reportsAnalytics.js.
// NOTE: fixtures below are SYNTHETIC test inputs for verifying calculation logic only.
// They are never shown in the application and never written to any database.
import assert from 'node:assert/strict';
import * as A from '../modules/reportsAnalytics.js';

let pass = 0; const t = (name, fn) => { try { fn(); pass++; console.log('PASS', name); } catch (e) { console.log('FAIL', name, '\n  ', e.message); process.exitCode = 1; } };
const TODAY = '2026-11-16';
const ob = (o) => ({ fee_type: 'واجب التمدرس', status: 'unpaid', discount_amount: 0, list_amount: o.amount_due, amount_paid: 0, ...o });
const lg = (o) => ({ fee_type: 'شهرية', billing_year: 2026, billing_month: 10, amount_paid: 0, ...o });

t('discount is not subtracted twice (due is already net)', () => {
  const { lines } = A.mergeFeeLines([], [ob({ student_number: 'S1', period_key: '2026-10', period_start: '2026-10-01', list_amount: 500, discount_amount: 100, amount_due: 400, amount_paid: 0 })]);
  const k = A.financeKpis(lines, TODAY);
  assert.equal(k.due, 400); assert.equal(k.listTotal, 500); assert.equal(k.discounts, 100);
  assert.equal(k.listTotal - k.discounts, k.due);
});
t('partial payment stays a debt, not "paid"', () => {
  const { lines } = A.mergeFeeLines([], [ob({ student_number: 'S1', period_key: '2026-10', period_start: '2026-10-01', amount_due: 400, amount_paid: 150, status: 'partial' })]);
  const k = A.financeKpis(lines, TODAY);
  assert.equal(k.collected, 150); assert.equal(k.debt, 250); assert.equal(k.partialLines, 1); assert.equal(k.unpaidLines, 0);
  assert.equal(A.lineState(lines[0], TODAY), 'partial');
});
t('overpayment is clipped (no negative debt, collected <= due)', () => {
  const { lines } = A.mergeFeeLines([lg({ student_number: 'S2', amount_due: 300, amount_paid: 500 })], []);
  const k = A.financeKpis(lines, TODAY);
  assert.equal(k.collected, 300); assert.equal(k.debt, 0);
});
t('waived / zero-due ledger lines excluded from dues', () => {
  const m = A.mergeFeeLines([], [ob({ student_number: 'S3', period_key: '2026-10', period_start: '2026-10-01', amount_due: 0, status: 'waived' })]);
  assert.equal(m.lines.length, 0); assert.equal(m.waived, 1);
});
t('legacy row with a matching obligation is NOT added again (no double counting)', () => {
  const m = A.mergeFeeLines(
    [lg({ student_number: 'S4', amount_due: 400, amount_paid: 400 })],
    [ob({ student_number: 'S4', period_key: '2026-10', period_start: '2026-10-01', amount_due: 400, amount_paid: 400, status: 'paid' })]);
  assert.equal(m.lines.length, 1); assert.equal(m.overlap, 1); assert.equal(m.lines[0].src, 'ledger');
  assert.equal(A.financeKpis(m.lines, TODAY).due, 400);
});
t('legacy row without obligation is kept; legacy fee label normalised', () => {
  const m = A.mergeFeeLines([lg({ student_number: 'S5', amount_due: 200, amount_paid: 0, fee_type: 'mensuel' })], []);
  assert.equal(m.lines.length, 1); assert.equal(m.lines[0].fee, 'واجب التمدرس');
});
t('same student, different fee type in same month are two lines', () => {
  const m = A.mergeFeeLines([], [
    ob({ student_number: 'S6', period_key: '2026-10', period_start: '2026-10-01', amount_due: 400 }),
    ob({ student_number: 'S6', period_key: '2026-10', period_start: '2026-10-01', amount_due: 150, fee_type: 'واجب النقل' })]);
  assert.equal(m.lines.length, 2);
  const k = A.financeKpis(m.lines, TODAY); assert.equal(k.multiDebtors.length, 1); assert.equal(k.debtStudents, 1);
});
t('future periods are "expected", never debt, never in the rate', () => {
  const m = A.mergeFeeLines([], [
    ob({ student_number: 'S7', period_key: '2026-10', period_start: '2026-10-01', amount_due: 400, amount_paid: 400, status: 'paid' }),
    ob({ student_number: 'S7', period_key: '2027-01', period_start: '2027-01-01', amount_due: 400 })]);
  const k = A.financeKpis(m.lines, TODAY);
  assert.equal(k.debt, 0); assert.equal(k.expected, 400); assert.equal(k.rate, 100); assert.equal(k.due, 800);
});
t('collection rate = collected / matured dues; null with no matured dues', () => {
  const m = A.mergeFeeLines([], [ob({ student_number: 'S8', period_key: '2026-10', period_start: '2026-10-01', amount_due: 400, amount_paid: 100 })]);
  assert.equal(A.financeKpis(m.lines, TODAY).rate, 25);
  assert.equal(A.financeKpis([], TODAY).rate, null);
});
t('aging buckets measured from period_start', () => {
  const mk = (start, num) => ob({ student_number: num, period_key: start.slice(0, 7), period_start: start, amount_due: 100 });
  const m = A.mergeFeeLines([], [mk('2026-11-16', 'a'), mk('2026-11-01', 'b'), mk('2026-10-01', 'c'), mk('2026-09-01', 'd'), mk('2026-06-01', 'e')]);
  const g = A.financeKpis(m.lines, TODAY).aging;
  // days: a=0 current, b=15 -> d30, c=46 -> d60, d=76 -> d90, e=168 -> over90
  assert.deepEqual(g, { current: 100, d30: 100, d60: 100, d90: 100, over90: 100 });
});
t('top debtors sorted by total remaining per student', () => {
  const m = A.mergeFeeLines([], [
    ob({ student_number: 'x', student_name: 'X', period_key: '2026-10', period_start: '2026-10-01', amount_due: 100 }),
    ob({ student_number: 'y', student_name: 'Y', period_key: '2026-10', period_start: '2026-10-01', amount_due: 300 }),
    ob({ student_number: 'x', student_name: 'X', period_key: '2026-09', period_start: '2026-09-01', amount_due: 250 })]);
  const d = A.financeKpis(m.lines, TODAY).debtors; assert.equal(d[0].number, 'x'); assert.equal(d[0].debt, 350);
});
t('filters: class, fee type, payment state, date range', () => {
  const m = A.mergeFeeLines([], [
    ob({ student_number: 'a', class_name: 'A1', period_key: '2026-10', period_start: '2026-10-01', amount_due: 100, amount_paid: 100, status: 'paid' }),
    ob({ student_number: 'b', class_name: 'A2', period_key: '2026-11', period_start: '2026-11-01', amount_due: 100, fee_type: 'واجب النقل' })]);
  assert.equal(A.filterLines(m.lines, { className: 'A1' }, TODAY).length, 1);
  assert.equal(A.filterLines(m.lines, { fee: 'واجب النقل' }, TODAY).length, 1);
  assert.equal(A.filterLines(m.lines, { pay: 'paid' }, TODAY).length, 1);
  assert.equal(A.filterLines(m.lines, { from: '2026-11-01', to: '2026-11-30' }, TODAY).length, 1);
});
t('previous range has equal length and ends the day before', () => {
  assert.deepEqual(A.previousRange('2026-10-16', '2026-11-15'), { from: '2026-09-15', to: '2026-10-15' });
  assert.equal(A.previousRange('', ''), null);
});
t('pctChange: not comparable when previous is 0', () => {
  assert.equal(A.pctChange(10, 0), null); assert.equal(A.pctChange(120, 100), 20);
});
t('attendance rate counts present+late; excused is an absence; empty = null', () => {
  const rows = [{ status: 'present' }, { status: 'late' }, { status: 'absent' }, { status: 'excused' }].map((r, i) => ({ ...r, student_number: 's' + i, att_date: '2026-11-02', class_name: 'A1' }));
  const k = A.attendanceKpis(rows); assert.equal(k.rate, 50); assert.equal(k.absent, 1); assert.equal(k.excused, 1);
  assert.equal(A.attendanceKpis([]).rate, null);
});
t('absence threshold uses unexcused absences only', () => {
  const rows = [];
  for (let i = 0; i < 3; i++) rows.push({ status: 'absent', student_number: 'a', student_name: 'A', att_date: `2026-11-0${i + 2}` });
  for (let i = 0; i < 5; i++) rows.push({ status: 'excused', student_number: 'b', student_name: 'B', att_date: `2026-11-0${i + 2}` });
  const over = A.absenceOverThreshold(A.attendanceKpis(rows), 3); assert.equal(over.length, 1); assert.equal(over[0].number, 'a');
});
t('expenses: totals/category/month, ignores non-positive amounts', () => {
  const k = A.expensesKpis([{ category: 'x', amount: 100, expense_date: '2026-10-05' }, { category: 'x', amount: 50, expense_date: '2026-11-05' }, { category: 'y', amount: 0, expense_date: '2026-11-05' }]);
  assert.equal(k.total, 150); assert.equal(k.byCategory.x, 150); assert.equal(k.byMonth['2026-11'], 50); assert.equal(k.count, 2);
});
t('incidents: open, no-action, repeat students', () => {
  const k = A.incidentsKpis([{ student_id: 1, status: 'open', type: 'تأخر' }, { student_id: 1, status: 'closed', type: 'تأخر', action_taken: 'إنذار' }, { student_id: 2, status: 'closed', type: 'عنف', action_taken: 'x' }]);
  assert.equal(k.total, 3); assert.equal(k.open, 1); assert.equal(k.noAction, 1); assert.equal(k.repeat, 1); assert.equal(k.studentCount, 2);
});
t('alerts: collection-drop fires only with enough data AND >=5 pts drop', () => {
  const base = { rate: 70, matured: 30 }, prev = { rate: 80, matured: 30 };
  assert.ok(A.buildAlerts({ fin: { ...base, byClass: {}, aging: { over90: 0 } }, finPrev: prev }).some((a) => a.id === 'collection-drop'));
  assert.ok(!A.buildAlerts({ fin: { rate: 77, matured: 30, byClass: {}, aging: { over90: 0 } }, finPrev: prev }).some((a) => a.id === 'collection-drop'));
  assert.ok(!A.buildAlerts({ fin: { rate: 50, matured: 5, byClass: {}, aging: { over90: 0 } }, finPrev: { rate: 90, matured: 5 } }).some((a) => a.id === 'collection-drop'));
});
t('alerts: nothing fires on empty data', () => {
  assert.equal(A.buildAlerts({}).length, 0);
  const fin = A.financeKpis([], TODAY);
  assert.equal(A.buildAlerts({ fin, finPrev: fin, att: A.attendanceKpis([]), attPrev: A.attendanceKpis([]), exp: A.expensesKpis([]), expPrev: A.expensesKpis([]), inc: A.incidentsKpis([]), missingFee: 0, merge: { overlap: 0 } }).length, 0);
});
t('alerts: expense rise >=20% only when previous > 0', () => {
  assert.ok(A.buildAlerts({ exp: { total: 130 }, expPrev: { total: 100 } }).some((a) => a.id === 'expense-rise'));
  assert.ok(!A.buildAlerts({ exp: { total: 130 }, expPrev: { total: 0 } }).some((a) => a.id === 'expense-rise'));
});
t('class-debt alert needs >=3 classes and >=1.5x average', () => {
  const fin = { byClass: { A: { debt: 900 }, B: { debt: 100 }, C: { debt: 200 } }, aging: { over90: 0 } };
  const al = A.buildAlerts({ fin }); assert.equal(al.filter((a) => a.id === 'class-debt').length, 1); assert.equal(al[0].data.name, 'A');
  assert.equal(A.buildAlerts({ fin: { byClass: { A: { debt: 900 }, B: { debt: 100 } }, aging: { over90: 0 } } }).filter((a) => a.id === 'class-debt').length, 0);
});
t('recommendations carry the real figures', () => {
  const m = A.mergeFeeLines([], [ob({ student_number: 'x', student_name: 'X', period_key: '2026-05', period_start: '2026-05-01', amount_due: 100 })]);
  const fin = A.financeKpis(m.lines, TODAY); const r = A.buildRecommendations({ fin }, []);
  assert.equal(r[0].id, 'chase-aged'); assert.equal(r[0].data.amount, 100); assert.equal(r[0].data.count, 1);
});
console.log(`\n${pass} passed`);
