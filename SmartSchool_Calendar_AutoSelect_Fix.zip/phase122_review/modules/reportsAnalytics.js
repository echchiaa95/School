// ============================================================================
// modules/reportsAnalytics.js — Reports Center (UI layer, pure functions).
// No DOM, no network, no database access. Input = rows returned by the
// EXISTING RPCs (fn_report_payments, fn_report_fee_obligations,
// fn_report_attendance, fn_list_expenses, fn_list_incidents).
// Every indicator has its definition in the comment above its function.
// ============================================================================

export const FEE_TYPES = ['واجب التسجيل', 'واجب التمدرس', 'واجب النقل'];
const DAY = 86400000;
const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
const pad2 = (v) => String(v).padStart(2, '0');

// ---- helpers --------------------------------------------------------------
export function normFee(raw) {
  const s = String(raw ?? '').trim();
  if (!s) return 'واجب التمدرس';
  if (['شهرية', 'شهري', 'mensuel', 'monthly'].includes(s.toLowerCase())) return 'واجب التمدرس';
  return s;
}
export function toDay(value) {
  if (!value) return '';
  const s = String(value).slice(0, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : '';
}
export function daysBetween(fromDay, toDayStr) {
  const a = Date.parse(fromDay + 'T00:00:00Z'), b = Date.parse(toDayStr + 'T00:00:00Z');
  if (Number.isNaN(a) || Number.isNaN(b)) return null;
  return Math.floor((b - a) / DAY);
}
export function addDays(day, delta) {
  return new Date(Date.parse(day + 'T00:00:00Z') + delta * DAY).toISOString().slice(0, 10);
}
/** Previous period of equal length ending the day before `from`. */
export function previousRange(from, to) {
  if (!from || !to) return null;
  const len = daysBetween(from, to);
  if (len === null || len < 0) return null;
  return { from: addDays(from, -(len + 1)), to: addDays(from, -1) };
}
const inRange = (day, from, to) => !!day && (!from || day >= from) && (!to || day <= to);

/** Percent change; null when the base is 0/absent (not comparable). */
export function pctChange(cur, prev) {
  if (prev === null || prev === undefined || !(prev > 0)) return null;
  return ((cur - prev) / prev) * 100;
}

// ---- fee lines (unified legacy + ledger, ledger first) ---------------------
/**
 * One line per (student_number, period YYYY-MM, fee type).
 * Source of truth: ledger obligation when it exists; a legacy `payments` row is
 * used ONLY when no obligation matches the same key (same rule as
 * fn_student_fee_calendar). Matching legacy rows are counted in `overlap`
 * and never added, so nothing is counted twice.
 * waived / zero-due ledger lines are excluded from dues.
 */
export function mergeFeeLines(legacy = [], ledger = []) {
  const lines = [];
  const keys = new Set();
  let waived = 0;
  const waivedLines = [];
  for (const o of ledger) {
    const fee = normFee(o.fee_type);
    const period = String(o.period_key || '').slice(0, 7) || String(o.period_start || '').slice(0, 7);
    const number = String(o.student_number ?? o.student_id ?? '');
    keys.add(`${number}|${period}|${fee}`);
    const start = toDay(o.period_start) || (period ? period + '-01' : '');
    if (o.status === 'waived' || n(o.amount_due) <= 0) {
      waived++;
      waivedLines.push({ src: 'ledger', name: o.student_name || '', number, cls: o.class_name || '', fee, period, start,
        list: n(o.list_amount), discount: n(o.discount_amount), due: 0, paid: 0, transport: !!o.uses_transport, payDate: '', method: '', receipt: '', waived: true });
      continue;
    }
    lines.push({
      src: 'ledger', name: o.student_name || '', number, cls: o.class_name || '', fee, period, start,
      list: n(o.list_amount), discount: n(o.discount_amount), due: n(o.amount_due), paid: n(o.amount_paid),
      transport: !!o.uses_transport, payDate: '', method: '', receipt: '',
    });
  }
  let overlap = 0;
  for (const p of legacy) {
    const fee = normFee(p.fee_type);
    const period = `${p.billing_year}-${pad2(p.billing_month)}`;
    const number = String(p.student_number ?? p.student_id ?? '');
    if (keys.has(`${number}|${period}|${fee}`)) { overlap++; continue; }
    if (n(p.amount_due) <= 0) continue;
    lines.push({
      src: 'legacy', name: p.student_name || '', number, cls: p.class_name || '', fee, period,
      start: `${period}-01`, list: n(p.amount_due), discount: 0, due: n(p.amount_due), paid: n(p.amount_paid), transport: false,
      payDate: toDay(p.payment_date), method: p.method || '', receipt: p.receipt_no || '',
    });
  }
  return { lines, overlap, waived, waivedLines };
}

/** Filter lines by the unified filters (period of due date, class, fee type, payment state). */
export function filterLines(lines, f = {}, today = '') {
  return lines.filter((l) => {
    if (f.from && l.start < f.from) return false;
    if (f.to && l.start > f.to) return false;
    if (f.className && l.cls !== f.className) return false;
    if (f.fee && l.fee !== f.fee) return false;
    if (f.pay) {
      const s = lineState(l, today);
      if (f.pay !== s) return false;
    }
    return true;
  });
}
/** paid | partial | unpaid | future  (partial is never "paid"). */
export function lineState(l, today) {
  if (l.paid >= l.due && l.due > 0) return 'paid';
  if (l.paid > 0) return 'partial';
  if (today && l.start > today) return 'future';
  return 'unpaid';
}

// ---- finance indicators ----------------------------------------------------
/**
 * due            = Σ amount_due (net of discount, already) of non-waived lines
 * collected      = Σ min(amount_paid, amount_due)          (accrual: collected ON dues)
 * dueMatured     = Σ amount_due of lines whose period start <= today
 * collectedMat.  = Σ min(paid, due) over matured lines
 * rate           = collectedMat / dueMatured (null if no matured dues)
 * debt           = Σ max(0, due - paid) over matured lines (partial stays a debt)
 * expected       = Σ max(0, due - paid) over FUTURE lines (expected, NOT collected)
 * discounts      = Σ discount_amount (ledger lines only; legacy rows carry none)
 */
export function financeKpis(lines, today) {
  const k = {
    count: lines.length, due: 0, collected: 0, dueMatured: 0, collectedMatured: 0, debt: 0, expected: 0,
    discounts: 0, listTotal: 0, discountStudents: 0, debtStudents: 0, unpaidLines: 0, partialLines: 0,
    rate: null, matured: 0,
    byFee: {}, byClass: {}, byMonth: {}, aging: { current: 0, d30: 0, d60: 0, d90: 0, over90: 0 },
    debtors: [], multiDebtors: [],
  };
  const debtors = new Map();
  const discStudents = new Set();
  for (const l of lines) {
    const col = Math.min(l.paid, l.due), rem = Math.max(0, l.due - l.paid);
    const isMat = !today || l.start <= today;
    k.due += l.due; k.collected += col; k.listTotal += l.list; k.discounts += l.discount;
    if (l.discount > 0) discStudents.add(l.number);
    const fee = (k.byFee[l.fee] ||= { due: 0, collected: 0, debt: 0 });
    fee.due += l.due; fee.collected += col;
    const month = (k.byMonth[l.period] ||= { due: 0, collected: 0, matured: isMat });
    month.due += l.due; month.collected += col;
    const cls = (k.byClass[l.cls || 'بدون قسم'] ||= { dueMatured: 0, collectedMatured: 0, debt: 0 });
    if (isMat) {
      k.matured++; k.dueMatured += l.due; k.collectedMatured += col; k.debt += rem;
      fee.debt += rem; cls.dueMatured += l.due; cls.collectedMatured += col; cls.debt += rem;
      if (rem > 0) {
        if (l.paid > 0) k.partialLines++; else k.unpaidLines++;
        const d = daysBetween(l.start, today || l.start);
        const b = d === null || d <= 0 ? 'current' : d <= 30 ? 'd30' : d <= 60 ? 'd60' : d <= 90 ? 'd90' : 'over90';
        k.aging[b] += rem;
        const key = l.number || l.name;
        const g = debtors.get(key) || { name: l.name, number: l.number, cls: l.cls, debt: 0, lines: 0, fees: new Set(), maxDays: 0 };
        g.debt += rem; g.lines++; g.fees.add(l.fee); g.maxDays = Math.max(g.maxDays, d || 0);
        debtors.set(key, g);
      }
    } else {
      k.expected += rem;
    }
  }
  k.rate = k.dueMatured > 0 ? (k.collectedMatured / k.dueMatured) * 100 : null;
  k.discountStudents = discStudents.size;
  k.debtors = [...debtors.values()].sort((a, b) => b.debt - a.debt)
    .map((g) => ({ ...g, fees: [...g.fees] }));
  k.debtStudents = k.debtors.length;
  k.multiDebtors = k.debtors.filter((g) => g.fees.length >= 2 || g.lines >= 2);
  return k;
}

// ---- attendance ------------------------------------------------------------
/**
 * rows = fn_report_attendance rows {student_*, class_name, att_date, status}.
 * rate    = (present + late) / all marked records       (null if no records)
 * unexcused = status 'absent' ; excused = status 'excused'
 */
export function attendanceKpis(rows = []) {
  const k = { total: 0, present: 0, absent: 0, late: 0, excused: 0, rate: null, byClass: {}, byStudent: new Map(), byWeekday: [0, 0, 0, 0, 0, 0, 0], weekly: {} };
  for (const r of rows) {
    const st = r.status;
    if (!['present', 'absent', 'late', 'excused'].includes(st)) continue;
    k.total++; k[st]++;
    const cls = (k.byClass[r.class_name || 'بدون قسم'] ||= { total: 0, present: 0, absent: 0, late: 0, excused: 0 });
    cls.total++; cls[st]++;
    const sk = `${r.student_number || ''}|${r.student_name || ''}`;
    const s = k.byStudent.get(sk) || { name: r.student_name, number: r.student_number, cls: r.class_name, absent: 0, excused: 0, late: 0, total: 0 };
    s.total++; s[st] = (s[st] || 0) + 1; k.byStudent.set(sk, s);
    const day = toDay(r.att_date);
    if (day) {
      if (st === 'absent') k.byWeekday[new Date(day + 'T00:00:00Z').getUTCDay()]++;
      const wk = weekStart(day);
      const w = (k.weekly[wk] ||= { total: 0, ok: 0 });
      w.total++; if (st === 'present' || st === 'late') w.ok++;
    }
  }
  k.rate = k.total > 0 ? ((k.present + k.late) / k.total) * 100 : null;
  k.unexcusedRate = k.total > 0 ? (k.absent / k.total) * 100 : null;
  k.students = [...k.byStudent.values()];
  return k;
}
export function weekStart(day) {
  const d = new Date(day + 'T00:00:00Z');
  const back = (d.getUTCDay() + 6) % 7; // Monday start
  return addDays(day, -back);
}
/** Students whose unexcused absences reach `threshold` (same notion as fn_attendance_absence_alerts). */
export function absenceOverThreshold(att, threshold = 3) {
  return att.students.filter((s) => s.absent >= threshold).sort((a, b) => b.absent - a.absent);
}
/** Weekday with a disproportionate share of absences (>=30% and >=10 absences). */
export function weekdayPattern(att) {
  const total = att.absent;
  if (total < 10) return null;
  let max = 0, idx = -1;
  att.byWeekday.forEach((v, i) => { if (v > max) { max = v; idx = i; } });
  return max / total >= 0.3 ? { weekday: idx, count: max, share: (max / total) * 100 } : null;
}

// ---- expenses --------------------------------------------------------------
/** rows = fn_list_expenses {category, amount, expense_date, recorder_name}. */
export function expensesKpis(rows = []) {
  const k = { total: 0, count: 0, byCategory: {}, byMonth: {}, byRecorder: {} };
  for (const r of rows) {
    const a = n(r.amount); if (a <= 0) continue;
    const day = toDay(r.expense_date);
    k.total += a; k.count++;
    const c = r.category || 'غير مصنف';
    k.byCategory[c] = (k.byCategory[c] || 0) + a;
    if (day) k.byMonth[day.slice(0, 7)] = (k.byMonth[day.slice(0, 7)] || 0) + a;
    const who = r.recorder_name || '—';
    k.byRecorder[who] = (k.byRecorder[who] || 0) + a;
  }
  return k;
}
export const filterByDay = (rows, field, from, to) => rows.filter((r) => inRange(toDay(r[field]), from, to));

// ---- incidents -------------------------------------------------------------
/** rows = fn_list_incidents {type, status open|closed, action_taken, occurred_at, student_id}. */
export function incidentsKpis(rows = []) {
  const k = { total: 0, open: 0, noAction: 0, byType: {}, students: new Set(), repeat: 0 };
  const per = new Map();
  for (const r of rows) {
    k.total++;
    if (r.status === 'open') k.open++;
    if (!String(r.action_taken || '').trim()) k.noAction++;
    const t = String(r.type || 'غير محدد').trim().replace(/\s+/g, ' ');
    k.byType[t] = (k.byType[t] || 0) + 1;
    const id = r.student_id || r.student_name;
    if (id) { k.students.add(id); per.set(id, (per.get(id) || 0) + 1); }
  }
  k.studentCount = k.students.size;
  k.repeat = [...per.values()].filter((v) => v >= 2).length;
  return k;
}

// ---- alerts & recommendations ---------------------------------------------
export const THRESHOLDS = {
  collectionDropPts: 5, minMaturedLines: 20, classDebtFactor: 1.5, minClasses: 3,
  unexcusedRisePts: 2, minAttendanceRecords: 200, expenseRisePct: 20, absenceThreshold: 3,
};
/**
 * Each alert = {id, level:'danger'|'warn'|'info', data:{...}} — present ONLY when its
 * numeric condition holds on real rows. Text is produced by the UI from `data`.
 */
export function buildAlerts(ctx, th = THRESHOLDS) {
  const out = [];
  const { fin, finPrev, att, attPrev, exp, expPrev, inc, merge, missingFee } = ctx;
  if (fin && finPrev && fin.rate !== null && finPrev.rate !== null
      && fin.matured >= th.minMaturedLines && finPrev.matured >= th.minMaturedLines
      && finPrev.rate - fin.rate >= th.collectionDropPts) {
    out.push({ id: 'collection-drop', level: 'danger', data: { cur: fin.rate, prev: finPrev.rate, diff: finPrev.rate - fin.rate } });
  }
  if (fin) {
    const cls = Object.entries(fin.byClass).filter(([, v]) => v.debt > 0);
    const all = Object.entries(fin.byClass);
    if (all.length >= th.minClasses) {
      const avg = all.reduce((a, [, v]) => a + v.debt, 0) / all.length;
      cls.filter(([, v]) => avg > 0 && v.debt >= avg * th.classDebtFactor)
        .sort((a, b) => b[1].debt - a[1].debt).slice(0, 3)
        .forEach(([name, v]) => out.push({ id: 'class-debt', level: 'warn', data: { name, debt: v.debt, avg } }));
    }
    if (fin.aging.over90 > 0) out.push({ id: 'aged-debt', level: 'warn', data: { amount: fin.aging.over90 } });
  }
  if (att && attPrev && att.total >= th.minAttendanceRecords && attPrev.total >= th.minAttendanceRecords
      && att.unexcusedRate - attPrev.unexcusedRate >= th.unexcusedRisePts) {
    out.push({ id: 'absence-rise', level: 'warn', data: { cur: att.unexcusedRate, prev: attPrev.unexcusedRate } });
  }
  if (att) {
    const over = absenceOverThreshold(att, th.absenceThreshold);
    if (over.length) out.push({ id: 'absence-threshold', level: 'warn', data: { count: over.length, threshold: th.absenceThreshold } });
  }
  if (exp && expPrev && expPrev.total > 0) {
    const ch = pctChange(exp.total, expPrev.total);
    if (ch !== null && ch >= th.expenseRisePct) out.push({ id: 'expense-rise', level: 'warn', data: { cur: exp.total, prev: expPrev.total, pct: ch } });
  }
  if (inc && inc.open > 0) out.push({ id: 'open-incidents', level: 'info', data: { open: inc.open, noAction: inc.noAction } });
  if (missingFee > 0) out.push({ id: 'missing-fee-lines', level: 'info', data: { count: missingFee } });
  if (merge && merge.overlap > 0) out.push({ id: 'legacy-overlap', level: 'info', data: { count: merge.overlap } });
  return out;
}
/** Recommendations are derived from fired alerts / indicators, always with the figures. */
export function buildRecommendations(ctx, alerts) {
  const rec = [];
  const { fin, att, inc } = ctx;
  const has = (id) => alerts.find((a) => a.id === id);
  if (fin && fin.debtors.length) {
    const old = fin.debtors.filter((d) => d.maxDays > 90);
    if (old.length) rec.push({ id: 'chase-aged', data: { count: old.length, amount: old.reduce((a, d) => a + d.debt, 0) }, open: 'rp-unpaid' });
    else rec.push({ id: 'chase-top', data: { count: Math.min(10, fin.debtors.length), amount: fin.debtors.slice(0, 10).reduce((a, d) => a + d.debt, 0) }, open: 'rp-unpaid' });
  }
  const cd = alerts.filter((a) => a.id === 'class-debt');
  if (cd.length) rec.push({ id: 'review-classes', data: { names: cd.map((a) => a.data.name) }, open: 'rp-payment-summary' });
  if (fin && fin.partialLines > 0) rec.push({ id: 'complete-partial', data: { count: fin.partialLines }, open: 'rp-unpaid' });
  if (has('absence-threshold')) rec.push({ id: 'follow-absent', data: has('absence-threshold').data, open: 'rp-attendance' });
  if (has('absence-rise')) rec.push({ id: 'absence-cause', data: has('absence-rise').data, open: 'rp-attendance' });
  if (att) { const p = weekdayPattern(att); if (p) rec.push({ id: 'weekday-pattern', data: p, open: 'rp-attendance' }); }
  if (has('expense-rise')) rec.push({ id: 'review-expenses', data: has('expense-rise').data, open: 'rp-expenses' });
  if (inc && inc.open > 0) rec.push({ id: 'close-incidents', data: { open: inc.open }, open: 'rp-incidents' });
  return rec;
}
