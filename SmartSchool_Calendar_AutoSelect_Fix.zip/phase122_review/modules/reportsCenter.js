// ============================================================================
// modules/reportsCenter.js — Reports Center dashboard (UI layer only).
// Reads through the EXISTING RPC wrappers handed in by adminConsole.js.
// No new RPC, no DB change. All numbers come from reportsAnalytics.js.
// Texts are bilingual (ar/fr) here because they embed live figures.
// ============================================================================
import * as A from './reportsAnalytics.js';

const LANG = () => (window.ssLang === 'fr' ? 'fr' : 'ar');
const esc = (v) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');

// ---- dictionary ------------------------------------------------------------
const L = {
  title: ['لوحة القيادة التنفيذية', 'Tableau de bord exécutif'],
  period: ['الفترة', 'Période'],
  vsPrev: ['مقارنة بالفترة السابقة', 'vs période précédente'],
  noData: ['لا توجد بيانات', 'Aucune donnée'],
  na: ['غير متاح', 'Non disponible'],
  notComparable: ['غير قابلة للمقارنة', 'Non comparable'],
  loading: ['جارٍ تحميل المؤشرات…', 'Chargement des indicateurs…'],
  retry: ['تحديث', 'Actualiser'],
  kStudents: ['التلاميذ النشطون', 'Élèves actifs'],
  kDue: ['إجمالي المستحقات', 'Total des créances'],
  kCollected: ['إجمالي التحصيل', 'Total encaissé'],
  kDebt: ['الديون المتبقية', 'Impayés restants'],
  kRate: ['نسبة التحصيل', "Taux d'encaissement"],
  kDiscounts: ['إجمالي التخفيضات', 'Total des remises'],
  kExpenses: ['إجمالي المصاريف', 'Total des dépenses'],
  kAttendance: ['نسبة الحضور', 'Taux de présence'],
  beneficiaries: ['مستفيد', 'bénéficiaire(s)'],
  debtors: ['تلميذ مدين', 'élève(s) débiteur(s)'],
  expectedLbl: ['متوقع تحصيله (مستحقات لم يحل أجلها)', 'À encaisser (échéances futures)'],
  records: ['سجل', 'enregistrement(s)'],
  open: ['عرض السجلات', 'Voir les détails'],
  cMonthly: ['التحصيل حسب شهر الاستحقاق', 'Encaissement par mois d\'échéance'],
  cMonthlyNote: ['المستحق مقابل المحصّل على نفس الشهر (وليس تاريخ الدفع الفعلي)', 'Dû vs encaissé sur le même mois (et non la date de paiement)'],
  due: ['المستحق', 'Dû'], collected: ['المحصّل', 'Encaissé'],
  cFee: ['توزيع التحصيل حسب نوع الرسم', 'Encaissement par type de frais'],
  cClassDebt: ['الديون حسب القسم', 'Impayés par classe'],
  cAttendance: ['تطور نسبة الحضور أسبوعياً', 'Évolution hebdomadaire de la présence'],
  cExpenses: ['توزيع المصاريف حسب التصنيف', 'Dépenses par catégorie'],
  needWeeks: ['يلزم أسبوعان على الأقل من البيانات', 'Au moins deux semaines de données requises'],
  aging: ['أعمار الديون', 'Ancienneté des impayés'],
  a0: ['غير متأخر', 'Non échu'], a30: ['1–30 يوماً', '1–30 j'], a60: ['31–60 يوماً', '31–60 j'], a90: ['61–90 يوماً', '61–90 j'], a91: ['أكثر من 90 يوماً', '> 90 j'],
  top10: ['أكبر 10 ديون مستحقة', '10 plus gros impayés'],
  colStudent: ['التلميذ', 'Élève'], colClass: ['القسم', 'Classe'], colDebt: ['المتبقي', 'Reste dû'], colLate: ['أيام التأخر', 'Jours de retard'], colLines: ['عدد المستحقات', 'Échéances'],
  alerts: ['التنبيهات الإدارية', 'Alertes de gestion'],
  recs: ['التوصيات', 'Recommandations'],
  noAlerts: ['لا توجد تنبيهات مستوفية للمعايير في هذه الفترة.', 'Aucune alerte ne répond aux critères sur cette période.'],
  noRecs: ['لا توجد توصيات: لا مؤشرات تستدعي إجراءً حالياً.', 'Aucune recommandation : aucun indicateur ne requiert d\'action.'],
  quality: ['جودة البيانات', 'Qualité des données'],
  srcFail: ['تعذر تحميل مصدر البيانات:', 'Source indisponible :'],
  srcLegacy: ['سجلات قديمة', 'ancien registre'],
  truncated: ['القائمة مقتطعة عند الحد الأقصى؛ الأرقام قد تكون ناقصة.', 'Liste tronquée au maximum ; les chiffres peuvent être incomplets.'],
  fmtOnlyAccrual: ['تُحسب النسبة على المستحقات التي حلّ أجلها فقط.', 'Le taux porte uniquement sur les échéances arrivées à terme.'],
  sInfo: ['ملاحظة', 'Info'], sWarn: ['تنبيه', 'Attention'], sDanger: ['مهم', 'Important'],
};
const T = (k) => (L[k] ? L[k][LANG() === 'fr' ? 1 : 0] : k);
const WEEKDAYS = {
  ar: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
  fr: ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'],
};
const pct = (v) => (v === null || v === undefined ? '—' : `${v.toFixed(1)}%`);

// ---- alert / recommendation messages (live figures) ---------------------------
export function alertText(a, money) {
  const fr = LANG() === 'fr', d = a.data;
  switch (a.id) {
    case 'collection-drop': return fr ? `Le taux d'encaissement passe de ${pct(d.prev)} à ${pct(d.cur)} (−${d.diff.toFixed(1)} pts) par rapport à la période précédente.` : `انخفضت نسبة التحصيل من ${pct(d.prev)} إلى ${pct(d.cur)} (−${d.diff.toFixed(1)} نقطة) مقارنة بالفترة السابقة.`;
    case 'class-debt': return fr ? `Classe ${d.name} : impayés ${money(d.debt)}, soit ≥ 1,5× la moyenne des classes (${money(d.avg)}).` : `ديون القسم ${d.name} بلغت ${money(d.debt)}، أي ≥ 1.5 ضعف متوسط الأقسام (${money(d.avg)}).`;
    case 'aged-debt': return fr ? `${money(d.amount)} d'impayés ont plus de 90 jours de retard.` : `${money(d.amount)} من الديون متأخرة أكثر من 90 يوماً.`;
    case 'absence-rise': return fr ? `Les absences non justifiées passent de ${pct(d.prev)} à ${pct(d.cur)} des enregistrements.` : `ارتفع الغياب غير المبرر من ${pct(d.prev)} إلى ${pct(d.cur)} من السجلات.`;
    case 'absence-threshold': return fr ? `${d.count} élève(s) ont ${d.threshold} absences non justifiées ou plus.` : `${d.count} تلميذاً بلغوا ${d.threshold} غيابات غير مبررة أو أكثر.`;
    case 'expense-rise': return fr ? `Dépenses : ${money(d.cur)} contre ${money(d.prev)} (+${d.pct.toFixed(1)}%).` : `المصاريف ${money(d.cur)} مقابل ${money(d.prev)} (+${d.pct.toFixed(1)}%).`;
    case 'open-incidents': return fr ? `${d.open} incident(s) non clôturé(s), dont ${d.noAction} sans mesure enregistrée.` : `${d.open} مخالفة غير مغلقة، منها ${d.noAction} بلا إجراء مسجل.`;
    case 'missing-fee-lines': return fr ? `${d.count} élève(s) actif(s) sans aucune créance enregistrée : leurs montants ne figurent pas dans les totaux.` : `${d.count} تلميذاً نشطاً بلا أي مستحقات مسجلة: مبالغهم غير داخلة في الإجماليات.`;
    case 'legacy-overlap': return fr ? `${d.count} ligne(s) de l'ancien registre ont une échéance équivalente dans le nouveau registre : comptées une seule fois.` : `${d.count} سجلاً من الجدول القديم يقابله مستحق في السجل الجديد: تم احتسابها مرة واحدة فقط.`;
    default: return '';
  }
}
export function recText(r, money) {
  const fr = LANG() === 'fr', d = r.data;
  switch (r.id) {
    case 'chase-aged': return fr ? `Prioriser le suivi de ${d.count} élève(s) en retard de plus de 90 jours (${money(d.amount)}).` : `أعطِ الأولوية لمتابعة ${d.count} تلميذاً متأخراً أكثر من 90 يوماً (${money(d.amount)}).`;
    case 'chase-top': return fr ? `Contacter les ${d.count} plus gros débiteurs (${money(d.amount)} au total).` : `تواصل مع أكبر ${d.count} مدينين (مجموعهم ${money(d.amount)}).`;
    case 'review-classes': return fr ? `Examiner l'encaissement des classes : ${d.names.join(', ')}.` : `راجع التحصيل في الأقسام: ${d.names.join('، ')}.`;
    case 'complete-partial': return fr ? `${d.count} échéance(s) partiellement payée(s) : demander le solde restant.` : `${d.count} مستحقاً مؤدى جزئياً: اطلب تسوية الباقي.`;
    case 'follow-absent': return fr ? `Suivre les ${d.count} élève(s) ayant dépassé ${d.threshold} absences non justifiées.` : `تابع ${d.count} تلميذاً تجاوزوا ${d.threshold} غيابات غير مبررة.`;
    case 'absence-cause': return fr ? `Analyser la hausse des absences non justifiées (${pct(d.prev)} → ${pct(d.cur)}).` : `حلّل أسباب ارتفاع الغياب غير المبرر (${pct(d.prev)} ← ${pct(d.cur)}).`;
    case 'weekday-pattern': return fr ? `${d.share.toFixed(0)}% des absences tombent le même jour (${WEEKDAYS.fr[d.weekday]}) : vérifier la cause.` : `${d.share.toFixed(0)}% من الغيابات تقع يوم ${WEEKDAYS.ar[d.weekday]}: افحص السبب.`;
    case 'review-expenses': return fr ? `Passer en revue les postes de dépense en hausse (+${d.pct.toFixed(1)}%).` : `راجع بنود الإنفاق التي ارتفعت (+${d.pct.toFixed(1)}%).`;
    case 'close-incidents': return fr ? `Traiter et clôturer ${d.open} incident(s) ouvert(s).` : `عالج وأغلق ${d.open} مخالفة مفتوحة.`;
    default: return '';
  }
}

// ---- tiny chart helpers (HTML/CSS bars are RTL-safe; SVG only for donut/line) ----
const PALETTE = ['#1d4265', '#c9a227', '#15803d', '#7c3aed', '#0e7490', '#b45309', '#64748b'];
export function hbars(items, fmt) {
  const max = Math.max(...items.map((i) => i.value), 0);
  if (!items.length || max <= 0) return `<p class="rc-empty">${esc(T('noData'))}</p>`;
  return `<div class="rc-hbars">${items.map((i) => `
    <div class="rc-hbar" title="${esc(i.label)}: ${esc(fmt(i.value))}">
      <span class="rc-hbar-label">${esc(i.label)}</span>
      <span class="rc-hbar-track"><span class="rc-hbar-fill" style="width:${Math.max(2, (i.value / max) * 100).toFixed(1)}%"></span></span>
      <span class="rc-hbar-val">${esc(fmt(i.value))}</span>
    </div>`).join('')}</div>`;
}
function monthlyBars(byMonth, fmt) {
  const keys = Object.keys(byMonth).sort();
  const max = Math.max(...keys.map((k) => byMonth[k].due), 0);
  if (!keys.length || max <= 0) return `<p class="rc-empty">${esc(T('noData'))}</p>`;
  return `<div class="rc-cols" role="img" aria-label="${esc(T('cMonthly'))}">${keys.map((k) => {
    const m = byMonth[k], hd = (m.due / max) * 100, hc = (m.collected / max) * 100;
    const [y, mo] = k.split('-');
    return `<div class="rc-col" title="${esc(k)} — ${esc(T('due'))}: ${esc(fmt(m.due))} / ${esc(T('collected'))}: ${esc(fmt(m.collected))}">
      <div class="rc-col-bars"><span class="rc-bar due ${m.matured ? '' : 'future'}" style="height:${hd.toFixed(1)}%"></span><span class="rc-bar paid" style="height:${hc.toFixed(1)}%"></span></div>
      <span class="rc-col-label">${esc(mo)}/${esc(y.slice(2))}</span></div>`;
  }).join('')}</div>
  <div class="rc-legend"><span><i class="due"></i>${esc(T('due'))}</span><span><i class="paid"></i>${esc(T('collected'))}</span></div>`;
}
function donut(items, fmt) {
  const total = items.reduce((a, i) => a + i.value, 0);
  if (!items.length || total <= 0) return `<p class="rc-empty">${esc(T('noData'))}</p>`;
  const R = 15.9155; let off = 25; // circumference 100
  const segs = items.map((i, idx) => {
    const p = (i.value / total) * 100;
    const s = `<circle r="${R}" cx="21" cy="21" fill="none" stroke="${PALETTE[idx % PALETTE.length]}" stroke-width="6" stroke-dasharray="${p.toFixed(2)} ${(100 - p).toFixed(2)}" stroke-dashoffset="${off.toFixed(2)}"><title>${esc(i.label)}: ${esc(fmt(i.value))} (${p.toFixed(1)}%)</title></circle>`;
    off -= p; return s;
  }).join('');
  return `<div class="rc-donut"><svg viewBox="0 0 42 42" role="img" aria-label="donut" style="direction:ltr">${segs}</svg>
    <ul class="rc-donut-legend">${items.map((i, idx) => `<li><i style="background:${PALETTE[idx % PALETTE.length]}"></i><span>${esc(i.label)}</span><b>${((i.value / total) * 100).toFixed(1)}%</b></li>`).join('')}</ul></div>`;
}
function lineChart(points) {
  if (points.length < 2) return `<p class="rc-empty">${esc(T('needWeeks'))}</p>`;
  const W = 300, H = 110, pad = 14;
  const vals = points.map((p) => p.value), lo = Math.min(...vals, 100) === 100 ? Math.min(...vals) - 5 : Math.min(...vals) - 2, hi = Math.min(100, Math.max(...vals) + 2);
  const lo2 = Math.min(lo, hi - 5);
  const x = (i) => pad + (i * (W - 2 * pad)) / (points.length - 1);
  const y = (v) => H - pad - ((v - lo2) / (hi - lo2 || 1)) * (H - 2 * pad);
  const path = points.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`).join(' ');
  return `<svg class="rc-line" viewBox="0 0 ${W} ${H}" role="img" aria-label="trend" style="direction:ltr"><path d="${path}" fill="none" stroke="#1d4265" stroke-width="2"/>${points.map((p, i) => `<circle cx="${x(i).toFixed(1)}" cy="${y(p.value).toFixed(1)}" r="3" fill="#c9a227"><title>${esc(p.label)}: ${p.value.toFixed(1)}%</title></circle>`).join('')}</svg>
  <div class="rc-line-axis"><span>${esc(points[0].label)}</span><span>${esc(points[points.length - 1].label)}</span></div>`;
}

// ---- KPI card -----------------------------------------------------------------
function delta(cur, prev, goodWhen, fmtDiff) {
  if (cur === null || cur === undefined) return '';
  if (prev === null || prev === undefined) return `<span class="rc-delta flat">${esc(T('vsPrev'))}: ${esc(T('notComparable'))}</span>`;
  const diff = cur - prev;
  if (Math.abs(diff) < 1e-9) return `<span class="rc-delta flat">= ${esc(T('vsPrev'))}</span>`;
  const up = diff > 0, good = goodWhen === 'up' ? up : !up;
  return `<span class="rc-delta ${good ? 'good' : 'bad'}">${up ? '▲' : '▼'} ${esc(fmtDiff(diff))} <small>${esc(T('vsPrev'))}</small></span>`;
}
function kpiCard({ label, value, sub = '', dlt = '', open = '', tone = '' }) {
  return `<button type="button" class="rc-kpi ${tone}" ${open ? `data-open="${open}"` : 'disabled'} aria-label="${esc(label)}">
    <span class="rc-kpi-label">${esc(label)}</span><span class="rc-kpi-value">${esc(value)}</span>
    ${sub ? `<span class="rc-kpi-sub">${esc(sub)}</span>` : ''}${dlt}</button>`;
}
const card = (title, body, note = '', open = '') => `<section class="rc-card"><header><h4>${esc(title)}</h4>${open ? `<button type="button" class="rc-link" data-open="${open}">${esc(T('open'))}</button>` : ''}</header>${note ? `<p class="rc-note">${esc(note)}</p>` : ''}${body}</section>`;

// ---- main ---------------------------------------------------------------------
/**
 * deps: {
 *   host: HTMLElement,
 *   getFilters(): {from,to,classId,className,fee,pay,yearId},
 *   fetch: { payments(), ledger(filters), attendance(from,to,classId), expenses(), incidents(), students(classId) },
 *   money(v), today(): 'YYYY-MM-DD', onOpen(buttonId)
 * }
 * each fetcher returns {ok:boolean, data:any[], limit?:number, error?:string}
 */
export function createReportsCenter(deps) {
  const { host, getFilters, fetch: F, onOpen } = deps;
  // French UI shows the dirham as "DH" (same wording as the i18n dictionary).
  const money = (v) => (LANG() === 'fr' ? deps.money(v).replace('د.م.', 'DH') : deps.money(v));
  const cacheStore = new Map();
  let seq = 0;
  const cached = (key, fn) => { if (!cacheStore.has(key)) cacheStore.set(key, fn().catch((e) => ({ ok: false, error: e?.message || String(e), data: [] }))); return cacheStore.get(key); };

  host.addEventListener('click', (e) => {
    const b = e.target.closest('[data-open]');
    if (b && !b.disabled) onOpen(b.dataset.open);
    if (e.target.closest('[data-rc-refresh]')) { cacheStore.clear(); refresh(); }
  });

  async function refresh() {
    const my = ++seq;
    host.innerHTML = `<p class="rc-empty">${esc(T('loading'))}</p>`;
    const f = getFilters();
    const today = deps.today();
    const prev = A.previousRange(f.from, f.to);
    const key = (x) => JSON.stringify(x);
    const [pay, led, att, attP, exp, inc, stu] = await Promise.all([
      cached('pay', () => F.payments()),
      cached('led' + key([f.yearId, f.classId]), () => F.ledger(f)),
      cached('att' + key([f.from, f.to, f.classId]), () => F.attendance(f.from, f.to, f.classId)),
      prev ? cached('att' + key([prev.from, prev.to, f.classId]), () => F.attendance(prev.from, prev.to, f.classId)) : Promise.resolve({ ok: true, data: [] }),
      cached('exp', () => F.expenses()),
      cached('inc', () => F.incidents()),
      cached('stu' + key(f.classId), () => F.students(f.classId)),
    ]);
    if (my !== seq) return; // a newer refresh superseded this one

    const fails = [];
    const need = (r, name) => { if (!r.ok) fails.push(name); return r.ok ? r.data : []; };
    const payRows = need(pay, T('srcLegacy')), ledRows = need(led, 'fee_obligations');
    const attRows = need(att, 'attendance'), attPRows = need(attP, 'attendance');
    const expRowsAll = need(exp, 'expenses'), incRowsAll = need(inc, 'incidents'), stuRows = need(stu, 'students');

    // finance
    const legacyScoped = f.className ? payRows.filter((p) => (p.class_name || '') === f.className) : payRows;
    const merged = A.mergeFeeLines(legacyScoped, ledRows);
    const base = { fee: f.fee, pay: f.pay, className: f.className };
    const linesCur = A.filterLines(merged.lines, { ...base, from: f.from, to: f.to }, today);
    const linesPrev = prev ? A.filterLines(merged.lines, { ...base, from: prev.from, to: prev.to }, today) : [];
    const fin = A.financeKpis(linesCur, today);
    const finPrev = prev ? A.financeKpis(linesPrev, today) : null;
    const finHasData = pay.ok || led.ok;

    // attendance / expenses / incidents
    const att$ = att.ok ? A.attendanceKpis(attRows) : null;
    const attP$ = attP.ok && prev ? A.attendanceKpis(attPRows) : null;
    const expCur = exp.ok ? A.expensesKpis(A.filterByDay(expRowsAll, 'expense_date', f.from, f.to)) : null;
    const expPrev = exp.ok && prev ? A.expensesKpis(A.filterByDay(expRowsAll, 'expense_date', prev.from, prev.to)) : null;
    const incCur = inc.ok ? A.incidentsKpis(A.filterByDay(incRowsAll, 'occurred_at', f.from, f.to)) : null;
    const incOpenAll = inc.ok ? A.incidentsKpis(incRowsAll) : null;

    // students
    const active = stu.ok ? stuRows.filter((r) => r.resultType === 'AUTHORIZED') : [];
    const withLines = new Set(merged.lines.map((l) => l.number));
    const missingFee = stu.ok && (pay.ok || led.ok) ? active.filter((r) => !withLines.has(String(r.student?.studentNumber ?? ''))).length : 0;

    const ctx = { fin: finHasData ? fin : null, finPrev: finHasData ? finPrev : null, att: att$, attPrev: attP$, exp: expCur, expPrev, inc: incOpenAll, merge: merged, missingFee };
    const alerts = A.buildAlerts(ctx);
    const recs = A.buildRecommendations(ctx, alerts);

    host.innerHTML = render({ f, prev, fin, finPrev, finHasData, att$, attP$, expCur, expPrev, incCur, active, stu, stuLimit: stu.limit, alerts, recs, fails, merged, exp, inc });
  }

  function render(s) {
    const { f, fin, finPrev, finHasData, att$, attP$, expCur, expPrev, active, stu, alerts, recs, fails } = s;
    const noFin = !finHasData || fin.count === 0;
    const sub = (txt) => txt;
    const kpis = [
      kpiCard({ label: T('kStudents'), value: stu.ok ? (stu.limit && active.length >= stu.limit ? `${active.length}+` : String(active.length)) : '—', open: 'rp-students' }),
      kpiCard({ label: T('kDue'), value: noFin ? '—' : money(fin.due), sub: noFin ? T('noData') : '', open: 'rp-fee-obligations',
        dlt: noFin ? '' : delta(fin.due, finPrev && finPrev.count ? finPrev.due : null, 'up', (d) => money(Math.abs(d))) }),
      kpiCard({ label: T('kCollected'), value: noFin ? '—' : money(fin.collected), open: 'rp-payments',
        dlt: noFin ? '' : delta(fin.collected, finPrev && finPrev.count ? finPrev.collected : null, 'up', (d) => money(Math.abs(d))) }),
      kpiCard({ label: T('kDebt'), value: noFin ? '—' : money(fin.debt), sub: noFin ? '' : `${fin.debtStudents} ${T('debtors')}`, open: 'rp-unpaid', tone: !noFin && fin.debt > 0 ? 'neg' : '',
        dlt: noFin ? '' : delta(fin.debt, finPrev && finPrev.count ? finPrev.debt : null, 'down', (d) => money(Math.abs(d))) }),
      kpiCard({ label: T('kRate'), value: noFin ? '—' : pct(fin.rate), open: 'rp-payment-summary',
        dlt: noFin || fin.rate === null ? '' : delta(fin.rate, finPrev ? finPrev.rate : null, 'up', (d) => `${Math.abs(d).toFixed(1)} pt`) }),
      kpiCard({ label: T('kDiscounts'), value: noFin ? '—' : money(fin.discounts), sub: noFin ? '' : `${fin.discountStudents} ${T('beneficiaries')}`, open: 'rp-discounts' }),
      kpiCard({ label: T('kExpenses'), value: expCur ? (expCur.count ? money(expCur.total) : money(0)) : '—', open: 'rp-expenses',
        dlt: expCur && expPrev && expPrev.count ? delta(expCur.total, expPrev.total, 'down', (d) => money(Math.abs(d))) : '' }),
      kpiCard({ label: T('kAttendance'), value: att$ ? pct(att$.rate) : '—', sub: att$ && att$.total ? `${att$.total} ${T('records')}` : '', open: 'rp-attendance',
        dlt: att$ && att$.rate !== null ? delta(att$.rate, attP$ && attP$.total ? attP$.rate : null, 'up', (d) => `${Math.abs(d).toFixed(1)} pt`) : '' }),
    ].join('');

    const expectedLine = finHasData && fin.expected > 0 ? `<p class="rc-note strong">${esc(T('expectedLbl'))}: <b>${esc(money(fin.expected))}</b></p>` : '';

    const weekly = att$ ? Object.keys(att$.weekly).sort().map((k) => ({ label: k, value: (att$.weekly[k].ok / att$.weekly[k].total) * 100 })) : [];
    const feeItems = finHasData ? Object.entries(fin.byFee).filter(([, v]) => v.collected > 0).map(([label, v]) => ({ label, value: v.collected })) : [];
    const clsItems = finHasData ? Object.entries(fin.byClass).filter(([, v]) => v.debt > 0).sort((a, b) => b[1].debt - a[1].debt).slice(0, 8).map(([label, v]) => ({ label, value: v.debt })) : [];
    const catEntries = expCur ? Object.entries(expCur.byCategory).sort((a, b) => b[1] - a[1]) : [];
    const catItems = catEntries.slice(0, 6).map(([label, value]) => ({ label, value }));
    const agingItems = finHasData ? [['a0', fin.aging.current], ['a30', fin.aging.d30], ['a60', fin.aging.d60], ['a90', fin.aging.d90], ['a91', fin.aging.over90]].map(([k, v]) => ({ label: T(k), value: v })) : [];

    const top = finHasData ? fin.debtors.slice(0, 10) : [];
    const topTable = top.length ? `<div class="data-table-wrap"><table class="data-table rc-table"><thead><tr><th>${esc(T('colStudent'))}</th><th>${esc(T('colClass'))}</th><th>${esc(T('colDebt'))}</th><th>${esc(T('colLate'))}</th><th>${esc(T('colLines'))}</th></tr></thead><tbody>${top.map((d) => `<tr><td>${esc(d.name || d.number)}</td><td>${esc(d.cls || '—')}</td><td class="num">${esc(money(d.debt))}</td><td class="num">${d.maxDays > 0 ? d.maxDays : '—'}</td><td class="num">${d.lines}</td></tr>`).join('')}</tbody></table></div>` : `<p class="rc-empty">${esc(T('noData'))}</p>`;

    const alertHtml = alerts.length ? `<ul class="rc-alerts">${alerts.map((a) => `<li class="${a.level}"><b>${esc(T(a.level === 'danger' ? 'sDanger' : a.level === 'warn' ? 'sWarn' : 'sInfo'))}</b><span>${esc(alertText(a, money))}</span></li>`).join('')}</ul>` : `<p class="rc-empty">${esc(T('noAlerts'))}</p>`;
    const recHtml = recs.length ? `<ul class="rc-recs">${recs.map((r) => `<li><span>${esc(recText(r, money))}</span><button type="button" class="rc-link" data-open="${esc(r.open)}">${esc(T('open'))}</button></li>`).join('')}</ul>` : `<p class="rc-empty">${esc(T('noRecs'))}</p>`;

    const notes = [];
    if (fails.length) notes.push(`${T('srcFail')} ${fails.join('، ')}`);
    if (s.exp.ok && s.exp.limit && s.exp.data.length >= s.exp.limit) notes.push(`${T('kExpenses')}: ${T('truncated')}`);
    if (s.inc.ok && s.inc.limit && s.inc.data.length >= s.inc.limit) notes.push(`${T('colStudent')}/incidents: ${T('truncated')}`);
    if (finHasData) notes.push(T('fmtOnlyAccrual'));

    const range = f.from && f.to ? `${f.from} → ${f.to}` : T('noData');
    return `<div class="rc-head"><div><h3>${esc(T('title'))}</h3><p class="rc-note">${esc(T('period'))}: <b dir="ltr">${esc(range)}</b>${s.prev ? ` · ${esc(T('vsPrev'))}: <span dir="ltr">${esc(s.prev.from)} → ${esc(s.prev.to)}</span>` : ''}</p></div>
      <button type="button" class="rc-link" data-rc-refresh>⟳ ${esc(T('retry'))}</button></div>
    <div class="rc-kpis">${kpis}</div>${expectedLine}
    <div class="rc-grid">
      ${card(T('cMonthly'), finHasData ? monthlyBars(fin.byMonth, money) : `<p class="rc-empty">${esc(T('noData'))}</p>`, T('cMonthlyNote'), 'rp-payment-summary')}
      ${card(T('cFee'), donut(feeItems, money), '', 'rp-payments')}
      ${card(T('cClassDebt'), hbars(clsItems, money), '', 'rp-unpaid')}
      ${card(T('aging'), hbars(agingItems, money), '', 'rp-unpaid')}
      ${card(T('cAttendance'), att$ ? lineChart(weekly) : `<p class="rc-empty">${esc(T('noData'))}</p>`, '', 'rp-attendance')}
      ${card(T('cExpenses'), hbars(catItems, money), '', 'rp-expenses')}
    </div>
    ${card(T('top10'), topTable, '', 'rp-unpaid')}
    <div class="rc-grid two">${card(T('alerts'), alertHtml)}${card(T('recs'), recHtml)}</div>
    ${notes.length ? `<div class="rc-quality"><b>${esc(T('quality'))}</b><ul>${notes.map((n) => `<li>${esc(n)}</li>`).join('')}</ul></div>` : ''}`;
  }

  return { refresh, clear: () => cacheStore.clear() };
}
