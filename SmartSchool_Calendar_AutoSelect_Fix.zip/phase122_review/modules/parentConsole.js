import { requireAuth, logout } from './auth.js';
import {
  el, esc, fmtDate, fmtDateTime, fmtMoney, attStatusAr, toast,
  loadingHtml, emptyHtml, errorHtml, initPageHeader, showView,
  armViewHistory, showInitError, openNotificationDetails,
} from './ui.js';
import {
  myChildren, getStudentFull, getStudentAttendance, listStudentGrades,
  studentTransportInfo, childPayments, listMyNotifications,
  markNotificationRead, unreadNotificationsCount, deleteMyNotification, getSchoolProfile,
  getStudentBadge, getStudentScheduleWithTime, getSchoolPeriods,
  submitParentDocumentRequest, listParentDocumentRequests,
  cancelParentDocumentRequest, openParentDocument, mapRpcError,
} from './school.js';
import { buildWeeklyTimetable, downloadWeeklyTimetablePdf, printWeeklyTimetable } from './scheduleGrid.js';
import { renderBadgeCard } from './badgeCard.js';
import { mountAppointmentFab } from './appointments.js';
import { enablePushNotifications, disablePushNotifications, isPushEnabled, isPushSupported } from './pushNotifications.js';
import { initErrorMonitor } from './errorMonitor.js';
import { mountInstallPrompt } from './installPrompt.js';
import { initOffline } from './offline.js';

let ctx = null;
let children = [];
let currentChild = null;
let schoolProfile = null;

const REL_AR = { father: 'الأب', mother: 'الأم', guardian: 'ولي الأمر' };

// Receipt download helper (§25) — html2canvas loaded lazily like badgeCard.js
// Phase 76: مهلة قصوى للتحميل — إن تعذّر جلب المكتبة (شبكة ضعيفة/حجب CDN)
// نتحول تلقائيًا لنافذة الطباعة (حفظ كـ PDF) بدل زر "لا يستجيب".
let h2cPromise = null;
function loadH2C() {
  if (window.html2canvas) return Promise.resolve();
  if (!h2cPromise) {
    h2cPromise = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js';
      s.onload = resolve;
      s.onerror = () => reject(new Error('HTML2CANVAS_LOAD_FAILED'));
      document.head.appendChild(s);
      setTimeout(() => reject(new Error('HTML2CANVAS_TIMEOUT')), 12000);
    });
    // عند الفشل نعيد المحاولة في المرة القادمة (لا نخزّن وعدًا مرفوضًا)
    h2cPromise.catch(() => { h2cPromise = null; });
  }
  return h2cPromise;
}

function parentAgeFromBirthDate(value) {
  if (!value) return null;
  const d = new Date(`${value}T00:00:00`), now = new Date();
  if (Number.isNaN(d.getTime())) return null;
  let age = now.getFullYear() - d.getFullYear();
  if (now.getMonth() < d.getMonth() || (now.getMonth() === d.getMonth() && now.getDate() < d.getDate())) age--;
  return age >= 0 ? age : null;
}
function parentBirthdayIsToday(value) {
  if (!value) return false;
  const d = new Date(`${value}T00:00:00`), now = new Date();
  return !Number.isNaN(d.getTime()) && d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
}

// ---- Children list ----------------------------------------------------------
async function loadChildren() {
  const host = el('children-list');
  host.innerHTML = loadingHtml();
  const res = await myChildren();
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  children = res.data || [];
  if (!children.length) {
    host.innerHTML = emptyHtml('لا يوجد أبناء مرتبطون بهذا الحساب. تواصل مع إدارة المؤسسة.');
    return;
  }
  host.innerHTML = `<div class="modules-grid">${children.map((c) => `
    <button type="button" class="module-card" data-child="${c.student_id}">
      ${c.photo_url
        ? `<img src="${esc(c.photo_url)}" alt="" style="width:48px; height:48px; border-radius:50%; object-fit:cover;" />`
        : '<span class="module-icon">🎓</span>'}
      ${esc(c.full_name)}
      <span class="badge badge-blue">${esc(c.class_name || 'بدون قسم')}${c.level ? ' — ' + esc(c.level) : ''}</span>
    </button>`).join('')}</div>`;
  host.querySelectorAll('[data-child]').forEach((b) => {
    b.addEventListener('click', () => openChild(b.dataset.child));
  });
}

// ---- Child detail -----------------------------------------------------------
function openChild(studentId) {
  closeReceipt(); // switching children must not keep the previous child's receipt open
  currentChild = children.find((c) => c.student_id === studentId) || null;
  if (!currentChild) return;
  // Fetch the authoritative birth date through the parent-authorized student RPC.
  loadParentBirthdayCard(currentChild.student_id);
  // §24: student's photo in the header (avatar fallback when missing)
  el('child-header').innerHTML = `<div class="panel">
    <div style="display:flex; gap:10px; align-items:center; margin-bottom:8px;">
      ${currentChild.photo_url
        ? `<img src="${esc(currentChild.photo_url)}" alt="" style="width:56px; height:56px; border-radius:50%; object-fit:cover; border:2px solid #e5e7eb;">`
        : '<div style="width:56px; height:56px; border-radius:50%; background:#e5e7eb; display:flex; align-items:center; justify-content:center; font-size:24px;">👤</div>'}
      <div><strong>${esc(currentChild.full_name)}</strong><div class="time">${esc(currentChild.student_number || '')}</div></div>
    </div>
    <div class="detail-row"><strong>القسم</strong><span>${esc(currentChild.class_name || '—')}${currentChild.level ? ' — ' + esc(currentChild.level) : ''}</span></div>
    <div class="detail-row"><strong>صلة القرابة</strong><span>${REL_AR[currentChild.relationship] || esc(currentChild.relationship || '—')}</span></div>
  </div>`;
  showView('child');
  refreshParentDocumentRequests();
  switchTab('attendance');
}

async function loadParentBirthdayCard(studentId) {
  const host = el('child-header');
  const result = await getStudentFull(studentId);
  if (!result.ok || !result.data || currentChild?.student_id !== studentId) return;
  const student = result.data;
  const age = parentAgeFromBirthDate(student.birth_date);
  const today = parentBirthdayIsToday(student.birth_date);
  const old = host.querySelector('[data-birthday-card]');
  old?.remove();
  const ageLine = document.createElement('div');
  ageLine.className = 'detail-row';
  ageLine.innerHTML = `<strong>العمر</strong><span>${age === null ? 'غير محدد' : `${age} سنة`}</span>`;
  host.querySelector('.panel')?.appendChild(ageLine);
  if (today) {
    const card = document.createElement('div');
    card.dataset.birthdayCard = 'true';
    card.className = 'panel';
    card.setAttribute('role', 'dialog');
    card.setAttribute('aria-modal', 'true');
    card.style.cssText = 'position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;padding:18px;background:rgba(12,31,52,.62);';
    card.innerHTML = `<div style="width:min(440px,100%);padding:24px;border:1px solid #e8c56a;border-radius:22px;background:linear-gradient(145deg,#fffaf0,#fff);text-align:center;box-shadow:0 22px 70px rgba(0,0,0,.22);"><div style="font-size:38px">🎂 🎉 🌟</div><h3 style="color:#173b5e;margin:10px 0">عيد ميلاد سعيد!</h3><p style="margin:0;color:#475569;line-height:1.9">اليوم عيد ميلاد ابنكم/ابنتكم <strong>${esc(student.full_name)}</strong>. مشاركتكم له/لها هذه المناسبة بكلمة طيبة ووقت جميل تعزز الثقة بالنفس والشعور بالاهتمام.</p><p style="margin:14px 0;padding:12px;background:#fff;border-radius:12px;color:#8a6418;line-height:1.8">كل عام وتلميذنا بخير، ونتمنى له عاماً مليئاً بالفرح والنجاح.</p><button type="button" data-close-birthday style="width:100%;padding:12px;border:0;border-radius:12px;background:#173b5e;color:#fff;font-weight:700">شكراً، عيد ميلاد سعيد</button></div>`;
    card.querySelector('[data-close-birthday]').addEventListener('click', () => card.remove());
    card.addEventListener('click', (event) => { if (event.target === card) card.remove(); });
    host.appendChild(card);
  }
}

function switchTab(tab) {
  closeReceipt(); // leaving payments (or any tab) must never leave a receipt open
  document.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('[data-tab-panel]').forEach((p) => { p.hidden = p.dataset.tabPanel !== tab; });
  if (tab === 'attendance') loadAttendance();
  if (tab === 'grades') loadGrades();
  if (tab === 'transport') loadTransport();
  if (tab === 'schedule') loadSchedule();
  if (tab === 'payments') loadPayments();
  if (tab === 'badge') loadBadge();
}

async function loadAttendance() {
  const host = el('child-attendance');
  host.innerHTML = loadingHtml();
  const res = await getStudentAttendance(currentChild.student_id, el('att-from').value || null, el('att-to').value || null);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد سجلات حضور في هذه الفترة.'); return; }
  const counts = rows.reduce((acc, r) => { acc[r.status] = (acc[r.status] || 0) + 1; return acc; }, {});
  host.innerHTML = `
    <div class="stats-grid" style="margin-bottom:12px;">
      <div class="stat-card tone-green"><div class="stat-value">${counts.present || 0}</div><div class="stat-label">حاضر</div></div>
      <div class="stat-card tone-red"><div class="stat-value">${counts.absent || 0}</div><div class="stat-label">غائب</div></div>
      <div class="stat-card tone-gold"><div class="stat-value">${counts.late || 0}</div><div class="stat-label">متأخر</div></div>
      <div class="stat-card"><div class="stat-value">${counts.excused || 0}</div><div class="stat-label">مبرر</div></div>
    </div>
    <div class="data-table-wrap"><table class="data-table"><thead><tr><th>التاريخ</th><th>الحالة</th></tr></thead>
    <tbody>${rows.map((r) => `<tr><td>${fmtDate(r.att_date)}</td><td><span class="badge ${
      r.status === 'present' ? 'badge-green' : r.status === 'absent' ? 'badge-red' : r.status === 'late' ? 'badge-gold' : 'badge-blue'
    }">${attStatusAr(r.status)}</span></td></tr>`).join('')}</tbody></table></div>`;
}

async function loadGrades() {
  const host = el('child-grades');
  host.innerHTML = loadingHtml();
  const res = await listStudentGrades(currentChild.student_id);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد نقاط مسجلة بعد.'); return; }
  host.innerHTML = `<div class="data-table-wrap"><table class="data-table"><thead><tr>
    <th>المادة</th><th>الفترة</th><th>النوع</th><th>النقطة</th><th>التاريخ</th>
  </tr></thead><tbody>${rows.map((g) => `<tr>
    <td>${esc(g.subject_name || '—')}</td><td>${esc(g.period || '—')}</td>
    <td>${esc(g.grade_type || '—')}</td><td>${g.score}/${g.max_score ?? 20}</td>
    <td>${fmtDate(g.created_at)}</td>
  </tr>`).join('')}</tbody></table></div>`;
}

async function loadTransport() {
  const host = el('child-transport');
  host.innerHTML = loadingHtml();
  const res = await studentTransportInfo(currentChild.student_id);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const t = res.data;
  if (!t) { host.innerHTML = emptyHtml('هذا التلميذ غير مسجل في النقل المدرسي.'); return; }
  host.innerHTML = `
    <div class="detail-row"><strong>الحافلة</strong><span>${esc(t.bus_code || '—')}${t.bus_plate ? ' (' + esc(t.bus_plate) + ')' : ''}</span></div>
    <div class="detail-row"><strong>المسار</strong><span>${esc(t.route_name || '—')}</span></div>
    <div class="detail-row"><strong>محطة الصعود</strong><span>${esc(t.pickup_stop || '—')}</span></div>
    <div class="detail-row"><strong>محطة النزول</strong><span>${esc(t.dropoff_stop || '—')}</span></div>`;
}

// ---- الجدول الزمني النهائي (قراءة فقط — لا تعديل إطلاقًا) + PDF/طباعة -----
let parentPeriodsCfg = null;
async function loadSchedule() {
  const host = el('child-schedule');
  host.innerHTML = loadingHtml();
  const [res, periodsRes, profileRes] = await Promise.all([
    getStudentScheduleWithTime(currentChild.student_id),
    getSchoolPeriods(),
    schoolProfile ? Promise.resolve({ ok: true, data: schoolProfile }) : getSchoolProfile(ctx.schoolId),
  ]);
  if (profileRes.ok && profileRes.data) schoolProfile = profileRes.data;
  if (periodsRes.ok && periodsRes.data) parentPeriodsCfg = periodsRes.data;
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا يوجد جدول زمني لهذا التلميذ بعد.'); return; }
  // الشبكة الرسمية النهائية: canEdit=false — لا أزرار إضافة/تعديل/حذف إطلاقًا
  const classLabel = `${currentChild.class_name || ''}${currentChild.level ? ' — ' + currentChild.level : ''}`;
  host.innerHTML = buildWeeklyTimetable(rows, classLabel, parentPeriodsCfg, false);
  host.querySelector('#sc-print')?.addEventListener('click', () =>
    printWeeklyTimetable(rows, classLabel, schoolProfile, parentPeriodsCfg));
  host.querySelector('#sc-pdf')?.addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true; btn.textContent = '⏳ جارٍ تجهيز PDF...';
    await downloadWeeklyTimetablePdf(rows, classLabel, schoolProfile, parentPeriodsCfg);
    btn.disabled = false; btn.textContent = '⬇️ تحميل PDF';
  });
}

// ---- Badge (§23): the SAME official QR from student_badges.secure_token —
// rendered from the badge row fetched server-side; never a second/generated
// code. Permission: parent-of-this-student only (fn_get_student_badge, P25).
async function loadBadge() {
  const host = el('child-badge');
  host.innerHTML = loadingHtml();
  if (!schoolProfile) {
    const spRes = await getSchoolProfile(ctx.schoolId);
    if (spRes.ok && spRes.data) schoolProfile = spRes.data;
  }
  const badgeRes = await getStudentBadge(currentChild.student_id);
  if (!badgeRes.ok) { host.innerHTML = errorHtml(badgeRes.error); return; }
  // fn_get_student_badge RETURNS TABLE → Supabase may deliver the row as an
  // ARRAY; normalize to a single badge object (null = no badge issued yet).
  const badge = (Array.isArray(badgeRes.data) ? badgeRes.data[0] : badgeRes.data) ?? null;
  if (!badge) { host.innerHTML = emptyHtml('لم تُصدر بطاقة لهذا التلميذ بعد.'); return; }
  await renderBadgeCard(host, {
    full_name: currentChild.full_name,
    student_number: currentChild.student_number,
    class_name: currentChild.class_name,
    year_name: null,
    photo_url: currentChild.photo_url,
    school_name: schoolProfile?.name,
    school_logo_url: schoolProfile?.logo_url,
  }, badge);
}

// ---- Receipt (§25): real payment rows from fn_child_payments + school header
// SINGLETON: exactly one receipt modal in the DOM (#payment-receipt-modal).
// Any previous receipt is removed before a new one opens; switching tabs or
// children also closes it. fn_child_payments reads a single table (no JOIN),
// so duplicate rows cannot originate from the RPC itself.
const RECEIPT_MODAL_ID = 'payment-receipt-modal';
function closeReceipt() {
  document.getElementById(RECEIPT_MODAL_ID)?.remove();
}
// نافذة طباعة الوصل (مشتركة بين زر الطباعة والبديل التلقائي عند فشل التحميل)
function printReceiptWindow(overlay) {
  const w = window.open('', '_blank', 'width=400,height=600');
  if (!w) { toast('اسمح بالنوافذ المنبثقة ثم أعد المحاولة.', 'error'); return; }
  w.document.write(`<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>وصل أداء</title></head><body style="font-family:sans-serif;">${overlay.querySelector('#rc-panel').outerHTML}</body></html>`);
  w.document.close(); w.focus(); setTimeout(() => w.print(), 400);
}
function openReceipt(p) {
  closeReceipt(); // never allow two receipt overlays at once
  const overlay = document.createElement('div');
  overlay.id = RECEIPT_MODAL_ID;
  overlay.className = 'map-picker-overlay';
  const statusAr = Number(p.amount_paid) >= Number(p.amount_due) && Number(p.amount_due) > 0
    ? 'مدفوع بالكامل' : Number(p.amount_paid) > 0 ? 'أداء جزئي' : 'غير مدفوع';
  overlay.innerHTML = `<div class="map-picker-sheet" style="max-width:380px;">
    <div class="map-picker-header"><strong>وصل الأداء</strong><button type="button" class="icon-btn" id="rc-close">✕</button></div>
    <div class="panel" id="rc-panel" style="text-align:center;">
      ${schoolProfile?.logo_url ? `<img src="${esc(schoolProfile.logo_url)}" alt="" style="max-height:40px;">` : ''}
      <div style="font-weight:700;">${esc(schoolProfile?.name || '')}</div>
      <hr style="border:none; border-top:1px dashed #d1d5db; margin:8px 0;">
      <div class="detail-row"><span class="k">ولي الأمر</span><span class="v">${esc(ctx.profile?.full_name || '—')}</span></div>
      <div class="detail-row"><span class="k">التلميذ</span><span class="v">${esc(currentChild.full_name)}</span></div>
      <div class="detail-row"><span class="k">القسم</span><span class="v">${esc(currentChild.class_name || '—')}</span></div>
      <div class="detail-row"><span class="k">نوع الأداء</span><span class="v">${esc(p.fee_type)}</span></div>
      <div class="detail-row"><span class="k">المبلغ المستحق</span><span class="v">${fmtMoney(p.amount_due)}</span></div>
      <div class="detail-row"><span class="k">المبلغ المؤدى</span><span class="v"><strong>${fmtMoney(p.amount_paid)}</strong></span></div>
      <div class="detail-row"><span class="k">التاريخ</span><span class="v">${fmtDate(p.payment_date)}</span></div>
      <div class="detail-row"><span class="k">رقم العملية</span><span class="v">${esc(p.receipt_no || '—')}</span></div>
      <div class="detail-row"><span class="k">الحالة</span><span class="v">${statusAr}</span></div>
      <div class="detail-row"><span class="k">المجموع</span><span class="v"><strong>${fmtMoney(p.amount_paid)}</strong></span></div>
    </div>
    <div style="display:flex; gap:8px; margin-top:10px;">
      <button type="button" class="quick-action-btn secondary" id="rc-dl" style="flex:1;">⬇️ تحميل الوصل</button>
      <button type="button" class="quick-action-btn secondary" id="rc-pr" style="flex:1;">🖨️ طباعة الوصل</button>
    </div></div>`;
  document.body.appendChild(overlay);
  overlay.querySelector('#rc-close').addEventListener('click', closeReceipt);
  overlay.querySelector('#rc-pr').addEventListener('click', () => printReceiptWindow(overlay));
  overlay.querySelector('#rc-dl').addEventListener('click', async () => {
    const btn = overlay.querySelector('#rc-dl');
    btn.disabled = true;
    try {
      await loadH2C();
      const c = await window.html2canvas(overlay.querySelector('#rc-panel'), { backgroundColor: '#ffffff', scale: 2, useCORS: true });
      const a = document.createElement('a');
      a.href = c.toDataURL('image/png');
      a.download = `receipt-${p.receipt_no || currentChild.student_number || 'payment'}.png`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      toast('تم تحميل الوصل كصورة PNG.', 'success');
    } catch (e) {
      console.error('receipt download failed:', e);
      // البديل التلقائي: نافذة طباعة يمكن منها "حفظ كـ PDF" — لا يبقى الزر بلا استجابة
      toast('تعذّر إنشاء الصورة — فتحنا نافذة الطباعة: اختر «حفظ كـ PDF».', 'info');
      printReceiptWindow(overlay);
    } finally { btn.disabled = false; }
  });
}

async function loadPayments() {
  const host = el('child-payments');
  host.innerHTML = loadingHtml();
  const res = await childPayments(currentChild.student_id);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد أداءات مسجلة.'); return; }
  const totalDue = rows.reduce((s, r) => s + Number(r.amount_due || 0), 0);
  const totalPaid = rows.reduce((s, r) => s + Number(r.amount_paid || 0), 0);
  host.innerHTML = `
    <div class="stats-grid" style="margin-bottom:12px;">
      <div class="stat-card"><div class="stat-value">${fmtMoney(totalDue)}</div><div class="stat-label">المستحق</div></div>
      <div class="stat-card tone-green"><div class="stat-value">${fmtMoney(totalPaid)}</div><div class="stat-label">المدفوع</div></div>
      <div class="stat-card tone-red"><div class="stat-value">${fmtMoney(totalDue - totalPaid)}</div><div class="stat-label">المتبقي</div></div>
    </div>
    <div class="data-table-wrap"><table class="data-table"><thead><tr>
      <th>نوع الرسوم</th><th>المستحق</th><th>المدفوع</th><th>التاريخ</th><th>الوصل</th>
    </tr></thead><tbody>${rows.map((p, i) => `<tr>
      <td>${esc(p.fee_type)}</td><td>${fmtMoney(p.amount_due)}</td><td>${fmtMoney(p.amount_paid)}</td>
      <td>${fmtDate(p.payment_date)}</td>
      <td>${esc(p.receipt_no || '—')}<br><button type="button" class="quick-action-btn secondary receipt-btn" data-rci="${i}">⬇️🖨️ الوصل</button></td>
    </tr>`).join('')}</tbody></table></div>`;
  host.querySelectorAll('[data-rci]').forEach((b) => {
    b.addEventListener('click', () => openReceipt(rows[Number(b.dataset.rci)]));
  });
}


// ---- Phase 92: Parent document requests ------------------------------------
const PARENT_DOC_TYPES = {
  ENROLLMENT: 'شهادة مدرسية', TRANSFER: 'شهادة انتقال',
  REPORT_CARD: 'نسخة من كشف النقط', OTHER: 'وثيقة أخرى'
};
const PARENT_DOC_STATUS = {
  SUBMITTED: 'تم الإرسال', UNDER_REVIEW: 'قيد الدراسة',
  APPROVED: 'تمت الموافقة', REJECTED: 'مرفوض',
  READY: 'الوثيقة جاهزة', DELIVERED: 'تم التسليم', CANCELLED: 'ملغى'
};
async function refreshParentDocumentRequests() {
  const host = el('pdoc-list');
  if (!host) return;
  host.innerHTML = loadingHtml();
  const res = await listParentDocumentRequests();
  if (!res.ok) { host.innerHTML = errorHtml(mapRpcError(res.error)); return; }
  const rows = (res.data || []).filter(r => !currentChild || r.student_id === currentChild.student_id);
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد طلبات وثائق لهذا التلميذ بعد.'); return; }
  const badge = (st) => st === 'REJECTED' || st === 'CANCELLED' ? 'badge-red' : st === 'READY' || st === 'DELIVERED' ? 'badge-green' : 'badge-blue';
  host.innerHTML = `<div class="data-table-wrap"><table class="data-table"><thead><tr>
    <th>التلميذ</th><th>الوثيقة</th><th>تاريخ الطلب</th><th>الحالة</th><th>رد الإدارة</th><th></th>
  </tr></thead><tbody>${rows.map(r => `<tr>
    <td>${esc(r.student_name || '—')}</td><td>${esc(PARENT_DOC_TYPES[r.request_type] || r.request_type)}</td>
    <td>${fmtDate(r.created_at)}</td><td><span class="badge ${badge(r.status)}">${esc(PARENT_DOC_STATUS[r.status] || r.status)}</span></td>
    <td>${esc(r.admin_response || '—')}</td>
    <td style="min-width:120px;">
      ${['READY','DELIVERED'].includes(r.status) && r.archive_document_id ? `<button type="button" class="quick-action-btn" data-pdoc-open="${esc(r.id)}">⬇️ تنزيل الوثيقة</button>` : ''}
      ${['SUBMITTED','UNDER_REVIEW'].includes(r.status) ? `<button type="button" class="quick-action-btn secondary" data-pdoc-cancel="${esc(r.id)}">إلغاء الطلب</button>` : ''}
    </td>
  </tr>`).join('')}</tbody></table></div>`;
}
let parentDocRequestsBound = false;
function initParentDocumentRequests() {
  if (!parentDocRequestsBound) {
    parentDocRequestsBound = true;
    el('pdoc-submit')?.addEventListener('click', async () => {
      const studentId = currentChild?.student_id;
      const typeEl = el('pdoc-type');
      const purposeEl = el('pdoc-purpose');
      const btn = el('pdoc-submit');
      // Defensive DOM checks: an old/cached HTML shell must not crash the portal.
      if (!typeEl || !purposeEl || !btn) {
        console.error('[parent-doc] Missing request form element', { type: !!typeEl, purpose: !!purposeEl, submit: !!btn });
        toast('تعذر تحميل نموذج الوثائق. حدّث الصفحة لإظهار النسخة الجديدة.', 'error');
        return;
      }
      if (!studentId) { toast('افتح بطاقة التلميذ أولاً.', 'error'); return; }
      const type = String(typeEl.value || '').trim();
      const purpose = String(purposeEl.value || '').trim();
      if (!type) { toast('اختر نوع الوثيقة أولاً.', 'error'); typeEl.focus(); return; }
      btn.disabled = true; btn.textContent = 'جارٍ إرسال الطلب...';
      try {
        const res = await submitParentDocumentRequest(studentId, type, purpose);
        if (!res.ok) { toast(mapRpcError(res.error) || 'تعذر إرسال الطلب.', 'error'); return; }
        purposeEl.value = '';
        toast('تم إرسال طلب الوثيقة إلى إدارة المؤسسة.', 'success');
        await refreshParentDocumentRequests();
      } catch (error) {
        console.error('[parent-doc] submit failed', error);
        toast('حدث خطأ أثناء إرسال الطلب. حاول مرة أخرى.', 'error');
      } finally {
        btn.disabled = false; btn.textContent = 'إرسال الطلب';
      }
    });
    el('pdoc-list')?.addEventListener('click', async (event) => {
      const open = event.target.closest('[data-pdoc-open]');
      const cancel = event.target.closest('[data-pdoc-cancel]');
      if (open) {
        open.disabled = true;
        const res = await openParentDocument(open.dataset.pdocOpen);
        open.disabled = false;
        if (!res.ok) { toast(mapRpcError(res.error) || 'تعذر فتح الوثيقة.', 'error'); return; }
        window.open(res.url, '_blank', 'noopener');
      } else if (cancel) {
        if (!window.confirm('هل تريد إلغاء هذا الطلب؟')) return;
        cancel.disabled = true;
        const res = await cancelParentDocumentRequest(cancel.dataset.pdocCancel);
        if (!res.ok) { cancel.disabled = false; toast(mapRpcError(res.error), 'error'); return; }
        toast('تم إلغاء الطلب.', 'success');
        refreshParentDocumentRequests();
      }
    });
  }
  refreshParentDocumentRequests();
}

// ---- Notifications ----------------------------------------------------------
// ---- Push Notifications (Phase 68) -------------------------------------------
async function refreshPushButton() {
  const btn = el('push-toggle-btn');
  if (!btn) return;
  if (!isPushSupported()) {
    btn.textContent = '🔕 غير مدعوم في هذا المتصفح';
    btn.disabled = true;
    return;
  }
  const enabled = await isPushEnabled();
  btn.textContent = enabled ? '🔕 إلغاء إشعارات الهاتف' : '🔔 تفعيل إشعارات الهاتف';
  btn.dataset.enabled = enabled ? '1' : '0';
}

el('push-toggle-btn')?.addEventListener('click', async () => {
  const btn = el('push-toggle-btn');
  btn.disabled = true;
  const wasEnabled = btn.dataset.enabled === '1';
  const res = wasEnabled ? await disablePushNotifications() : await enablePushNotifications();
  btn.disabled = false;
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast(wasEnabled ? 'تم إلغاء إشعارات الهاتف.' : 'تم تفعيل إشعارات الهاتف بنجاح 🎉', 'success');
  refreshPushButton();
});

async function loadNotifications() {
  const host = el('notif-list');
  host.innerHTML = loadingHtml();
  const res = await listMyNotifications(50);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد إشعارات.'); refreshNotifBadge(); return; }
  const typeLabels = { announcement: 'إعلان', incident: 'بلاغ', attendance: 'حضور', grade: 'نقطة', transport: 'نقل', schedule: 'جدول', system: 'نظام' };
  host.innerHTML = rows.map((n) => `
    <div class="notif-swipe-wrap">
      <div class="notif-delete-zone">🗑 حذف</div>
      <div class="notif-card" data-notif="${n.notification_id}" style="${n.is_read ? 'opacity:.65;' : 'font-weight:600;'}">
        <div class="notif-head">
          <span>${esc(n.title)}</span>
          <span class="badge badge-blue">${esc(typeLabels[n.type] || n.type || 'إشعار')}</span>
        </div>
        ${n.body ? `<div class="notif-body">${esc(n.body)}</div>` : ''}
        ${n.image_url ? `<img src="${esc(n.image_url)}" alt="">` : ''}
        <div class="time">${fmtDateTime(n.created_at)}</div>
      </div>
    </div>`).join('');

  host.querySelectorAll('.notif-card').forEach((card) => {
    card.addEventListener('click', async () => {
      if (card.dataset.swiping === '1') return;
      await markNotificationRead(card.dataset.notif);
      card.style.opacity = '.65';
      card.style.fontWeight = '400';
      openNotificationDetails(rows.find((n) => n.notification_id === card.dataset.notif));
      refreshNotifBadge();
    });

    let startX = 0, dx = 0, dragging = false;
    card.addEventListener('touchstart', (e) => { startX = e.touches[0].clientX; dragging = true; card.style.transition = 'none'; }, { passive: true });
    card.addEventListener('touchmove', (e) => {
      if (!dragging) return;
      dx = e.touches[0].clientX - startX;
      if (dx < 0) card.style.transform = `translateX(${dx}px)`;
    }, { passive: true });
    card.addEventListener('touchend', async () => {
      dragging = false;
      card.style.transition = 'transform .2s';
      if (dx < -90) {
        card.dataset.swiping = '1';
        card.style.transform = 'translateX(-100%)';
        const res2 = await deleteMyNotification(card.dataset.notif);
        if (res2.ok) {
          setTimeout(() => { card.closest('.notif-swipe-wrap')?.remove(); refreshNotifBadge(); }, 180);
        } else {
          card.style.transform = 'translateX(0)';
          setTimeout(() => { card.dataset.swiping = '0'; }, 200);
        }
      } else {
        card.style.transform = 'translateX(0)';
      }
      dx = 0;
    });
  });
  refreshNotifBadge();
}

async function refreshNotifBadge() {
  const res = await unreadNotificationsCount();
  const badge = el('notif-count');
  if (!badge) return;
  const count = res.ok ? (res.data || 0) : 0;
  badge.hidden = !count;
  badge.textContent = count;
}

// ---- School announcements shortcut (same institution as the signed-in parent) ----
function mountSchoolAnnouncementsFab(schoolId) {
  if (!schoolId || document.getElementById('parent-announcements-fab')) return;
  const link = document.createElement('a');
  link.id = 'parent-announcements-fab';
  link.className = 'parent-announcements-fab';
  link.href = `school.html?id=${encodeURIComponent(schoolId)}#announcements`;
  link.target = '_blank';
  link.rel = 'noopener noreferrer';
  link.title = 'إعلانات وتدوينات المؤسسة';
  link.setAttribute('aria-label', 'فتح إعلانات وتدوينات المؤسسة');
  link.innerHTML = '📢';
  document.body.appendChild(link);
}

// ---- Init -------------------------------------------------------------------
(async () => {
  try {
    initErrorMonitor('parent.html');
    mountInstallPrompt();
    const who = el('who-label');
    if (who) who.textContent = 'جارٍ التحقق من الجلسة والصلاحيات...';
    ctx = await requireAuth('parent.html');
    if (!ctx) { if (who) who.textContent = 'تعذر التحقق من الحساب؛ أعد تسجيل الدخول.'; return; }
    initOffline();
    window.__PARENT_BOOTED = true;
    if (who) who.textContent = `${ctx.profile.full_name || 'ولي الأمر'} — ولي الأمر`;
    armViewHistory('home');
    document.getElementById('app-body').hidden = false;

    const schoolRes = await getSchoolProfile(ctx.schoolId);
    if (schoolRes.ok && schoolRes.data) schoolProfile = schoolRes.data;
    await initPageHeader(ctx, schoolProfile ? schoolProfile.name : null, logout);

    const today = new Date();
    const monthAgo = new Date(today.getTime() - 30 * 86400000);
    el('att-from').value = monthAgo.toISOString().slice(0, 10);
    el('att-to').value = today.toISOString().slice(0, 10);

    document.querySelectorAll('[data-back]').forEach((b) => {
      b.addEventListener('click', () => showView('home'));
    });
    document.querySelectorAll('[data-tab]').forEach((b) => {
      b.addEventListener('click', () => switchTab(b.dataset.tab));
    });
    el('att-reload').addEventListener('click', loadAttendance);
    el('notif-btn').addEventListener('click', () => { showView('notifications'); loadNotifications(); refreshPushButton(); });

    await loadChildren();
    initParentDocumentRequests();
    refreshNotifBadge();
    mountSchoolAnnouncementsFab(ctx.schoolId);
    mountAppointmentFab();
  } catch (error) {
    console.error('parent portal init error:', error);
    window.__PARENT_BOOTED = true;
    const who = el('who-label'); if (who) who.textContent = 'حدث خطأ أثناء تشغيل بوابة ولي الأمر';
    showInitError(error);
  }
})();
