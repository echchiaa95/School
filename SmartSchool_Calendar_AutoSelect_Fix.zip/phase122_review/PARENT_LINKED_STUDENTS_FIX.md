# Smart School — Parent linked students display fix

## Changes
- Updated `modules/adminConsole.js` to load parent details on demand using the existing `getParentDetail(parentId)` query.
- The parent account details modal now displays all linked students from `parent_students`, including student name, student number, and relationship.
- Existing parent-child links are read only; this change does not modify database records or payment history.

## Apply
Replace the existing `modules/adminConsole.js` in the deployed project with the file from this archive, then deploy the updated frontend. No SQL migration is required for this UI change.

## Validation
Open Management > Parents, select a parent account, and verify that the linked student(s) appear in the details modal.
