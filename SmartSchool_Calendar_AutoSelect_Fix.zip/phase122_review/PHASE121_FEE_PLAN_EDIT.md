# Phase 121 — Edit existing fee plans

## What changed
- The Edit action loads the selected fee plan into the existing form.
- Saving an edit now updates that exact `school_fee_plans.id` through `fn_school_fee_plan_update_v1`; it no longer silently creates a second fee plan.
- The edit operation validates price, billing period, date range, and level scope, and rejects overlapping active plans with the same fee type and level scope.
- The audit log records before/after values. Existing payment records and fee-obligation snapshots are not rewritten.
- The admin entry point and `school.js` import have cache-busting version `121.0`.

## Deployment
1. Run `supabase/migrations/phase121_edit_existing_fee_plan.sql` in the Supabase SQL Editor.
2. Deploy the complete project, including `admin.html` and the `modules/` directory (especially `modules/adminConsole.js` and `modules/school.js`).
3. Open `https://school.elbordiji.com/admin.html?v=121` and refresh.
4. In Finance → Fee plans, press **تعديل** beside a plan, change the price/date/period/levels, then save.

## Safety
This migration does not modify payments, receipts, or existing fee-obligation rows. It updates only the selected fee-plan record. If the requested date range conflicts with another active plan for the same fee and level scope, the update is rejected with `FEE_PLAN_PERIOD_OVERLAP` rather than silently changing another plan.
