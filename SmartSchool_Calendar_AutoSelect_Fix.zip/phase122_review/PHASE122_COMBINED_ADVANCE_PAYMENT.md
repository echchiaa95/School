# Phase 122 — Combined tuition/transport advance payments

## Changes
- Added a combined tuition + transport choice for advance payments.
- Advance preview now computes the exact consecutive month keys and includes every matching open obligation for the selected fee type(s), rather than taking only N obligation rows. This fixes the case where two fee types exist in one month and the requested month count was incorrectly treated as a row count.
- The preview shows tuition and transport separately for each month and totals the outstanding amounts after discounts.
- Registration fees are explicitly rejected in monthly advance mode because they are annual/one-time obligations.
- Bank transfer and cheque selections reveal a required reference field. The reference is saved in the existing payment note field; no database schema change is required.
- The ordinary payment flow also passes the reference through the existing `p_note` parameter.
- Selecting the combined fee option is restricted to advance mode.

## Important operational condition
Transport obligations are generated only when the student's `uses_transport` flag is true and an active monthly transport fee plan applies to the student's class level and selected academic year. If the preview reports no transport obligations, verify those existing settings; the frontend intentionally does not fabricate obligations or amounts.

## Validation
- `node --check modules/adminConsole.js` passed.
- `node --test tests/reportsAnalytics.test.mjs` passed (23/23).
- No live Supabase calls or browser E2E run were performed. No database migration was added or applied.
