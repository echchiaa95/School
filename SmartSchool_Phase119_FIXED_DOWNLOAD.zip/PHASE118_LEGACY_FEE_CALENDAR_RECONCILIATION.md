# Phase 118 — Legacy fee calendar reconciliation

- Normalizes legacy fee labels (`شهرية` → `واجب التمدرس`) only for matching.
- Displays legacy receipts alongside new obligations without modifying source payment rows.
- Uses new allocation totals when present to avoid counting legacy and new allocations together.
- Marks future-dated obligations as `future`.
- Shows excess legacy payment as a visible credit in the student calendar.

Apply `supabase/migrations/phase118_legacy_fee_calendar_reconciliation.sql` in Supabase SQL Editor.
