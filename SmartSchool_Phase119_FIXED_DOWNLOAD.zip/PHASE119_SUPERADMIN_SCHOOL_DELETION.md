# Phase 119 — SuperAdmin full school deletion

## Included
- Adds a permanent-delete action to the SuperAdmin school detail view.
- Requires a downloadable JSON backup, exact school-name entry, and a final confirmation.
- Adds `fn_superadmin_export_school_for_deletion(uuid)` and `fn_superadmin_delete_school(uuid,text)`.
- Both database functions enforce `fn_is_superadmin()` server-side.
- Removes school-scoped rows with direct `NO ACTION` school foreign keys before deleting `schools`; remaining `ON DELETE CASCADE` relationships are handled by PostgreSQL.
- Writes a platform-level audit row without a foreign key to the deleted school.

## Identity safety policy
This phase deliberately removes school memberships through the `user_roles` foreign-key cascade but does **not** delete `auth.users` or `profiles`. The schema includes numerous `NO ACTION` references to profiles (audit history, payments, attendance, appointments, notifications, etc.), and a profile can be shared across schools. Deleting Auth identities safely requires a separate reference-completeness check and server-side Auth Admin workflow. Retaining those identities prevents accidental loss of shared accounts and historical attribution.

## Deployment
1. Apply `supabase/migrations/phase119_superadmin_school_deletion.sql` in Supabase SQL Editor or through the project's migration workflow.
2. Deploy the updated frontend.
3. Test on a disposable school first. Confirm backup JSON downloads and inspect it before confirming deletion.
4. Verify `platform_school_deletion_audit` after deletion.

## Validation
- `node --check modules/superadmin.js`: passed.
- Inline module extracted from `superadmin.html` and checked with `node --check`: passed.
- `npm run build`: not run successfully because dependencies are not installed in this environment (`vite: not found`).
- SQL migration has not been executed against the live Supabase project; database behavior must be verified there before production use.
