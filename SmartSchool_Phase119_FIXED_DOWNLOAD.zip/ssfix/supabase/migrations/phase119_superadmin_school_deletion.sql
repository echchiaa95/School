-- Phase 119: SuperAdmin-only full school deletion with downloadable backup.
-- User identities are deliberately retained; only school-scoped memberships/data are removed.

CREATE TABLE IF NOT EXISTS public.platform_school_deletion_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id uuid NOT NULL,
  school_name text NOT NULL,
  actor_id uuid NOT NULL,
  deleted_at timestamptz NOT NULL DEFAULT now(),
  backup_downloaded boolean NOT NULL DEFAULT true,
  details jsonb NOT NULL DEFAULT '{}'::jsonb
);
ALTER TABLE public.platform_school_deletion_audit ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.platform_school_deletion_audit FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.fn_superadmin_export_school_for_deletion(p_school_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE
  v_school jsonb;
  v_data jsonb := '{}'::jsonb;
  v_table text;
  v_rows jsonb;
BEGIN
  IF auth.uid() IS NULL OR NOT public.fn_is_superadmin() THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  SELECT to_jsonb(s) INTO v_school FROM public.schools s WHERE s.id=p_school_id;
  IF v_school IS NULL THEN RAISE EXCEPTION 'SCHOOL_NOT_FOUND'; END IF;
  FOR v_table IN
    SELECT DISTINCT c.table_name
    FROM information_schema.columns c
    WHERE c.table_schema='public' AND c.column_name='school_id'
      AND c.table_name NOT IN ('platform_school_deletion_audit')
    ORDER BY c.table_name
  LOOP
    IF to_regclass(format('public.%I',v_table)) IS NULL THEN CONTINUE; END IF;
    EXECUTE format('SELECT COALESCE(jsonb_agg(to_jsonb(t)), ''[]''::jsonb) FROM public.%I t WHERE school_id=$1',v_table)
      INTO v_rows USING p_school_id;
    v_data := v_data || jsonb_build_object(v_table,COALESCE(v_rows,'[]'::jsonb));
  END LOOP;
  RETURN jsonb_build_object('app','smart-school','backup_version',1,'kind','full-school-deletion',
    'exported_at',now(),'school_id',p_school_id,'school',v_school,'tables',v_data);
END; $$;
REVOKE ALL ON FUNCTION public.fn_superadmin_export_school_for_deletion(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_superadmin_export_school_for_deletion(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.fn_superadmin_delete_school(p_school_id uuid,p_confirmation text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE
  v_name text;
  v_actor uuid := auth.uid();
  v_deleted jsonb := '{}'::jsonb;
  v_count integer;
  v_table text;
BEGIN
  IF v_actor IS NULL OR NOT public.fn_is_superadmin() THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  SELECT name INTO v_name FROM public.schools WHERE id=p_school_id FOR UPDATE;
  IF v_name IS NULL THEN RAISE EXCEPTION 'SCHOOL_NOT_FOUND'; END IF;
  IF p_confirmation IS DISTINCT FROM v_name THEN RAISE EXCEPTION 'CONFIRMATION_MISMATCH'; END IF;

  -- Explicitly remove school-scoped rows whose FK to schools is NO ACTION.
  -- Delete dependants before their parent records where applicable.
  FOREACH v_table IN ARRAY ARRAY[
    'appointment_settings','appointments','student_fee_payment_allocations',
    'student_fee_payment_transactions','payments','staff_attendance','student_grades'
  ] LOOP
    IF to_regclass(format('public.%I',v_table)) IS NULL THEN CONTINUE; END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name=v_table AND column_name='school_id') THEN
      EXECUTE format('DELETE FROM public.%I WHERE school_id=$1',v_table) USING p_school_id;
      GET DIAGNOSTICS v_count = ROW_COUNT;
      v_deleted := v_deleted || jsonb_build_object(v_table,v_count);
    END IF;
  END LOOP;

  -- All remaining school-scoped FK rows marked CASCADE are removed by this delete.
  -- Audit is platform-level and intentionally has no FK to schools.
  INSERT INTO public.platform_school_deletion_audit(school_id,school_name,actor_id,details)
  VALUES(p_school_id,v_name,v_actor,jsonb_build_object('manual_no_action_tables',v_deleted));

  DELETE FROM public.schools WHERE id=p_school_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'SCHOOL_DELETE_FAILED'; END IF;

  RETURN jsonb_build_object('ok',true,'school_id',p_school_id,'school_name',v_name,
    'manual_deletions',v_deleted,
    'identity_policy','School memberships removed by FK cascade; profile/auth identities retained to protect shared accounts and historical references.');
END; $$;
REVOKE ALL ON FUNCTION public.fn_superadmin_delete_school(uuid,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_superadmin_delete_school(uuid,text) TO authenticated;
