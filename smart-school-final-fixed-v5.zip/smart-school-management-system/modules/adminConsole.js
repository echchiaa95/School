// ============================================================================
// modules/adminConsole.js — REAL Admin operational dashboard.
// Admin = operational/administrative staff: students, staff records,
// attendance, transport, payments/expenses, incidents, notifications,
// reports. Governance (academic structure, guard permission policies,
// school configuration, teacher assignments) stays with the DIRECTOR —
// deliberately absent here. Every operation is re-authorized server-side
// by RLS + SECURITY DEFINER RPCs; this UI never asserts school_id.
// ============================================================================

import { requireAuth, logout } from './auth.js';
import {
  el, esc, fmtDate, fmtDateTime, fmtMoney, toast, confirmDialog, showView,
  initPageHeader, statCard, loadingHtml, emptyHtml, attStatusAr,
  armViewHistory, armErrorBoundary, showInitError,
} from './ui.js';
import {
  schoolDashboard, getSchoolProfile,
  listMyAcademicYears, listMyClasses,
  schoolAttendanceToday, getClassAttendance, saveAttendance, reportAttendance,
  reportIncident, listIncidents,
  sendNotification, listMyNotifications, markNotificationRead, unreadNotificationsCount,
  listBuses, listRoutes,
  recordPayment, listPayments, recordExpense, listExpenses, financeSummary,
  mapRpcError,
} from './school.js';
import { registerStudent, filterStudents, searchStudents } from './students.js';
import { listTeachers, listDrivers, listParents, createStaffAccount } from './accounts.js';
import { listGuards, createGuardAccount } from './admin.js';

let ctx = null;
let schoolId = null;
let cache = { years: null, classes: null };
let pickedStudent = null;   // payment / incident target
let currentStaffType = 'teacher';

// ===== INIT =====
(async () => {
  try {
    armErrorBoundary();
    ctx = await requireAuth('admin.html');
    if (!ctx) return;
    schoolId = ctx.schoolId;
    const profile = await getSchoolProfile(schoolId);
    initPageHeader(ctx, profile.ok && profile.data ? profile.data.name : null, logout);
    el('app-body').hidden = false;
    armViewHistory('home');
    showView('home');
    loadDashboard();
    refreshNotifCount();
  } catch (error) {
    console.error('admin init error:', error);
    // Session stays valid — surface the real error, never a silent
    // "جارٍ التحقق..." and never a blind redirect loop.
    showInitError(error);
  }
})();

// ===== NAV =====
document.querySelectorAll('[data-go]').forEach((b) => b.addEventListener('click', () => openModule(b.dataset.go)));
document.querySelectorAll('[data-back]').forEach((b) => b.addEventListener('click', () => {
  showView(b.dataset.back);
  if (b.dataset.back === 'home') loadDashboard();
  if (b.dataset.back === 'students') loadStudents();
  if (b.dataset.back === 'staff') loadStaff();
  if (b.dataset.back === 'incidents') loadIncidents();
}));

function openModule(name) {
  showView(name);
  const loaders = {
    students: loadStudents, staff: loadStaff, attendance: loadAttendance,
    transport: loadTransport, finance: loadFinance, incidents: loadIncidents,
    notifications: loadNotifications, reports: () => {},
  };
  loaders[name]?.();
}

async function refreshNotifCount() {
  const res = await unreadNotificationsCount();
  if (res.ok && res.data > 0) {
    el('notif-count').hidden = false;
    el('notif-count').textContent = res.data;
  }
}
el('notif-btn').addEventListener('click', () => openModule('notifications'));

// ===== DASHBOARD =====
async function loadDashboard() {
  const host = el('dash-stats');
  host.innerHTML = loadingHtml();
  const res = await schoolDashboard();
  if (!res.ok) { host.innerHTML = emptyHtml(res.error); return; }
  const d = res.data || {};
  const att = d.attendance_today || {};
  host.innerHTML = '<div class="stats-grid">'
    + statCard(d.students ?? 0, 'التلاميذ')
    + statCard(att.present ?? 0, 'حاضرون اليوم', 'tone-green')
    + statCard((att.absent ?? 0) + (att.late ?? 0), 'غياب/تأخر اليوم', 'tone-red')
    + statCard(d.teachers ?? 0, 'الأساتذة')
    + statCard(d.guards ?? 0, 'الحراس')
    + statCard(d.drivers ?? 0, 'السائقون')
    + statCard(d.parents ?? 0, 'أولياء الأمور')
    + statCard(d.buses ?? 0, 'الحافلات')
    + statCard(fmtMoney(d.payments_month), 'أداءات الشهر', 'tone-green')
    + statCard(fmtMoney(d.expenses_month), 'مصاريف الشهر', 'tone-red')
    + statCard(d.open_incidents ?? 0, 'مخالفات مفتوحة', 'tone-gold')
    + '</div>';
}

// ===== SHARED: years/classes =====
async function ensureYearsClasses() {
  if (!cache.years) {
    const res = await listMyAcademicYears();
    cache.years = res.ok ? res.data || [] : [];
  }
  if (!cache.classes) {
    const res = await listMyClasses(null);
    cache.classes = res.ok ? res.data || [] : [];
  }
  return cache;
}

// ===== STUDENTS =====
async function loadStudents() {
  const panel = el('students-panel');
  panel.innerHTML = loadingHtml();
  const { classes } = await ensureYearsClasses();
  el('students-class').innerHTML = '<option value="">كل الأقسام</option>'
    + classes.map((c) => `<option value="${c.class_id}">${esc(c.class_name)} — ${esc(c.year_name || '')}</option>`).join('');
  const rows = await filterStudents({ query: el('students-search').value, classId: el('students-class').value || null, limit: 100 });
  panel.innerHTML = rows.length
    ? rows.map((r) => `<div class="history-item"><div><strong>${esc(r.student?.fullName || '—')}</strong>
        <span class="time">#${esc(r.student?.studentNumber || '—')}</span></div>
        <span class="time">${esc(r.student?.className || 'بدون قسم')} ${r.resultType === 'AUTHORIZED' ? '<span class="badge badge-green">نشط</span>' : '<span class="badge badge-red">غير نشط</span>'}</span></div>`).join('')
    : emptyHtml('لا توجد نتائج.');
}
el('students-search').addEventListener('input', loadStudents);
el('students-class').addEventListener('change', loadStudents);

el('btn-add-student').addEventListener('click', async () => {
  const { years, classes } = await ensureYearsClasses();
  el('st-year').innerHTML = years.map((y) => `<option value="${y.year_id}">${esc(y.year_name)}${y.is_current ? ' (الحالية)' : ''}</option>`).join('');
  const fillClasses = () => {
    const yid = el('st-year').value;
    el('st-class').innerHTML = classes.filter((c) => !yid || c.academic_year_id === yid)
      .map((c) => `<option value="${c.class_id}">${esc(c.class_name)}</option>`).join('');
  };
  el('st-year').onchange = fillClasses;
  fillClasses();
  el('st-error').hidden = true;
  el('add-student-form').reset();
  showView('add-student');
});

el('add-student-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = el('st-error');
  err.hidden = true;
  const res = await registerStudent({
    fullName: el('st-name').value.trim(),
    studentNumber: el('st-number').value.trim(),
    classId: el('st-class').value,
    academicYearId: el('st-year').value,
    birthDate: el('st-birth').value || null,
    gender: el('st-gender').value || null,
  });
  if (!res.ok) { err.hidden = false; err.textContent = res.error; return; }
  toast('تم تسجيل التلميذ بنجاح.', 'success');
  showView('students');
  loadStudents();
});

// ===== STAFF =====
const STAFF_LISTERS = { teachers: listTeachers, guards: listGuards, drivers: listDrivers, parents: listParents };

async function loadStaff() {
  const kind = el('staff-kind').value;
  const panel = el('staff-panel');
  panel.innerHTML = loadingHtml();
  const rows = await STAFF_LISTERS[kind](el('staff-search').value);
  panel.innerHTML = rows.length
    ? rows.map((r) => {
        const name = r.profiles?.full_name || r.fullName || '—';
        const num = r.profiles?.user_number || r.userNumber || '';
        const badge = kind === 'guards'
          ? (r.isDisabled ? '<span class="badge badge-red">معطل</span>' : '<span class="badge badge-green">نشط</span>')
          : '';
        return `<div class="history-item"><div><strong>${esc(name)}</strong> <span class="time">${esc(num)}</span></div>${badge}</div>`;
      }).join('')
    : emptyHtml('لا توجد نتائج.');
}
el('staff-kind').addEventListener('change', loadStaff);
el('staff-search').addEventListener('input', loadStaff);

el('btn-add-staff').addEventListener('click', () => {
  currentStaffType = { teachers: 'teacher', guards: 'guard', drivers: 'driver', parents: 'parent' }[el('staff-kind').value];
  const labels = { teacher: 'إضافة أستاذ', guard: 'إضافة حارس', driver: 'إضافة سائق', parent: 'إضافة ولي أمر' };
  el('staff-add-title').textContent = labels[currentStaffType];
  const extra = el('sf-extra-1');
  if (currentStaffType === 'teacher') { extra.hidden = false; el('sf-extra-1-label').textContent = 'رقم الموظف'; }
  else if (currentStaffType === 'driver') { extra.hidden = false; el('sf-extra-1-label').textContent = 'رقم رخصة القيادة'; }
  else extra.hidden = true;
  el('sf-error').hidden = true;
  el('add-staff-form').reset();
  showView('add-staff');
});

el('add-staff-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = el('sf-error');
  err.hidden = true;
  const base = {
    fullName: el('sf-name').value.trim(),
    email: el('sf-email').value.trim(),
    password: el('sf-password').value,
    phone: el('sf-phone').value.trim() || undefined,
  };
  const result = currentStaffType === 'guard'
    ? await createGuardAccount(base)
    : await createStaffAccount({
        ...base,
        accountType: currentStaffType,
        employeeNumber: currentStaffType === 'teacher' ? el('sf-extra-1-input').value.trim() || undefined : undefined,
        licenseNumber: currentStaffType === 'driver' ? el('sf-extra-1-input').value.trim() || undefined : undefined,
      });
  if (!result.ok) { err.hidden = false; err.textContent = result.error; return; }
  toast('تم إنشاء الحساب بنجاح.', 'success');
  showView('staff');
  loadStaff();
});

// ===== ATTENDANCE =====
async function loadAttendance() {
  const host = el('att-today');
  host.innerHTML = loadingHtml();
  const res = await schoolAttendanceToday();
  const t = res.ok && res.data?.length ? res.data[0] : {};
  host.innerHTML = '<div class="stats-grid">'
    + statCard(t.present ?? 0, 'حاضر', 'tone-green') + statCard(t.absent ?? 0, 'غائب', 'tone-red')
    + statCard(t.late ?? 0, 'متأخر', 'tone-gold') + statCard(t.excused ?? 0, 'مبرر')
    + statCard(t.total_marked ?? 0, 'إجمالي المسجلين') + '</div>';
  const { classes } = await ensureYearsClasses();
  el('att-class').innerHTML = '<option value="">— اختر القسم —</option>'
    + classes.map((c) => `<option value="${c.class_id}">${esc(c.class_name)} — ${esc(c.year_name || '')}</option>`).join('');
  el('att-date').valueAsDate = new Date();
  el('att-roster').innerHTML = '';
}

el('att-load').addEventListener('click', async () => {
  const classId = el('att-class').value;
  const date = el('att-date').value || null;
  if (!classId) { toast('اختر القسم أولًا.', 'error'); return; }
  const host = el('att-roster');
  host.innerHTML = loadingHtml();
  const res = await getClassAttendance(classId, date);
  if (!res.ok) { host.innerHTML = emptyHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا يوجد تلاميذ في هذا القسم.'); return; }
  const state = {};
  rows.forEach((r) => { state[r.student_id] = r.status || 'present'; });
  const render = () => {
    host.innerHTML = rows.map((r) => `
      <div class="history-item" style="align-items:flex-start; flex-direction:column; gap:6px;">
        <div><strong>${esc(r.full_name)}</strong> <span class="time">#${esc(r.student_number || '')}</span></div>
        <div style="display:flex; gap:6px;">
          ${['present', 'absent', 'late', 'excused'].map((st) => `<button type="button" class="att-btn ${state[r.student_id] === st ? 'active-' + st : ''}" data-st="${r.student_id}" data-val="${st}">${attStatusAr(st)}</button>`).join('')}
        </div>
      </div>`).join('')
      + '<button type="button" class="quick-action-btn" id="att-save" style="width:100%; margin-top:10px;">حفظ الحضور</button>';
    host.querySelectorAll('[data-st]').forEach((b) => b.addEventListener('click', () => { state[b.dataset.st] = b.dataset.val; render(); }));
    el('att-save').addEventListener('click', async () => {
      const payload = Object.entries(state).map(([student_id, status]) => ({ student_id, status }));
      const res2 = await saveAttendance(classId, date, payload);
      if (!res2.ok) { toast(res2.error, 'error'); return; }
      toast(`تم حفظ حضور ${res2.data} تلميذًا.`, 'success');
      loadAttendance();
    });
  };
  render();
});

// ===== TRANSPORT =====
async function loadTransport() {
  const bp = el('buses-panel');
  const rp = el('routes-panel');
  bp.innerHTML = loadingHtml();
  rp.innerHTML = loadingHtml();
  const [buses, routes] = await Promise.all([listBuses(), listRoutes()]);
  const b = buses.ok ? buses.data || [] : [];
  bp.innerHTML = b.length
    ? b.map((x) => `<div class="history-item"><strong>${esc(x.code)}</strong>
        <span class="time">${esc(x.plate || '')} ${x.driver_name ? '— ' + esc(x.driver_name) : ''}</span></div>`).join('')
    : emptyHtml('لا توجد حافلات.');
  const r = routes.ok ? routes.data || [] : [];
  rp.innerHTML = r.length
    ? r.map((x) => `<div class="history-item"><strong>${esc(x.route_name)}</strong>
        <span class="time">${(Array.isArray(x.stops) ? x.stops.length : 0)} محطة</span></div>`).join('')
    : emptyHtml('لا توجد مسارات.');
}

// ===== FINANCE =====
async function loadFinance() {
  const sum = el('fin-summary');
  sum.innerHTML = loadingHtml();
  const res = await financeSummary(null, null);
  const d = res.ok && res.data?.length ? res.data[0] : {};
  sum.innerHTML = '<div class="stats-grid">'
    + statCard(fmtMoney(d.total_paid), 'إجمالي الأداءات', 'tone-green')
    + statCard(fmtMoney(d.total_expenses), 'إجمالي المصاريف', 'tone-red')
    + statCard(fmtMoney(d.net), 'الرصيد', 'tone-gold') + '</div>';
  loadPayments();
  loadExpenses();
}

async function loadPayments() {
  const panel = el('payments-panel');
  panel.innerHTML = loadingHtml();
  const res = await listPayments(null, 30);
  const rows = res.ok ? res.data || [] : [];
  panel.innerHTML = rows.length
    ? rows.map((p) => `<div class="history-item"><div><strong>${esc(p.student_name || '')}</strong>
        <span class="time">${esc(p.fee_type || '')}</span></div>
        <span class="time">${fmtMoney(p.amount_paid)} / ${fmtMoney(p.amount_due)} — ${fmtDate(p.payment_date)}</span></div>`).join('')
    : emptyHtml('لا توجد أداءات.');
}

async function loadExpenses() {
  const panel = el('expenses-panel');
  panel.innerHTML = loadingHtml();
  const res = await listExpenses(30);
  const rows = res.ok ? res.data || [] : [];
  panel.innerHTML = rows.length
    ? rows.map((x) => `<div class="history-item"><div><strong>${esc(x.category || '')}</strong>
        <span class="time">${esc(x.description || '')}</span></div>
        <span class="time">${fmtMoney(x.amount)} — ${fmtDate(x.expense_date)}</span></div>`).join('')
    : emptyHtml('لا توجد مصاريف.');
}

function wireStudentPicker(inputId, resultsId, onPick) {
  el(inputId).addEventListener('input', async () => {
    const q = el(inputId).value;
    const host = el(resultsId);
    if (!q.trim()) { host.innerHTML = ''; return; }
    const rows = await searchStudents(q);
    host.innerHTML = rows.map((s) => `<div class="history-item" data-pick="${s.id}" data-name="${esc(s.full_name)}" style="cursor:pointer;">
      <strong>${esc(s.full_name)}</strong> <span class="time">#${esc(s.student_number || '')}</span></div>`).join('');
    host.querySelectorAll('[data-pick]').forEach((it) => it.addEventListener('click', () => {
      onPick({ id: it.dataset.pick, name: it.dataset.name });
      host.innerHTML = `<div class="history-item"><strong>${esc(it.dataset.name)}</strong> <span class="badge badge-green">محدد</span></div>`;
    }));
  });
}

wireStudentPicker('pay-student-search', 'pay-student-results', (s) => { pickedStudent = s; });

el('add-payment-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = el('pay-error');
  err.hidden = true;
  if (!pickedStudent) { err.hidden = false; err.textContent = 'اختر التلميذ أولًا.'; return; }
  const res = await recordPayment({
    studentId: pickedStudent.id,
    feeType: el('pay-type').value.trim(),
    amountDue: Number(el('pay-due').value),
    amountPaid: Number(el('pay-paid').value),
    method: el('pay-method').value.trim() || null,
  });
  if (!res.ok) { err.hidden = false; err.textContent = res.error; return; }
  toast('تم تسجيل الأداء.', 'success');
  e.target.reset();
  pickedStudent = null;
  el('pay-student-results').innerHTML = '';
  loadFinance();
});

el('add-expense-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = el('exp-error');
  err.hidden = true;
  const res = await recordExpense({
    category: el('exp-category').value.trim(),
    amount: Number(el('exp-amount').value),
    description: el('exp-desc').value.trim() || null,
  });
  if (!res.ok) { err.hidden = false; err.textContent = res.error; return; }
  toast('تم تسجيل المصروف.', 'success');
  e.target.reset();
  loadFinance();
});

// ===== INCIDENTS =====
async function loadIncidents() {
  const panel = el('incidents-panel');
  panel.innerHTML = loadingHtml();
  const res = await listIncidents(el('inc-status').value || null, 50, 0);
  const rows = res.ok ? res.data || [] : [];
  panel.innerHTML = rows.length
    ? rows.map((i) => `<div class="history-item"><div><strong>${esc(i.title)}</strong>
        <span class="time">${esc(i.student_name || '')} — ${esc(i.type || '')}</span></div>
        <span class="badge ${i.status === 'open' ? 'badge-red' : 'badge-green'}">${i.status === 'open' ? 'مفتوحة' : 'مغلقة'}</span></div>`).join('')
    : emptyHtml('لا توجد مخالفات.');
}
el('inc-status').addEventListener('change', loadIncidents);
el('btn-add-incident').addEventListener('click', () => {
  pickedStudent = null;
  el('inc-error').hidden = true;
  el('add-incident-form').reset();
  el('inc-student-results').innerHTML = '';
  showView('add-incident');
});
wireStudentPicker('inc-student-search', 'inc-student-results', (s) => { pickedStudent = s; });

el('add-incident-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = el('inc-error');
  err.hidden = true;
  if (!pickedStudent) { err.hidden = false; err.textContent = 'اختر التلميذ أولًا.'; return; }
  const res = await reportIncident({
    studentId: pickedStudent.id,
    type: el('inc-type').value.trim(),
    title: el('inc-title').value.trim(),
    description: el('inc-desc').value.trim() || null,
    place: el('inc-place').value.trim() || null,
  });
  if (!res.ok) { err.hidden = false; err.textContent = res.error; return; }
  toast('تم إرسال البلاغ.', 'success');
  showView('incidents');
  loadIncidents();
});

// ===== NOTIFICATIONS =====
async function loadNotifications() {
  const panel = el('notif-panel');
  panel.innerHTML = loadingHtml();
  const res = await listMyNotifications(50);
  const rows = res.ok ? res.data || [] : [];
  panel.innerHTML = rows.length
    ? rows.map((n) => `<div class="history-item" data-notif="${n.notification_id}" style="cursor:pointer;">
        <div><strong>${esc(n.title)}</strong><div class="time">${esc(n.body || '')}</div></div>
        <span class="time">${fmtDateTime(n.created_at)}</span></div>`).join('')
    : emptyHtml('لا توجد إشعارات.');
  panel.querySelectorAll('[data-notif]').forEach((it) => it.addEventListener('click', () => {
    markNotificationRead(it.dataset.notif);
    refreshNotifCount();
  }));
}

el('send-notif-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = el('nt-error');
  err.hidden = true;
  const res = await sendNotification({
    title: el('nt-title').value.trim(),
    body: el('nt-body').value.trim() || null,
    targetRole: el('nt-role').value || null,
  });
  if (!res.ok) { err.hidden = false; err.textContent = res.error; return; }
  toast('تم إرسال الإشعار.', 'success');
  e.target.reset();
});

// ===== REPORTS =====
el('rp-attendance').addEventListener('click', async () => {
  const host = el('rp-result');
  host.hidden = false;
  host.innerHTML = loadingHtml();
  const res = await reportAttendance(el('rp-from').value || null, el('rp-to').value || null, null);
  const rows = res.ok ? res.data || [] : [];
  host.innerHTML = rows.length
    ? '<p class="section-title">تقرير الحضور</p>' + rows.map((r) => `<div class="detail-row">
        <span class="k">${esc(r.student_name || '')} — ${esc(r.class_name || '')} — ${fmtDate(r.att_date)}</span>
        <span class="v">${attStatusAr(r.status)}</span></div>`).join('')
    : emptyHtml('لا توجد بيانات في هذه الفترة.');
});

el('rp-finance').addEventListener('click', async () => {
  const host = el('rp-result');
  host.hidden = false;
  host.innerHTML = loadingHtml();
  const res = await financeSummary(el('rp-from').value || null, el('rp-to').value || null);
  if (!res.ok) { host.innerHTML = emptyHtml(res.error); return; }
  const d = res.data?.length ? res.data[0] : {};
  host.innerHTML = '<p class="section-title">التقرير المالي</p><div class="stats-grid">'
    + statCard(fmtMoney(d.total_paid), 'الأداءات', 'tone-green')
    + statCard(fmtMoney(d.total_expenses), 'المصاريف', 'tone-red')
    + statCard(fmtMoney(d.net), 'الرصيد', 'tone-gold') + '</div>';
});
