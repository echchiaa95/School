import { requireAuth, logout } from './auth.js';
import {
  el, esc, fmtDate, fmtDateTime, fmtMoney, attStatusAr, toast,
  loadingHtml, emptyHtml, errorHtml, initPageHeader, showView,
  armViewHistory, armErrorBoundary, showInitError,
} from './ui.js';
import {
  myChildren, getStudentAttendance, listStudentGrades,
  studentTransportInfo, childPayments, listMyNotifications,
  markNotificationRead, unreadNotificationsCount, getSchoolProfile,
} from './school.js';

let ctx = null;
let children = [];
let currentChild = null;

const REL_AR = { father: 'الأب', mother: 'الأم', guardian: 'ولي الأمر' };

// ---- Children list ----------------------------------------------------------
async function loadChildren() {
  const host = el('children-list');
  host.innerHTML = loadingHtml();
  const res = await myChildren();
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  children = res.data || [];
  if (!children.length) {
    host.innerHTML = emptyHtml('لا يوجد أبناء مرتبطون بهذا الحساب. تواصل مع إدارة المؤسسة.');
    return;
  }
  host.innerHTML = `<div class="modules-grid">${children.map((c) => `
    <button type="button" class="module-card" data-child="${c.student_id}">
      ${c.photo_url
        ? `<img src="${esc(c.photo_url)}" alt="" style="width:48px; height:48px; border-radius:50%; object-fit:cover;" />`
        : '<span class="module-icon">🎓</span>'}
      ${esc(c.full_name)}
      <span class="badge badge-blue">${esc(c.class_name || 'بدون قسم')}${c.level ? ' — ' + esc(c.level) : ''}</span>
    </button>`).join('')}</div>`;
  host.querySelectorAll('[data-child]').forEach((b) => {
    b.addEventListener('click', () => openChild(b.dataset.child));
  });
}

// ---- Child detail -----------------------------------------------------------
function openChild(studentId) {
  currentChild = children.find((c) => c.student_id === studentId) || null;
  if (!currentChild) return;
  el('child-header').innerHTML = `<div class="panel">
    <div class="detail-row"><strong>الاسم</strong><span>${esc(currentChild.full_name)}</span></div>
    <div class="detail-row"><strong>الرقم</strong><span>${esc(currentChild.student_number || '—')}</span></div>
    <div class="detail-row"><strong>القسم</strong><span>${esc(currentChild.class_name || '—')}${currentChild.level ? ' — ' + esc(currentChild.level) : ''}</span></div>
    <div class="detail-row"><strong>صلة القرابة</strong><span>${REL_AR[currentChild.relationship] || esc(currentChild.relationship || '—')}</span></div>
  </div>`;
  showView('child');
  switchTab('attendance');
}

function switchTab(tab) {
  document.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('[data-tab-panel]').forEach((p) => { p.hidden = p.dataset.tabPanel !== tab; });
  if (tab === 'attendance') loadAttendance();
  if (tab === 'grades') loadGrades();
  if (tab === 'transport') loadTransport();
  if (tab === 'payments') loadPayments();
}

async function loadAttendance() {
  const host = el('child-attendance');
  host.innerHTML = loadingHtml();
  const res = await getStudentAttendance(currentChild.student_id, el('att-from').value || null, el('att-to').value || null);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد سجلات حضور في هذه الفترة.'); return; }
  const counts = rows.reduce((acc, r) => { acc[r.status] = (acc[r.status] || 0) + 1; return acc; }, {});
  host.innerHTML = `
    <div class="stats-grid" style="margin-bottom:12px;">
      <div class="stat-card tone-green"><div class="stat-value">${counts.present || 0}</div><div class="stat-label">حاضر</div></div>
      <div class="stat-card tone-red"><div class="stat-value">${counts.absent || 0}</div><div class="stat-label">غائب</div></div>
      <div class="stat-card tone-gold"><div class="stat-value">${counts.late || 0}</div><div class="stat-label">متأخر</div></div>
      <div class="stat-card"><div class="stat-value">${counts.excused || 0}</div><div class="stat-label">مبرر</div></div>
    </div>
    <div class="data-table-wrap"><table class="data-table"><thead><tr><th>التاريخ</th><th>الحالة</th></tr></thead>
    <tbody>${rows.map((r) => `<tr><td>${fmtDate(r.att_date)}</td><td><span class="badge ${
      r.status === 'present' ? 'badge-green' : r.status === 'absent' ? 'badge-red' : r.status === 'late' ? 'badge-gold' : 'badge-blue'
    }">${attStatusAr(r.status)}</span></td></tr>`).join('')}</tbody></table></div>`;
}

async function loadGrades() {
  const host = el('child-grades');
  host.innerHTML = loadingHtml();
  const res = await listStudentGrades(currentChild.student_id);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد نقاط مسجلة بعد.'); return; }
  host.innerHTML = `<div class="data-table-wrap"><table class="data-table"><thead><tr>
    <th>المادة</th><th>الفترة</th><th>النوع</th><th>النقطة</th><th>التاريخ</th>
  </tr></thead><tbody>${rows.map((g) => `<tr>
    <td>${esc(g.subject_name || '—')}</td><td>${esc(g.period || '—')}</td>
    <td>${esc(g.grade_type || '—')}</td><td>${g.score}/${g.max_score ?? 20}</td>
    <td>${fmtDate(g.created_at)}</td>
  </tr>`).join('')}</tbody></table></div>`;
}

async function loadTransport() {
  const host = el('child-transport');
  host.innerHTML = loadingHtml();
  const res = await studentTransportInfo(currentChild.student_id);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const t = res.data;
  if (!t) { host.innerHTML = emptyHtml('هذا التلميذ غير مسجل في النقل المدرسي.'); return; }
  host.innerHTML = `
    <div class="detail-row"><strong>الحافلة</strong><span>${esc(t.bus_code || '—')}${t.bus_plate ? ' (' + esc(t.bus_plate) + ')' : ''}</span></div>
    <div class="detail-row"><strong>المسار</strong><span>${esc(t.route_name || '—')}</span></div>
    <div class="detail-row"><strong>محطة الصعود</strong><span>${esc(t.pickup_stop || '—')}</span></div>
    <div class="detail-row"><strong>محطة النزول</strong><span>${esc(t.dropoff_stop || '—')}</span></div>`;
}

async function loadPayments() {
  const host = el('child-payments');
  host.innerHTML = loadingHtml();
  const res = await childPayments(currentChild.student_id);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد أداءات مسجلة.'); return; }
  const totalDue = rows.reduce((s, r) => s + Number(r.amount_due || 0), 0);
  const totalPaid = rows.reduce((s, r) => s + Number(r.amount_paid || 0), 0);
  host.innerHTML = `
    <div class="stats-grid" style="margin-bottom:12px;">
      <div class="stat-card"><div class="stat-value">${fmtMoney(totalDue)}</div><div class="stat-label">المستحق</div></div>
      <div class="stat-card tone-green"><div class="stat-value">${fmtMoney(totalPaid)}</div><div class="stat-label">المدفوع</div></div>
      <div class="stat-card tone-red"><div class="stat-value">${fmtMoney(totalDue - totalPaid)}</div><div class="stat-label">المتبقي</div></div>
    </div>
    <div class="data-table-wrap"><table class="data-table"><thead><tr>
      <th>نوع الرسوم</th><th>المستحق</th><th>المدفوع</th><th>التاريخ</th><th>الوصل</th>
    </tr></thead><tbody>${rows.map((p) => `<tr>
      <td>${esc(p.fee_type)}</td><td>${fmtMoney(p.amount_due)}</td><td>${fmtMoney(p.amount_paid)}</td>
      <td>${fmtDate(p.payment_date)}</td><td>${esc(p.receipt_no || '—')}</td>
    </tr>`).join('')}</tbody></table></div>`;
}

// ---- Notifications ----------------------------------------------------------
async function loadNotifications() {
  const host = el('notif-list');
  host.innerHTML = loadingHtml();
  const res = await listMyNotifications(50);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد إشعارات.'); refreshNotifBadge(); return; }
  host.innerHTML = rows.map((n) => `
    <div class="detail-row" data-notif="${n.id}" style="cursor:pointer; ${n.is_read ? 'opacity:.65;' : 'font-weight:600;'}">
      <div style="flex:1;">
        <div>${esc(n.title)}</div>
        ${n.body ? `<div style="font-size:.85em; color:var(--muted);">${esc(n.body)}</div>` : ''}
      </div>
      <span class="badge badge-blue">${esc(n.type || '')}</span>
      <span style="font-size:.8em; color:var(--muted);">${fmtDateTime(n.created_at)}</span>
    </div>`).join('');
  host.querySelectorAll('[data-notif]').forEach((row) => {
    row.addEventListener('click', async () => {
      await markNotificationRead(row.dataset.notif);
      row.style.opacity = '.65';
      row.style.fontWeight = '400';
      refreshNotifBadge();
    });
  });
  refreshNotifBadge();
}

async function refreshNotifBadge() {
  const res = await unreadNotificationsCount();
  const badge = el('notif-count');
  if (!badge) return;
  const count = res.ok ? (res.data || 0) : 0;
  badge.hidden = !count;
  badge.textContent = count;
}

// ---- Init -------------------------------------------------------------------
(async () => {
  try {
    armErrorBoundary();
    ctx = await requireAuth('parent.html');
    if (!ctx) return;
    armViewHistory('home');
    document.getElementById('app-body').hidden = false;

    const schoolRes = await getSchoolProfile(ctx.schoolId);
    await initPageHeader(ctx, schoolRes.ok ? schoolRes.data?.name : null, logout);

    const today = new Date();
    const monthAgo = new Date(today.getTime() - 30 * 86400000);
    el('att-from').value = monthAgo.toISOString().slice(0, 10);
    el('att-to').value = today.toISOString().slice(0, 10);

    document.querySelectorAll('[data-back]').forEach((b) => {
      b.addEventListener('click', () => showView('home'));
    });
    document.querySelectorAll('[data-tab]').forEach((b) => {
      b.addEventListener('click', () => switchTab(b.dataset.tab));
    });
    el('att-reload').addEventListener('click', loadAttendance);
    el('notif-btn').addEventListener('click', () => { showView('notifications'); loadNotifications(); });

    await loadChildren();
    refreshNotifBadge();
  } catch (error) {
    console.error('parent portal init error:', error);
    showInitError(error);
  }
})();
