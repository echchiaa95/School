# Phase 117 — Student photo RPC and fee calendar hotfix

## Fixes
- Removes every legacy overload of `public.fn_update_student_photo` and recreates exactly one signature: `(p_student_id uuid, p_photo_url text)`. This resolves PostgREST `PGRST203` ambiguity while preserving the existing authorization and Storage URL checks.
- Makes `fn_student_fee_calendar(uuid)` `VOLATILE` and lazily invokes the idempotent `fn_generate_student_fee_obligations(student_id, active_academic_year_id)` before reading the ledger. Students enrolled before Phase 99/116 therefore receive their missing ledger obligations when the calendar is opened, provided an active fee plan applies to their school and level.
- Does not invent fee amounts, does not create payments, and does not change existing payment allocations or receipts.

## Deployment
Run `supabase/migrations/phase117_student_photo_rpc_and_fee_calendar_hotfix.sql` once in Supabase SQL Editor, then redeploy the complete project files. The SQL ends with a PostgREST schema cache reload.

## Important
If the calendar still says “لا توجد رسوم مسجلة”, verify that the student has an ACTIVE enrollment in the current academic year and that the school has active fee plans whose effective dates and `levels` include the student's class level. The migration intentionally does not fabricate fee plans or prices.
