-- Phase 117 hotfix: remove ambiguous photo RPC overloads and backfill the
-- ledger lazily when a student annual fee calendar is opened.
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS signature
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND p.proname = 'fn_update_student_photo'
      AND p.prokind = 'f'
  LOOP
    EXECUTE format('DROP FUNCTION %s', r.signature);
  END LOOP;
END;
$$;

CREATE FUNCTION public.fn_update_student_photo(
  p_student_id uuid,
  p_photo_url text
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_id uuid;
  v_role text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  IF p_student_id IS NULL THEN RAISE EXCEPTION 'INVALID_STUDENT'; END IF;

  SELECT s.school_id INTO v_school_id
  FROM public.students s
  WHERE s.id = p_student_id AND s.deleted_at IS NULL;
  IF v_school_id IS NULL THEN RAISE EXCEPTION 'INVALID_STUDENT'; END IF;

  v_role := public.fn_resolve_my_role(v_school_id);
  IF NOT (
    v_role = 'admin'
    OR public.fn_has_permission('students.photo.manage', v_school_id)
    OR public.fn_is_school_staff(v_school_id)
  ) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;

  IF p_photo_url IS NOT NULL AND (
    length(trim(p_photo_url)) = 0
    OR p_photo_url NOT LIKE '%/storage/v1/object/public/student-photos/%'
  ) THEN RAISE EXCEPTION 'INVALID_STUDENT_PHOTO_URL'; END IF;

  UPDATE public.students
  SET photo_url = NULLIF(trim(p_photo_url), ''), updated_at = now()
  WHERE id = p_student_id AND school_id = v_school_id;

  PERFORM public.fn_safe_audit(
    v_school_id, 'STUDENT_PHOTO_UPDATED', 'students', p_student_id,
    NULL, jsonb_build_object('photo_url', p_photo_url, 'updated_by', auth.uid())
  );
END;
$$;
REVOKE ALL ON FUNCTION public.fn_update_student_photo(uuid,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_update_student_photo(uuid,text) TO authenticated;

CREATE OR REPLACE FUNCTION public.fn_student_fee_calendar(p_student_id uuid)
RETURNS TABLE(
  obligation_id uuid, academic_year_id uuid, fee_type text, period_key text,
  period_start date, period_end date, list_amount numeric, discount_amount numeric,
  amount_due numeric, amount_paid numeric, remaining numeric, status text,
  paid_transactions jsonb
)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_school uuid; v_year uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  SELECT s.school_id INTO v_school FROM public.students s
  WHERE s.id=p_student_id AND s.deleted_at IS NULL;
  IF v_school IS NULL THEN RAISE EXCEPTION 'INVALID_STUDENT'; END IF;
  IF NOT (public.fn_is_school_staff(v_school) OR public.fn_has_permission('finance.view',v_school)
          OR public.fn_has_permission('finance.manage',v_school)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  SELECT se.academic_year_id INTO v_year
  FROM public.student_enrollments se
  WHERE se.student_id=p_student_id AND se.school_id=v_school AND se.status='ACTIVE'
  ORDER BY se.created_at DESC LIMIT 1;
  IF v_year IS NOT NULL THEN
    PERFORM public.fn_generate_student_fee_obligations(p_student_id, v_year);
  END IF;
  RETURN QUERY
  SELECT o.id,o.academic_year_id,o.fee_type,o.period_key,o.period_start,o.period_end,
         o.list_amount,o.discount_amount,o.amount_due,o.amount_paid,
         GREATEST(0,o.amount_due-o.amount_paid),o.status,
         COALESCE((
           SELECT jsonb_agg(jsonb_build_object(
             'amount',a.amount,'paid_on',t.paid_on,'method',t.method,
             'receipt_no',t.receipt_no,'transaction_id',t.id
           ) ORDER BY t.paid_on)
           FROM public.student_fee_payment_allocations a
           JOIN public.student_fee_payment_transactions t ON t.id=a.transaction_id
           WHERE a.obligation_id=o.id
         ),'[]'::jsonb)
  FROM public.student_fee_obligations o
  WHERE o.student_id=p_student_id AND o.school_id=v_school
    AND (v_year IS NULL OR o.academic_year_id=v_year)
  ORDER BY o.period_start,o.fee_type;
END;
$$;
REVOKE ALL ON FUNCTION public.fn_student_fee_calendar(uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_student_fee_calendar(uuid) TO authenticated;
NOTIFY pgrst, 'reload schema';
