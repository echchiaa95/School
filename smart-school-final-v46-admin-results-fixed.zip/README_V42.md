# Smart School V42

This package is based on V41 and preserves the existing application files.
The intended V42 account integration targets are:
- Teacher: enter assessments, coefficients, marks, and notes.
- Administration/director: review and approve.
- General supervisor: view and print.
- Student/parent: read-only results.
- Driver: no grades module.
