# V40 — Grade system in accounts

- Added subject coefficient storage per class and academic year.
- Added RPC to read subject coefficients.
- V39 assessment/mark foundation retained.
- This phase is database foundation; account UI wiring and PDF result sheets follow in the next implementation step.
