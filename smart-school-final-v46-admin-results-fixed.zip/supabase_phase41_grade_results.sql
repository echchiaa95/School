-- PHASE 41 — Semester and annual grade calculations
-- MUTATING SQL: run once on Smart School Production.

create or replace function public.fn_grade_semester_summary(
  p_class_id uuid,
  p_period text
)
returns table(
  student_id uuid,
  student_name text,
  semester_average numeric
)
language sql stable security definer set search_path=public
as $$
  with subject_scores as (
    select
      s.id as student_id,
      s.full_name as student_name,
      ga.subject_id,
      coalesce(gsc.coefficient,1) as subject_coefficient,
      sum(gm.score / nullif(ga.max_score,0) *
          case when c.level ilike '%ابتدائي%' or c.level ilike '%primary%' then 10 else 20 end *
          ga.coefficient) / nullif(sum(ga.coefficient),0) as subject_score
    from public.students s
    join public.student_enrollments se on se.student_id=s.id and se.class_id=p_class_id
    join public.classes c on c.id=se.class_id
    join public.grade_assessments ga on ga.class_id=p_class_id and ga.period=p_period
    join public.grade_marks gm on gm.assessment_id=ga.id and gm.student_id=s.id
    left join public.grade_subject_coefficients gsc on gsc.class_id=p_class_id and gsc.subject_id=ga.subject_id
    where s.deleted_at is null
    group by s.id,s.full_name,ga.subject_id,gsc.coefficient,c.level
  )
  select student_id,student_name,
    round((sum(subject_score*subject_coefficient)/nullif(sum(subject_coefficient),0))::numeric,2)
  from subject_scores
  group by student_id,student_name
  order by student_name;
$$;

create or replace function public.fn_grade_annual_summary(p_class_id uuid)
returns table(student_id uuid, student_name text, semester_1 numeric, semester_2 numeric, annual_average numeric)
language sql stable security definer set search_path=public
as $$
  with s1 as (select * from public.fn_grade_semester_summary(p_class_id,'SEMESTER_1')),
       s2 as (select * from public.fn_grade_semester_summary(p_class_id,'SEMESTER_2'))
  select coalesce(s1.student_id,s2.student_id), coalesce(s1.student_name,s2.student_name),
         s1.semester_average, s2.semester_average,
         case when s1.semester_average is not null and s2.semester_average is not null
              then round(((s1.semester_average+s2.semester_average)/2)::numeric,2) end
  from s1 full join s2 on s2.student_id=s1.student_id
  order by coalesce(s1.student_name,s2.student_name);
$$;

revoke all on function public.fn_grade_semester_summary(uuid,text) from public;
revoke all on function public.fn_grade_annual_summary(uuid) from public;
grant execute on function public.fn_grade_semester_summary(uuid,text) to authenticated;
grant execute on function public.fn_grade_annual_summary(uuid) to authenticated;
