-- PHASE 45 — Admin results selectors and editable subject coefficients
-- MUTATING SQL: run once in Supabase SQL Editor.
create or replace function public.fn_set_grade_subject_coefficient(p_class_id uuid, p_subject_id uuid, p_coefficient numeric)
returns table(subject_id uuid, subject_name text, coefficient numeric)
language plpgsql security definer set search_path=public
as $$
declare v_school_id uuid;
declare v_year_id uuid;
begin
  if p_coefficient is null or p_coefficient <= 0 then raise exception 'COEFFICIENT_INVALID'; end if;
  select school_id, academic_year_id into v_school_id, v_year_id from public.classes where id=p_class_id;
  if v_school_id is null then raise exception 'CLASS_NOT_FOUND'; end if;
  if not public.fn_is_school_staff(v_school_id) then raise exception 'FORBIDDEN'; end if;
  insert into public.grade_subject_coefficients(school_id,class_id,subject_id,academic_year_id,coefficient,created_by,updated_at)
  values(v_school_id,p_class_id,p_subject_id,v_year_id,p_coefficient,auth.uid(),now())
  on conflict(class_id,subject_id,academic_year_id) do update set coefficient=excluded.coefficient,updated_at=now();
  return query select x.subject_id, x.subject_name, x.coefficient from public.fn_grade_subject_coefficients(p_class_id) as x where x.subject_id=p_subject_id;
end;
$$;
revoke all on function public.fn_set_grade_subject_coefficient(uuid,uuid,numeric) from public;
grant execute on function public.fn_set_grade_subject_coefficient(uuid,uuid,numeric) to authenticated;
