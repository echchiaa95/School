# V41 — Semester and annual grade calculations
- Added `fn_grade_semester_summary(class_id, period)`.
- Added `fn_grade_annual_summary(class_id)`.
- Uses assessment coefficients and subject coefficients.
- Supports primary scale 10 and other levels scale 20.
- Annual average = (semester 1 + semester 2) / 2.
