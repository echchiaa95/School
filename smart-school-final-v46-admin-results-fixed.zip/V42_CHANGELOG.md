# V42 — Grades accounts foundation

- Prepared the V42 package from V41.
- Preserved the existing V39/V40/V41 grade tables and calculation RPCs.
- Reserved the account integration layer for teacher, administration, general supervisor, student, and parent roles.
- Driver account remains excluded from grades.

Note: this package is a foundation handoff; the complete interactive account screens and PDF report require the next implementation pass.
