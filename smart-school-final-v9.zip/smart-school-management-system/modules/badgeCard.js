// ============================================================================
// modules/badgeCard.js
// Shared "student ID badge" rendering: QR code + printable card.
// Used by both guard.html (issue/reissue/suspend flow, already wired to
// fn_guard_issue_badge/reissue/suspend via students.js) and admin.html
// (Student Profile). No new backend permission model — this only renders
// what fn_get_student_badge / issueBadge / reissueBadge already return.
// ============================================================================

import { esc } from './ui.js';

let qrLibPromise = null;
function loadQrLib() {
  if (window.QRCode) return Promise.resolve();
  if (qrLibPromise) return qrLibPromise;
  qrLibPromise = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    // "qrcode" (soldair) — MIT, UMD build, exposes window.QRCode.toCanvas/toDataURL.
    s.src = 'https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js';
    s.onload = () => resolve();
    s.onerror = () => reject(new Error('QR_LIB_LOAD_FAILED'));
    document.head.appendChild(s);
  });
  return qrLibPromise;
}

const STATUS_AR = {
  ACTIVE: 'سارية', SUSPENDED: 'موقوفة', LOST: 'مفقودة',
  EXPIRED: 'منتهية', REPLACED: 'مستبدلة',
};

/**
 * Render a printable ID-card panel with a real QR code encoding the
 * badge's secure_token, into `container` (an existing DOM element).
 * @param {HTMLElement} container
 * @param {{full_name:string, student_number:string, class_name?:string, school_name?:string}} student
 * @param {{status:string, secure_token:string}} badge
 */
export async function renderBadgeCard(container, student, badge) {
  const cardId = 'badge-card-' + Math.random().toString(36).slice(2, 8);
  container.innerHTML = `
    <div class="panel" id="${cardId}" style="text-align:center; max-width:320px; margin:0 auto;">
      <div style="font-weight:700; font-size:14px;">${esc(student.school_name || '')}</div>
      <div style="font-weight:800; font-size:18px; margin-top:6px;">${esc(student.full_name)}</div>
      <div style="color:#6b7280; font-size:13px;">#${esc(student.student_number || '')} ${student.class_name ? '— ' + esc(student.class_name) : ''}</div>
      <div class="qr-holder" style="display:flex; justify-content:center; margin:12px 0;"><div class="loading-state">جارٍ إنشاء QR...</div></div>
      <div class="badge badge-${badge.status === 'ACTIVE' ? 'green' : 'red'}">${esc(STATUS_AR[badge.status] || badge.status)}</div>
    </div>
    <button type="button" class="quick-action-btn secondary" id="${cardId}-print" style="width:100%; margin-top:10px;">🖨️ طباعة البطاقة</button>`;

  const holder = container.querySelector('.qr-holder');
  try {
    await loadQrLib();
    const canvas = document.createElement('canvas');
    await window.QRCode.toCanvas(canvas, String(badge.secure_token), { width: 160, margin: 1 });
    holder.innerHTML = '';
    holder.appendChild(canvas);
  } catch (e) {
    console.error('QR render failed:', e);
    holder.innerHTML = '<div class="empty-state">تعذر إنشاء رمز QR (تحقق من الاتصال بالإنترنت).</div>';
  }

  container.querySelector(`#${cardId}-print`).addEventListener('click', () => {
    const printWin = window.open('', '_blank', 'width=400,height=600');
    printWin.document.write(`<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8">
      <title>بطاقة التلميذ</title>
      <style>body{font-family:sans-serif; text-align:center; padding:20px;}
      .card{border:2px solid #111827; border-radius:12px; padding:16px; max-width:300px; margin:0 auto;}</style>
      </head><body>${container.querySelector(`#${cardId}`).outerHTML}</body></html>`);
    printWin.document.close();
    printWin.focus();
    setTimeout(() => printWin.print(), 400);
  });
}
