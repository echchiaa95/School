import { requireAuth, logout } from './auth.js';
import {
  el, esc, fmtDate, fmtDateTime, fmtTime, toast, confirmDialog,
  loadingHtml, emptyHtml, errorHtml, initPageHeader, showView,
  armViewHistory, armErrorBoundary, showInitError,
} from './ui.js';
import {
  driverContext, getActiveTrip, startTrip, endTrip, recordTripEvent,
  listBusStudentsOrdered, listRoutes, myTrips, getSchoolProfile,
} from './school.js';

let ctx = null;
let dctx = null;       // fn_driver_context jsonb
let activeTrip = null; // fn_get_active_trip jsonb
let busStudents = [];

const DIRECTION_AR = { pickup: 'ذهاب', dropoff: 'عودة' };

// ---- Bus + trip state -------------------------------------------------------
async function loadContext() {
  const busCard = el('bus-card');
  const res = await driverContext();
  if (!res.ok) { busCard.innerHTML = errorHtml(res.error); return false; }
  dctx = res.data;
  if (!dctx) {
    busCard.innerHTML = errorHtml('لا يوجد ملف سائق مرتبط بهذا الحساب. تواصل مع إدارة المؤسسة.');
    return false;
  }
  if (!dctx.bus_id) {
    busCard.innerHTML = `<div class="panel">
      <div class="empty-state">لم يتم إسناد حافلة إليك بعد. تواصل مع إدارة المؤسسة.</div>
    </div>`;
    return false;
  }
  busCard.innerHTML = `<div class="panel">
    <div class="detail-row"><strong>الحافلة</strong><span>${esc(dctx.bus_code || '—')}</span></div>
    <div class="detail-row"><strong>اللوحة</strong><span>${esc(dctx.bus_plate || '—')}</span></div>
    <div class="detail-row"><strong>السعة</strong><span>${dctx.bus_capacity ?? '—'}</span></div>
  </div>`;
  return true;
}

async function refreshTrip() {
  const res = await getActiveTrip();
  activeTrip = res.ok ? res.data : null;
  const startPanel = el('trip-start-panel');
  const activePanel = el('trip-active-panel');
  if (activeTrip) {
    startPanel.hidden = true;
    activePanel.hidden = false;
    el('trip-info').innerHTML = `
      <div class="detail-row"><strong>المسار</strong><span>${esc(activeTrip.route_name || 'بدون مسار')}</span></div>
      <div class="detail-row"><strong>الاتجاه</strong><span>${DIRECTION_AR[activeTrip.direction] || esc(activeTrip.direction)}</span></div>
      <div class="detail-row"><strong>بدأت في</strong><span>${fmtDateTime(activeTrip.started_at)}</span></div>
      <div class="detail-row"><strong>الأحداث المسجلة</strong><span>${(activeTrip.events || []).length}</span></div>`;
  } else {
    startPanel.hidden = false;
    activePanel.hidden = true;
  }
  await loadBusStudents();
}

async function loadRoutesInto() {
  const select = el('trip-route');
  const res = await listRoutes();
  const routes = res.ok ? (res.data || []) : [];
  select.innerHTML = '<option value="">بدون مسار محدد</option>'
    + routes.filter((r) => r.is_active !== false)
      .map((r) => `<option value="${r.id}">${esc(r.name)}</option>`).join('');
}

function mapsLink(lat, lng) {
  return (lat != null && lng != null) ? `https://www.google.com/maps?q=${lat},${lng}` : null;
}

async function loadBusStudents() {
  const host = el('bus-students');
  const summary = el('route-summary');
  if (!dctx?.bus_id) { host.innerHTML = emptyHtml('لا توجد حافلة مسندة.'); summary.hidden = true; return; }
  host.innerHTML = loadingHtml();

  summary.hidden = false;
  summary.innerHTML = `
    <div class="detail-row"><span class="k">الحافلة</span><span class="v">${esc(dctx.bus_code || '—')}</span></div>
    <div class="detail-row"><span class="k">رقم اللوحة</span><span class="v">${esc(dctx.bus_plate || '—')}</span></div>
    <div class="detail-row"><span class="k">المسار</span><span class="v">${esc(activeTrip?.route_name || 'بدون مسار محدد')}</span></div>
    <div class="detail-row"><span class="k">الاتجاه</span><span class="v">${activeTrip ? (DIRECTION_AR[activeTrip.direction] || esc(activeTrip.direction)) : '—'}</span></div>
    <div class="detail-row"><span class="k">التاريخ</span><span class="v">${fmtDate(activeTrip?.started_at || new Date())}</span></div>`;

  const res = await listBusStudentsOrdered(dctx.bus_id, activeTrip?.trip_id || null);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  busStudents = res.data || [];
  if (!busStudents.length) {
    host.innerHTML = emptyHtml('لا يوجد تلاميذ مسندون إلى هذه الحافلة.');
    return;
  }
  host.innerHTML = busStudents.map((s, i) => {
    const boarded = !!s.boarded_at;
    const alighted = !!s.alighted_at;
    const lat = s.student_latitude ?? s.stop_latitude;
    const lng = s.student_longitude ?? s.stop_longitude;
    const mapUrl = mapsLink(lat, lng);
    return `<div class="detail-row" style="flex-wrap:wrap; gap:6px;">
      <div style="flex:1; min-width:150px;">
        <strong>${i + 1} — ${esc(s.full_name)}</strong>
        <div style="font-size:.8em; color:var(--muted);">${esc(s.student_number || '')} · صعود: ${esc(s.pickup_stop || '—')} · نزول: ${esc(s.dropoff_stop || '—')}</div>
        ${mapUrl ? `<a href="${mapUrl}" target="_blank" rel="noopener" style="font-size:.8em;">📍 فتح الموقع في Google Maps</a>` : ''}
      </div>
      ${boarded ? `<span class="badge badge-green">صعد ${fmtTime(s.boarded_at)}</span>` : ''}
      ${alighted ? `<span class="badge badge-blue">نزل ${fmtTime(s.alighted_at)}</span>` : ''}
      ${activeTrip ? `
        ${!boarded ? `<button type="button" class="att-btn" data-act="board" data-student="${s.student_id}">تسجيل الصعود</button>` : ''}
        ${boarded && !alighted ? `<button type="button" class="att-btn" data-act="alight" data-student="${s.student_id}">تسجيل النزول</button>` : ''}
      ` : ''}
    </div>`;
  }).join('');

  host.querySelectorAll('[data-act]').forEach((b) => {
    b.addEventListener('click', async () => {
      const res = await recordTripEvent(activeTrip.trip_id, b.dataset.student, b.dataset.act);
      if (!res.ok) { toast(res.error, 'error'); return; }
      toast(b.dataset.act === 'board' ? 'تم تسجيل الصعود' : 'تم تسجيل النزول', 'success');
      refreshTrip();
    });
  });
}

async function loadHistory() {
  const host = el('trips-list');
  host.innerHTML = loadingHtml();
  const res = await myTrips(30);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد رحلات سابقة.'); return; }
  host.innerHTML = `<div class="data-table-wrap"><table class="data-table"><thead><tr>
    <th>التاريخ</th><th>الاتجاه</th><th>المسار</th><th>الحالة</th><th>البداية</th><th>النهاية</th><th>الأحداث</th>
  </tr></thead><tbody>${rows.map((t) => `<tr>
    <td>${fmtDate(t.trip_date)}</td>
    <td>${DIRECTION_AR[t.direction] || esc(t.direction || '—')}</td>
    <td>${esc(t.route_name || '—')}</td>
    <td><span class="badge ${t.status === 'completed' ? 'badge-green' : t.status === 'active' ? 'badge-gold' : 'badge-red'}">${
      t.status === 'completed' ? 'مكتملة' : t.status === 'active' ? 'نشطة' : 'ملغاة'}</span></td>
    <td>${fmtTime(t.started_at)}</td>
    <td>${t.ended_at ? fmtTime(t.ended_at) : '—'}</td>
    <td>${t.events_count ?? 0}</td>
  </tr>`).join('')}</tbody></table></div>`;
}

// ---- Init -------------------------------------------------------------------
(async () => {
  try {
    armErrorBoundary();
    ctx = await requireAuth('driver.html');
    if (!ctx) return;
    armViewHistory('home');
    document.getElementById('app-body').hidden = false;

    const schoolRes = await getSchoolProfile(ctx.schoolId);
    await initPageHeader(ctx, schoolRes.ok ? schoolRes.data?.name : null, logout);

    document.querySelectorAll('[data-go]').forEach((b) => {
      b.addEventListener('click', () => {
        showView(b.dataset.go);
        if (b.dataset.go === 'history') loadHistory();
      });
    });
    document.querySelectorAll('[data-back]').forEach((b) => {
      b.addEventListener('click', () => showView('home'));
    });

    el('trip-start').addEventListener('click', async () => {
      const res = await startTrip(el('trip-route').value || null, el('trip-direction').value);
      if (!res.ok) { toast(res.error, 'error'); return; }
      toast('بدأت الرحلة', 'success');
      refreshTrip();
    });

    el('trip-end').addEventListener('click', async () => {
      if (!activeTrip) return;
      const ok = await confirmDialog('هل تريد إنهاء الرحلة الحالية؟');
      if (!ok) return;
      const res = await endTrip(activeTrip.trip_id);
      if (!res.ok) { toast(res.error, 'error'); return; }
      toast('انتهت الرحلة', 'success');
      refreshTrip();
    });

    const ok = await loadContext();
    if (ok) {
      await loadRoutesInto();
      await refreshTrip();
    }
  } catch (error) {
    console.error('driver console init error:', error);
    showInitError(error);
  }
})();
