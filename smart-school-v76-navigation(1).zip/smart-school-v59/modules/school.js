// ============================================================================
// modules/school.js
// Data access wrappers for the Phase 12 platform RPCs. Every function returns
// { ok, ... } and maps server error codes to clear Arabic messages. Technical
// details stay in console — users see safe, useful messages only.
// ============================================================================

import { supabase } from './supabase.js';

/** Map known PostgreSQL/RPC error codes to Arabic messages. */
export function mapRpcError(message) {
  const msg = String(message || '');
  const table = [
    ['PERMISSION_DENIED', 'ليس لديك صلاحية لهذه العملية.'],
    ['NOT_AUTHENTICATED', 'يجب تسجيل الدخول.'],
    ['NO_SCHOOL_CONTEXT', 'لا توجد مؤسسة مرتبطة بهذا الحساب.'],
    ['INVALID_SCHOOL', 'المؤسسة غير موجودة.'],
    ['INVALID_ACADEMIC_YEAR', 'السنة الدراسية غير صالحة.'],
    ['INVALID_CLASS', 'القسم غير موجود.'],
    ['INVALID_TEACHER', 'الأستاذ غير موجود في هذه المؤسسة.'],
    ['INVALID_STUDENT', 'التلميذ غير موجود.'],
    ['INVALID_DRIVER', 'السائق غير موجود في هذه المؤسسة.'],
    ['INVALID_BUS', 'الحافلة غير موجودة.'],
    ['INVALID_ROUTE', 'المسار غير موجود.'],
    ['INVALID_TRIP', 'الرحلة غير موجودة.'],
    ['TRIP_NOT_ACTIVE', 'الرحلة ليست نشطة.'],
    ['STUDENT_NOT_ON_BUS', 'التلميذ غير مسجل في هذه الحافلة.'],
    ['STUDENT_NAME_REQUIRED', 'اسم التلميذ مطلوب.'],
    ['INVALID_INCIDENT', 'المخالفة غير موجودة.'],
    ['ACADEMIC_YEAR_EXISTS', 'السنة الدراسية موجودة بالفعل.'],
    ['ACADEMIC_YEAR_SCHOOL_MISMATCH', 'السنة الدراسية لا تتبع مؤسسة القسم.'],
    ['YEAR_NAME_REQUIRED', 'اسم السنة الدراسية مطلوب.'],
    ['CLASS_NAME_REQUIRED', 'اسم القسم مطلوب.'],
    ['SCHOOL_NAME_REQUIRED', 'اسم المؤسسة مطلوب.'],
    ['SUBJECT_NAME_REQUIRED', 'اسم المادة مطلوب.'],
    ['BUS_CODE_REQUIRED', 'رقم الحافلة مطلوب.'],
    ['ROUTE_NAME_REQUIRED', 'اسم المسار مطلوب.'],
    ['FEE_TYPE_REQUIRED', 'نوع الرسوم مطلوب.'],
    ['EXPENSE_CATEGORY_REQUIRED', 'تصنيف المصروف مطلوب.'],
    ['INCIDENT_TITLE_REQUIRED', 'عنوان المخالفة مطلوب.'],
    ['NOTIFICATION_TITLE_REQUIRED', 'عنوان الإشعار مطلوب.'],
    ['INVALID_AMOUNT', 'المبلغ غير صالح.'],
    ['INVALID_SCORE', 'النقطة غير صالحة.'],
    ['GRADE_SUBJECT_REQUIRED', 'اختر المادة أولاً.'],
    ['INVALID_SUBJECT', 'المادة غير موجودة أو غير تابعة لهذه المؤسسة.'],
    ['INVALID_DIRECTION', 'اتجاه الرحلة غير صالح.'],
    ['INVALID_EVENT_TYPE', 'نوع العملية غير صالح.'],
    ['INVALID_ROWS', 'البيانات المرسلة غير صالحة.'],
    ['USER_NOT_IN_SCHOOL', 'المستخدم لا ينتمي إلى هذه المؤسسة.'],
    ['UNKNOWN_PERMISSION', 'صلاحية غير معروفة.'],
    ['CANNOT_DISABLE_LAST_SUPERADMIN', 'لا يمكن تعطيل آخر SuperAdmin.'],
    ['CANNOT_REMOVE_LAST_SUPERADMIN', 'لا يمكن إزالة دور آخر SuperAdmin.'],
    ['NOT_YOUR_CLASS', 'لا يمكنك تنفيذ هذه العملية على قسم لا تدرّسه.'],
    ['YEAR_IS_CURRENT', 'لا يمكن تعطيل السنة الحالية؛ حدد سنة أخرى كحالية أولًا.'],
    ['CLASS_EXISTS', 'القسم موجود بالفعل في هذه السنة.'],
    ['INVALID_CAPACITY', 'سعة القسم غير صالحة.'],
    ['INVALID_PATCH', 'بيانات التعديل غير صالحة.'],
    ['NOT_A_DRIVER', 'هذا الحساب ليس حساب سائق.'],
    ['NO_BUS_ASSIGNED', 'لا توجد حافلة مرتبطة بهذا السائق.'],
    ['students_school_id_student_number_key', 'رقم الطالب مستخدم بالفعل في هذه المؤسسة.'],
    ['DUPLICATE_STUDENT_NUMBER', 'رقم الطالب مستخدم بالفعل في هذه المؤسسة.'],
    ['STUDENT_INSERT_FAILED', 'تعذر حفظ بيانات التلميذ، حاول مرة أخرى.'],
    ['ENROLLMENT_INSERT_FAILED', 'تعذر تسجيل التلميذ في القسم، حاول مرة أخرى.'],
    ['CLASS_NOT_FOUND', 'القسم غير موجود.'],
    ['ACADEMIC_YEAR_NOT_FOUND', 'السنة الدراسية غير موجودة.'],
    ['SCHOOL_NOT_FOUND', 'المؤسسة غير موجودة.'],
    ['INVALID_PARENT', 'ولي الأمر غير صالح.'],
    ['INVALID_TRANSPORT', 'بيانات النقل غير صالحة.'],
    ['duplicate', 'موجود مسبقًا.'],
    ['students.create', 'ليس لديك صلاحية إضافة التلاميذ.'],
    ['TEACHER_ASSIGNMENT_REQUIRED', 'الأستاذ غير مرتبط بهذه المادة أو القسم.'],
    ['SUBJECT_SCHOOL_MISMATCH', 'المادة لا تنتمي إلى هذه المؤسسة.'],
    ['CLASS_SCHOOL_MISMATCH', 'القسم لا ينتمي إلى هذه المؤسسة.'],
    ['DUPLICATE_STUDENT', 'رقم التلميذ مستخدم مسبقًا.'],
    ['PERMISSION_CHECK_FAILED', 'تعذر التحقق من الصلاحية، حاول مرة أخرى.'],
    ['EMAIL_EXISTS', 'البريد الإلكتروني مستخدم بالفعل.'],
    ['SCHOOL_ACCESS_DENIED', 'لا يمكنك الوصول إلى هذه المؤسسة.'],
    ['CLASS_SLOT_TAKEN', 'هذا التوقيت محجوز بالفعل لهذا القسم.'],
    ['TEACHER_SCHEDULE_CONFLICT', 'الأستاذ لديه حصة أخرى في نفس التوقيت.'],
    ['INVALID_LESSON', 'الحصة غير موجودة.'],
    ['INVALID_WEEKDAY', 'اليوم غير صالح.'],
    ['INVALID_PERIOD', 'رقم الحصة غير صالح.'],
    ['SCHEDULE_TEACHER_REQUIRED', 'حدد الأستاذ أولاً.'],
    ['INVALID_LATITUDE', 'خط العرض غير صالح.'],
    ['INVALID_LONGITUDE', 'خط الطول غير صالح.'],
    ['PAYROLL_MONTH_NOT_FOUND', 'يجب إدخال ساعات هذا الشهر أولاً قبل تسجيل دفعة.'],
    ['BADGE_INSERT_FAILED', 'تعذر إصدار البطاقة. تحقق من سجل العمليات/قاعدة البيانات ثم حاول مرة أخرى.'],
    ['BADGE_TOKEN_MISSING', 'البطاقة لا تحتوي على رمز QR رسمي صالح.'],
    ['BADGE_REISSUE_FAILED', 'تعذرت إعادة إصدار البطاقة، حاول مرة أخرى.'],
    ['BADGE_STATUS_UPDATE_FAILED', 'تعذر تحديث حالة البطاقة.'],
    ['INVALID_BADGE', 'البطاقة غير موجودة.'],
    ['STUDENT_NOT_ON_THIS_ROUTE', 'هذا التلميذ غير مسجل في هذا المسار.'],
    ['ALREADY_BOARDED', 'تم تسجيل صعود هذا التلميذ مسبقًا.'],
    ['NOT_BOARDED_YET', 'لم يصعد هذا التلميذ بعد.'],
    ['ALREADY_DROPPED', 'تم تسجيل نزول هذا التلميذ مسبقًا.'],
    ['NO_ACTIVE_TRIP', 'لا توجد رحلة نشطة حاليًا.'],
    ['UNKNOWN_BADGE', 'رمز البطاقة غير معروف.'],
    ['BADGE_NOT_ACTIVE', 'هذه البطاقة غير سارية.'],
    ['NOT_A_DRIVER', 'هذا الحساب ليس حساب سائق.'],
    ['INVALID_BUS', 'الحافلة غير موجودة.'],
    ['INVALID_GUARD', 'الحارس غير موجود.'],
    ['INVALID_DRIVER', 'السائق غير موجود.'],
    ['INVALID_PARENT', 'ولي الأمر غير موجود.'],
    ['TRIP_NOT_ACTIVE', 'الرحلة لم تعد نشطة.'],
    ['INVALID_COORDINATES', 'إحداثيات غير صالحة.'],
    ['INVALID_TRIP', 'الرحلة غير موجودة.'],
    ['TOO_MANY_LESSONS', 'مجموع الحصص يتجاوز 8 حصص/يوم.'],
    ['INVALID_DURATION', 'مدة الحصة غير صالحة.'],
    ['DATE_TOO_SOON', 'هذا التاريخ قريب جدًا، اختر يومًا لاحقًا.'],
    ['DATE_TOO_FAR', 'هذا التاريخ بعيد جدًا.'],
    ['NOT_A_WORKING_DAY', 'هذا اليوم عطلة، اختر يوم عمل.'],
    ['DAY_FULL', 'هذا اليوم مكتمل الحجز، اختر يومًا آخر.'],
    ['INVALID_TARGET', 'الجهة المطلوبة غير صالحة.'],
    ['APPOINTMENT_NOT_FOUND', 'الموعد غير موجود.'],
  ];
  for (const [code, ar] of table) {
    if (msg.includes(code)) return ar;
  }
  if (msg.includes('schema cache') || msg.includes('Could not find the function')) {
    return 'خطأ تقني: الوظيفة المطلوبة غير منشورة على القاعدة (يرجى إبلاغ الدعم الفني).';
  }
  if (msg.includes('permission denied') || msg.includes('row-level security')) {
    return 'ليس لديك صلاحية للوصول إلى هذه البيانات.';
  }
  return 'تعذر الاتصال بالخادم أو تنفيذ العملية، حاول مرة أخرى.';
}

// ---- PHASE 27 — Central error classification + diagnostic mode -------------
// Enable with: localStorage.setItem('SMART_SCHOOL_DEBUG', '1')
// Never log secrets: params are sanitized (token/pin/password fields masked).
export const isDebug = () => {
  try { return localStorage.getItem('SMART_SCHOOL_DEBUG') === '1'; } catch { return false; }
};

export function classifyRpcError(fnName, params, error) {
  const msg = String(error?.message || error || '');
  const code = error?.code || '';
  let kind = 'UNKNOWN_ERROR';
  if (/Failed to fetch|NetworkError|fetch failed|Network request failed|ERR_INTERNET|timeout/i.test(msg) && !String(code).startsWith('P'))
    kind = 'NETWORK_ERROR';
  else if (/not authenticated|JWT expired|AuthSessionMissing|invalid jwt/i.test(msg)) kind = 'AUTH_ERROR';
  else if (/PERMISSION_DENIED|permission denied|row-level security|42501/i.test(msg)) kind = 'PERMISSION_DENIED';
  else if (/Could not find the function|does not exist|schema cache|PGRST202/i.test(msg)) kind = 'RPC_NOT_FOUND';
  else if (/PGRST204|structure of query results|column .* does not exist/i.test(msg)) kind = 'RPC_SIGNATURE_MISMATCH';
  else if (/invalid input value for enum|invalid_parameter_value|22P02|invalid text representation/i.test(msg)) kind = 'INVALID_PARAMETER';
  else if (/violates.*constraint|23505|23503|23502/i.test(msg)) kind = 'DATABASE_ERROR';
  if (isDebug()) {
    const safe = JSON.parse(JSON.stringify(params || {}, (k, v) => /token|pin|password|secret/i.test(k) ? '***' : v));
    console.error(`[RPC ERROR] ${fnName}\nkind: ${kind}\ncode: ${code || '—'}\nmessage: ${msg}\nparams:`, safe);
  }
  return kind;
}

function diagnosticErrorText(fnName, params, error, kind) {
  const friendly = mapRpcError(error?.message || error);
  const msg = String(error?.message || error || '');
  const code = String(error?.code || '');
  // v14 Diagnostic: show the real Supabase error in-app so phone-only testing
  // does not require DevTools. Params are sanitized and technical details are
  // shown only in this diagnostic build.
  const safeParams = JSON.parse(JSON.stringify(params || {}, (k, v) =>
    /token|pin|password|secret/i.test(k) ? '***' : v));
  let detail = msg || 'Unknown error';
  if (detail.length > 1200) detail = detail.slice(0, 1200) + '…';
  let safeParamText = '';
  try { safeParamText = JSON.stringify(safeParams); } catch { safeParamText = '{}'; }
  return `${friendly}\n\n[DIAGNOSTIC]\nRPC: ${fnName}\nKIND: ${kind}\nCODE: ${code || '—'}\nMESSAGE: ${detail}\nPARAMS: ${safeParamText}`;
}

export async function call(fnName, params) {
  if (isDebug()) console.log(`[RPC START] ${fnName}`, params || {});
  try {
    const { data, error } = await supabase.rpc(fnName, params || {});
    if (error) {
      const kind = classifyRpcError(fnName, params, error);
      return { ok: false, error: diagnosticErrorText(fnName, params, error, kind), kind };
    }
    if (isDebug()) console.log(`[RPC SUCCESS] ${fnName}`, data);
    return { ok: true, data };
  } catch (e) {
    const kind = classifyRpcError(fnName, params, e);
    return { ok: false, error: diagnosticErrorText(fnName, params, e, kind), kind };
  }
}

// ---- Schools (SuperAdmin / school profile) -------------------------------------
export const createSchoolFull = (name, data) => call('fn_create_school_full', { p_name: name, p_data: data || {} });
export const updateSchool = (schoolId, data) => call('fn_update_school', { p_school_id: schoolId, p_data: data });
export const getSchoolProfile = (schoolId) => call('fn_get_school_profile', { p_school_id: schoolId });
export const listSchoolsFull = () => call('fn_list_schools_full');

// ---- Users ------------------------------------------------------------------
export const listAllUsersV2 = (f) => call('fn_list_all_users_v2', {
  p_query: f?.query || null, p_role: f?.role || null,
  p_school_id: f?.schoolId || null, p_status: f?.status || null,
  p_limit: f?.limit || 25, p_offset: f?.offset || 0,
});
export const updateProfile = (profileId, fullName, phone) =>
  call('fn_update_profile', { p_profile_id: profileId, p_full_name: fullName, p_phone: phone });

// ---- Permissions ------------------------------------------------------------
export const myPermissions = () => call('fn_my_permissions');
export const getUserPermissions = (profileId, schoolId) =>
  call('fn_get_user_permissions', { p_profile_id: profileId, p_school_id: schoolId });
export const grantUserPermission = (profileId, schoolId, key) =>
  call('fn_grant_user_permission', { p_profile_id: profileId, p_school_id: schoolId, p_permission_key: key });
export const revokeUserPermission = (profileId, schoolId, key) =>
  call('fn_revoke_user_permission', { p_profile_id: profileId, p_school_id: schoolId, p_permission_key: key });

// ---- Academic structure -----------------------------------------------------
export const createAcademicYearMy = (name, isCurrent) =>
  call('fn_create_academic_year_my', { p_name: name, p_is_current: !!isCurrent });
export const setCurrentAcademicYear = (yearId) => call('fn_set_current_academic_year', { p_year_id: yearId });
export const updateAcademicYear = (yearId, name, isDisabled) =>
  call('fn_update_academic_year', { p_year_id: yearId, p_name: name ?? null, p_is_disabled: isDisabled ?? null });
export const createClassMy = (yearId, name, level, capacity, teacherId) =>
  call('fn_create_class_my', { p_academic_year_id: yearId, p_name: name, p_level: level || null, p_capacity: capacity || null, p_teacher_id: teacherId || null });
export const updateClass = (classId, fields) =>
  call('fn_update_class', {
    p_class_id: classId,
    p_data: {
      ...(Object.prototype.hasOwnProperty.call(fields || {}, 'name')
        ? { name: fields.name }
        : {}),
      ...(Object.prototype.hasOwnProperty.call(fields || {}, 'level')
        ? { level: fields.level }
        : {}),
      ...(Object.prototype.hasOwnProperty.call(fields || {}, 'capacity')
        ? { capacity: fields.capacity }
        : {}),
      ...(Object.prototype.hasOwnProperty.call(fields || {}, 'teacherId')
        ? { teacher_id: fields.teacherId }
        : {}),
      ...(Object.prototype.hasOwnProperty.call(fields || {}, 'isDisabled')
        ? { is_disabled: fields.isDisabled }
        : {}),
    },
  });
export const listMyClasses = (yearId) => call('fn_list_my_classes', { p_academic_year_id: yearId || null });
export const listMyAcademicYears = () => call('fn_list_my_academic_years');

// ---- Subjects ---------------------------------------------------------------
export const createSubject = (name) => call('fn_create_subject', { p_name: name });
export const listSubjects = () => call('fn_list_subjects');

// ---- Attendance -------------------------------------------------------------
export const saveAttendance = (classId, date, rows) =>
  call('fn_save_attendance', { p_class_id: classId, p_date: date, p_rows: rows });
export const getClassAttendance = (classId, date) =>
  call('fn_get_class_attendance', { p_class_id: classId, p_date: date || null });
export const getStudentAttendance = (studentId, from, to) =>
  call('fn_student_attendance', { p_student_id: studentId, p_from: from || null, p_to: to || null });
export const schoolAttendanceToday = () => call('fn_school_attendance_today');
export const reportAttendance = (from, to, classId) =>
  call('fn_report_attendance', { p_from: from || null, p_to: to || null, p_class_id: classId || null });

// ---- Staff Attendance (Phase 59) --------------------------------------------
export const listSchoolStaff = (schoolId) =>
  call('fn_list_school_staff', { p_school_id: schoolId });
export const staffCheckIn = (profileId, workDate) =>
  call('fn_staff_check_in', { p_profile_id: profileId, p_work_date: workDate });
export const staffCheckOut = (profileId, workDate) =>
  call('fn_staff_check_out', { p_profile_id: profileId, p_work_date: workDate });
export const markStaffAttendance = (profileId, workDate, status, notes) =>
  call('fn_mark_staff_attendance', { p_profile_id: profileId, p_work_date: workDate, p_status: status, p_notes: notes || null });
export const getStaffAttendanceReport = (profileId, from, to) =>
  call('fn_get_staff_attendance_report', { p_profile_id: profileId, p_from: from, p_to: to });

// ---- Grades -----------------------------------------------------------------
export const addGrade = (g) => call('fn_add_grade', {
  p_student_id: g.studentId, p_class_id: g.classId || null, p_subject_id: g.subjectId || null,
  p_period: g.period || null, p_grade_type: g.gradeType || null,
  p_score: g.score, p_max_score: g.maxScore || 20, p_note: g.note || null,
});
export const listStudentGrades = (studentId) => call('fn_list_student_grades', { p_student_id: studentId });
export const listStudentGradesForTeacher = (studentId) => call('fn_list_student_grades_for_teacher', { p_student_id: studentId });
export const createGradeAssessment = (a) => call('fn_create_grade_assessment', {
  p_school_id: a.schoolId, p_class_id: a.classId, p_subject_id: a.subjectId,
  p_academic_year_id: a.academicYearId || null, p_period: a.period,
  p_title: a.title, p_assessment_type: a.assessmentType,
  p_coefficient: a.coefficient, p_max_score: a.maxScore,
  p_assessment_date: a.assessmentDate || null,
});
export const saveGradeMark = (m) => call('fn_save_grade_mark', {
  p_assessment_id: m.assessmentId, p_student_id: m.studentId,
  p_score: m.score, p_teacher_note: m.teacherNote || null,
});
export const updateGradeAssessmentCoefficient = (id, coefficient) =>
  call('fn_update_grade_assessment_coefficient', { p_assessment_id: id, p_coefficient: coefficient });
export const listStudentAssessmentMarks = async (studentId, subjectId, classId, period) => {
  // Read through the security-definer RPC first. This avoids RLS blocking the
  // teacher's previously saved marks while still returning only the selected
  // student/class/subject/period rows.
  const rpc = await call('fn_teacher_student_assessment_marks', {
    p_student_id: studentId, p_class_id: classId, p_subject_id: subjectId, p_period: period,
  });
  if (rpc.ok) return { ok: true, data: rpc.data || [] };

  // Backward-compatible fallback for deployments where the new migration has
  // not been applied yet.
  const { data: assessments, error: assessmentError } = await supabase
    .from('grade_assessments')
    .select('id,title,assessment_type,coefficient,max_score,assessment_date,created_at')
    .eq('class_id', classId)
    .eq('subject_id', subjectId)
    .eq('period', period)
    .order('assessment_date', { ascending: false })
    .order('created_at', { ascending: false });
  if (assessmentError) return { ok: false, error: mapRpcError(assessmentError.message) };
  const ids = (assessments || []).map(a => a.id);
  if (!ids.length) return { ok: true, data: [] };
  const { data: marks, error: marksError } = await supabase
    .from('grade_marks')
    .select('assessment_id,score,teacher_note,created_at')
    .eq('student_id', studentId)
    .in('assessment_id', ids);
  if (marksError) return { ok: false, error: mapRpcError(marksError.message) };
  const byAssessment = new Map((marks || []).map(m => [m.assessment_id, m]));
  return { ok: true, data: (assessments || []).filter(a => byAssessment.has(a.id)).map(a => ({ ...a, ...byAssessment.get(a.id) })) };
};

export const listGradeAssessments = async (classId, subjectId, period) => {
  const { data, error } = await supabase.from('grade_assessments').select('*')
    .eq('class_id', classId).eq('subject_id', subjectId).eq('period', period)
    .order('assessment_date', { ascending: false }).order('created_at', { ascending: false });
  return error ? { ok: false, error: mapRpcError(error.message) } : { ok: true, data: data || [] };
};

// ---- Incidents --------------------------------------------------------------
export const reportIncident = (i) => call('fn_report_incident', {
  p_student_id: i.studentId, p_type: i.type, p_title: i.title,
  p_description: i.description || null, p_place: i.place || null, p_occurred_at: i.occurredAt || null,
});
export const listIncidents = (status, limit, offset) =>
  call('fn_list_incidents', { p_status: status || null, p_limit: limit || 50, p_offset: offset || 0 });
export const updateIncident = (id, status, actionTaken) =>
  call('fn_update_incident', { p_incident_id: id, p_status: status || null, p_action_taken: actionTaken || null });

// ---- Notifications ------------------------------------------------------------
export const sendNotification = (n) => call('fn_send_notification', {
  p_title: n.title, p_body: n.body || null, p_type: n.type || 'announcement',
  p_target_role: n.targetRole || null, p_target_profile_id: n.targetProfileId || null,
  p_student_id: n.studentId || null, p_image_url: n.imageUrl || null,
});
export const listMyNotifications = (limit) => call('fn_list_my_notifications', { p_limit: limit || 50 });
export const markNotificationRead = (id) => call('fn_mark_notification_read', { p_notification_id: id });
export const unreadNotificationsCount = () => call('fn_unread_notifications_count');
export const deleteMyNotification = (id) => call('fn_delete_my_notification', { p_notification_id: id });

/** ضغط الصورة تلقائيًا في المتصفح قبل الرفع (canvas)، ثم رفعها إلى bucket الإشعارات. */
export async function uploadNotificationImage(schoolId, file, maxWidth = 1280, quality = 0.72) {
  const compressed = await new Promise((resolve, reject) => {
    const img = new Image();
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('READ_FAILED'));
    reader.onload = () => { img.src = reader.result; };
    img.onerror = () => reject(new Error('IMAGE_DECODE_FAILED'));
    img.onload = () => {
      const scale = Math.min(1, maxWidth / img.width);
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error('COMPRESS_FAILED'))), 'image/jpeg', quality);
    };
    reader.readAsDataURL(file);
  });

  const path = `${schoolId}/${crypto.randomUUID()}.jpg`;
  const { error } = await supabase.storage.from('notification-images').upload(path, compressed, {
    contentType: 'image/jpeg', upsert: false,
  });
  if (error) return { ok: false, error: error.message };
  const { data } = supabase.storage.from('notification-images').getPublicUrl(path);
  return { ok: true, data: data.publicUrl };
}


// ---- Transport --------------------------------------------------------------
export const createBus = (b) => call('fn_create_bus', {
  p_code: b.code, p_plate: b.plate || null, p_capacity: b.capacity || null, p_driver_id: b.driverId || null,
});
export const listBuses = () => call('fn_list_buses');
export const createRoute = (name, stops) => call('fn_create_route', { p_name: name, p_stops: stops || [] });
export const listRoutes = () => call('fn_list_routes');
export const assignStudentTransport = (studentId, t) => call('fn_assign_student_transport', {
  p_student_id: studentId, p_bus_id: t.busId || null, p_route_id: t.routeId || null,
  p_pickup_stop_id: t.pickupStopId || null, p_dropoff_stop_id: t.dropoffStopId || null,
});
export const studentTransportInfo = (studentId) => call('fn_student_transport_info', { p_student_id: studentId });
export const driverContext = () => call('fn_driver_context');
export const startTrip = (routeId, direction) => call('fn_start_trip', { p_route_id: routeId || null, p_direction: direction || 'pickup' });
export const endTrip = (tripId) => call('fn_end_trip', { p_trip_id: tripId });
export const recordTripEvent = (tripId, studentId, eventType) =>
  call('fn_record_trip_event', { p_trip_id: tripId, p_student_id: studentId, p_event_type: eventType });
export const getActiveTrip = () => call('fn_get_active_trip');
export const listBusStudents = (busId, tripId) => call('fn_list_bus_students', { p_bus_id: busId, p_trip_id: tripId || null });
export const getGuardStats = (profileId) => call('fn_get_guard_stats', { p_profile_id: profileId });
export const getDriverStats = (driverId) => call('fn_get_driver_stats', { p_driver_id: driverId });
export const getParentStats = (parentId) => call('fn_get_parent_stats', { p_parent_id: parentId });
export const recordGpsPing = (tripId, lat, lng, accuracy, speed, heading) =>
  call('fn_record_gps_ping', { p_trip_id: tripId, p_latitude: lat, p_longitude: lng, p_accuracy: accuracy ?? null, p_speed: speed ?? null, p_heading: heading ?? null });
export const getActiveBusLocations = () => call('fn_get_active_bus_locations');
export const getAllBusesStatus = () => call('fn_get_all_buses_status');
export const listBusTrips = (busId, limit) => call('fn_list_bus_trips', { p_bus_id: busId, p_limit: limit || 30 });
export const getTripRouteHistory = (tripId) => call('fn_get_trip_route_history', { p_trip_id: tripId });
export const getTripBoardingDropoffPoints = (tripId) => call('fn_get_trip_boarding_dropoff_points', { p_trip_id: tripId });
export const teacherClassRoster = (classId) => call('fn_teacher_class_roster', { p_class_id: classId });
export const getSchoolPeriods = () => call('fn_get_school_periods');
export const setSchoolPeriods = (cfg) => call('fn_set_school_periods', {
  p_morning_start: cfg.morningStart, p_morning_lesson_minutes: cfg.morningLessonMinutes,
  p_afternoon_start: cfg.afternoonStart, p_afternoon_lesson_minutes: cfg.afternoonLessonMinutes,
});
export const updateStudentPhoto = (studentId, photoUrl) => call('fn_update_student_photo', { p_student_id: studentId, p_photo_url: photoUrl });
export const updateSchoolLocation = (latitude, longitude, locationLabel) =>
  call('fn_update_school_location', { p_latitude: latitude, p_longitude: longitude, p_location_label: locationLabel || null });
export const adminSaveSchoolLocation = (schoolId, latitude, longitude, locationLabel) =>
  call('fn_admin_save_school_location', { p_school_id: schoolId, p_latitude: latitude, p_longitude: longitude, p_location_label: locationLabel || null });
export const driverLookupBadge = (secureToken) => call('fn_driver_lookup_badge', { p_secure_token: secureToken });
export const listBusStudentsOrdered = (busId, tripId) => call('fn_list_bus_students_ordered', { p_bus_id: busId, p_trip_id: tripId || null });
export const setDriverPassengerOrder = (busId, studentIds) => call('fn_set_driver_passenger_order', { p_bus_id: busId, p_student_ids: studentIds });
export const myTrips = (limit) => call('fn_my_trips', { p_limit: limit || 20 });
// ---- PHASE 25 — Live map overview (school + homes + fleet + stops) --------
// fn_get_map_overview() takes NO parameters: Admin/Director are pinned
// server-side to their own school. (Sending p_school_id to a 0-arg function
// makes PostgREST fail with PGRST202 — that was the "map loads but data
// never appears" bug.)
export const getMapOverview = () => call('fn_get_map_overview');

// ---- PHASE 27 — School-wide trip log (all buses, filters, pagination) -----
export const listSchoolTrips = (f) => call('fn_list_school_trips', {
  p_bus_id: f?.busId || null,
  p_from: f?.from || null,
  p_to: f?.to || null,
  p_limit: f?.limit || 25,
  p_offset: f?.offset || 0,
});

// ---- Finance ----------------------------------------------------------------
export const recordPayment = (p) => call('fn_record_payment', {
  p_student_id: p.studentId, p_fee_type: p.feeType, p_amount_due: p.amountDue || 0,
  p_amount_paid: p.amountPaid || 0, p_payment_date: p.paymentDate || null,
  p_method: p.method || null, p_note: p.note || null,
});
export const listPayments = (studentId, limit) => call('fn_list_payments', { p_student_id: studentId || null, p_limit: limit || 100 });
export const recordExpense = (e) => call('fn_record_expense', {
  p_category: e.category, p_amount: e.amount, p_expense_date: e.expenseDate || null, p_description: e.description || null,
});
export const listExpenses = (limit) => call('fn_list_expenses', { p_limit: limit || 100 });
export const financeSummary = (from, to) => call('fn_finance_summary', { p_from: from || null, p_to: to || null });

// ---- Schedule ---------------------------------------------------------------
export const setClassSchedule = (classId, entries) => call('fn_set_class_schedule', { p_class_id: classId, p_entries: entries });
export const getClassSchedule = (classId) => call('fn_get_class_schedule', { p_class_id: classId });
export const teacherClasses = () => call('fn_teacher_classes');

// ---- Students / parents -----------------------------------------------------
export const getStudentFull = (studentId) => call('fn_get_student_full', { p_student_id: studentId });
export const myChildren = () => call('fn_my_children');
export const childPayments = (studentId) => call('fn_child_payments', { p_student_id: studentId });

// ---- Dashboard / audit ------------------------------------------------------
export const schoolDashboard = () => call('fn_get_school_dashboard');
export const schoolAudit = (limit, offset) => call('fn_get_school_audit', { p_limit: limit || 50, p_offset: offset || 0 });

// ---- PHASE 14 — Teacher academic assignments (server-enforced) ------------
export const assignTeacherSubject = (teacherId, subjectId) =>
  call('fn_assign_teacher_subject', { p_teacher_id: teacherId, p_subject_id: subjectId });
export const removeTeacherSubject = (teacherId, subjectId) =>
  call('fn_remove_teacher_subject', { p_teacher_id: teacherId, p_subject_id: subjectId });
export const listTeacherSubjects = (teacherId) =>
  call('fn_list_teacher_subjects', { p_teacher_id: teacherId });
export const assignTeacherClass = (teacherId, classId) =>
  call('fn_assign_teacher_class', { p_teacher_id: teacherId, p_class_id: classId });
export const removeTeacherClass = (teacherId, classId) =>
  call('fn_remove_teacher_class', { p_teacher_id: teacherId, p_class_id: classId });
export const listTeacherClasses = (teacherId) =>
  call('fn_list_teacher_classes', { p_teacher_id: teacherId });
export const myTeacherSubjects = () => call('fn_my_teacher_subjects');
export const gradeSubjectCoefficients = (classId) => call('fn_grade_subject_coefficients', { p_class_id: classId });

// ---- PHASE 19 — Teacher / Student profiles, single-lesson CRUD -------------
export const getTeacherFull = (teacherId) => call('fn_get_teacher_full', { p_teacher_id: teacherId });
export const getTeacherSchedule = (teacherId) => call('fn_admin_get_teacher_schedule', { p_teacher_id: teacherId });
export const getMyTeacherSchedule = () => call('fn_get_my_teacher_schedule');
export const addLesson = (l) => call('fn_add_lesson', {
  p_class_id: l.classId, p_weekday: l.weekday, p_period: l.period,
  p_subject_id: l.subjectId, p_teacher_id: l.teacherId || null, p_notes: l.notes || null,
});
export const updateLesson = (l) => call('fn_update_lesson', {
  p_entry_id: l.entryId, p_weekday: l.weekday, p_period: l.period,
  p_subject_id: l.subjectId, p_teacher_id: l.teacherId || null, p_notes: l.notes || null,
});
export const deleteLesson = (entryId) => call('fn_delete_lesson', { p_entry_id: entryId });
export const getStudentSchedule = (studentId) => call('fn_get_student_schedule', { p_student_id: studentId });
export const getStudentScheduleWithTime = (studentId) => call('fn_get_student_schedule_with_time', { p_student_id: studentId });
export const getStudentBadge = (studentId) => call('fn_get_student_badge', { p_student_id: studentId });
export const updateStudentLocation = (l) => call('fn_update_student_location', {
  p_student_id: l.studentId, p_latitude: l.latitude, p_longitude: l.longitude,
  p_address: l.address || null, p_location_label: l.locationLabel || null,
});

// ---- PHASE 18 — Teacher payroll ---------------------------------------------
export const setTeacherRate = (teacherId, hourlyRate) =>
  call('fn_set_teacher_rate', { p_teacher_id: teacherId, p_hourly_rate: hourlyRate });
export const upsertTeacherMonth = (teacherId, periodMonth, hoursWorked, notes) =>
  call('fn_upsert_teacher_month', { p_teacher_id: teacherId, p_period_month: periodMonth, p_hours_worked: hoursWorked, p_notes: notes || null });
export const recordTeacherPayment = (teacherId, periodMonth, amount) =>
  call('fn_record_teacher_payment', { p_teacher_id: teacherId, p_period_month: periodMonth, p_amount: amount });
export const listTeacherPayroll = (teacherId) => call('fn_list_teacher_payroll', { p_teacher_id: teacherId });

// ---- PHASE 62 — Appointments -------------------------------------------------
export const getAppointmentSettings = () => call('fn_get_appointment_settings');
export const updateAppointmentSettings = (s) => call('fn_update_appointment_settings', {
  p_working_weekdays: s.workingWeekdays, p_max_per_day: s.maxPerDay,
  p_min_days_ahead: s.minDaysAhead, p_max_days_ahead: s.maxDaysAhead,
});
export const getAppointmentAvailability = (monthStart, targetRole) =>
  call('fn_get_appointment_availability', { p_month_start: monthStart, p_target_role: targetRole || null });
export const requestAppointment = (targetRole, appointmentDate, reason) =>
  call('fn_request_appointment', { p_target_role: targetRole, p_appointment_date: appointmentDate, p_reason: reason || null });
export const listMyAppointments = () => call('fn_list_my_appointments');
export const cancelMyAppointment = (id) => call('fn_cancel_my_appointment', { p_id: id });
export const listSchoolAppointments = (status, targetRole) =>
  call('fn_list_school_appointments', { p_status: status || null, p_target_role: targetRole || null });
export const reviewAppointment = (id, status, note) =>
  call('fn_review_appointment', { p_id: id, p_status: status, p_note: note || null });
