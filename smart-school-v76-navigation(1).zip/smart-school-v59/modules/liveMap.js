// ============================================================================
// modules/liveMap.js — Phase 25 (Batch 1)
// Admin/Director general live map. ONE school-scoped RPC (fn_get_map_overview)
// feeds everything: 🏫 school, 🏠 ALL student homes with real coordinates,
// 🚌 the FULL fleet (live active buses + "آخر موقع معروف" for idle buses),
// 📍 route stops, ➖ active-trip GPS polylines (bus_trip_locations).
// Layers are toggleable (🏠🚌📍➖). Clicking a bus opens a detail panel
// (mode B) with driver/trip/speed/passengers + its trip students, without
// rebuilding the map — markers move via setLatLng, popups via setPopupContent.
// Realtime on bus_last_locations + bus_trip_students; 12s polling fallback.
// ============================================================================

import { supabase } from './supabase.js';
import { getMapOverview, getTripRouteHistory, getTripBoardingDropoffPoints, listBusTrips, listSchoolTrips, listBusStudentsOrdered, isDebug } from './school.js';
import { loadLeaflet } from './mapPicker.js';
import { esc } from './ui.js';

const POLL_MS = 12000;
const STALE_MS = 75000;

let map = null;
let layerGroups = {};      // key -> L.layerGroup (homes|buses|stops|routes)
let layerVisible = { homes: true, buses: true, stops: true, routes: true };
let schoolMarker = null;
let busMarkers = {};       // bus_id -> L.marker
let homeMarkers = {};      // student_id -> L.marker
let stopMarkers = [];      // L.marker[]
let routeLines = {};       // active trip_id -> { line, points }
let historyRouteLine = null; // V24: selected previous-trip route, kept separate from active polling
let busRows = [];          // latest overview.buses
let focusedBusId = null;
let focusedStudents = [];
let pollTimer = null;
let rtChannel = null;
let firstFitDone = false;
let refreshSeq = 0;

// ---- my-location (director live navigation) state ----
let meMarker = null;       // L.marker — director's own position
let meCircle = null;       // L.circle — GPS accuracy radius
let meWatchId = null;      // navigator.geolocation watch id
let meFollowing = false;   // auto-center the map on the director position
let baseLayersCtl = null;  // L.control.layers (standard/satellite/hybrid)

// ---- in-app navigation (director → bus) state ----
let navLine = null;        // L.polyline — driving route to the bus
let navOutline = null;     // L.polyline — white outline under the route
let navBusId = null;       // bus_id the route leads to (null = no active nav)
let navFollowTimer = null; // re-routes periodically while both sides move

function timeAgoAr(iso) {
  if (!iso) return '—';
  const s = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `منذ ${s} ثانية`;
  const m = Math.floor(s / 60);
  if (m < 60) return `منذ ${m} دقيقة`;
  return `منذ ${Math.floor(m / 60)} ساعة`;
}

// Valid WGS84 coordinate guard — never hand invalid numbers to Leaflet.
// (0,0) is treated as an unset placeholder (never a real school/home/bus site).
function validLatLng(lat, lng) {
  const la = Number(lat), ln = Number(lng);
  return Number.isFinite(la) && Number.isFinite(ln)
    && la >= -90 && la <= 90 && ln >= -180 && ln <= 180
    && !(la === 0 && ln === 0);
}

// ---------------------------------------------------------------- icons ----
// High-visibility badge markers — solid colored disc + white ring + shadow,
// so they never blend into satellite/hybrid imagery.
function badgeIcon(emoji, bg, size) {
  const html = `<div style="width:${size}px;height:${size}px;border-radius:50%;background:${bg};border:3px solid #fff;box-shadow:0 2px 10px rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;font-size:${Math.round(size * 0.48)}px;line-height:1;">${emoji}</div>`;
  return window.L.divIcon({ html, className: '', iconSize: [size, size], iconAnchor: [size / 2, size / 2] });
}

function busIcon(row) {
  const live = row.has_active_trip && row.live &&
    (Date.now() - new Date(row.recorded_at).getTime() <= STALE_MS);
  const bg = row.has_active_trip ? (live ? '#16a34a' : '#f59e0b') : '#6b7280';
  const size = row.has_active_trip ? 42 : 34;
  return badgeIcon('🚌', bg, size);
}

function homeIcon() { return badgeIcon('🏠', '#dc2626', 30); }
function stopIcon() { return badgeIcon('📍', '#2563eb', 26); }
function schoolIcon() { return badgeIcon('🏫', '#b45309', 46); }

// ---------------------------------------------------------------- popup ----
function busPopupHtml(row) {
  const live = row.has_active_trip && row.live &&
    (Date.now() - new Date(row.recorded_at).getTime() <= STALE_MS);
  const passengers = row.has_active_trip && row.total_students != null
    ? `${row.boarded_count ?? 0} / ${row.total_students}` : '—';
  const dirAr = row.direction === 'pickup' ? 'ذهاب (نحو المؤسسة)'
    : row.direction === 'dropoff' ? 'إياب (نحو المنزل)' : '—';
  return `<div style="min-width:200px; text-align:right;">
    <strong>🚌 ${esc(row.bus_code || 'الحافلة')} — ${esc(row.bus_plate || '—')}</strong><br>
    السائق: ${esc(row.driver_name || 'بدون سائق')}<br>
    ${row.has_active_trip ? `الاتجاه: ${dirAr}<br>
    السرعة: ${row.speed != null ? Math.round(row.speed * 3.6) + ' كم/س' : '—'}<br>
    الركاب: 👥 ${passengers}${row.dropped_count ? ` (نزل: ${row.dropped_count})` : ''}<br>
    GPS: ${live ? '<span style="color:#16a34a;">🟢 متصل</span>' : '<span style="color:#dc2626;">⚠️ غير محدَّث</span>'}<br>
    آخر تحديث: ${row.recorded_at ? timeAgoAr(row.recorded_at) : 'لا يوجد بعد'}` :
    `<span style="color:#6b7280;">⚪ غير نشطة — آخر موقع معروف${row.recorded_at ? ` (${timeAgoAr(row.recorded_at)})` : ''}</span>`}
    <br><button type="button" onclick="window.__ssNavToBus('${row.bus_id}')"
      style="margin-top:6px;padding:6px 12px;border:none;border-radius:999px;background:#f59e0b;color:#fff;font-weight:bold;cursor:pointer;">🧭 الوصول إلى الحافلة</button>
  </div>`;
}

// ------------------------------------------------------------ bus list -----
function renderBusList() {
  const host = document.getElementById('live-map-status');
  if (!host) return;
  if (!busRows.length) {
    host.innerHTML = '<p class="section-title" style="margin-top:14px;">🚌 قائمة الحافلات</p><div class="panel"><div class="empty-state">لا توجد حافلات مسجلة في هذه المؤسسة.</div></div>';
    return;
  }
  const row = (r) => {
    const live = r.has_active_trip && r.live &&
      (Date.now() - new Date(r.recorded_at).getTime() <= STALE_MS);
    const status = r.has_active_trip
      ? (live ? '<span class="badge" style="background:#dcfce7;color:#16a34a;">🟢 نشطة</span>'
              : '<span class="badge badge-blue">🟡 رحلة بدون GPS حديث</span>')
      : '<span class="badge" style="background:#f3f4f6;color:#6b7280;">⚪ غير نشطة</span>';
    return `<div class="detail-row" data-bus="${r.bus_id}" style="flex-wrap:wrap; gap:6px; cursor:pointer;">
      <div style="flex:1; min-width:150px;">
        <strong>🚌 ${esc(r.bus_code || 'حافلة')}</strong> <span class="time">${esc(r.bus_plate || '')}</span><br>
        <span class="time">${esc(r.driver_name || 'بدون سائق')}</span>
      </div>
      ${status}
      ${r.has_active_trip && r.total_students != null ? `<span class="badge">👥 ${r.boarded_count ?? 0}/${r.total_students} ركاب</span>` : ''}
    </div>`;
  };
  host.innerHTML = `<p class="section-title" style="margin-top:14px;">🚌 قائمة الحافلات (${busRows.length})</p>
    <div class="panel">${busRows.map(row).join('')}</div>`;
  host.querySelectorAll('[data-bus]').forEach((el) => {
    el.addEventListener('click', () => focusBus(el.dataset.bus));
  });
}

// --------------------------------------------------------- detail panel ----
async function renderDetailPanel() {
  const host = document.getElementById('live-map-detail');
  if (!host) return;
  const row = busRows.find((b) => b.bus_id === focusedBusId);
  if (!row) { host.innerHTML = ''; return; }
  const dirAr = row.direction === 'pickup' ? 'ذهاب' : row.direction === 'dropoff' ? 'إياب' : '—';
  const studentsHtml = row.has_active_trip
    ? (focusedStudents.length
        ? focusedStudents.map((s, i) => {
            const st = s.alighted_at ? 'DROPPED' : s.boarded_at ? 'BOARDED' : 'NOT_BOARDED';
            const stAr = st === 'BOARDED' ? `🟢 صعد${s.boarded_at ? ` · ${new Date(s.boarded_at).toLocaleTimeString('ar-MA',{hour:'2-digit',minute:'2-digit'})}` : ''}` : st === 'DROPPED' ? `🔵 نزل${s.alighted_at ? ` · ${new Date(s.alighted_at).toLocaleTimeString('ar-MA',{hour:'2-digit',minute:'2-digit'})}` : ''}` : '🔴 لم يصعد';
            return `<div class="detail-row">
              <span class="k">#${i + 1} ${esc(s.full_name || '')}</span>
              <span class="v">${stAr}</span>
            </div>`;
          }).join('')
        : '<div class="empty-state">لا يوجد تلاميذ مرتبطون بهذه الرحلة.</div>')
    : '<div class="empty-state">الحافلة ليست في رحلة حاليًا.</div>';
  host.innerHTML = `<div class="panel" style="margin-top:10px; border:1px solid #2563eb33;">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <strong>🚌 ${esc(row.bus_code || 'الحافلة')} — ${esc(row.bus_plate || '—')}</strong>
      <button type="button" class="icon-btn" id="lm-unfocus">✕</button>
    </div>
    <div class="detail-row"><span class="k">السائق</span><span class="v">${esc(row.driver_name || '—')}</span></div>
    ${row.has_active_trip ? `
    <div class="detail-row"><span class="k">الرحلة</span><span class="v">🟢 نشطة · ${dirAr}</span></div>
    <div class="detail-row"><span class="k">السرعة</span><span class="v">${row.speed != null ? Math.round(row.speed * 3.6) + ' كم/س' : '—'}</span></div>
    <div class="detail-row"><span class="k">GPS</span><span class="v">${row.live ? '🟢 متصل' : '⚠️ غير محدَّث'}</span></div>
    <div class="detail-row"><span class="k">آخر تحديث</span><span class="v">${row.recorded_at ? timeAgoAr(row.recorded_at) : '—'}</span></div>
    <div class="detail-row"><span class="k">الركاب</span><span class="v">👥 ${row.boarded_count ?? 0} / ${row.total_students ?? '—'}</span></div>
    <p class="section-title" style="margin-top:8px;">التلاميذ المرتبطون بالرحلة</p>${studentsHtml}` :
    `<div class="detail-row"><span class="k">الحالة</span><span class="v">⚪ غير نشطة — آخر موقع معروف</span></div>`}
    <div style="display:flex; gap:8px; margin-top:10px;">
      <button type="button" class="quick-action-btn" id="lm-nav" style="flex:1; background:#f59e0b;">🧭 الوصول إلى الحافلة</button>
      <button type="button" class="quick-action-btn secondary" id="lm-history" style="flex:1;">سجل الرحلات</button>
    </div>
  </div>`;
  host.querySelector('#lm-unfocus').addEventListener('click', unfocusBus);
  host.querySelector('#lm-history').addEventListener('click', () =>
    openBusHistoryModal(row.bus_id, row.bus_code || row.bus_plate || 'الحافلة'));
  host.querySelector('#lm-nav').addEventListener('click', () => startNavToBus(row.bus_id));
}

async function focusBus(busId) {
  focusedBusId = busId;
  const row = busRows.find((b) => b.bus_id === busId);
  if (row && row.latitude != null && map) {
    map.setView([row.latitude, row.longitude], Math.max(map.getZoom(), 15), { animate: true });
    const m = busMarkers[busId];
    if (m) m.openPopup();
  }
  focusedStudents = [];
  if (row && row.has_active_trip && row.trip_id) {
    const res = await listBusStudentsOrdered(busId, row.trip_id);
    if (res.ok && res.data) focusedStudents = res.data;
  }
  await renderDetailPanel();
}

function unfocusBus() {
  focusedBusId = null;
  focusedStudents = [];
  renderDetailPanel();
}

// ------------------------------------------------------ base tile layers ---
// Standard OSM + satellite + hybrid (satellite imagery WITH Arabic street
// labels — like Apple Plans "Hybrid").
// Hybrid uses Google tiles (lyrs=y, hl=ar): no API key, no watermark, full
// coverage with Arabic road/place names. Esri World Imagery is kept as a
// key-free pure-satellite alternative.
function buildBaseLayers(mapInstance) {
  const L = window.L;
  // Google Maps is the PRIMARY provider across the app (no API key, no
  // watermark, hl=ar → Arabic labels). OSM kept only as a fallback layer.
  const gOpts = { attribution: '© Google Maps', subdomains: ['0', '1', '2', '3'], maxZoom: 21 };
  const googleHybrid = L.tileLayer('https://mt{s}.google.com/vt/lyrs=y&hl=ar&x={x}&y={y}&z={z}', gOpts);
  const googleRoad = L.tileLayer('https://mt{s}.google.com/vt/lyrs=m&hl=ar&x={x}&y={y}&z={z}', gOpts);
  const googleSat = L.tileLayer('https://mt{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', gOpts);
  const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap', maxZoom: 19,
  });
  baseLayersCtl = L.control.layers(
    {
      '🛰️ هجين (شوارع + صور)': googleHybrid,
      '🗺️ خريطة Google': googleRoad,
      '🛰️ قمر صناعي': googleSat,
      '🗺️ OpenStreetMap (بديل)': osm,
    },
    null, { position: 'topright', collapsed: true }
  ).addTo(mapInstance);
  googleHybrid.addTo(mapInstance); // default view: Google hybrid
}

// ----------------------------------------------- director live location ----
function myLocationIcon() {
  return window.L.divIcon({
    html: `<div style="width:18px;height:18px;border-radius:50%;background:#2563eb;border:3px solid #fff;box-shadow:0 0 0 4px #2563eb44;"></div>`,
    className: '', iconSize: [18, 18], iconAnchor: [9, 9],
  });
}

function updateMeButton() {
  const btn = document.getElementById('lm-locate-me');
  if (!btn) return;
  btn.textContent = meWatchId ? (meFollowing ? '🧭 إيقاف التتبع' : '📍 موقعي (تتبع متوقف)') : '📍 موقعي / تتبعني';
  btn.style.opacity = meWatchId ? '1' : '.85';
}

function onMyPosition(pos) {
  if (!map || !validLatLng(pos.coords.latitude, pos.coords.longitude)) return;
  const latlng = [pos.coords.latitude, pos.coords.longitude];
  const acc = pos.coords.accuracy || 0;
  if (!meMarker) {
    meMarker = window.L.marker(latlng, { icon: myLocationIcon(), zIndexOffset: 1000 })
      .addTo(map)
      .bindPopup('<strong>📍 موقعك الحالي</strong>');
  } else {
    meMarker.setLatLng(latlng);
  }
  if (acc && acc < 5000) {
    if (!meCircle) {
      meCircle = window.L.circle(latlng, { radius: acc, color: '#2563eb', weight: 1, fillColor: '#2563eb', fillOpacity: 0.12 }).addTo(map);
    } else {
      meCircle.setLatLng(latlng); meCircle.setRadius(acc);
    }
  }
  if (meFollowing) map.setView(latlng, Math.max(map.getZoom(), 16), { animate: true });
}

function onMyPositionError(err) {
  const msg = err && err.code === 1
    ? 'تم رفض إذن تحديد الموقع — فعّله من إعدادات المتصفح.'
    : 'تعذر تحديد موقعك (تأكد من تفعيل GPS والاتصال).';
  const host = document.getElementById('live-map-empty');
  if (host) { host.textContent = msg; host.hidden = false; }
  stopMyLocation();
}

function startMyLocation() {
  if (!('geolocation' in navigator)) {
    onMyPositionError(null);
    return;
  }
  meFollowing = true;
  meWatchId = navigator.geolocation.watchPosition(onMyPosition, onMyPositionError, {
    enableHighAccuracy: true, maximumAge: 5000, timeout: 20000,
  });
  updateMeButton();
}

function stopMyLocation() {
  if (meWatchId != null && 'geolocation' in navigator) navigator.geolocation.clearWatch(meWatchId);
  meWatchId = null;
  meFollowing = false;
  if (map && meMarker) { map.removeLayer(meMarker); meMarker = null; }
  if (map && meCircle) { map.removeLayer(meCircle); meCircle = null; }
  updateMeButton();
}

function toggleMyLocation() {
  if (meWatchId) {
    if (meFollowing) {
      // second tap: keep watching but stop auto-centering
      meFollowing = false;
      updateMeButton();
    } else {
      stopMyLocation();
    }
  } else {
    startMyLocation();
  }
}

// ------------------------------------------------- in-app navigation ------
// Real driving route from the director's position to a bus, drawn on the
// map itself (no external app). Routing via OSRM public server — free, no
// API key. Re-routes every 20s while the director and/or the bus move.
function clearNavRoute() {
  if (map && navOutline) { map.removeLayer(navOutline); navOutline = null; }
  if (map && navLine) { map.removeLayer(navLine); navLine = null; }
  if (navFollowTimer) { clearInterval(navFollowTimer); navFollowTimer = null; }
  navBusId = null;
  const info = document.getElementById('live-map-navinfo');
  if (info) { info.hidden = true; info.innerHTML = ''; }
}

function showNavInfo(html) {
  const info = document.getElementById('live-map-navinfo');
  if (!info) return;
  info.innerHTML = html;
  info.hidden = false;
}

function myCurrentLatLng() {
  if (meMarker) return Promise.resolve(meMarker.getLatLng());
  if (!('geolocation' in navigator)) return Promise.reject(new Error('no-geo'));
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      reject,
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 5000 });
  });
}

async function drawNavRoute(busId) {
  const row = busRows.find((b) => b.bus_id === busId);
  if (!map || !row) return;
  if (!validLatLng(row.latitude, row.longitude)) {
    showNavInfo('<div class="panel" style="border:1px solid #fecaca;"><strong>⚠️ لا يوجد موقع معروف لهذه الحافلة بعد.</strong></div>');
    return;
  }
  let me;
  try {
    me = await myCurrentLatLng();
  } catch (e) {
    showNavInfo(`<div class="panel" style="border:1px solid #fecaca;"><strong>⚠️ تعذر تحديد موقعك</strong><div class="time">فعّل إذن الموقع أو اضغط "📍 موقعي / تتبعني" أولًا، ثم أعد المحاولة.</div></div>`);
    return;
  }
  const url = `https://router.project-osrm.org/route/v1/driving/${me.lng},${me.lat};${row.longitude},${row.latitude}?overview=full&geometries=geojson`;
  let route;
  try {
    const resp = await fetch(url);
    const json = await resp.json();
    route = json.routes && json.routes[0];
  } catch (e) { /* fall through */ }
  if (!route) {
    showNavInfo('<div class="panel" style="border:1px solid #fecaca;"><strong>⚠️ تعذر حساب المسار</strong><div class="time">تحقق من الاتصال بالإنترنت ثم أعد المحاولة.</div></div>');
    return;
  }
  const latlngs = route.geometry.coordinates.map(([lng, lat]) => [lat, lng]);
  if (navOutline) map.removeLayer(navOutline);
  if (navLine) map.removeLayer(navLine);
  navOutline = window.L.polyline(latlngs, { color: '#ffffff', weight: 10, opacity: 0.9 }).addTo(map);
  navLine = window.L.polyline(latlngs, { color: '#f59e0b', weight: 6, opacity: 0.95 }).addTo(map);
  navOutline.bringToBack(); navLine.bringToFront();
  const km = (route.distance / 1000).toFixed(1);
  const mins = Math.round(route.duration / 60);
  showNavInfo(`<div class="panel" style="border:1px solid #f59e0b; display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
    <strong>🧭 المسار إلى 🚌 ${esc(row.bus_code || 'الحافلة')}</strong>
    <span class="badge" style="background:#fef3c7;color:#b45309;">📏 ${km} كم</span>
    <span class="badge" style="background:#fef3c7;color:#b45309;">⏱️ ≈ ${mins} دقيقة</span>
    <button type="button" class="quick-action-btn secondary" id="lm-nav-end" style="width:auto; padding:5px 12px; font-size:.82em;">✕ إنهاء المسار</button>
  </div>`);
  document.getElementById('lm-nav-end')?.addEventListener('click', clearNavRoute);
  try { map.fitBounds(navLine.getBounds().pad(0.2)); } catch { /* keep view */ }
}

async function startNavToBus(busId) {
  clearNavRoute();
  navBusId = busId;
  showNavInfo('<div class="panel"><strong>🧭 جارٍ حساب أقرب مسار...</strong></div>');
  await drawNavRoute(busId);
  if (navBusId === busId) {
    navFollowTimer = setInterval(() => drawNavRoute(busId), 20000);
  }
}

window.__ssNavToBus = startNavToBus; // used from bus popup buttons

// ------------------------------------------------------------- layers ------
function applyLayerVisibility() {
  if (!map) return;
  Object.entries(layerGroups).forEach(([key, group]) => {
    const have = map.hasLayer(group);
    if (layerVisible[key] && !have) group.addTo(map);
    if (!layerVisible[key] && have) map.removeLayer(group);
  });
  document.querySelectorAll('[data-layer]').forEach((btn) => {
    btn.style.opacity = layerVisible[btn.dataset.layer] ? '1' : '.45';
  });
}

function renderLayerBar() {
  const bar = document.getElementById('live-map-layers');
  if (!bar) return;
  const items = [
    ['homes', '🏠 المنازل'], ['buses', '🚌 الحافلات'],
    ['stops', '📍 نقاط التوقف'], ['routes', '➖ المسار'],
  ];
  bar.innerHTML = items.map(([k, label]) =>
    `<button type="button" data-layer="${k}" class="quick-action-btn secondary"
       style="padding:5px 10px; font-size:.82em; border-radius:999px;">${label}</button>`).join('')
    + `<button type="button" id="lm-locate-me" class="quick-action-btn"
       style="padding:5px 12px; font-size:.82em; border-radius:999px; width:auto;">📍 موقعي / تتبعني</button>`;
  bar.querySelectorAll('[data-layer]').forEach((btn) => {
    btn.addEventListener('click', () => {
      layerVisible[btn.dataset.layer] = !layerVisible[btn.dataset.layer];
      applyLayerVisibility();
    });
  });
  bar.querySelector('#lm-locate-me').addEventListener('click', toggleMyLocation);
  updateMeButton();
}

// -------------------------------------------------------------- refresh ----
async function refresh() {
  if (!map) return;
  const seq = ++refreshSeq;
  if (isDebug()) console.log('[MAP] refresh: requesting fn_get_map_overview');
  let res;
  try {
    // fn_get_map_overview() takes NO parameters (admin pinned server-side).
    res = await getMapOverview();
  } catch (e) {
    if (isDebug()) console.error('[MAP ERROR] getMapOverview threw:', e);
    res = { ok: false, error: 'تعذر تحميل بيانات التتبع.' };
  }
  if (!res.ok || !res.data) {
    if (isDebug()) console.error('[MAP ERROR]', res.error);
    const emptyEl = document.getElementById('live-map-empty');
    if (emptyEl) { emptyEl.textContent = res.error || 'تعذر تحميل بيانات التتبع.'; emptyEl.hidden = false; }
    renderBusList();
    const statusHost = document.getElementById('live-map-status');
    if (statusHost) statusHost.insertAdjacentHTML('afterbegin', `<div class="panel" style="margin-bottom:8px;border:1px solid #fecaca;"><strong>⚠️ تعذر تحديث الخريطة</strong><div class="time">${esc(res.error || 'خطأ غير معروف')}</div></div>`);
    return;
  }
  if (seq !== refreshSeq || !map) return; // stale response after cleanup/reentry

  const ov = res.data;
  const L = window.L;
  if (isDebug()) console.log('[MAP DATA]', {
    school: ov.school
      ? { name: ov.school.name, hasCoords: validLatLng(ov.school.latitude, ov.school.longitude) }
      : null,
    homes: (ov.homes || []).length,
    buses: (ov.buses || []).length,
    stops: (ov.stops || []).length,
  });
  syncBusFilterOptions(ov.buses);

  // 🏫 school (once) — missing coordinates is a NOTICE, not a connection error.
  const schoolMissingEl = document.getElementById('live-map-school-missing');
  const schoolHasCoords = !!ov.school && validLatLng(ov.school.latitude, ov.school.longitude);
  if (schoolMissingEl) {
    schoolMissingEl.hidden = schoolHasCoords;
    if (!schoolHasCoords) {
      schoolMissingEl.textContent = '🏫 موقع المؤسسة غير محدد — حدّده من "معلومات المؤسسة" ليظهر على الخريطة.';
    }
  }
  if (schoolHasCoords) {
    if (!schoolMarker) {
      schoolMarker = L.marker([ov.school.latitude, ov.school.longitude], {
        icon: schoolIcon(), zIndexOffset: 500,
      }).addTo(map).bindPopup(`<strong>${esc(ov.school.name || 'المؤسسة')}</strong><br>${esc(ov.school.location_label || '')}`);
    }
  } else if (schoolMarker) {
    map.removeLayer(schoolMarker);
    schoolMarker = null;
  }

  // 🏠 homes — diff update, never fake markers; invalid coords are skipped
  const homes = (ov.homes || []).filter((h) => validLatLng(h.latitude, h.longitude));
  const seenHomes = new Set();
  homes.forEach((h) => {
    seenHomes.add(h.student_id);
    const popup = `<strong>${esc(h.full_name)}</strong><br>${esc(h.class_name || '')}<br>${esc(h.location_label || '')}`;
    if (homeMarkers[h.student_id]) {
      homeMarkers[h.student_id].setLatLng([h.latitude, h.longitude]);
      homeMarkers[h.student_id].setPopupContent(popup);
    } else {
      homeMarkers[h.student_id] = L.marker([h.latitude, h.longitude], { icon: homeIcon() })
        .bindPopup(popup)
        .addTo(layerGroups.homes);
    }
  });
  Object.keys(homeMarkers).forEach((id) => {
    if (!seenHomes.has(id)) { layerGroups.homes.removeLayer(homeMarkers[id]); delete homeMarkers[id]; }
  });

  // 📍 stops (cheap, refresh each cycle)
  stopMarkers.forEach((m) => layerGroups.stops.removeLayer(m));
  stopMarkers = [];
  (ov.stops || []).forEach((s) => {
    const m = L.marker([s.latitude, s.longitude], { icon: stopIcon() })
      .bindPopup(`📍 <strong>${esc(s.name)}</strong><br>${esc(s.route_name || '')}`);
    m.addTo(layerGroups.stops);
    stopMarkers.push(m);
  });

  // 🚌 buses — move existing markers, don't rebuild the map
  busRows = ov.buses || [];
  const seenBuses = new Set();
  busRows.forEach((row) => {
    if (!validLatLng(row.latitude, row.longitude)) return;
    seenBuses.add(row.bus_id);
    const marker = busMarkers[row.bus_id];
    if (marker) {
      marker.setLatLng([row.latitude, row.longitude]);
      marker.setIcon(busIcon(row));
      marker.setPopupContent(busPopupHtml(row));
    } else {
      busMarkers[row.bus_id] = L.marker([row.latitude, row.longitude], { icon: busIcon(row) })
        .addTo(layerGroups.buses)
        .bindPopup(busPopupHtml(row))
        .on('click', () => focusBus(row.bus_id));
    }
  });
  Object.keys(busMarkers).forEach((id) => {
    if (!seenBuses.has(id)) {
      layerGroups.buses.removeLayer(busMarkers[id]);
      delete busMarkers[id];
      if (focusedBusId === id) focusedBusId = null;
    }
  });

  // ➖ active-trip polylines from real GPS history (bus_trip_locations)
  const activeTrips = busRows.filter((b) => b.has_active_trip && b.trip_id);
  const activeTripIds = new Set(activeTrips.map((b) => b.trip_id));
  Object.keys(routeLines).forEach((tid) => {
    if (!activeTripIds.has(tid)) { layerGroups.routes.removeLayer(routeLines[tid].line); delete routeLines[tid]; }
  });
  await Promise.all(activeTrips.map(async (b) => {
    const hist = await getTripRouteHistory(b.trip_id);
    if (!hist.ok || !hist.data || !hist.data.length || !map) return;
    const latlngs = hist.data.map((p) => [p.latitude, p.longitude]);
    const existing = routeLines[b.trip_id];
    if (existing) {
      existing.line.setLatLngs(latlngs);
      existing.points = latlngs.length;
    } else {
      const line = L.polyline(latlngs, { color: '#2563eb', weight: 4, opacity: 0.85 }).addTo(layerGroups.routes);
      routeLines[b.trip_id] = { line, points: latlngs.length };
    }
  }));

  // notes + list + detail
  const emptyEl = document.getElementById('live-map-empty');
  if (emptyEl) {
    const anyLive = busRows.some((b) => b.has_active_trip && b.live);
    const anyTripNoGps = busRows.some((b) => b.has_active_trip && !b.live);
    emptyEl.textContent = anyLive ? ''
      : anyTripNoGps ? 'يوجد رحلة نشطة لكن لم يصل أي موقع GPS بعد.'
      : 'لا توجد رحلات نشطة حاليًا — تُعرض المواقع المعروفة فقط.';
    emptyEl.hidden = !emptyEl.textContent;
  }
  renderBusList();
  await renderDetailPanel();

  // fit bounds once
  if (!firstFitDone) {
    firstFitDone = true;
    const pts = [];
    if (schoolHasCoords) pts.push([ov.school.latitude, ov.school.longitude]);
    homes.forEach((h) => pts.push([h.latitude, h.longitude]));
    busRows.forEach((b) => { if (validLatLng(b.latitude, b.longitude)) pts.push([b.latitude, b.longitude]); });
    (ov.stops || []).forEach((st) => { if (validLatLng(st.latitude, st.longitude)) pts.push([st.latitude, st.longitude]); });
    if (pts.length > 1) map.fitBounds(L.latLngBounds(pts).pad(0.15));
    else if (pts.length === 1) map.setView(pts[0], 14);
    setTimeout(() => map && map.invalidateSize(), 60);
  }
}

// ----------------------------------------------------- route history -------
function fmtDur(a, b) {
  if (!a || !b) return '—';
  const mins = Math.round((new Date(b) - new Date(a)) / 60000);
  return mins < 60 ? `${mins} دقيقة` : `${Math.floor(mins / 60)} س ${mins % 60} د`;
}

export async function openBusHistoryModal(busId, busLabel) {
  const overlay = document.createElement('div');
  overlay.className = 'map-picker-overlay';
  overlay.innerHTML = `
    <div class="map-picker-sheet" style="max-width:560px;">
      <div class="map-picker-header"><strong>سجل الرحلات — ${esc(busLabel || '')}</strong><button type="button" class="icon-btn" id="bh-close">✕</button></div>
      <div style="display:flex;gap:6px;align-items:center;margin-bottom:8px;"><label style="flex:0 0 auto;">التاريخ</label><input type="date" id="bh-date" class="search-input" style="flex:1;" title="اختر تاريخ الرحلة"></div>
      <select id="bh-trip-select" class="search-input" style="width:100%; margin-bottom:8px;"><option>جارٍ التحميل...</option></select>
      <div id="bh-info" class="panel" style="margin-bottom:8px;"></div>
      <div id="bh-map" style="width:100%; height:min(45vh, 320px); border-radius:10px; background:#e5e7eb;"></div><button type="button" class="quick-action-btn secondary" id="bh-close-bottom" style="width:100%; margin-top:8px;">إغلاق سجل الرحلات</button>
    </div>`;
  document.body.appendChild(overlay);
  let hmap = null;
  let historyPointLayers = [];
  let closed = false;
  const closeHistory = () => {
    if (closed) return;
    closed = true;
    try { historyPointLayers.forEach((m) => { try { hmap?.removeLayer(m); } catch {} }); historyPointLayers = []; } catch {}
    try { if (hmap) hmap.remove(); } catch {}
    overlay.remove();
  };
  overlay.querySelector('#bh-close').addEventListener('click', closeHistory);
  overlay.querySelector('#bh-close-bottom').addEventListener('click', closeHistory);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) closeHistory(); });
  document.addEventListener('keydown', function bhEsc(e){ if (e.key === 'Escape') { closeHistory(); document.removeEventListener('keydown', bhEsc); } });

  let trips = [];
  const select = overlay.querySelector('#bh-trip-select');
  const dateInput = overlay.querySelector('#bh-date');
  async function loadTripsForDate() {
    select.innerHTML = '<option value="">جارٍ تحميل الرحلات...</option>';
    const chosen = dateInput.value || '';
    const res = await listSchoolTrips({ busId, from: chosen || null, to: chosen || null, limit: 50, offset: 0 });
    trips = res.ok ? (res.data || []).map((t) => ({
      trip_id: t.trip_id, started_at: t.starts_at, ended_at: t.ends_at,
      direction: t.direction, status: t.status, passenger_count: t.boarded_count ?? 0,
    })) : [];
    select.innerHTML = trips.length
      ? trips.map((t) => `<option value="${t.trip_id}">${new Date(t.started_at).toLocaleString('ar-MA-u-nu-latn')} — ${t.direction === 'pickup' ? 'ذهاب' : 'إياب'} (${t.status === 'COMPLETED' ? 'مكتملة' : t.status})</option>`).join('')
      : '<option value="">لا توجد رحلات لهذا التاريخ.</option>';
    if (trips.length) await loadSelectedTrip();
    else overlay.querySelector('#bh-info').innerHTML = '<p class="empty-state">لا توجد رحلة مسجلة لهذا التاريخ والحافلة.</p>';
  }
  dateInput.addEventListener('change', loadTripsForDate);

  await loadLeaflet();
  hmap = window.L.map('bh-map').setView([27.15, -13.2], 12);
  {
    const savedCtl = baseLayersCtl; // history modal gets its own layers control
    buildBaseLayers(hmap);
    baseLayersCtl = savedCtl;
  }
  let polyline = null;

  async function loadSelectedTrip() {
    const tripId = select.value;
    const info = overlay.querySelector('#bh-info');
    if (!tripId) { info.innerHTML = ''; return; }
    const trip = trips.find((t) => t.trip_id === tripId);
    info.innerHTML = `
      <div class="detail-row"><span class="k">التاريخ</span><span class="v">${new Date(trip.started_at).toLocaleDateString('ar')}</span></div>
      <div class="detail-row"><span class="k">الاتجاه</span><span class="v">${trip.direction === 'pickup' ? 'ذهاب' : 'إياب'}</span></div>
      <div class="detail-row"><span class="k">البداية</span><span class="v">${new Date(trip.started_at).toLocaleTimeString('ar')}</span></div>
      <div class="detail-row"><span class="k">النهاية</span><span class="v">${trip.ended_at ? new Date(trip.ended_at).toLocaleTimeString('ar') : 'الرحلة جارية'}</span></div>
      <div class="detail-row"><span class="k">المدة</span><span class="v">${fmtDur(trip.started_at, trip.ended_at)}</span></div>
      <div class="detail-row"><span class="k">عدد الركاب</span><span class="v">${trip.passenger_count ?? 0}</span></div>
      <div class="detail-row"><span class="k">الحالة</span><span class="v">${trip.status === 'COMPLETED' ? '✅ مكتملة' : esc(trip.status || '—')}</span></div>`;
    const [histRes, eventRes] = await Promise.all([
      getTripRouteHistory(tripId),
      getTripBoardingDropoffPoints(tripId),
    ]);
    const points = histRes.ok
      ? (histRes.data || []).filter((p) => validLatLng(p.latitude, p.longitude))
      : [];
    const eventPoints = eventRes.ok
      ? (eventRes.data || []).filter((p) => validLatLng(p.latitude, p.longitude))
      : [];
    if (polyline) { hmap.removeLayer(polyline); polyline = null; }
    if (!points.length) {
      const reason = histRes.ok
        ? 'لا توجد نقاط GPS محفوظة لهذه الرحلة. إذا كانت الرحلة قديمة، فهذا يعني أن تتبع GPS لم يكن يسجل نقاطها.'
        : (histRes.error || 'تعذر تحميل سجل GPS لهذه الرحلة.');
      info.innerHTML += '<p class="empty-state" style="margin-top:8px;">' + esc(reason) + '</p>';
      eventPoints.forEach((pt) => {
        const isBoard = pt.point_type === 'BOARD';
        const marker = window.L.circleMarker([pt.latitude, pt.longitude], { radius: 8, weight: 3, color: isBoard ? '#16a34a' : '#dc2626', fillColor: isBoard ? '#22c55e' : '#ef4444', fillOpacity: .95 }).addTo(hmap);
        marker.bindPopup(`<strong>${isBoard ? '🟢 نقطة الصعود' : '🔴 نقطة النزول'}</strong><br>${esc(pt.student_name || '')}`);
        historyPointLayers.push(marker);
      });
      if (eventPoints.length) hmap.fitBounds(window.L.latLngBounds(eventPoints.map((pt) => [pt.latitude, pt.longitude])).pad(0.2));
      return;
    }
    const latlngs = points.map((p) => [p.latitude, p.longitude]);
    polyline = window.L.polyline(latlngs, { color: '#2563eb', weight: 4 }).addTo(hmap);
    window.L.circleMarker(latlngs[0], { color: '#16a34a', radius: 7 }).addTo(hmap).bindTooltip('البداية');
    window.L.circleMarker(latlngs[latlngs.length - 1], { color: '#dc2626', radius: 7 }).addTo(hmap).bindTooltip('النهاية');
    hmap.fitBounds(polyline.getBounds(), { padding: [20, 20] });
    eventPoints.forEach((pt) => {
      const isBoard = pt.point_type === 'BOARD';
      const marker = window.L.circleMarker([pt.latitude, pt.longitude], {
        radius: 8, weight: 3, color: isBoard ? '#16a34a' : '#dc2626', fillColor: isBoard ? '#22c55e' : '#ef4444', fillOpacity: 0.95,
      }).addTo(hmap);
      marker.bindPopup(`<strong>${isBoard ? '🟢 نقطة الصعود' : '🔴 نقطة النزول'}</strong><br>${esc(pt.student_name || '')}<br>${pt.recorded_at ? esc(fmtDT(pt.recorded_at)) : ''}`);
      historyPointLayers.push(marker);
    });
    setTimeout(() => hmap.invalidateSize(), 50);
  }
  select.addEventListener('change', loadSelectedTrip);
  loadTripsForDate();
  setTimeout(() => hmap.invalidateSize(), 60);
}

// ---------------------------------------------------------------- entry ----
// ---- PHASE 28 — Trip history: ALL school buses (independent of live layer) -
// Reads via fn_list_school_trips (phase28); details reuse the existing
// fn_list_bus_students_ordered + fn_get_trip_route_history. Draws the GPS
// track on the map only when real history points exist — never fake coords.
const TH_PAGE = 25;
const thState = { busId: '', from: '', to: '', offset: 0, total: 0, rows: [], loading: false };

function fmtDT(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '—'
    : d.toLocaleString('ar-MA-u-nu-latn', { dateStyle: 'short', timeStyle: 'short' });
}
function tripStatusAr(s) {
  return { PLANNED: 'مخططة', ACTIVE: 'نشطة', COMPLETED: 'مكتملة', CANCELLED: 'ملغاة' }[s] || s || '—';
}
function tripDirAr(d) {
  return d === 'pickup' ? 'ذهاب (للمدرسة)' : d === 'dropoff' ? 'عودة (للبيوت)' : (d || '—');
}

// Keep the bus filter in sync with the fleet returned by the map overview,
// without resetting the user's current selection.
function syncBusFilterOptions(buses) {
  const sel = document.getElementById('th-bus');
  if (!sel) return;
  const current = sel.value;
  sel.innerHTML = '<option value="">جميع الحافلات</option>' + (buses || [])
    .map((b) => `<option value="${b.bus_id}">${esc(b.label || b.bus_id)}</option>`).join('');
  sel.value = [...sel.options].some((o) => o.value === current) ? current : '';
  thState.busId = sel.value;
}

async function loadTripHistory() {
  const list = document.getElementById('th-list');
  if (!list || thState.loading) return;
  thState.loading = true;
  if (isDebug()) console.log('[TRIP HISTORY]', {
    bus: thState.busId || null, from: thState.from || null, to: thState.to || null, offset: thState.offset,
  });
  list.innerHTML = '<div class="empty-state">جاري تحميل سجل الرحلات...</div>';
  const res = await listSchoolTrips({
    busId: thState.busId || null, from: thState.from || null, to: thState.to || null,
    limit: TH_PAGE, offset: thState.offset,
  });
  thState.loading = false;
  if (!res.ok) {
    if (isDebug()) console.error('[TRIP HISTORY ERROR]', res.error, res.kind || '');
    list.innerHTML = `<div class="empty-state">${esc(res.error || 'تعذر تحميل سجل الرحلات.')}</div>`;
    const pager = document.getElementById('th-pager');
    if (pager) pager.hidden = true;
    return;
  }
  thState.rows = res.data || [];
  thState.total = thState.rows.length ? Number(thState.rows[0].total_count || thState.rows.length) : 0;
  if (isDebug()) console.log('[TRIP HISTORY DATA]', { rows: thState.rows.length, total: thState.total });
  renderTripHistoryTable();
}

function renderTripHistoryTable() {
  const list = document.getElementById('th-list');
  const pager = document.getElementById('th-pager');
  if (!list) return;
  const rows = thState.rows;
  if (!rows.length) {
    list.innerHTML = '<div class="empty-state">لا توجد رحلات مطابقة للفلاتر.</div>';
    if (pager) pager.hidden = true;
    return;
  }
  list.innerHTML = `<div style="overflow-x:auto;"><table style="width:100%; border-collapse:collapse; font-size:13px;">
    <thead><tr style="text-align:right; border-bottom:2px solid #e5e7eb;">
      <th style="padding:6px;">الحافلة</th><th style="padding:6px;">السائق</th><th style="padding:6px;">التاريخ</th>
      <th style="padding:6px;">الاتجاه</th><th style="padding:6px;">البداية</th><th style="padding:6px;">النهاية</th>
      <th style="padding:6px;">الحالة</th><th style="padding:6px;">صعد</th><th style="padding:6px;">نزل</th><th style="padding:6px;"></th>
    </tr></thead>
    <tbody>${rows.map((t) => `<tr style="border-bottom:1px solid #f3f4f6;">
      <td style="padding:6px;">${esc(t.bus_label || '—')}</td>
      <td style="padding:6px;">${esc(t.driver_name || '—')}</td>
      <td style="padding:6px;">${t.starts_at ? esc(new Date(t.starts_at).toLocaleDateString('ar-MA-u-nu-latn')) : '—'}</td>
      <td style="padding:6px;">${esc(tripDirAr(t.direction))}</td>
      <td style="padding:6px;">${esc(fmtDT(t.starts_at))}</td>
      <td style="padding:6px;">${esc(fmtDT(t.ends_at))}</td>
      <td style="padding:6px;">${esc(tripStatusAr(t.status))}</td>
      <td style="padding:6px;">${t.boarded_count ?? 0}</td>
      <td style="padding:6px;">${t.dropped_count ?? 0}</td>
      <td style="padding:6px;"><button type="button" class="quick-action-btn secondary" data-th-detail="${t.trip_id}" style="padding:4px 10px; font-size:12px;">تفاصيل</button></td>
    </tr>`).join('')}</tbody></table></div>`;
  list.querySelectorAll('[data-th-detail]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const trip = thState.rows.find((r) => r.trip_id === btn.dataset.thDetail);
      if (trip) showTripDetail(trip);
    });
  });
  if (pager) {
    pager.hidden = false;
    const page = Math.floor(thState.offset / TH_PAGE) + 1;
    const pages = Math.max(1, Math.ceil(thState.total / TH_PAGE));
    document.getElementById('th-info').textContent = `الصفحة ${page} من ${pages} — ${thState.total} رحلة`;
    document.getElementById('th-prev').disabled = thState.offset <= 0;
    document.getElementById('th-next').disabled = page >= pages;
  }
}

async function showTripDetail(trip) {
  const list = document.getElementById('th-list');
  if (!list) return;
  list.innerHTML = '<div class="empty-state">جاري تحميل تفاصيل الرحلة...</div>';
  if (isDebug()) console.log('[TRIP HISTORY] detail trip=', trip.trip_id);
  const [stuRes, histRes, eventRes] = await Promise.all([
    listBusStudentsOrdered(trip.bus_id, trip.trip_id),
    getTripRouteHistory(trip.trip_id),
    getTripBoardingDropoffPoints(trip.trip_id),
  ]);
  const students = stuRes.ok ? (stuRes.data || []) : [];
  let gpsNote = 'المسار التاريخي غير متوفر (لا بيانات GPS لهذه الرحلة).';
  let pts = [];
  if (histRes.ok && histRes.data && histRes.data.length) {
    pts = histRes.data
      .filter((p) => validLatLng(p.latitude, p.longitude))
      .map((p) => [p.latitude, p.longitude]);
    if (pts.length) gpsNote = `تم عرض مسار الرحلة على الخريطة (${pts.length} نقطة GPS).`;
  }
  if (window.L && map && layerGroups?.routes) {
    if (historyRouteLine) { layerGroups.routes.removeLayer(historyRouteLine); historyRouteLine = null; }
    // Remove old boarding/drop-off markers before drawing the newly selected trip.
    if (!window.__ssTripEventMarkers) window.__ssTripEventMarkers = [];
    window.__ssTripEventMarkers.forEach((m) => { try { layerGroups.routes.removeLayer(m); } catch {} });
    window.__ssTripEventMarkers = [];
    const eventPoints = eventRes.ok ? (eventRes.data || []).filter((p) => validLatLng(p.latitude, p.longitude)) : [];
    eventPoints.forEach((pt) => {
      const isBoard = pt.point_type === 'BOARD';
      const marker = window.L.circleMarker([pt.latitude, pt.longitude], { radius: 8, weight: 3, color: isBoard ? '#16a34a' : '#dc2626', fillColor: isBoard ? '#22c55e' : '#ef4444', fillOpacity: .95 })
        .addTo(layerGroups.routes)
        .bindPopup(`<strong>${isBoard ? '🟢 نقطة الصعود' : '🔴 نقطة النزول'}</strong><br>${esc(pt.student_name || '')}<br>${pt.recorded_at ? esc(fmtDT(pt.recorded_at)) : ''}`);
      window.__ssTripEventMarkers.push(marker);
    });
    if (pts.length) {
      historyRouteLine = window.L.polyline(pts, { color: '#7c3aed', weight: 5, opacity: 0.9 })
        .addTo(layerGroups.routes)
        .bindPopup(`<strong>مسار الرحلة السابقة</strong><br>${esc(trip.bus_label || '')} — ${esc(fmtDT(trip.starts_at))}`);
      try { map.fitBounds(historyRouteLine.getBounds().pad(0.2)); } catch { /* keep current view */ }
    }
  }
  const stuHtml = students.length
    ? students.map((s) => {
        const boarded = !!s.boarded_at;
        const alighted = !!(s.alighted_at ?? s.dropped_at);
        const st = alighted ? '🔵 نزل' : boarded ? '🟢 صعد' : '⚪ لم يصعد';
        return `<tr style="border-bottom:1px solid #f3f4f6;">
          <td style="padding:6px;">${esc(s.full_name || '—')}</td>
          <td style="padding:6px;">${esc(s.student_number || '—')}</td>
          <td style="padding:6px;">${st}</td>
          <td style="padding:6px;">${esc(fmtDT(s.boarded_at))}</td>
          <td style="padding:6px;">${esc(fmtDT(s.dropped_at || s.alighted_at))}</td>
        </tr>`;
      }).join('')
    : `<tr><td colspan="5" style="padding:8px;" class="empty-state">${stuRes.ok ? 'لا يوجد تلاميذ مسجلون في هذه الرحلة.' : esc(stuRes.error || 'تعذر تحميل قائمة التلاميذ.')}</td></tr>`;
  list.innerHTML = `
    <button type="button" class="quick-action-btn secondary" id="th-back" style="margin-bottom:8px;">← عودة للسجل</button>
    <div class="panel" style="margin-bottom:8px;">
      <strong>${esc(trip.bus_label || 'رحلة')}</strong> — ${esc(trip.driver_name || 'سائق غير متوفر')}
      <div style="display:flex; gap:16px; flex-wrap:wrap; margin-top:6px; font-size:13px;">
        <span>📅 ${esc(fmtDT(trip.starts_at))}</span>
        <span>⏱️ البداية: ${esc(fmtDT(trip.starts_at))}</span>
        <span>🏁 النهاية: ${esc(fmtDT(trip.ends_at))}</span>
        <span>↔️ ${esc(tripDirAr(trip.direction))}</span>
        <span>الحالة: ${esc(tripStatusAr(trip.status))}</span>
        <span>المسار: ${esc(trip.route_name || 'غير متوفر')}</span>
        <span>🟢 صعد: ${trip.boarded_count ?? 0}</span>
        <span>🔵 نزل: ${trip.dropped_count ?? 0}</span>
      </div>
      <p class="empty-state" style="margin:6px 0 0;">${esc(gpsNote)}</p>
    </div>
    <div style="overflow-x:auto;"><table style="width:100%; border-collapse:collapse; font-size:13px;">
      <thead><tr style="text-align:right; border-bottom:2px solid #e5e7eb;">
        <th style="padding:6px;">التلميذ</th><th style="padding:6px;">الرقم</th><th style="padding:6px;">الحالة</th>
        <th style="padding:6px;">وقت الصعود</th><th style="padding:6px;">وقت النزول</th>
      </tr></thead><tbody>${stuHtml}</tbody></table></div>`;
  document.getElementById('th-back')?.addEventListener('click', renderTripHistoryTable);
}

function initTripHistory() {
  document.getElementById('th-apply')?.addEventListener('click', () => {
    thState.busId = document.getElementById('th-bus')?.value || '';
    thState.from = document.getElementById('th-from')?.value || '';
    thState.to = document.getElementById('th-to')?.value || '';
    thState.offset = 0;
    loadTripHistory();
  });
  document.getElementById('th-prev')?.addEventListener('click', () => {
    if (thState.offset <= 0) return;
    thState.offset -= TH_PAGE;
    loadTripHistory();
  });
  document.getElementById('th-next')?.addEventListener('click', () => {
    if ((thState.offset + TH_PAGE) >= thState.total) return;
    thState.offset += TH_PAGE;
    loadTripHistory();
  });
  loadTripHistory();
}

export async function renderLiveMap(container, schoolId = null) {
  container.innerHTML = `
    <div id="live-map-layers" style="display:flex; gap:6px; flex-wrap:wrap; margin-bottom:8px;"></div>
    <div id="live-map-status"></div>
    <div id="live-map-detail"></div>
    <div id="live-map" style="width:100%; height:min(60vh, 420px); border-radius:10px; background:#e5e7eb;"></div>
    <div id="live-map-navinfo" style="margin-top:8px;" hidden></div>
    <p class="empty-state" id="live-map-school-missing" style="margin-top:8px; color:#b45309;" hidden></p>
    <p class="empty-state" id="live-map-empty" style="margin-top:8px;" hidden></p>
    <div id="trip-history" style="margin-top:14px;">
      <div class="panel">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; flex-wrap:wrap; margin-bottom:8px;">
          <strong>📚 سجل الرحلات السابقة</strong>
          <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
            <select id="th-bus" class="search-input" style="width:auto;"></select>
            <input type="date" id="th-from" class="search-input" style="width:auto;" title="من تاريخ">
            <input type="date" id="th-to" class="search-input" style="width:auto;" title="إلى تاريخ">
            <button type="button" class="quick-action-btn" id="th-apply" style="width:auto; padding:8px 14px;">تطبيق</button>
          </div>
        </div>
        <div id="th-list"></div>
        <div id="th-pager" style="display:flex; justify-content:space-between; align-items:center; margin-top:8px;" hidden>
          <button type="button" class="quick-action-btn secondary" id="th-prev">السابق</button>
          <span id="th-info" class="empty-state" style="margin:0;"></span>
          <button type="button" class="quick-action-btn secondary" id="th-next">التالي</button>
        </div>
      </div>
    </div>
    `;
  try {
    await loadLeaflet();
  } catch (e) {
    if (isDebug()) console.error('[MAP ERROR] loadLeaflet failed:', e);
    container.innerHTML = '<div class="empty-state">تعذر تحميل مكتبة الخرائط (تحقق من الاتصال بالإنترنت أو من حجب CDN).</div>';
    return () => {};
  }
  const L = window.L;
  map = L.map('live-map').setView([27.15, -13.2], 12);
  buildBaseLayers(map);
  layerGroups = { homes: L.layerGroup().addTo(map), buses: L.layerGroup().addTo(map),
                  stops: L.layerGroup().addTo(map), routes: L.layerGroup().addTo(map) };
  renderLayerBar();
  applyLayerVisibility();
  setTimeout(() => map.invalidateSize(), 50);

  await refresh();
  pollTimer = setInterval(refresh, POLL_MS);

  // Best-effort Realtime: GPS pings AND boarding/dropoff (passenger counts
  // change live without refresh). Polling above is the guaranteed fallback.
  rtChannel = supabase
    .channel('map-overview-live')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'bus_last_locations' }, () => refresh())
    .on('postgres_changes', { event: '*', schema: 'public', table: 'bus_trip_students' }, () => refresh())
    .subscribe();

  return function cleanupLiveMap() {
    refreshSeq++;
    if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
    if (rtChannel) { supabase.removeChannel(rtChannel); rtChannel = null; }
    stopMyLocation();
    clearNavRoute();
    if (baseLayersCtl && map) { map.removeControl(baseLayersCtl); baseLayersCtl = null; }
    if (map) { map.remove(); map = null; }
    busMarkers = {}; homeMarkers = {}; stopMarkers = []; routeLines = {};
    if (historyRouteLine && layerGroups?.routes) { layerGroups.routes.removeLayer(historyRouteLine); }
    historyRouteLine = null;
    schoolMarker = null; busRows = []; focusedBusId = null; focusedStudents = [];
    firstFitDone = false;
  };
}
