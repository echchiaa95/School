// ============================================================================
// modules/auth.js
// Central auth service. Every page imports ONLY from here.
//
// PHASE 3.2: email+password login replaced by PIN login.
// PHASE 3.3: the PIN is no longer used ALONE as the account identifier.
// Login now requires two factors, matching one of:
//   - QR method:     { method: 'qr',     qr_token, pin }
//   - Manual method:  { method: 'manual', user_number, pin }
// The identifier (qr_token / user_number) selects the ACCOUNT; the PIN
// still AUTHENTICATES it. Neither alone creates a session — see
// fn_verify_login in supabase/migrations/phase3_3_qr_manual_login.sql.
//
// The PIN itself is NEVER checked in this file (or anywhere in the
// browser). login() calls the `login-with-pin` Edge Function, which
// verifies method+identifier+pin server-side and returns a one-time
// `token_hash`. The frontend exchanges that for a REAL Supabase session via
// supabase.auth.verifyOtp() — using only the public anon-key client, same
// mechanism as a magic-link login. getSession() / getCurrentUser() /
// requireAuth() are unaffected by any of this.
//
// SECURITY NOTES (unchanged from Phase 3):
// - No role/school_id/user_id is ever trusted from the URL, localStorage,
//   sessionStorage, or client state. Every fact here comes from a live query
//   against `profiles` / `user_roles`, protected by RLS.
// - Real authorization for any data mutation still happens in Postgres RPCs.
// ============================================================================

import { supabase } from './supabase.js';
import { homePageForRole, isRoleAllowedOnPage, pickPrimaryRole } from './permissions.js';

const PIN_REGEX = /^\d{4}$/;

/**
 * Authenticate with two factors: an identifier (QR token or user number)
 * plus a 4-digit PIN. Either alone is rejected server-side.
 *
 * PHASE 3.4: on success, also returns the account's user_number (when the
 * account has one) so the caller can remember this device (see
 * modules/device.js) and skip QR/manual identification next time — the
 * remembered flow simply replays method:'manual' with that cached
 * user_number, reusing this exact function and the exact same server-side
 * checks. Nothing about verification itself changes.
 *
 * @param {'qr'|'manual'} method
 * @param {string} identifier - qr_token for 'qr', user_number for 'manual'
 * @param {string} pin - exactly 4 digits
 * @returns {Promise<{ok: true, userNumber: string|null} | {ok: false, error: string}>}
 */
export async function login(method, identifier, pin) {
  if (method !== 'qr' && method !== 'manual') {
    return { ok: false, error: 'INVALID_METHOD' };
  }
  if (!identifier || typeof identifier !== 'string') {
    return { ok: false, error: 'INVALID_IDENTIFIER' };
  }
  if (!PIN_REGEX.test(pin)) {
    return { ok: false, error: 'INVALID_FORMAT' };
  }

  const body =
    method === 'qr'
      ? { method: 'qr', qr_token: identifier, pin }
      : { method: 'manual', user_number: identifier, pin };

  let invokeResult;
  try {
    invokeResult = await supabase.functions.invoke('login-with-pin', { body });
  } catch (err) {
    console.error('login network error:', err);
    return { ok: false, error: 'NETWORK_ERROR' };
  }

  const { data, error } = invokeResult;
  if (error || !data?.token_hash) {
    // The Edge Function intentionally returns the SAME generic response for
    // "unknown QR", "unknown user_number", "wrong PIN", "disabled",
    // "locked", and "rate limited" — never distinguish these here.
    return { ok: false, error: 'INVALID_CREDENTIALS' };
  }

  const { error: verifyError } = await supabase.auth.verifyOtp({
    token_hash: data.token_hash,
    type: 'magiclink',
  });

  if (verifyError) {
    console.error('verifyOtp error:', verifyError);
    return { ok: false, error: 'INVALID_CREDENTIALS' };
  }

  return { ok: true, userNumber: data.user_number ?? null };
}

/**
 * Sign out and send the user back to the login page.
 */
export async function logout() {
  await supabase.auth.signOut();
  window.location.href = 'index.html';
}

/**
 * Raw Supabase session (has the JWT), or null if not logged in.
 */
export async function getSession() {
  const { data, error } = await supabase.auth.getSession();
  if (error) {
    console.error('getSession error:', error);
    return null;
  }
  return data.session;
}

/**
 * Raw Supabase auth user (id, email, etc.), or null if not logged in.
 */
export async function getCurrentUser() {
  const { data, error } = await supabase.auth.getUser();
  if (error) {
    console.error('getCurrentUser error:', error);
    return null;
  }
  return data.user;
}

/**
 * The current user's row from `profiles`, or null if not logged in, no
 * profile exists, or the account has been disabled.
 */
async function loadCurrentProfile(userId) {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, full_name, phone, avatar_url, is_disabled')
    .eq('id', userId)
    .single();

  if (error) {
    console.error('loadCurrentProfile error:', error);
    return null;
  }
  return data;
}

/**
 * All of the current user's (school_id, role) pairs from `user_roles`.
 */
async function loadUserRoles() {
  const { data, error } = await supabase
    .from('user_roles')
    .select('school_id, role');

  if (error) {
    console.error('loadUserRoles error:', error);
    return [];
  }
  return data || [];
}

/**
 * PHASE 3.2 — single source of truth for "who is logged in and as what".
 * Verifies, in order: session -> user -> profile exists & not disabled ->
 * roles exist -> deterministic primary role (see ROLE_PRIORITY).
 * Used by both redirectToRoleHome() and requireAuth() so the two can never
 * disagree about who the user is.
 *
 * @returns {Promise<{
 *   session: object, user: object, profile: object,
 *   role: string, schoolId: string
 * } | null>} null means "not authenticated" — caller must send to login.
 */
export async function getAuthenticatedContext() {
  const session = await getSession();
  if (!session) return null;

  const user = await getCurrentUser();
  if (!user) return null;

  const profile = await loadCurrentProfile(user.id);
  if (!profile || profile.is_disabled) return null;

  const roles = await loadUserRoles();
  const primary = pickPrimaryRole(roles);
  if (!primary) return null;

  return {
    session,
    user,
    profile,
    role: primary.role,
    schoolId: primary.school_id,
  };
}

/**
 * Send the user to the home page for their role. Call right after a
 * successful login().
 */
export async function redirectToRoleHome() {
  const ctx = await getAuthenticatedContext();
  if (!ctx) {
    console.error('No valid authenticated context after login.');
    await logout();
    return;
  }
  const page = homePageForRole(ctx.role);
  if (!page) {
    console.error('Unknown role, cannot route:', ctx.role);
    await logout();
    return;
  }
  window.location.href = page;
}

/**
 * Page guard: call this at the top of every role-specific page
 * (guard.html, director.html, teacher.html, driver.html, parent.html).
 * Returns the authenticated context on success, or null after already
 * redirecting the user somewhere appropriate (login page, or their real
 * role home if they hit the wrong page).
 */
export async function requireAuth(currentPageFileName) {
  const ctx = await getAuthenticatedContext();
  if (!ctx) {
    window.location.href = 'index.html';
    return null;
  }

  if (!isRoleAllowedOnPage(ctx.role, currentPageFileName)) {
    await redirectToRoleHome();
    return null;
  }

  return ctx;
}

/**
 * Keep the UI in sync if the session changes in another tab (login/logout).
 */
export function onAuthStateChange(callback) {
  return supabase.auth.onAuthStateChange((_event, session) => {
    callback(session);
  });
}
