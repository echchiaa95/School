# Smart School v21 — Location Diagnostic Hotfix

- Fixed the diagnostic error-boundary JavaScript string that could prevent `ui.js` from parsing in some browsers.
- Bumped module cache version from `v=26` to `v=27` to prevent mixed/stale frontend assets.
- No database changes. No SQL migration. No timezone/time changes.
- Purpose: restore Admin dashboard loading, then reproduce the institution-location save issue with the diagnostic boundary active.


V22: fixed map picker validPick ReferenceError and guard Supabase client import; bumped module cache to v28.
