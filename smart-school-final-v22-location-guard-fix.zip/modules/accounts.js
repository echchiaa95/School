// ============================================================================
// modules/accounts.js
// PHASE 4.3 — Teacher / Driver / Parent account management for the Guard
// console. Kept as its own file (not folded into students.js) to avoid one
// module growing monolithic, per the standing "students.js stays focused"
// guidance from Phase 4.1.
//
// READ operations here go through the SAME RLS-protected `supabase` client
// as the rest of the app — access is scoped to the caller's own school by
// the EXISTING policies (p_teachers_staff / p_drivers_staff /
// p_parents_staff), role-based, same documented limitation as
// students/classes (view-level enforcement is role-based, not yet
// permission-fine-grained; the UI additionally gates visibility by the
// real teachers.view/drivers.view/parents.view permission).
//
// WRITE (account creation) goes through the new create-staff-account Edge
// Function — never a direct table insert (there is no INSERT policy on
// profiles/user_roles/teachers/drivers/parents for any client role, by
// design since Phase 2 — only the Edge Function's service-role client can
// write there).
// ============================================================================

import { supabase } from './supabase.js?v=28';

async function listByRole(table, query) {
  let q = supabase
    .from(table)
    .select('id, profile_id, deleted_at, profiles(full_name, phone, user_number)')
    .is('deleted_at', null)
    .order('id');
  const { data, error } = await q;
  if (error) {
    console.error(`list ${table} error:`, error);
    return [];
  }
  const trimmed = (query || '').trim().toLowerCase();
  const rows = data || [];
  if (!trimmed) return rows;
  return rows.filter((r) =>
    (r.profiles?.full_name || '').toLowerCase().includes(trimmed) ||
    (r.profiles?.user_number || '').toLowerCase().includes(trimmed)
  );
}

export async function listTeachers(query) { return listByRole('teachers', query); }
export async function listDrivers(query) { return listByRole('drivers', query); }
export async function listParents(query) { return listByRole('parents', query); }

export async function getTeacherDetail(teacherId) {
  const { data, error } = await supabase
    .from('teachers')
    .select('id, employee_number, profiles(full_name, phone, user_number, avatar_url)')
    .eq('id', teacherId).maybeSingle();
  if (error) { console.error('getTeacherDetail error:', error); return null; }
  return data;
}

export async function getDriverDetail(driverId) {
  const { data, error } = await supabase
    .from('drivers')
    .select('id, license_number, profiles(full_name, phone, user_number, avatar_url)')
    .eq('id', driverId).maybeSingle();
  if (error) { console.error('getDriverDetail error:', error); return null; }
  return data;
}

export async function getParentDetail(parentId) {
  const { data, error } = await supabase
    .from('parents')
    .select('id, profiles(full_name, phone, user_number, avatar_url), parent_students(relationship, students(id, full_name, student_number))')
    .eq('id', parentId).maybeSingle();
  if (error) { console.error('getParentDetail error:', error); return null; }
  return data;
}

/**
 * Create a teacher/driver/parent account via the create-staff-account Edge
 * Function. school_id is NEVER sent — the function derives it itself from
 * the caller's own authenticated context, exactly like fn_guard_* does for
 * students/badges.
 * @param {{
 *   accountType: 'teacher'|'driver'|'parent', fullName: string,
 *   email: string, password: string, phone?: string,
 *   employeeNumber?: string, licenseNumber?: string,
 *   parentStudentLinks?: {studentId: string, relationship?: string}[]
 * }} params
 */
export async function createStaffAccount(params) {
  const { data, error } = await supabase.functions.invoke('create-staff-account', { body: params });
  if (error) {
    // The Edge Function returns a specific Arabic message in its JSON body
    // on failure; supabase-js surfaces the HTTP error separately, so try
    // to read the real message out of the response context when present.
    let message = 'تعذر إنشاء الحساب';
    try {
      const bodyText = await error.context?.text?.();
      if (bodyText) {
        const parsed = JSON.parse(bodyText);
        if (parsed?.error) message = parsed.error;
      }
    } catch {
      // fall back to the generic message
    }
    return { ok: false, error: message };
  }
  if (!data?.ok) {
    return { ok: false, error: data?.error || 'تعذر إنشاء الحساب' };
  }
  return { ok: true, profileId: data.profileId, email: data.email };
}
