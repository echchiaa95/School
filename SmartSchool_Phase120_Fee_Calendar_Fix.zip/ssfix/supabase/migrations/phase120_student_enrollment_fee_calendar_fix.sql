-- Phase 120: correct annual fee calendar start at the student's actual enrollment date.
-- Excludes stale obligations and legacy payments from months before active enrollment.
-- Legacy fee labels are normalized only for matching; source rows remain untouched.
CREATE OR REPLACE FUNCTION public.fn_student_fee_calendar(p_student_id uuid)
RETURNS TABLE(
  obligation_id uuid, academic_year_id uuid, fee_type text, period_key text,
  period_start date, period_end date, list_amount numeric, discount_amount numeric,
  amount_due numeric, amount_paid numeric, remaining numeric, status text,
  paid_transactions jsonb
)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=public
AS $$
DECLARE
  v_school uuid;
  v_year uuid;
  v_year_start date;
  v_year_end date;
  v_enrolled date;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;

  SELECT s.school_id INTO v_school
  FROM public.students s
  WHERE s.id=p_student_id AND s.deleted_at IS NULL;
  IF v_school IS NULL THEN RAISE EXCEPTION 'INVALID_STUDENT'; END IF;

  IF NOT (public.fn_is_school_staff(v_school)
      OR public.fn_has_permission('finance.view',v_school)
      OR public.fn_has_permission('finance.manage',v_school)) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  SELECT se.academic_year_id INTO v_year
  FROM public.student_enrollments se
  WHERE se.student_id=p_student_id AND se.school_id=v_school
    AND se.status::text='ACTIVE'
  ORDER BY se.created_at DESC LIMIT 1;

  IF v_year IS NULL THEN
    RETURN;
  END IF;

  SELECT ay.starts_on, ay.ends_on INTO v_year_start,v_year_end
  FROM public.academic_years ay
  WHERE ay.id=v_year AND ay.school_id=v_school;
  IF v_year_start IS NULL OR v_year_end IS NULL THEN
    RAISE EXCEPTION 'INVALID_ACADEMIC_YEAR';
  END IF;

  -- The student's financial calendar starts at their first ACTIVE enrollment
  -- date in the selected academic year, never at the academic-year start.
  SELECT min(se.enrolled_on) INTO v_enrolled
  FROM public.student_enrollments se
  WHERE se.student_id=p_student_id
    AND se.school_id=v_school
    AND se.academic_year_id=v_year
    AND se.status::text='ACTIVE';

  IF v_enrolled IS NULL THEN
    RETURN;
  END IF;

  PERFORM public.fn_generate_student_fee_obligations(p_student_id,v_year);

  RETURN QUERY
  SELECT
    o.id, o.academic_year_id, o.fee_type, o.period_key,
    o.period_start, o.period_end, o.list_amount, o.discount_amount,
    o.amount_due,
    COALESCE(alloc.paid_total, legacy.amount_paid, o.amount_paid)::numeric,
    GREATEST(0,o.amount_due-COALESCE(alloc.paid_total,legacy.amount_paid,o.amount_paid))::numeric,
    CASE
      WHEN o.amount_due<=0 THEN 'waived'
      WHEN o.period_start>CURRENT_DATE AND COALESCE(alloc.paid_total,legacy.amount_paid,o.amount_paid)<=0 THEN 'future'
      WHEN COALESCE(alloc.paid_total,legacy.amount_paid,o.amount_paid)>=o.amount_due THEN 'paid'
      WHEN COALESCE(alloc.paid_total,legacy.amount_paid,o.amount_paid)>0 THEN 'partial'
      ELSE 'unpaid'
    END::text,
    CASE
      WHEN alloc.paid_total IS NOT NULL THEN alloc.txns
      WHEN legacy.id IS NOT NULL THEN jsonb_build_array(jsonb_build_object(
        'amount',legacy.amount_paid,'paid_on',legacy.paid_on,'method',legacy.method,
        'receipt_no',legacy.receipt_no,'transaction_id',legacy.id,'source','legacy'))
      ELSE '[]'::jsonb
    END
  FROM public.student_fee_obligations o
  LEFT JOIN LATERAL (
    SELECT SUM(a.amount)::numeric AS paid_total,
      jsonb_agg(jsonb_build_object('amount',a.amount,'paid_on',t.paid_on,
        'method',t.method,'receipt_no',t.receipt_no,'transaction_id',t.id)
        ORDER BY t.paid_on) AS txns
    FROM public.student_fee_payment_allocations a
    JOIN public.student_fee_payment_transactions t ON t.id=a.transaction_id
    WHERE a.obligation_id=o.id
  ) alloc ON TRUE
  LEFT JOIN LATERAL (
    SELECT p.* FROM public.payments p
    WHERE p.student_id=o.student_id
      AND p.month=EXTRACT(MONTH FROM o.period_start)::integer
      AND p.year=EXTRACT(YEAR FROM o.period_start)::integer
      AND COALESCE(p.school_id,v_school)=v_school
      AND CASE
        WHEN lower(trim(COALESCE(p.fee_type,''))) IN ('شهرية','شهري','mensuel','monthly') THEN 'واجب التمدرس'
        WHEN trim(COALESCE(p.fee_type,''))='' THEN 'واجب التمدرس'
        ELSE trim(p.fee_type)
      END = o.fee_type
    ORDER BY p.created_at DESC LIMIT 1
  ) legacy ON alloc.paid_total IS NULL
  WHERE o.student_id=p_student_id AND o.school_id=v_school
    AND o.academic_year_id=v_year
    AND o.period_start >= v_enrolled

  UNION ALL

  SELECT NULL::uuid,v_year,
    CASE WHEN lower(trim(COALESCE(p.fee_type,''))) IN ('شهرية','شهري','mensuel','monthly')
      THEN 'واجب التمدرس' ELSE COALESCE(NULLIF(trim(p.fee_type),''),'واجب التمدرس') END::text,
    to_char(make_date(p.year,p.month,1),'YYYY-MM'),
    make_date(p.year,p.month,1),
    (make_date(p.year,p.month,1)+interval '1 month - 1 day')::date,
    p.amount_due::numeric,0::numeric,p.amount_due::numeric,p.amount_paid::numeric,
    GREATEST(0,p.amount_due-p.amount_paid)::numeric,
    CASE WHEN p.amount_paid>=p.amount_due THEN 'paid'
      WHEN p.amount_paid>0 THEN 'partial'
      WHEN make_date(p.year,p.month,1)>CURRENT_DATE THEN 'future'
      ELSE 'unpaid' END::text,
    CASE WHEN p.amount_paid>0 THEN jsonb_build_array(jsonb_build_object(
      'amount',p.amount_paid,'paid_on',p.paid_on,'method',p.method,
      'receipt_no',p.receipt_no,'transaction_id',p.id,'source','legacy'))
      ELSE '[]'::jsonb END
  FROM public.payments p
  WHERE p.student_id=p_student_id
    AND COALESCE(p.school_id,v_school)=v_school
    AND make_date(p.year,p.month,1) BETWEEN GREATEST(v_year_start,v_enrolled) AND v_year_end
    AND NOT EXISTS (
      SELECT 1 FROM public.student_fee_obligations o
      WHERE o.student_id=p_student_id AND o.academic_year_id=v_year
        AND o.period_key=to_char(make_date(p.year,p.month,1),'YYYY-MM')
        AND o.period_start >= v_enrolled
        AND o.fee_type=CASE
          WHEN lower(trim(COALESCE(p.fee_type,''))) IN ('شهرية','شهري','mensuel','monthly') THEN 'واجب التمدرس'
          WHEN trim(COALESCE(p.fee_type,''))='' THEN 'واجب التمدرس'
          ELSE trim(p.fee_type) END
    )
  ORDER BY period_start,fee_type;
END;
$$;
REVOKE ALL ON FUNCTION public.fn_student_fee_calendar(uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.fn_student_fee_calendar(uuid) TO authenticated;
NOTIFY pgrst,'reload schema';
