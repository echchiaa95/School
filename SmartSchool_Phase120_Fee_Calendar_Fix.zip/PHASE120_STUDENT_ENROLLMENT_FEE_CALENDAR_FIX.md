# Phase 120 — Student enrollment-based fee calendar

## Purpose
Correct the annual student fee calendar so it never displays legacy payments or generated fee obligations for months before the student's first ACTIVE enrollment date in the selected academic year.

## Changes
- Resolve the active academic year for the student.
- Read the first ACTIVE `student_enrollments.enrolled_on` date for that year.
- Generate obligations using the existing fee generator.
- Exclude existing ledger obligations whose `period_start` is before enrollment.
- Exclude legacy `payments` rows whose month begins before enrollment.
- Return no calendar rows when the student has no active enrollment in the selected academic year.
- Preserve existing payment records and receipts; this migration does not delete or rewrite financial history.

## Apply
Run `supabase/migrations/phase120_student_enrollment_fee_calendar_fix.sql` in Supabase SQL Editor after Phase 118.

## Validation
After applying, open the student's fee calendar and verify:
1. Months before `enrolled_on` do not appear as due months.
2. The enrollment month and later months follow the configured fee plan.
3. Months without a fee plan remain "no fees registered".
4. Legacy payments remain visible only when their payment month is on/after enrollment.
