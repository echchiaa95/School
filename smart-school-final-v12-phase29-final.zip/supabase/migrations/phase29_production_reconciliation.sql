-- PHASE 29 — PRODUCTION RECONCILIATION (audit-driven)
-- Final corrected version. Executed successfully in Production and verified 8/8 PASS.
-- This file is retained as the project migration record; do NOT re-run against Production.

-- §0 — PRE-FLIGHT ASSERTIONS

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_proc
    WHERE pronamespace = 'public'::regnamespace
      AND proname = 'fn_get_map_overview'
      AND pg_get_function_identity_arguments(oid) = 'p_school_id uuid'
  ) THEN
    RAISE EXCEPTION 'PREFLIGHT FAILED: fn_get_map_overview(uuid) baseline overload not found — production state differs from the audited baseline. Aborting.';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_proc
    WHERE pronamespace = 'public'::regnamespace
      AND proname = 'fn_update_school_location'
      AND pg_get_function_identity_arguments(oid) <> 'p_latitude double precision, p_longitude double precision, p_location_label text'
  ) THEN
    RAISE EXCEPTION 'PREFLIGHT FAILED: fn_update_school_location exists with an unexpected signature. Aborting.';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_proc
    WHERE pronamespace = 'public'::regnamespace
      AND proname = 'fn_get_class_attendance'
      AND pg_get_function_identity_arguments(oid) = 'p_class_id uuid, p_date date'
  ) THEN
    RAISE EXCEPTION 'PREFLIGHT FAILED: fn_get_class_attendance(uuid,date) not found — production state differs from the audited baseline. Aborting.';
  END IF;
END $$;

DO $$
DECLARE
  v_oid oid;
  v_actual text[];
  v_expected text[] := ARRAY[
    'student_id','full_name','student_number',
    'pickup_stop','dropoff_stop','stop_order',
    'stop_latitude','stop_longitude','student_latitude','student_longitude',
    'boarded_at','alighted_at'
  ];
BEGIN
  SELECT p.oid INTO v_oid
  FROM pg_proc p
  WHERE p.pronamespace = 'public'::regnamespace
    AND p.proname = 'fn_list_bus_students_ordered'
    AND p.pronargs = 2
    AND p.proargtypes = '2950 2950'::oidvector;
  IF v_oid IS NULL THEN
    RAISE EXCEPTION 'PREFLIGHT FAILED: fn_list_bus_students_ordered(uuid,uuid) not found. Aborting.';
  END IF;

  SELECT array_agg(u.col_name ORDER BY u.ord) INTO v_actual
  FROM pg_proc p
  CROSS JOIN LATERAL unnest(p.proargnames, p.proargmodes)
       WITH ORDINALITY AS u(col_name, col_mode, ord)
  WHERE p.oid = v_oid AND u.col_mode IN ('o','t');

  IF v_actual IS DISTINCT FROM v_expected THEN
    RAISE EXCEPTION 'PREFLIGHT FAILED: fn_list_bus_students_ordered return shape is NOT the audited 12-column baseline (found % column(s): %). Aborting BEFORE any change.',
      COALESCE(array_length(v_actual, 1), 0),
      COALESCE(array_to_string(v_actual, ', '), '(none)');
  END IF;
END $$;

DO $$
DECLARE
  v_oid oid;
  v_deps int;
BEGIN
  SELECT oid INTO v_oid
  FROM pg_proc
  WHERE pronamespace = 'public'::regnamespace
    AND proname = 'fn_list_bus_students_ordered'
    AND pg_get_function_identity_arguments(oid) = 'p_bus_id uuid, p_trip_id uuid';

  SELECT count(*) INTO v_deps
  FROM pg_depend
  WHERE refobjid = v_oid
    AND refclassid = 'pg_proc'::regclass
    AND deptype <> 'i';

  IF v_deps > 0 THEN
    RAISE EXCEPTION 'UNSAFE DEPENDENCY: % object(s) depend on fn_list_bus_students_ordered(uuid,uuid). Aborting BEFORE drop. Inspect pg_depend manually and reconcile first.', v_deps;
  END IF;
END $$;

DO $$
DECLARE
  v_oid oid;
  v_cols text[];
BEGIN
  SELECT p.oid INTO v_oid
  FROM pg_proc p
  WHERE p.pronamespace = 'public'::regnamespace
    AND p.proname = 'fn_list_school_trips'
    AND p.pronargs = 5
    AND p.proargtypes = '2950 1082 1082 23 23'::oidvector;

  IF v_oid IS NOT NULL THEN
    SELECT array_agg(u.col_name ORDER BY u.ord) INTO v_cols
    FROM pg_proc p
    CROSS JOIN LATERAL unnest(p.proargnames, p.proargmodes)
         WITH ORDINALITY AS u(col_name, col_mode, ord)
    WHERE p.oid = v_oid AND u.col_mode IN ('o','t');

    IF COALESCE(array_length(v_cols, 1), 0) <> 12
       OR v_cols[array_length(v_cols, 1)] <> 'total_count' THEN
      RAISE EXCEPTION 'PREFLIGHT FAILED: fn_list_school_trips exists with the exact intended signature but an incompatible return shape (expected 12 columns ending with total_count; found %). Aborting.',
        COALESCE(array_to_string(v_cols, ', '), '(none)');
    END IF;
    RAISE NOTICE 'phase29: fn_list_school_trips already present with the exact signature and a compatible shape — re-run refreshes it with the phase28 body.';
  END IF;
END $$;

-- PART A — TRUE zero-argument overload for admin/director
CREATE OR REPLACE FUNCTION fn_get_map_overview()
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_id uuid;
  v_result jsonb;
BEGIN
  SELECT ur.school_id INTO v_school_id FROM user_roles ur
  WHERE ur.profile_id = auth.uid() AND ur.role IN ('admin', 'director')
  LIMIT 1;
  IF v_school_id IS NULL THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;

  SELECT jsonb_build_object(
    'school', (
      SELECT jsonb_build_object(
        'name', s.name, 'latitude', s.latitude,
        'longitude', s.longitude, 'location_label', s.location_label
      ) FROM schools s WHERE s.id = v_school_id
    ),
    'homes', COALESCE((
      SELECT jsonb_agg(jsonb_build_object(
        'student_id', st.id, 'full_name', st.full_name,
        'class_name', cls.name, 'latitude', st.latitude,
        'longitude', st.longitude, 'location_label', st.location_label
      ) ORDER BY st.full_name)
      FROM students st
      LEFT JOIN student_enrollments se ON se.student_id = st.id AND se.status = 'ACTIVE'
      LEFT JOIN classes cls ON cls.id = se.class_id
      WHERE st.school_id = v_school_id
        AND st.deleted_at IS NULL
        AND st.latitude IS NOT NULL
        AND st.longitude IS NOT NULL
      LIMIT 1500
    ), '[]'::jsonb),
    'buses', COALESCE((
      SELECT jsonb_agg(jsonb_build_object(
        'bus_id', b.id, 'bus_code', b.code, 'bus_plate', b.plate_number,
        'driver_name', prof.full_name,
        'has_active_trip', t.id IS NOT NULL,
        'trip_id', t.id,
        'direction', CASE
          WHEN t.direction = 'TO_SCHOOL'::trip_direction THEN 'pickup'
          WHEN t.direction = 'TO_HOME'::trip_direction THEN 'dropoff'
          ELSE NULL END,
        'latitude', COALESCE(ll_trip.latitude, ll_last.latitude),
        'longitude', COALESCE(ll_trip.longitude, ll_last.longitude),
        'speed', ll_trip.speed,
        'recorded_at', COALESCE(ll_trip.recorded_at, ll_last.recorded_at),
        'live', ll_trip.recorded_at IS NOT NULL,
        'total_students', CASE WHEN t.id IS NOT NULL THEN
          (SELECT count(*) FROM student_transport_assignments sta
           WHERE sta.bus_id = b.id AND sta.is_active)::int ELSE NULL END,
        'boarded_count', CASE WHEN t.id IS NOT NULL THEN
          (SELECT count(*) FROM bus_trip_students bts
           WHERE bts.trip_id = t.id AND bts.boarded_at IS NOT NULL)::int ELSE NULL END,
        'dropped_count', CASE WHEN t.id IS NOT NULL THEN
          (SELECT count(*) FROM bus_trip_students bts
           WHERE bts.trip_id = t.id AND bts.dropped_at IS NOT NULL)::int ELSE NULL END
      ) ORDER BY b.code)
      FROM buses b
      LEFT JOIN bus_trips t ON t.bus_id = b.id AND t.status = 'ACTIVE'::trip_status
      LEFT JOIN bus_last_locations ll_trip ON ll_trip.bus_id = b.id AND ll_trip.trip_id = t.id
      LEFT JOIN LATERAL (
        SELECT ll.latitude, ll.longitude, ll.recorded_at
        FROM bus_last_locations ll
        WHERE ll.bus_id = b.id
        ORDER BY ll.recorded_at DESC LIMIT 1
      ) ll_last ON t.id IS NULL
      LEFT JOIN drivers d ON d.id = COALESCE(t.driver_id, b.driver_id)
      LEFT JOIN profiles prof ON prof.id = d.profile_id
      WHERE b.school_id = v_school_id
    ), '[]'::jsonb),
    'stops', COALESCE((
      SELECT jsonb_agg(jsonb_build_object(
        'stop_id', bs.id, 'name', bs.name,
        'latitude', bs.latitude, 'longitude', bs.longitude,
        'route_name', br.name
      ) ORDER BY br.name, rs.sequence_order)
      FROM bus_route_stops rs
      JOIN bus_stops bs ON bs.id = rs.stop_id
      JOIN bus_routes br ON br.id = rs.route_id
      WHERE br.school_id = v_school_id
        AND bs.latitude IS NOT NULL
        AND bs.longitude IS NOT NULL
    ), '[]'::jsonb)
  ) INTO v_result;

  RETURN v_result;
END;
$$;

REVOKE ALL ON FUNCTION fn_get_map_overview() FROM public;
GRANT EXECUTE ON FUNCTION fn_get_map_overview() TO authenticated;

-- PART B — school location
CREATE OR REPLACE FUNCTION fn_update_school_location(
  p_latitude double precision,
  p_longitude double precision,
  p_location_label text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  SELECT ur.school_id INTO v_school_id FROM user_roles ur
  WHERE ur.profile_id = auth.uid() AND ur.role IN ('admin', 'director') LIMIT 1;
  IF v_school_id IS NULL THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  IF p_latitude < -90 OR p_latitude > 90 THEN RAISE EXCEPTION 'INVALID_LATITUDE'; END IF;
  IF p_longitude < -180 OR p_longitude > 180 THEN RAISE EXCEPTION 'INVALID_LONGITUDE'; END IF;

  UPDATE schools
  SET latitude = p_latitude, longitude = p_longitude,
      location_label = COALESCE(p_location_label, location_label)
  WHERE id = v_school_id;

  PERFORM fn_safe_audit(v_school_id, 'SCHOOL_LOCATION_UPDATED', 'schools', v_school_id, NULL,
    jsonb_build_object('latitude', p_latitude, 'longitude', p_longitude, 'updated_by', auth.uid()));
END;
$$;

REVOKE ALL ON FUNCTION fn_update_school_location(double precision, double precision, text) FROM public;
GRANT EXECUTE ON FUNCTION fn_update_school_location(double precision, double precision, text) TO authenticated;

-- PART C — assigned-teacher attendance authorization
CREATE OR REPLACE FUNCTION fn_get_class_attendance(p_class_id uuid, p_date date DEFAULT NULL)
RETURNS TABLE(student_id uuid, full_name text, student_number text, status text, note text)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_id uuid;
  v_teacher_id uuid;
  v_teacher_assigned boolean := false;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  SELECT school_id INTO v_school_id FROM classes WHERE id = p_class_id;
  IF v_school_id IS NULL THEN RAISE EXCEPTION 'INVALID_CLASS'; END IF;

  SELECT t.id INTO v_teacher_id
  FROM teachers t
  WHERE t.school_id = v_school_id
    AND t.profile_id = auth.uid()
    AND t.deleted_at IS NULL
  LIMIT 1;

  IF v_teacher_id IS NOT NULL THEN
    v_teacher_assigned := EXISTS (
      SELECT 1 FROM teacher_classes tc
      WHERE tc.teacher_id = v_teacher_id AND tc.class_id = p_class_id
    ) OR EXISTS (
      SELECT 1 FROM classes c
      WHERE c.id = p_class_id AND c.teacher_id = v_teacher_id
    );
  END IF;

  IF NOT (
    fn_is_school_member(v_school_id)
    OR v_teacher_assigned
    OR fn_has_permission('attendance.view', v_school_id)
    OR fn_has_permission('attendance.manage', v_school_id)
  ) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  RETURN QUERY
  SELECT st.id, st.full_name, st.student_number, ar.status, ar.note
  FROM student_enrollments se
  JOIN students st ON st.id = se.student_id AND st.deleted_at IS NULL
  LEFT JOIN attendance_records ar
    ON ar.student_id = st.id
   AND ar.class_id = se.class_id
   AND ar.att_date = COALESCE(p_date, current_date)
  WHERE se.class_id = p_class_id
    AND se.status = 'ACTIVE'
  ORDER BY st.full_name;
END;
$$;

REVOKE ALL ON FUNCTION fn_get_class_attendance(uuid, date) FROM public;
GRANT EXECUTE ON FUNCTION fn_get_class_attendance(uuid, date) TO authenticated;

-- PART D — roster 12 -> 13 columns
DROP FUNCTION public.fn_list_bus_students_ordered(uuid, uuid);

CREATE FUNCTION fn_list_bus_students_ordered(p_bus_id uuid, p_trip_id uuid DEFAULT NULL)
RETURNS TABLE(
  student_id uuid, full_name text, student_number text, photo_url text,
  pickup_stop text, dropoff_stop text,
  stop_order int, stop_latitude double precision, stop_longitude double precision,
  student_latitude double precision, student_longitude double precision,
  boarded_at timestamptz, alighted_at timestamptz
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_id uuid;
  v_ctx jsonb;
  v_direction trip_direction;
BEGIN
  SELECT school_id INTO v_school_id FROM buses WHERE id = p_bus_id;
  IF v_school_id IS NULL THEN RAISE EXCEPTION 'INVALID_BUS'; END IF;

  v_ctx := fn_driver_context();
  IF NOT (fn_is_school_member(v_school_id)
          OR (v_ctx IS NOT NULL AND (v_ctx->>'bus_id')::uuid = p_bus_id)) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  IF p_trip_id IS NOT NULL THEN
    SELECT direction INTO v_direction FROM bus_trips WHERE id = p_trip_id;
  END IF;

  RETURN QUERY
  SELECT sta.student_id, s.full_name, s.student_number, s.photo_url,
         COALESCE(bs_pick.name,
           CASE WHEN v_direction = 'TO_SCHOOL'::trip_direction OR v_direction IS NULL
                THEN 'منزل التلميذ'
                ELSE (SELECT sc.name FROM schools sc WHERE sc.id = v_school_id) END),
         COALESCE(bs_drop.name,
           CASE WHEN v_direction = 'TO_SCHOOL'::trip_direction OR v_direction IS NULL
                THEN (SELECT sc.name FROM schools sc WHERE sc.id = v_school_id)
                ELSE 'منزل التلميذ' END),
         brs.sequence_order,
         bs_pick.latitude, bs_pick.longitude,
         s.latitude, s.longitude,
         bts.boarded_at, bts.dropped_at
  FROM student_transport_assignments sta
  JOIN students s ON s.id = sta.student_id AND s.deleted_at IS NULL
  LEFT JOIN bus_stops bs_pick ON bs_pick.id = sta.pickup_stop_id
  LEFT JOIN bus_stops bs_drop ON bs_drop.id = sta.dropoff_stop_id
  LEFT JOIN bus_route_stops brs ON brs.route_id = sta.route_id AND brs.stop_id = sta.pickup_stop_id
  LEFT JOIN bus_trip_students bts ON bts.trip_id = p_trip_id AND bts.student_id = sta.student_id
  WHERE sta.bus_id = p_bus_id AND sta.is_active
  ORDER BY COALESCE(brs.sequence_order, 999999), s.full_name;
END;
$$;

REVOKE ALL ON FUNCTION fn_list_bus_students_ordered(uuid, uuid) FROM public;
GRANT EXECUTE ON FUNCTION fn_list_bus_students_ordered(uuid, uuid) TO authenticated;

-- PART E — school trip history
CREATE OR REPLACE FUNCTION fn_list_school_trips(
  p_bus_id uuid DEFAULT NULL,
  p_from date DEFAULT NULL,
  p_to date DEFAULT NULL,
  p_limit int DEFAULT 25,
  p_offset int DEFAULT 0
)
RETURNS TABLE(
  trip_id uuid, bus_id uuid, bus_label text, driver_name text,
  route_name text, direction text, status text,
  starts_at timestamptz, ends_at timestamptz,
  boarded_count int, dropped_count int, total_count bigint
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;

  SELECT school_id INTO v_school_id FROM user_roles
  WHERE profile_id = auth.uid() LIMIT 1;
  IF v_school_id IS NULL THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  IF NOT fn_is_school_staff(v_school_id) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;

  IF p_bus_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM buses b WHERE b.id = p_bus_id AND b.school_id = v_school_id
  ) THEN
    RAISE EXCEPTION 'INVALID_BUS';
  END IF;

  RETURN QUERY
  SELECT
    t.id,
    b.id,
    COALESCE(NULLIF(b.code, ''), b.plate_number, 'غير متوفر'),
    COALESCE(p.full_name, 'غير متوفر'),
    COALESCE(r.name, 'غير متوفر'),
    CASE WHEN t.direction = 'TO_SCHOOL'::trip_direction THEN 'pickup' ELSE 'dropoff' END,
    t.status::text,
    t.starts_at,
    t.ends_at,
    (SELECT count(*) FROM bus_trip_students x WHERE x.trip_id = t.id AND x.boarded_at IS NOT NULL)::int,
    (SELECT count(*) FROM bus_trip_students x WHERE x.trip_id = t.id AND x.dropped_at IS NOT NULL)::int,
    count(*) OVER ()
  FROM bus_trips t
  JOIN buses b ON b.id = t.bus_id
  LEFT JOIN drivers d ON d.id = t.driver_id
  LEFT JOIN profiles p ON p.id = d.profile_id
  LEFT JOIN bus_routes r ON r.id = t.route_id
  WHERE t.school_id = v_school_id
    AND (p_bus_id IS NULL OR t.bus_id = p_bus_id)
    AND (p_from IS NULL OR t.starts_at::date >= p_from)
    AND (p_to IS NULL OR t.starts_at::date <= p_to)
  ORDER BY t.starts_at DESC NULLS LAST
  LIMIT GREATEST(1, LEAST(COALESCE(p_limit, 25), 100))
  OFFSET GREATEST(0, COALESCE(p_offset, 0));
END;
$$;

REVOKE ALL ON FUNCTION fn_list_school_trips(uuid, date, date, int, int) FROM public;
GRANT EXECUTE ON FUNCTION fn_list_school_trips(uuid, date, date, int, int) TO authenticated;

-- §I — POST-DEPLOY VERIFICATION (manual/read-only)
-- Expected after deployment: all eight verification checks PASS.
-- 1) map overview: both '' and 'p_school_id uuid'
-- 2) school location RPC exists
-- 3) teacher attendance contains teacher assignment logic
-- 4) roster has 13 columns including photo_url and alighted_at
-- 5) school trip history RPC exists
-- 6) DROP_OFF enum count = 1
-- 7) three badge/guard RPCs exist
-- 8) fn_record_trip_event still contains DROP_OFF logic
