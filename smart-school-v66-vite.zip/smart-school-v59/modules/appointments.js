// ============================================================================
// modules/appointments.js — Phase 62
// زر عائم + تقويم شهري لطلب موعد (ولي الأمر)، ولوحة إدارة الطلبات (مدير/حارس).
// ============================================================================
import {
  getAppointmentAvailability, requestAppointment, listMyAppointments, cancelMyAppointment,
  listSchoolAppointments, reviewAppointment, getAppointmentSettings, updateAppointmentSettings,
  mapRpcError,
} from './school.js';

const WEEKDAYS_AR = ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
const MONTHS_AR = ['يناير','فبراير','مارس','أبريل','ماي','يونيو','يوليوز','غشت','شتنبر','أكتوبر','نونبر','دجنبر'];
const STATUS_AR = { PENDING: 'قيد الانتظار', APPROVED: 'مقبول', REJECTED: 'مرفوض', CANCELLED: 'ملغى' };

function injectStyleOnce() {
  if (document.getElementById('appt-style')) return;
  const style = document.createElement('style');
  style.id = 'appt-style';
  style.textContent = `
    .appt-fab{position:fixed;inset-inline-end:18px;bottom:24px;z-index:9998;width:60px;height:60px;border-radius:50%;
      background:linear-gradient(135deg,var(--ss-navy-600,#1d4265),var(--ss-navy-800,#10293f));color:#fff;border:0;
      box-shadow:var(--ss-shadow-lg,0 18px 48px rgba(11,31,51,.18));font-family:var(--ss-font,inherit);
      font-size:26px;display:flex;align-items:center;justify-content:center;cursor:pointer;
      transition:transform .18s var(--ss-ease,ease),box-shadow .25s var(--ss-ease,ease)}
    .appt-fab:hover{transform:translateY(-2px)}
    .appt-fab:active{transform:scale(.94)}
    .appt-overlay{position:fixed;inset:0;z-index:10001;background:rgba(11,31,51,.58);display:flex;align-items:center;
      justify-content:center;padding:14px;backdrop-filter:blur(3px)}
    .appt-modal{width:min(420px,100%);max-height:88vh;overflow:auto;background:var(--ss-surface,#fff);
      border-radius:var(--ss-radius,16px);padding:18px;box-shadow:var(--ss-shadow-lg,0 18px 48px rgba(11,31,51,.18));
      direction:rtl;font-family:var(--ss-font,inherit)}
    .appt-modal-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
    .appt-modal-head h3{margin:0;font-size:18px;color:var(--ss-navy-700,#16334e)}
    .appt-close{background:var(--ss-bg,#eef2f7);border:0;border-radius:var(--ss-radius-sm,10px);padding:8px 12px;
      color:var(--ss-navy-700,#16334e);cursor:pointer}
    .appt-tabs{display:flex;gap:6px;margin-bottom:12px}
    .appt-tab{flex:1;padding:8px;border-radius:var(--ss-radius-sm,10px);border:0;background:var(--ss-bg,#eef2f7);
      color:var(--ss-muted,#5b6b7c);font-weight:700;cursor:pointer;transition:background .15s var(--ss-ease,ease)}
    .appt-tab.active{background:var(--ss-navy-600,#1d4265);color:#fff}
    .appt-cal-nav{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;color:var(--ss-navy-700,#16334e)}
    .appt-cal-nav button{background:var(--ss-bg,#eef2f7);border:0;border-radius:8px;padding:6px 10px;cursor:pointer;font-size:16px}
    .appt-cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:5px;text-align:center}
    .appt-cal-grid .wd{font-size:11px;color:var(--ss-muted,#5b6b7c);font-weight:700;padding-bottom:4px}
    .appt-day{aspect-ratio:1;border-radius:var(--ss-radius-sm,10px);display:flex;align-items:center;justify-content:center;
      font-size:13px;cursor:pointer;border:1px solid transparent;transition:background .15s var(--ss-ease,ease)}
    .appt-day.off{background:var(--ss-bg,#eef2f7);color:#b9c4d0;cursor:not-allowed}
    .appt-day.past{background:var(--ss-bg,#eef2f7);color:#b9c4d0;cursor:not-allowed}
    .appt-day.full{background:#fdeceb;color:var(--ss-danger,#dc2626);cursor:not-allowed}
    .appt-day.avail{background:#e9f5ee;color:var(--ss-success,#15803d);font-weight:700}
    .appt-day.avail:hover{background:var(--ss-success,#15803d);color:#fff}
    .appt-day.selected{background:var(--ss-navy-600,#1d4265) !important;color:#fff !important}
    .appt-legend{display:flex;gap:10px;flex-wrap:wrap;font-size:11px;color:var(--ss-muted,#5b6b7c);margin-top:10px}
    .appt-legend span{display:flex;align-items:center;gap:4px}
    .appt-dot{width:10px;height:10px;border-radius:3px;display:inline-block}
    .appt-form{margin-top:14px;border-top:1px solid var(--ss-line,#e3e9f0);padding-top:12px}
    .appt-form label{display:block;font-size:12px;color:var(--ss-navy-700,#16334e);margin-bottom:4px;font-weight:700}
    .appt-form select,.appt-form textarea{width:100%;padding:9px;border-radius:var(--ss-radius-sm,10px);
      border:1.5px solid var(--ss-line,#e3e9f0);margin-bottom:10px;font-family:inherit;font-size:14px}
    .appt-submit{width:100%;padding:11px;border-radius:var(--ss-radius,16px);border:0;
      background:linear-gradient(135deg,var(--ss-navy-700,#16334e),var(--ss-navy-500,#25517b));color:#fff;
      font-weight:800;cursor:pointer;font-size:14px;transition:transform .18s var(--ss-ease,ease)}
    .appt-submit:hover{transform:translateY(-1px)}
    .appt-submit:disabled{opacity:.6;cursor:not-allowed;transform:none}
    .appt-my-item{border:1px solid var(--ss-line,#e3e9f0);border-radius:var(--ss-radius,16px);padding:10px;margin-bottom:8px}
    .appt-badge{display:inline-block;padding:3px 9px;border-radius:999px;font-size:11px;font-weight:800}
    .appt-badge.PENDING{background:#fdf3d9;color:var(--ss-warning,#b45309)}
    .appt-badge.APPROVED{background:#e9f5ee;color:var(--ss-success,#15803d)}
    .appt-badge.REJECTED{background:#fdeceb;color:var(--ss-danger,#dc2626)}
    .appt-badge.CANCELLED{background:var(--ss-bg,#eef2f7);color:var(--ss-muted,#5b6b7c)}
    .appt-cancel-btn{margin-top:6px;background:#fdeceb;color:var(--ss-danger,#dc2626);border:0;
      border-radius:8px;padding:6px 10px;font-size:12px;cursor:pointer}
  `;
  document.head.appendChild(style);
}

/** يُدرج زرًا عائمًا في الصفحة يفتح تقويم طلب المواعيد (يُستعمل في parent.html). */
export function mountAppointmentFab() {
  injectStyleOnce();
  if (document.getElementById('appt-fab-btn')) return;
  const fab = document.createElement('button');
  fab.id = 'appt-fab-btn';
  fab.className = 'appt-fab';
  fab.type = 'button';
  fab.title = 'طلب موعد';
  fab.innerHTML = '📅';
  fab.addEventListener('click', openAppointmentModal);
  document.body.appendChild(fab);
}

let currentMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
let selectedDate = null;
let activeTargetRole = 'admin';

function openAppointmentModal() {
  const overlay = document.createElement('div');
  overlay.className = 'appt-overlay';
  overlay.innerHTML = `
    <div class="appt-modal" role="dialog" aria-modal="true">
      <div class="appt-modal-head"><h3>📅 طلب موعد</h3><button type="button" class="appt-close">✕</button></div>
      <div class="appt-tabs">
        <button type="button" class="appt-tab active" data-tab="new">حجز جديد</button>
        <button type="button" class="appt-tab" data-tab="mine">مواعيدي</button>
      </div>
      <div id="appt-tab-new"></div>
      <div id="appt-tab-mine" hidden></div>
    </div>`;
  document.body.appendChild(overlay);
  const close = () => overlay.remove();
  overlay.querySelector('.appt-close').addEventListener('click', close);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });

  overlay.querySelectorAll('.appt-tab').forEach((btn) => btn.addEventListener('click', () => {
    overlay.querySelectorAll('.appt-tab').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    const isNew = btn.dataset.tab === 'new';
    overlay.querySelector('#appt-tab-new').hidden = !isNew;
    overlay.querySelector('#appt-tab-mine').hidden = isNew;
    if (!isNew) renderMyAppointments(overlay.querySelector('#appt-tab-mine'));
  }));

  currentMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  selectedDate = null;
  renderCalendarTab(overlay.querySelector('#appt-tab-new'));
}

async function renderCalendarTab(host) {
  host.innerHTML = '<div class="loading-state">جارٍ التحميل...</div>';
  const monthStr = `${currentMonth.getFullYear()}-${String(currentMonth.getMonth() + 1).padStart(2, '0')}-01`;
  const res = await getAppointmentAvailability(monthStr, activeTargetRole);
  if (!res.ok) { host.innerHTML = `<div class="empty-state">${mapRpcError(res.error)}</div>`; return; }
  const days = res.data || [];
  const firstDow = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1).getDay(); // 0=Sunday

  const cells = [];
  for (let i = 0; i < firstDow; i++) cells.push('<div></div>');
  days.forEach((d) => {
    const dateStr = d.day;
    const dayNum = Number(dateStr.slice(-2));
    let cls = 'appt-day ';
    let clickable = false;
    if (d.is_past) cls += 'past';
    else if (!d.is_working) cls += 'off';
    else if (d.is_full) cls += 'full';
    else { cls += 'avail'; clickable = true; }
    if (selectedDate === dateStr) cls += ' selected';
    cells.push(`<div class="${cls}" ${clickable ? `data-day="${dateStr}"` : ''}>${dayNum}</div>`);
  });

  host.innerHTML = `
    <div class="appt-cal-nav">
      <button type="button" id="appt-prev">‹</button>
      <strong>${MONTHS_AR[currentMonth.getMonth()]} ${currentMonth.getFullYear()}</strong>
      <button type="button" id="appt-next">›</button>
    </div>
    <div style="margin-bottom:8px;">
      <select id="appt-target" class="search-input" style="width:100%;">
        <option value="admin" ${activeTargetRole === 'admin' ? 'selected' : ''}>لقاء مدير المؤسسة</option>
        <option value="guard" ${activeTargetRole === 'guard' ? 'selected' : ''}>لقاء الحراسة العامة</option>
      </select>
    </div>
    <div class="appt-cal-grid">
      ${WEEKDAYS_AR.map((w) => `<div class="wd">${w}</div>`).join('')}
      ${cells.join('')}
    </div>
    <div class="appt-legend">
      <span><i class="appt-dot" style="background:#e7f6ec;"></i>متاح</span>
      <span><i class="appt-dot" style="background:#fee2e2;"></i>مكتمل</span>
      <span><i class="appt-dot" style="background:#f8fafc;border:1px solid #e5e7eb;"></i>عطلة/ماضٍ</span>
    </div>
    <div id="appt-form-zone"></div>
  `;

  host.querySelector('#appt-prev').addEventListener('click', () => {
    currentMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1);
    renderCalendarTab(host);
  });
  host.querySelector('#appt-next').addEventListener('click', () => {
    currentMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1);
    renderCalendarTab(host);
  });
  host.querySelector('#appt-target').addEventListener('change', (e) => {
    activeTargetRole = e.target.value;
    selectedDate = null;
    renderCalendarTab(host);
  });
  host.querySelectorAll('[data-day]').forEach((cell) => cell.addEventListener('click', () => {
    selectedDate = cell.dataset.day;
    renderCalendarTab(host);
  }));

  if (selectedDate) {
    const zone = host.querySelector('#appt-form-zone');
    zone.innerHTML = `
      <div class="appt-form">
        <label>سبب الطلب (اختياري)</label>
        <textarea id="appt-reason" rows="2" placeholder="مثال: مناقشة نتائج التلميذ..."></textarea>
        <button type="button" class="appt-submit" id="appt-submit-btn">تأكيد طلب الموعد — ${selectedDate}</button>
      </div>`;
    zone.querySelector('#appt-submit-btn').addEventListener('click', async (e) => {
      const btn = e.target;
      btn.disabled = true; btn.textContent = 'جارٍ الإرسال...';
      const reason = host.querySelector('#appt-reason').value;
      const res2 = await requestAppointment(activeTargetRole, selectedDate, reason);
      if (!res2.ok) {
        alert(mapRpcError(res2.error));
        btn.disabled = false; btn.textContent = `تأكيد طلب الموعد — ${selectedDate}`;
        return;
      }
      alert('تم إرسال طلب الموعد بنجاح، سيصلك إشعار عند الرد.');
      selectedDate = null;
      renderCalendarTab(host);
    });
  }
}

async function renderMyAppointments(host) {
  host.innerHTML = '<div class="loading-state">جارٍ التحميل...</div>';
  const res = await listMyAppointments();
  if (!res.ok) { host.innerHTML = `<div class="empty-state">${mapRpcError(res.error)}</div>`; return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = '<div class="empty-state">لا توجد طلبات مواعيد بعد.</div>'; return; }
  host.innerHTML = rows.map((a) => `
    <div class="appt-my-item">
      <div><strong>${a.target_role === 'admin' ? 'مدير المؤسسة' : 'الحراسة العامة'}</strong>
        <span class="appt-badge ${a.status}">${STATUS_AR[a.status] || a.status}</span></div>
      <div style="color:#64748b;font-size:13px;">📅 ${a.appointment_date}</div>
      ${a.reason ? `<div style="font-size:13px;margin-top:4px;">${a.reason}</div>` : ''}
      ${a.review_note ? `<div style="font-size:12px;color:#64748b;margin-top:4px;">ملاحظة: ${a.review_note}</div>` : ''}
      ${['PENDING', 'APPROVED'].includes(a.status) ? `<button type="button" class="appt-cancel-btn" data-cancel="${a.id}">إلغاء الموعد</button>` : ''}
    </div>`).join('');
  host.querySelectorAll('[data-cancel]').forEach((b) => b.addEventListener('click', async () => {
    if (!confirm('إلغاء هذا الموعد؟')) return;
    const res2 = await cancelMyAppointment(b.dataset.cancel);
    if (!res2.ok) { alert(mapRpcError(res2.error)); return; }
    renderMyAppointments(host);
  }));
}

// ============================================================================
// لوحة إدارة الطلبات (تُستعمل في admin.html و guard.html)
// ============================================================================
export async function renderAppointmentManagement(containerEl, { canManageSettings = false } = {}) {
  injectStyleOnce();
  containerEl.innerHTML = '<div class="loading-state">جارٍ التحميل...</div>';
  const res = await listSchoolAppointments('PENDING');
  const allRes = await listSchoolAppointments();
  if (!res.ok) { containerEl.innerHTML = `<div class="empty-state">${mapRpcError(res.error)}</div>`; return; }

  const pending = res.data || [];
  const all = allRes.ok ? (allRes.data || []) : [];

  containerEl.innerHTML = `
    <p class="section-title">طلبات قيد الانتظار (${pending.length})</p>
    <div id="appt-pending-list"></div>
    <p class="section-title" style="margin-top:16px;">كل الطلبات</p>
    <div id="appt-all-list"></div>
    ${canManageSettings ? '<p class="section-title" style="margin-top:16px;">إعدادات المواعيد</p><div id="appt-settings-zone"></div>' : ''}
  `;

  const renderRow = (a, showActions) => `
    <div class="appt-my-item">
      <div><strong>${a.requester_name || '—'}</strong> ${a.requester_phone ? `<span style="color:#64748b;font-size:12px;">· ${a.requester_phone}</span>` : ''}
        <span class="appt-badge ${a.status}">${STATUS_AR[a.status] || a.status}</span></div>
      <div style="color:#64748b;font-size:13px;">📅 ${a.appointment_date} — ${a.target_role === 'admin' ? 'المدير' : 'الحراسة العامة'}</div>
      ${a.reason ? `<div style="font-size:13px;margin-top:4px;">${a.reason}</div>` : ''}
      ${showActions ? `
        <div style="display:flex;gap:6px;margin-top:8px;">
          <button type="button" class="quick-action-btn" data-approve="${a.id}" style="flex:1;">قبول</button>
          <button type="button" class="quick-action-btn secondary" data-reject="${a.id}" style="flex:1;">رفض</button>
        </div>` : ''}
    </div>`;

  const pendingHost = containerEl.querySelector('#appt-pending-list');
  pendingHost.innerHTML = pending.length ? pending.map((a) => renderRow(a, true)).join('') : '<div class="empty-state">لا توجد طلبات قيد الانتظار.</div>';
  pendingHost.querySelectorAll('[data-approve]').forEach((b) => b.addEventListener('click', async () => {
    const r = await reviewAppointment(b.dataset.approve, 'APPROVED');
    if (!r.ok) { alert(mapRpcError(r.error)); return; }
    renderAppointmentManagement(containerEl, { canManageSettings });
  }));
  pendingHost.querySelectorAll('[data-reject]').forEach((b) => b.addEventListener('click', async () => {
    const note = prompt('سبب الرفض (اختياري):') || '';
    const r = await reviewAppointment(b.dataset.reject, 'REJECTED', note);
    if (!r.ok) { alert(mapRpcError(r.error)); return; }
    renderAppointmentManagement(containerEl, { canManageSettings });
  }));

  containerEl.querySelector('#appt-all-list').innerHTML = all.length
    ? all.map((a) => renderRow(a, false)).join('')
    : '<div class="empty-state">لا توجد طلبات.</div>';

  if (canManageSettings) {
    const settingsRes = await getAppointmentSettings();
    const zone = containerEl.querySelector('#appt-settings-zone');
    if (!settingsRes.ok) { zone.innerHTML = `<div class="empty-state">${mapRpcError(settingsRes.error)}</div>`; return; }
    const s = settingsRes.data;
    const days = s.working_weekdays || [];
    zone.innerHTML = `
      <div class="panel">
        <label style="font-size:12px;font-weight:700;">أيام العمل المتاحة للمواعيد</label>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin:8px 0;">
          ${WEEKDAYS_AR.map((w, i) => `<label style="display:flex;align-items:center;gap:4px;font-size:12px;">
            <input type="checkbox" data-wd="${i + 1}" ${days.includes(i + 1) ? 'checked' : ''}> ${w}</label>`).join('')}
        </div>
        <label style="font-size:12px;font-weight:700;">أقصى عدد مواعيد في اليوم</label>
        <input type="number" id="appt-max-per-day" class="search-input" value="${s.max_per_day}" min="1" style="margin-bottom:8px;">
        <button type="button" class="quick-action-btn" id="appt-save-settings" style="width:100%;">حفظ الإعدادات</button>
      </div>`;
    zone.querySelector('#appt-save-settings').addEventListener('click', async () => {
      const workingWeekdays = Array.from(zone.querySelectorAll('[data-wd]:checked')).map((cb) => Number(cb.dataset.wd));
      const maxPerDay = Number(zone.querySelector('#appt-max-per-day').value) || 1;
      const r = await updateAppointmentSettings({ workingWeekdays, maxPerDay, minDaysAhead: s.min_days_ahead, maxDaysAhead: s.max_days_ahead });
      if (!r.ok) { alert(mapRpcError(r.error)); return; }
      alert('تم حفظ الإعدادات.');
    });
  }
}
