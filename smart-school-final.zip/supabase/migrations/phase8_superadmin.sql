-- ============================================================================
-- Phase 8 — SuperAdmin Platform
-- SuperAdmin-only functions for platform management.
-- Compatible with REAL schema:
--   profiles: id, full_name, phone, user_number, avatar_url, is_disabled, created_at, updated_at
--   user_roles: profile_id, school_id, role, created_at
--   schools: id, name, address, phone, logo_url, created_at, updated_at
--   app_role: admin, guard, director, teacher, driver, parent
-- Adds 'superadmin' to app_role enum (additive, safe).
-- No references to: profiles.role, profiles.school_id, profiles.deleted_at,
--   profiles.is_active, schools.email, schools.deleted_at, activity_logs.
-- ============================================================================

-- Add superadmin to app_role enum if not exists (PostgreSQL 9.1+ safe additive)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_enum
    WHERE enumlabel = 'superadmin'
    AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'app_role')
  ) THEN
    ALTER TYPE public.app_role ADD VALUE 'superadmin';
  END IF;
END $$;

-- is_superadmin: checks user_roles for superadmin role
CREATE OR REPLACE FUNCTION public.is_superadmin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM user_roles
    WHERE profile_id = auth.uid()
      AND role = 'superadmin'
  );
$$;

-- fn_list_all_schools: SuperAdmin only
-- Returns schools without email/deleted_at (not in schema)
CREATE OR REPLACE FUNCTION public.fn_list_all_schools()
RETURNS TABLE (
  id UUID,
  name TEXT,
  address TEXT,
  phone TEXT,
  admin_count BIGINT,
  student_count BIGINT,
  created_at TIMESTAMPTZ
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_superadmin() THEN
    RAISE EXCEPTION 'SuperAdmin only';
  END IF;

  RETURN QUERY
  SELECT
    s.id,
    s.name,
    s.address,
    s.phone,
    (SELECT COUNT(DISTINCT ur.profile_id) FROM user_roles ur WHERE ur.school_id = s.id AND ur.role = 'admin')::BIGINT,
    (SELECT COUNT(*) FROM students st WHERE st.school_id = s.id)::BIGINT,
    s.created_at
  FROM schools s
  ORDER BY s.created_at DESC;
END;
$$;

-- fn_create_school: SuperAdmin only
-- schools table: id, name, address, phone, logo_url, created_at, updated_at
-- No email, no deleted_at, no activity_logs
CREATE OR REPLACE FUNCTION public.fn_create_school(
  p_name TEXT,
  p_address TEXT DEFAULT NULL,
  p_phone TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_id UUID;
BEGIN
  IF NOT public.is_superadmin() THEN
    RETURN jsonb_build_object('ok', false, 'error', 'SuperAdmin only');
  END IF;

  IF p_name IS NULL OR LENGTH(TRIM(p_name)) = 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'School name is required');
  END IF;

  INSERT INTO schools (name, address, phone)
  VALUES (TRIM(p_name), p_address, p_phone)
  RETURNING id INTO v_school_id;

  RETURN jsonb_build_object('ok', true, 'school_id', v_school_id);
END;
$$;

-- fn_list_school_admins: SuperAdmin only
-- Uses user_roles for role/school, profiles for name/is_disabled
CREATE OR REPLACE FUNCTION public.fn_list_school_admins(p_school_id UUID)
RETURNS TABLE (
  id UUID,
  full_name TEXT,
  email TEXT,
  role TEXT,
  is_disabled BOOLEAN,
  created_at TIMESTAMPTZ
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_superadmin() THEN
    RAISE EXCEPTION 'SuperAdmin only';
  END IF;

  RETURN QUERY
  SELECT
    p.id,
    p.full_name,
    u.email,
    ur.role,
    p.is_disabled,
    p.created_at
  FROM profiles p
  JOIN auth.users u ON u.id = p.id
  JOIN user_roles ur ON ur.profile_id = p.id
  WHERE ur.school_id = p_school_id
    AND ur.role = 'admin'
  ORDER BY p.created_at DESC;
END;
$$;

-- fn_get_platform_stats: SuperAdmin only
CREATE OR REPLACE FUNCTION public.fn_get_platform_stats()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_count BIGINT;
  v_student_count BIGINT;
  v_staff_count BIGINT;
  v_guard_check_count BIGINT;
BEGIN
  IF NOT public.is_superadmin() THEN
    RETURN jsonb_build_object('ok', false, 'error', 'SuperAdmin only');
  END IF;

  SELECT COUNT(*) INTO v_school_count FROM schools;
  SELECT COUNT(*) INTO v_student_count FROM students;
  SELECT COUNT(DISTINCT ur.profile_id) INTO v_staff_count FROM user_roles ur;
  SELECT COUNT(*) INTO v_guard_check_count FROM guard_checks;

  RETURN jsonb_build_object(
    'ok', true,
    'schools', v_school_count,
    'students', v_student_count,
    'staff', v_staff_count,
    'guard_checks', v_guard_check_count
  );
END;
$$;
