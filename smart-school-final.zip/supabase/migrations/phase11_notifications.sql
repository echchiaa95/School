-- ============================================================================
-- Phase 11 — Notifications System (REAL schema)
-- notifications: id, school_id, title, body, created_at
-- notification_deliveries: id, notification_id, profile_id, read_at
-- NO created_at in notification_deliveries per real schema.
-- NO profiles.school_id, NO profiles.role, NO profiles.deleted_at.
-- Uses user_roles for school/role lookups.
-- Additive only. No DROP. No TRUNCATE.
-- ============================================================================

-- Notifications table (REAL schema — no profile_id, no read column)
CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  body TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE public.notifications IS 'School-wide notifications. Read state lives in notification_deliveries.';

-- Notification deliveries (read/unread per user)
-- REAL schema: id, notification_id, profile_id, read_at
-- NO created_at per user confirmation.
CREATE TABLE IF NOT EXISTS public.notification_deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  notification_id UUID NOT NULL REFERENCES public.notifications(id) ON DELETE CASCADE,
  profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  read_at TIMESTAMPTZ,
  UNIQUE(notification_id, profile_id)
);

COMMENT ON TABLE public.notification_deliveries IS 'Per-user delivery/read state for notifications';

-- Indexes
CREATE INDEX IF NOT EXISTS idx_notifications_school ON public.notifications(school_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_deliveries_profile ON public.notification_deliveries(profile_id);
CREATE INDEX IF NOT EXISTS idx_deliveries_unread ON public.notification_deliveries(profile_id, read_at) WHERE read_at IS NULL;

-- RLS on notifications
-- Users see notifications for schools they belong to (via user_roles, NOT profiles.school_id)
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS notifications_select_school ON public.notifications;
CREATE POLICY notifications_select_school ON public.notifications
  FOR SELECT USING (
    school_id IN (SELECT school_id FROM user_roles WHERE profile_id = auth.uid())
  );

DROP POLICY IF EXISTS notifications_insert_school ON public.notifications;
CREATE POLICY notifications_insert_school ON public.notifications
  FOR INSERT WITH CHECK (
    school_id IN (SELECT school_id FROM user_roles WHERE profile_id = auth.uid())
  );

-- RLS on notification_deliveries
ALTER TABLE public.notification_deliveries ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS deliveries_select_own ON public.notification_deliveries;
CREATE POLICY deliveries_select_own ON public.notification_deliveries
  FOR SELECT USING (profile_id = auth.uid());

DROP POLICY IF EXISTS deliveries_update_own ON public.notification_deliveries;
CREATE POLICY deliveries_update_own ON public.notification_deliveries
  FOR UPDATE USING (profile_id = auth.uid());

DROP POLICY IF EXISTS deliveries_insert_system ON public.notification_deliveries;
CREATE POLICY deliveries_insert_system ON public.notification_deliveries
  FOR INSERT WITH CHECK (
    notification_id IN (
      SELECT n.id FROM notifications n
      WHERE n.school_id IN (SELECT school_id FROM user_roles WHERE profile_id = auth.uid())
    )
  );

-- RPC: send_notification (creates notification + delivery for single user)
CREATE OR REPLACE FUNCTION public.fn_send_notification(
  p_school_id UUID,
  p_profile_id UUID,
  p_title TEXT,
  p_body TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_notif_id UUID;
BEGIN
  INSERT INTO notifications (school_id, title, body)
  VALUES (p_school_id, p_title, p_body)
  RETURNING id INTO v_notif_id;

  INSERT INTO notification_deliveries (notification_id, profile_id)
  VALUES (v_notif_id, p_profile_id);

  RETURN jsonb_build_object('ok', true, 'id', v_notif_id);
END;
$$;

-- ============================================================================
-- STEP 1.1 — Notifications Targeting by Role
-- RPC for sending notifications to all users with specific roles in a school.
-- SECURITY DEFINER to bypass RLS for bulk delivery creation.
-- Validates sender belongs to the target school via user_roles (NOT profiles.school_id).
-- Uses user_roles for role targeting and profiles.is_disabled for active check.
-- ============================================================================

CREATE OR REPLACE FUNCTION public.fn_send_notification_to_roles(
  p_school_id UUID,
  p_title TEXT,
  p_body TEXT DEFAULT NULL,
  p_target_roles TEXT[] DEFAULT ARRAY['teacher', 'driver', 'guard', 'parent']
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_notif_id UUID;
  v_sender_school UUID;
  v_target_profile RECORD;
  v_count INT := 0;
BEGIN
  -- Validate sender belongs to the school via user_roles (profiles has no school_id)
  SELECT school_id INTO v_sender_school
  FROM user_roles
  WHERE profile_id = auth.uid()
  LIMIT 1;

  IF v_sender_school IS NULL OR v_sender_school != p_school_id THEN
    RETURN jsonb_build_object('ok', false, 'error', 'School access denied');
  END IF;

  -- Validate target roles
  IF p_target_roles IS NULL OR array_length(p_target_roles, 1) IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'No target roles specified');
  END IF;

  -- Create the notification
  INSERT INTO notifications (school_id, title, body)
  VALUES (p_school_id, p_title, p_body)
  RETURNING id INTO v_notif_id;

  -- Create deliveries for all matching users in the same school
  -- Uses user_roles for school+role, profiles.is_disabled for active check
  FOR v_target_profile IN
    SELECT DISTINCT ur.profile_id
    FROM user_roles ur
    JOIN profiles p ON p.id = ur.profile_id
    WHERE ur.school_id = p_school_id
      AND ur.role = ANY(p_target_roles)
      AND p.is_disabled = false
  LOOP
    INSERT INTO notification_deliveries (notification_id, profile_id)
    VALUES (v_notif_id, v_target_profile.profile_id)
    ON CONFLICT (notification_id, profile_id) DO NOTHING;
    v_count := v_count + 1;
  END LOOP;

  RETURN jsonb_build_object('ok', true, 'id', v_notif_id, 'recipients', v_count);
END;
$$;

COMMENT ON FUNCTION public.fn_send_notification_to_roles IS
  'Sends a notification to all users with specified roles in the same school. Sender must belong to the school. Uses user_roles for school/role lookups.';
