// ============================================================================
// modules/superadmin.js
// SuperAdmin platform functions — RPC wrappers.
// Uses phase8_superadmin.sql RPCs. No service_role in frontend.
// ============================================================================
import { supabase } from './supabase.js'

/** @returns {Promise<{ok:boolean, schools?:number, students?:number, staff?:number, guard_checks?:number, error?:string}>} */
export async function getPlatformStats() {
  const { data, error } = await supabase.rpc('fn_get_platform_stats')
  if (error) { console.error('getPlatformStats:', error); return { ok: false, error: error.message } }
  return data || { ok: false, error: 'No data' }
}

/** @returns {Promise<Array<{id:string, name:string, address:string|null, phone:string|null, admin_count:number, student_count:number, created_at:string}>>} */
export async function listAllSchools() {
  const { data, error } = await supabase.rpc('fn_list_all_schools')
  if (error) { console.error('listAllSchools:', error); return [] }
  return data || []
}

/** @param {string} name @param {string|null} address @param {string|null} phone */
export async function createSchool(name, address, phone) {
  const { data, error } = await supabase.rpc('fn_create_school', {
    p_name: name,
    p_address: address,
    p_phone: phone,
  })
  if (error) { console.error('createSchool:', error); return { ok: false, error: error.message } }
  return data || { ok: false, error: 'No data' }
}

/** @param {string} schoolId */
export async function listSchoolAdmins(schoolId) {
  const { data, error } = await supabase.rpc('fn_list_school_admins', { p_school_id: schoolId })
  if (error) { console.error('listSchoolAdmins:', error); return [] }
  return data || []
}
