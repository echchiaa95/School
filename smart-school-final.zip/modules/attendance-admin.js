// ============================================================================
// modules/attendance-admin.js
// Attendance admin dashboard data — director & superadmin read-only views.
// Uses the REAL schema: guard_checks, students, student_enrollments, classes.
// ============================================================================
import { supabase } from './supabase.js'

/** @param {string} schoolId @param {string} [dateStr] */
export async function getAttendanceStats(schoolId, dateStr) {
  const date = dateStr || new Date().toISOString().slice(0, 10)
  const startOfDay = date + 'T00:00:00'
  const endOfDay = date + 'T23:59:59'
  const { count: totalStudents, error: e1 } = await supabase
    .from('students').select('*', { count: 'exact', head: true })
    .eq('school_id', schoolId).is('deleted_at', null)
  if (e1) { console.error('getAttendanceStats total:', e1); return null }
  const { count: present, error: e2 } = await supabase
    .from('guard_checks').select('*', { count: 'exact', head: true })
    .eq('school_id', schoolId).eq('result', 'AUTHORIZED')
    .gte('created_at', startOfDay).lte('created_at', endOfDay)
  if (e2) { console.error('getAttendanceStats present:', e2); return null }
  const { count: absent, error: e3 } = await supabase
    .from('guard_checks').select('*', { count: 'exact', head: true })
    .eq('school_id', schoolId).in('result', ['UNAUTHORIZED', 'ABSENT_INACTIVE'])
    .gte('created_at', startOfDay).lte('created_at', endOfDay)
  if (e3) { console.error('getAttendanceStats absent:', e3); return null }
  const rate = totalStudents > 0 ? Math.round((present / totalStudents) * 100) : 0
  return { totalStudents, present, absent, rate }
}

/** @param {string} schoolId @param {string} [dateStr] */
export async function getAttendanceByClass(schoolId, dateStr) {
  const date = dateStr || new Date().toISOString().slice(0, 10)
  const startOfDay = date + 'T00:00:00'
  const endOfDay = date + 'T23:59:59'
  const { data: classes, error: e1 } = await supabase
    .from('classes').select('id, name, level')
    .eq('school_id', schoolId).order('level', { ascending: true })
  if (e1) { console.error('getAttendanceByClass classes:', e1); return [] }
  const results = []
  for (const cls of classes || []) {
    const { count: total, error: e2 } = await supabase
      .from('student_enrollments').select('*', { count: 'exact', head: true })
      .eq('class_id', cls.id).eq('status', 'ACTIVE')
    if (e2) continue
    const { data: presentChecks, error: e3 } = await supabase
      .from('guard_checks').select('student_id')
      .eq('school_id', schoolId).eq('result', 'AUTHORIZED')
      .gte('created_at', startOfDay).lte('created_at', endOfDay)
    if (e3) continue
    const { data: enrollments } = await supabase
      .from('student_enrollments').select('student_id')
      .eq('class_id', cls.id).eq('status', 'ACTIVE')
    const enrollmentStudentIds = new Set((enrollments || []).map(e => e.student_id))
    const present = (presentChecks || []).filter(c => enrollmentStudentIds.has(c.student_id)).length
    const { data: absentChecks, error: e4 } = await supabase
      .from('guard_checks').select('student_id')
      .eq('school_id', schoolId).in('result', ['UNAUTHORIZED', 'ABSENT_INACTIVE'])
      .gte('created_at', startOfDay).lte('created_at', endOfDay)
    if (e4) continue
    const absent = (absentChecks || []).filter(c => enrollmentStudentIds.has(c.student_id)).length
    const rate = total > 0 ? Math.round((present / total) * 100) : 0
    results.push({ classId: cls.id, className: cls.name, level: cls.level || '', total, present, absent, rate })
  }
  return results
}

/** @param {string} schoolId @param {number} [limit] */
export async function getRecentSessions(schoolId, limit = 10) {
  const { data, error } = await supabase
    .from('guard_checks')
    .select('id, result, method, created_at, students ( full_name ), student_enrollments ( classes ( name ) )')
    .eq('school_id', schoolId).order('created_at', { ascending: false }).limit(limit)
  if (error) { console.error('getRecentSessions:', error); return [] }
  return (data || []).map((row) => ({
    id: row.id,
    studentName: row.students?.full_name || '—',
    className: row.student_enrollments?.classes?.name || '—',
    result: row.result,
    method: row.method,
    time: row.created_at
  }))
}

/** @param {string} schoolId */
export async function getGradesOverview(schoolId) {
  const { data, error } = await supabase
    .from('student_grades')
    .select('grade, students ( full_name, school_id )')
    .eq('students.school_id', schoolId)
    .limit(200)
  if (error) { console.error('getGradesOverview:', error); return null }
  const rows = data || []
  const studentGrades = {}
  rows.forEach((r) => {
    const name = r.students?.full_name
    if (!name) return
    if (!studentGrades[name]) studentGrades[name] = []
    studentGrades[name].push(r.grade || 0)
  })
  const totalGrades = rows.length
  let totalSum = 0
  const studentAvgs = []
  Object.entries(studentGrades).forEach(([name, grades]) => {
    const avg = grades.reduce((a, b) => a + b, 0) / grades.length
    totalSum += avg
    studentAvgs.push({ name, avgGrade: Math.round(avg * 10) / 10 })
  })
  const avgGrade = studentAvgs.length > 0 ? Math.round((totalSum / studentAvgs.length) * 10) / 10 : 0
  const topStudents = studentAvgs.sort((a, b) => b.avgGrade - a.avgGrade).slice(0, 5)
  return { totalGrades, avgGrade, topStudents }
}
