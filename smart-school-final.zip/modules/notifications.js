// ============================================================================
// modules/notifications.js
// Notifications system — compatible with REAL Supabase schema:
//   notifications: id, school_id, title, body, created_at
//   notification_deliveries: id, notification_id, profile_id, read_at
// Uses notification_deliveries for read/unread state. No profile_id in notifications.
// ============================================================================
import { supabase } from './supabase.js'

async function getCurrentUserId() {
  const { data: { user } } = await supabase.auth.getUser()
  return user ? user.id : null
}

/** @param {string} schoolId @param {number} [limit=20] */
export async function getNotifications(schoolId, limit = 20) {
  const profileId = await getCurrentUserId()
  if (!profileId) return []

  const { data: deliveries, error: e1 } = await supabase
    .from('notification_deliveries')
    .select('notification_id, read_at')
    .eq('profile_id', profileId)

  if (e1) { console.error('getNotifications deliveries:', e1); return [] }
  if (!deliveries || deliveries.length === 0) return []

  const notifIds = deliveries.map(d => d.notification_id)
  const readMap = {}
  deliveries.forEach(d => { readMap[d.notification_id] = d.read_at })

  const { data: notifications, error: e2 } = await supabase
    .from('notifications')
    .select('id, school_id, title, body, created_at')
    .in('id', notifIds)
    .eq('school_id', schoolId)
    .order('created_at', { ascending: false })
    .limit(limit)

  if (e2) { console.error('getNotifications notifications:', e2); return [] }

  return (notifications || []).map(n => ({
    id: n.id,
    title: n.title,
    body: n.body,
    type: 'general',
    read: !!readMap[n.id],
    created_at: n.created_at,
  }))
}

/** @param {string} schoolId */
export async function getUnreadCount(schoolId) {
  const profileId = await getCurrentUserId()
  if (!profileId) return 0

  const { count, error } = await supabase
    .from('notification_deliveries')
    .select('*', { count: 'exact', head: true })
    .eq('profile_id', profileId)
    .is('read_at', null)

  if (error) { console.error('getUnreadCount:', error); return 0 }
  return count || 0
}

/** @param {string} notificationId */
export async function markAsRead(notificationId) {
  const profileId = await getCurrentUserId()
  if (!profileId) return false

  const { error } = await supabase
    .from('notification_deliveries')
    .update({ read_at: new Date().toISOString() })
    .eq('notification_id', notificationId)
    .eq('profile_id', profileId)

  if (error) { console.error('markAsRead:', error); return false }
  return true
}

/** @param {string} schoolId */
export async function markAllAsRead(schoolId) {
  const profileId = await getCurrentUserId()
  if (!profileId) return false

  const { error } = await supabase
    .from('notification_deliveries')
    .update({ read_at: new Date().toISOString() })
    .eq('profile_id', profileId)
    .is('read_at', null)

  if (error) { console.error('markAllAsRead:', error); return false }
  return true
}

/** @param {string} schoolId @param {string} title @param {string} body */
export async function sendNotification(schoolId, title, body) {
  const profileId = await getCurrentUserId()
  if (!profileId) return { ok: false, error: 'Not authenticated' }

  const { data: notif, error: e1 } = await supabase
    .from('notifications')
    .insert({ school_id: schoolId, title, body })
    .select()
    .single()

  if (e1) { console.error('sendNotification insert:', e1); return { ok: false, error: e1.message } }

  const { error: e2 } = await supabase
    .from('notification_deliveries')
    .insert({ notification_id: notif.id, profile_id: profileId })

  if (e2) { console.error('sendNotification delivery:', e2); return { ok: false, error: e2.message } }
  return { ok: true, id: notif.id }
}

/**
 * Send a notification to all users with specific roles in the same school.
 * Uses SECURITY DEFINER RPC for bulk delivery creation.
 * @param {string} schoolId
 * @param {string} title
 * @param {string} body
 * @param {string[]} targetRoles e.g. ['teacher', 'driver', 'guard', 'parent']
 */
export async function sendNotificationToRoles(schoolId, title, body, targetRoles) {
  if (!targetRoles || !Array.isArray(targetRoles) || targetRoles.length === 0) {
    return { ok: false, error: 'Target roles required' }
  }

  const { data, error } = await supabase.rpc('fn_send_notification_to_roles', {
    p_school_id: schoolId,
    p_title: title,
    p_body: body,
    p_target_roles: targetRoles,
  })

  if (error) { console.error('sendNotificationToRoles:', error); return { ok: false, error: error.message } }
  return data || { ok: false, error: 'No response' }
}
