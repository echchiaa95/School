// Smart School Management System — Service Worker
// Caches static assets only. Never caches auth/API/user data.

const STATIC_CACHE = 'smart-school-static-v1';
const STATIC_ASSETS = [
  './',
  './index.html',
  './director.html',
  './guard.html',
  './teacher.html',
  './driver.html',
  './parent.html',
  './assets/css/auth.css',
  './assets/css/dashboard.css',
  './modules/auth.js',
  './modules/supabase.js',
  './modules/students.js',
  './modules/admin.js',
  './modules/accounts.js',
  './modules/permissions.js',
  './modules/notifications.js',
  './modules/attendance-admin.js',
  './modules/device.js',
  './modules/qrScanner.js',
  'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.js'
];

// Install: cache static assets
self.addEventListener('install', function (event) {
  event.waitUntil(
    caches.open(STATIC_CACHE).then(function (cache) {
      return cache.addAll(STATIC_ASSETS);
    }).catch(function () {
      // Silent fail for individual assets
    })
  );
  self.skipWaiting();
});

// Activate: clean old caches
self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(
        keys.filter(function (key) { return key !== STATIC_CACHE; })
            .map(function (key) { return caches.delete(key); })
      );
    })
  );
  self.clients.claim();
});

// Fetch: network-first for HTML, cache-first for static assets, bypass for API/auth
self.addEventListener('fetch', function (event) {
  const url = new URL(event.request.url);
  const req = event.request;

  // NEVER cache Supabase / auth / API / dynamic data
  if (
    url.hostname.includes('supabase.co') ||
    url.hostname.includes('supabase.in') ||
    url.pathname.includes('/auth/') ||
    url.pathname.includes('/rest/v1/') ||
    url.pathname.includes('/storage/v1/') ||
    req.method !== 'GET'
  ) {
    return; // Let browser handle it normally
  }

  // Network-first for HTML pages
  if (req.headers.get('accept') && req.headers.get('accept').includes('text/html')) {
    event.respondWith(
      fetch(req).catch(function () {
        return caches.match(req).then(function (res) {
          return res || caches.match('./index.html');
        });
      })
    );
    return;
  }

  // Cache-first for static assets (CSS, JS, fonts)
  event.respondWith(
    caches.match(req).then(function (cached) {
      if (cached) return cached;
      return fetch(req).then(function (networkRes) {
        if (!networkRes || networkRes.status !== 200 || networkRes.type !== 'basic') {
          return networkRes;
        }
        const clone = networkRes.clone();
        caches.open(STATIC_CACHE).then(function (cache) {
          cache.put(req, clone);
        });
        return networkRes;
      }).catch(function () {
        return cached;
      });
    })
  );
});