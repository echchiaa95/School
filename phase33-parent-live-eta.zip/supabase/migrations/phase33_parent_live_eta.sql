-- ============================================================================
-- PHASE 33 — ETA حي لولي الأمر (ميزة تنافسية جديدة، ليست في المستند الأصلي)
-- Purely additive: one new function, no DROP TABLE/TRUNCATE, no changes to
-- any existing table or function.
--
-- Design (no routing engine / no external API in this stack — vanilla
-- JS + Supabase only): straight-line (haversine) distance from the bus's
-- last known GPS point to the RELEVANT target for this child right now:
--   - trip going TO_HOME (afternoon)            -> child's dropoff stop
--   - trip going TO_SCHOOL (morning), not yet
--     boarded                                    -> child's pickup stop
--   - trip going TO_SCHOOL, already boarded      -> the school itself
--     (the child is already on the bus; what matters now is arrival time
--     at school, not the pickup stop behind them)
-- Speed used for the estimate: the bus's current reported speed if it's
-- actually moving (>5 km/h, filters out GPS noise while stopped at a
-- light/stop); otherwise a sane fallback urban-with-stops average
-- (18 km/h), clamped to a reasonable driving range. A 1.3x factor is
-- applied to the straight-line distance because real streets are never
-- perfectly straight — this is a labeled ESTIMATE, not a routed ETA.
-- ============================================================================
create or replace function fn_get_child_bus_eta(p_student_id uuid)
returns table(
  has_active_trip boolean,
  direction text,
  target_label text,
  is_boarded boolean,
  is_dropped boolean,
  bus_latitude double precision, bus_longitude double precision,
  target_latitude double precision, target_longitude double precision,
  distance_km numeric,
  eta_minutes int,
  speed_kmh numeric,
  recorded_at timestamptz,
  is_stale boolean
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_sta record;
  v_trip record;
  v_bts record;
  v_school record;
  v_ll record;
  v_target_lat double precision;
  v_target_lng double precision;
  v_target_label text;
  v_dist_km numeric;
  v_speed_kmh numeric;
  v_earth_radius_km constant numeric := 6371;
begin
  if not fn_is_parent_of(p_student_id) then
    raise exception 'PERMISSION_DENIED';
  end if;

  -- Current active transport assignment for this child (current academic year only).
  select sta.bus_id, sta.pickup_stop_id, sta.dropoff_stop_id, sta.route_id
    into v_sta
  from student_transport_assignments sta
  join academic_years ay on ay.id = sta.academic_year_id and ay.is_current = true
  where sta.student_id = p_student_id and sta.is_active = true
  limit 1;

  if v_sta.bus_id is null then
    return query select false, null::text, null::text, null::boolean, null::boolean,
      null::double precision, null::double precision, null::double precision, null::double precision,
      null::numeric, null::int, null::numeric, null::timestamptz, null::boolean;
    return;
  end if;

  select t.id as trip_id, t.direction, t.school_id
    into v_trip
  from bus_trips t
  where t.bus_id = v_sta.bus_id and t.status = 'ACTIVE'::trip_status
  order by t.starts_at desc
  limit 1;

  if v_trip.trip_id is null then
    return query select false, null::text, null::text, null::boolean, null::boolean,
      null::double precision, null::double precision, null::double precision, null::double precision,
      null::numeric, null::int, null::numeric, null::timestamptz, null::boolean;
    return;
  end if;

  select bts.boarded_at, bts.dropped_at into v_bts
  from bus_trip_students bts
  where bts.trip_id = v_trip.trip_id and bts.student_id = p_student_id;

  select s.name, s.latitude, s.longitude into v_school from schools s where s.id = v_trip.school_id;

  if v_trip.direction = 'TO_HOME'::trip_direction then
    select bs.name, bs.latitude, bs.longitude into v_target_label, v_target_lat, v_target_lng
    from bus_stops bs where bs.id = v_sta.dropoff_stop_id;
  else -- TO_SCHOOL
    if v_bts.boarded_at is not null then
      v_target_label := coalesce(v_school.name, 'المؤسسة');
      v_target_lat := v_school.latitude; v_target_lng := v_school.longitude;
    else
      select bs.name, bs.latitude, bs.longitude into v_target_label, v_target_lat, v_target_lng
      from bus_stops bs where bs.id = v_sta.pickup_stop_id;
    end if;
  end if;

  -- No usable stop/school coordinates saved -> we cannot estimate anything;
  -- say so honestly instead of guessing.
  if v_target_lat is null or v_target_lng is null then
    return query select true, (case when v_trip.direction = 'TO_HOME'::trip_direction then 'dropoff' else 'pickup' end),
      v_target_label, (v_bts.boarded_at is not null), (v_bts.dropped_at is not null),
      null::double precision, null::double precision, v_target_lat, v_target_lng,
      null::numeric, null::int, null::numeric, null::timestamptz, null::boolean;
    return;
  end if;

  select ll.latitude, ll.longitude, ll.speed, ll.recorded_at into v_ll
  from bus_last_locations ll where ll.bus_id = v_sta.bus_id;

  if v_ll.latitude is null or v_ll.longitude is null then
    return query select true, (case when v_trip.direction = 'TO_HOME'::trip_direction then 'dropoff' else 'pickup' end),
      v_target_label, (v_bts.boarded_at is not null), (v_bts.dropped_at is not null),
      null::double precision, null::double precision, v_target_lat, v_target_lng,
      null::numeric, null::int, null::numeric, null::timestamptz, null::boolean;
    return;
  end if;

  -- Haversine distance (km) — no PostGIS/earthdistance extension needed.
  v_dist_km := v_earth_radius_km * 2 * asin(sqrt(
    sin(radians(v_target_lat - v_ll.latitude) / 2) ^ 2 +
    cos(radians(v_ll.latitude)) * cos(radians(v_target_lat)) *
    sin(radians(v_target_lng - v_ll.longitude) / 2) ^ 2
  ));

  -- speed column is stored in m/s (consistent with the existing live-map
  -- popup, which already does `speed * 3.6` for display) -> km/h.
  v_speed_kmh := coalesce(v_ll.speed, 0) * 3.6;
  if v_speed_kmh < 5 then v_speed_kmh := 18; end if; -- stopped/noise -> urban fallback
  v_speed_kmh := least(greatest(v_speed_kmh, 8), 60); -- sane driving range

  return query select
    true,
    (case when v_trip.direction = 'TO_HOME'::trip_direction then 'dropoff' else 'pickup' end),
    v_target_label,
    (v_bts.boarded_at is not null), (v_bts.dropped_at is not null),
    v_ll.latitude, v_ll.longitude, v_target_lat, v_target_lng,
    round(v_dist_km::numeric, 2),
    ceil(((v_dist_km * 1.3) / v_speed_kmh) * 60)::int,
    round(v_speed_kmh, 1),
    v_ll.recorded_at,
    (v_ll.recorded_at is null or now() - v_ll.recorded_at > interval '90 seconds');
end;
$$;
revoke all on function fn_get_child_bus_eta(uuid) from public;
grant execute on function fn_get_child_bus_eta(uuid) to authenticated;
