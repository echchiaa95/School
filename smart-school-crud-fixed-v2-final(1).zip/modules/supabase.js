// ============================================================================
// modules/supabase.js
// One Supabase client for the whole app.
//
// Only the public project URL and anon key belong here. Real protection comes
// from Supabase Auth, PostgreSQL RLS, and server-side RPC/Edge Functions.
// ============================================================================

const SUPABASE_URL = 'https://catyxewgmghtxmlvnuip.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_unggS_0GPLieFylpCN6-PA_LE9nFDu2';

export const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});
