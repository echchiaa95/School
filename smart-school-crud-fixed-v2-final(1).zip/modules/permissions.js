// ============================================================================
// modules/permissions.js
// Client-side role routing and UI permission gating.
//
// This module grants no database access by itself. Real authorization remains
// in Supabase/Postgres (RLS, policies, and RPC functions). The role used here
// is always the role already loaded from user_roles by modules/auth.js.
// ============================================================================

export const ROLES = Object.freeze({
  SUPERADMIN: 'superadmin',
  ADMIN: 'admin',
  DIRECTOR: 'director',
  GUARD: 'guard',
  TEACHER: 'teacher',
  DRIVER: 'driver',
  PARENT: 'parent',
});

const ROLE_HOME_PAGE = Object.freeze({
  [ROLES.SUPERADMIN]: 'superadmin.html',
  [ROLES.ADMIN]: 'admin.html',
  [ROLES.DIRECTOR]: 'director.html',
  [ROLES.GUARD]: 'guard.html',
  [ROLES.TEACHER]: 'teacher.html',
  [ROLES.DRIVER]: 'driver.html',
  [ROLES.PARENT]: 'parent.html',
});

const PAGE_ALLOWED_ROLES = Object.freeze({
  'superadmin.html': [ROLES.SUPERADMIN],
  'admin.html': [ROLES.ADMIN],
  'director.html': [ROLES.DIRECTOR],
  'guard.html': [ROLES.GUARD],
  'teacher.html': [ROLES.TEACHER],
  'driver.html': [ROLES.DRIVER],
  'parent.html': [ROLES.PARENT],
});

export const ROLE_PRIORITY = Object.freeze([
  ROLES.SUPERADMIN,
  ROLES.ADMIN,
  ROLES.DIRECTOR,
  ROLES.GUARD,
  ROLES.TEACHER,
  ROLES.DRIVER,
  ROLES.PARENT,
]);

const GUARD_CONSOLE_PERMISSIONS = Object.freeze([
  'students.view',
  'students.create',
  'students.badge.view',
  'students.badge.issue',
  'students.badge.reissue',
  'students.badge.suspend',
  'classes.view',
  'teachers.view',
  'teachers.create',
  'drivers.view',
  'drivers.create',
  'parents.view',
  'parents.create',
]);

const ROLE_PERMISSIONS = Object.freeze({
  [ROLES.SUPERADMIN]: GUARD_CONSOLE_PERMISSIONS,
  [ROLES.ADMIN]: GUARD_CONSOLE_PERMISSIONS,
  [ROLES.DIRECTOR]: GUARD_CONSOLE_PERMISSIONS,
  [ROLES.GUARD]: GUARD_CONSOLE_PERMISSIONS,
  [ROLES.TEACHER]: [],
  [ROLES.DRIVER]: [],
  [ROLES.PARENT]: [],
});

let currentPermissionKeys = new Set();

export function homePageForRole(role) {
  return ROLE_HOME_PAGE[role] ?? null;
}

export function isRoleAllowedOnPage(role, pageFileName) {
  const allowed = PAGE_ALLOWED_ROLES[pageFileName];
  return Array.isArray(allowed) && allowed.includes(role);
}

export function pickPrimaryRole(roleRows) {
  if (!Array.isArray(roleRows) || roleRows.length === 0) return null;

  for (const role of ROLE_PRIORITY) {
    const match = roleRows.find((row) => row?.role === role && row?.school_id);
    if (match) return match;
  }
  return null;
}

/**
 * Initialize UI permissions from the authenticated role. No unavailable RPC or
 * permission table is called. Server-side authorization still happens in the
 * database for every actual read/write operation.
 */
export async function loadMyPermissions(role) {
  currentPermissionKeys = new Set(ROLE_PERMISSIONS[role] ?? []);
  return new Set(currentPermissionKeys);
}

export function hasPermission(permissionKey) {
  return currentPermissionKeys.has(permissionKey);
}

export function clearPermissions() {
  currentPermissionKeys = new Set();
}
