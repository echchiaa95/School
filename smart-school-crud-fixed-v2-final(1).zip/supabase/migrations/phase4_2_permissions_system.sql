-- ============================================================================
-- supabase/migrations/phase4_2_permissions_system.sql
-- Role-based permission enforcement for guard operations.
--
-- This migration intentionally uses user_roles as the authorization source.
-- It creates only the permission catalog needed by the existing UI, then
-- defines role-based guards for the existing student/badge RPC wrappers.
-- No data is dropped, deleted, or truncated.
-- ============================================================================

alter type app_role add value if not exists 'superadmin';

create table if not exists permissions (
  id uuid primary key default gen_random_uuid(),
  permission_key text not null unique,
  module text not null,
  name text not null,
  description text,
  created_at timestamptz not null default now()
);

alter table permissions enable row level security;

do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'public'
      and tablename = 'permissions'
      and policyname = 'p_permissions_read'
  ) then
    create policy p_permissions_read on permissions
      for select using (auth.uid() is not null);
  end if;
end $$;

insert into permissions (permission_key, module, name) values
  ('students.view',          'students',   'عرض التلاميذ'),
  ('students.create',        'students',   'إضافة تلميذ'),
  ('students.update',        'students',   'تعديل تلميذ'),
  ('students.badge.view',    'students',   'عرض البادج'),
  ('students.badge.issue',   'students',   'إصدار بادج'),
  ('students.badge.reissue', 'students',   'إعادة إصدار بادج'),
  ('students.badge.suspend', 'students',   'تعليق بادج'),
  ('attendance.view',        'attendance', 'عرض الحضور'),
  ('attendance.manage',      'attendance', 'إدارة الحضور'),
  ('classes.view',           'classes',    'عرض الأقسام'),
  ('classes.manage',         'classes',    'إدارة الأقسام'),
  ('teachers.view',          'teachers',   'عرض الأساتذة'),
  ('teachers.create',        'teachers',   'إضافة أستاذ'),
  ('teachers.update',        'teachers',   'تعديل أستاذ'),
  ('drivers.view',           'drivers',    'عرض السائقين'),
  ('drivers.create',         'drivers',    'إضافة سائق'),
  ('drivers.update',         'drivers',    'تعديل سائق'),
  ('parents.view',           'parents',    'عرض أولياء الأمور'),
  ('parents.create',         'parents',    'إضافة ولي أمر'),
  ('parents.update',         'parents',    'تعديل ولي أمر'),
  ('transport.view',         'transport',  'عرض النقل'),
  ('transport.manage',       'transport',  'إدارة النقل'),
  ('payments.view',          'payments',   'عرض المدفوعات'),
  ('payments.manage',        'payments',   'إدارة المدفوعات'),
  ('audit.view',             'audit',      'عرض السجل')
on conflict (permission_key) do nothing;

create or replace function fn_resolve_my_role(p_school_id uuid)
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role::text
  from user_roles
  where profile_id = auth.uid()
    and school_id = p_school_id
  order by case role::text
    when 'superadmin' then 0
    when 'admin'      then 1
    when 'director'   then 2
    when 'guard'      then 3
    when 'teacher'    then 4
    when 'driver'     then 5
    when 'parent'     then 6
    else 7
  end
  limit 1;
$$;

revoke all on function fn_resolve_my_role(uuid) from public;
grant execute on function fn_resolve_my_role(uuid) to authenticated;

create or replace function fn_has_permission(p_permission_key text, p_school_id uuid)
returns boolean
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_role text;
begin
  if exists (
    select 1 from user_roles
    where profile_id = auth.uid()
      and role::text = 'superadmin'
  ) then
    return true;
  end if;

  v_role := fn_resolve_my_role(p_school_id);
  return v_role in ('admin', 'director', 'guard');
end;
$$;

revoke all on function fn_has_permission(text, uuid) from public;
grant execute on function fn_has_permission(text, uuid) to authenticated;

create or replace function fn_guard_register_student(
  p_full_name text,
  p_student_number text,
  p_class_id uuid,
  p_academic_year_id uuid,
  p_birth_date date default null,
  p_gender text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
begin
  select school_id into v_school_id
  from classes
  where id = p_class_id;

  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;

  if not exists (
    select 1 from academic_years
    where id = p_academic_year_id
      and school_id = v_school_id
  ) then
    raise exception 'ACADEMIC_YEAR_SCHOOL_MISMATCH';
  end if;

  v_role := fn_resolve_my_role(v_school_id);
  if v_role is null then
    raise exception 'PERMISSION_DENIED: no role in this school';
  end if;
  if v_role not in ('admin', 'director')
     and not fn_has_permission('students.create', v_school_id) then
    raise exception 'PERMISSION_DENIED: missing students.create';
  end if;

  return fn_register_student(
    v_school_id,
    p_full_name,
    p_student_number,
    p_class_id,
    p_academic_year_id,
    p_birth_date,
    p_gender
  );
end;
$$;

revoke all on function fn_guard_register_student(text, text, uuid, uuid, date, text) from public;
grant execute on function fn_guard_register_student(text, text, uuid, uuid, date, text) to authenticated;

create or replace function fn_guard_issue_badge(p_student_id uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
begin
  v_school_id := fn_student_school(p_student_id);
  if v_school_id is null then
    raise exception 'INVALID_STUDENT';
  end if;

  v_role := fn_resolve_my_role(v_school_id);
  if v_role is null then
    raise exception 'PERMISSION_DENIED: no role in this school';
  end if;
  if v_role not in ('admin', 'director')
     and not fn_has_permission('students.badge.issue', v_school_id) then
    raise exception 'PERMISSION_DENIED: missing students.badge.issue';
  end if;

  return fn_issue_badge(p_student_id);
end;
$$;

revoke all on function fn_guard_issue_badge(uuid) from public;
grant execute on function fn_guard_issue_badge(uuid) to authenticated;

create or replace function fn_guard_reissue_badge(p_student_id uuid, p_reason text default null)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
begin
  v_school_id := fn_student_school(p_student_id);
  if v_school_id is null then
    raise exception 'INVALID_STUDENT';
  end if;

  v_role := fn_resolve_my_role(v_school_id);
  if v_role is null then
    raise exception 'PERMISSION_DENIED: no role in this school';
  end if;
  if v_role not in ('admin', 'director')
     and not fn_has_permission('students.badge.reissue', v_school_id) then
    raise exception 'PERMISSION_DENIED: missing students.badge.reissue';
  end if;

  return fn_reissue_badge(p_student_id, p_reason);
end;
$$;

revoke all on function fn_guard_reissue_badge(uuid, text) from public;
grant execute on function fn_guard_reissue_badge(uuid, text) to authenticated;

create or replace function fn_guard_suspend_badge(
  p_badge_id uuid,
  p_new_status badge_status,
  p_reason text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_student_id uuid;
  v_school_id uuid;
  v_role text;
begin
  select student_id into v_student_id
  from student_badges
  where id = p_badge_id;

  v_school_id := fn_student_school(v_student_id);
  if v_school_id is null then
    raise exception 'INVALID_BADGE';
  end if;

  v_role := fn_resolve_my_role(v_school_id);
  if v_role is null then
    raise exception 'PERMISSION_DENIED: no role in this school';
  end if;
  if v_role not in ('admin', 'director')
     and not fn_has_permission('students.badge.suspend', v_school_id) then
    raise exception 'PERMISSION_DENIED: missing students.badge.suspend';
  end if;

  perform fn_suspend_badge(p_badge_id, p_new_status, p_reason);
end;
$$;

revoke all on function fn_guard_suspend_badge(uuid, badge_status, text) from public;
grant execute on function fn_guard_suspend_badge(uuid, badge_status, text) to authenticated;

-- ============================================================================
-- END OF PHASE 4.2 MIGRATION
-- ============================================================================
