-- ============================================================================
-- supabase/migrations/phase11_school_creation.sql
-- PHASE 11 — Guaranteed school-creation RPC.
--
-- WHY THIS FILE EXISTS: fn_create_school was defined in Phase 8 but is NOT
-- present in the current production database. This migration re-creates it
-- as a standalone, self-contained RPC so school creation works regardless
-- of whether Phase 8 was ever applied (create or replace is idempotent).
--
-- SAFETY: purely additive/idempotent. No DROP TABLE, no DROP COLUMN, no
-- DELETE, no TRUNCATE, no data modification of existing rows. No existing
-- RLS policy or function other than fn_create_school itself is touched.
--
-- SECURITY:
--   - SECURITY DEFINER, search_path pinned to public.
--   - Server-side superadmin check via auth.uid() -> user_roles (inline,
--     no dependency on fn_is_superadmin existing).
--   - Empty names rejected.
--   - Audit logging uses the existing fn_write_audit, wrapped in its own
--     exception block so a logging hiccup can never block school creation.
--   - execute granted to authenticated only; the function itself rejects
--     anyone without the superadmin role.
-- ============================================================================

create or replace function fn_create_school(p_name text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  -- 1. Must be authenticated.
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  -- 2. Must hold the superadmin role (checked server-side, inline — no
  --    reliance on any helper function being deployed).
  if not exists (
    select 1 from user_roles
    where profile_id = auth.uid()
      and role::text = 'superadmin'
  ) then
    raise exception 'PERMISSION_DENIED';
  end if;

  -- 3. Name required.
  if p_name is null or trim(p_name) = '' then
    raise exception 'SCHOOL_NAME_REQUIRED';
  end if;

  -- 4. Create the school (real schema: schools.id, schools.name).
  insert into schools (name)
  values (trim(p_name))
  returning id into v_school_id;

  -- 5. Audit — best effort: logging failure must never roll back the
  --    school the user just created.
  begin
    perform fn_write_audit(
      v_school_id,
      'CREATE_SCHOOL',
      'schools',
      v_school_id,
      null,
      jsonb_build_object('name', trim(p_name))
    );
  exception when others then
    -- Intentionally swallowed: audit is diagnostic, not transactional.
    raise notice 'fn_create_school: audit logging skipped (%).', sqlerrm;
  end;

  return v_school_id;
end;
$$;

revoke all on function fn_create_school(text) from public;
grant execute on function fn_create_school(text) to authenticated;

-- ============================================================================
-- END OF PHASE 11 SCHOOL CREATION MIGRATION
-- ============================================================================
