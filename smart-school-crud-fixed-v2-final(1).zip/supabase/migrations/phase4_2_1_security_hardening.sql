-- ============================================================================
-- supabase/migrations/phase4_2_1_security_hardening.sql
-- Re-affirms the role-based permission check without adding any table.
-- The complete wrapper definitions live in phase4_2_permissions_system.sql.
-- ============================================================================

create or replace function fn_has_permission(p_permission_key text, p_school_id uuid)
returns boolean
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_role text;
begin
  if exists (
    select 1 from user_roles
    where profile_id = auth.uid()
      and role::text = 'superadmin'
  ) then
    return true;
  end if;

  select role::text into v_role
  from user_roles
  where profile_id = auth.uid()
    and school_id = p_school_id
  order by case role::text
    when 'superadmin' then 0
    when 'admin'      then 1
    when 'director'   then 2
    when 'guard'      then 3
    when 'teacher'    then 4
    when 'driver'     then 5
    when 'parent'     then 6
    else 7
  end
  limit 1;

  return v_role in ('admin', 'director', 'guard');
end;
$$;

revoke all on function fn_has_permission(text, uuid) from public;
grant execute on function fn_has_permission(text, uuid) to authenticated;

-- No data is inserted, updated, deleted, dropped, or truncated here.
