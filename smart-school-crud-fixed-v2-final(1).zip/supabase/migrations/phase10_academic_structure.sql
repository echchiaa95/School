-- ============================================================================
-- supabase/migrations/phase10_academic_structure.sql
-- PHASE 10 — Academic structure creation: academic years + classes.
--
-- SAFETY: purely additive. No DROP, no TRUNCATE, no DELETE, no data
-- modification of existing rows. No existing table, RLS policy, or function
-- is altered. Only two new SECURITY DEFINER RPCs are created.
--
-- AUTHORIZATION MODEL (same as the rest of the system):
--   - Identity always comes from auth.uid() -> user_roles, never from the
--     client.
--   - superadmin may create years/classes for ANY school (platform role).
--   - admin/director may create them ONLY inside their own school
--     (fn_resolve_my_role confirms the caller's role in that school).
--   - fn_create_class derives school_id from the academic_years row itself,
--     so a class can never be attached to a year of another school.
--
-- SCHEMA ASSUMPTIONS (columns already used by the app/migrations):
--   academic_years: id, school_id, name, is_current
--   classes:        id, school_id, academic_year_id, name, level
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. fn_create_academic_year — create an academic year for a school.
--    p_school_id is validated server-side: non-superadmin callers must hold
--    an admin/director role IN THAT SCHOOL; the value is never trusted
--    blindly.
-- ----------------------------------------------------------------------------
create or replace function fn_create_academic_year(
  p_school_id uuid,
  p_name text,
  p_is_current boolean default false
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_year_id uuid;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  if p_school_id is null then
    raise exception 'INVALID_SCHOOL';
  end if;

  if p_name is null or trim(p_name) = '' then
    raise exception 'YEAR_NAME_REQUIRED';
  end if;

  if not exists (select 1 from schools where id = p_school_id) then
    raise exception 'INVALID_SCHOOL';
  end if;

  -- superadmin (platform) OR admin/director of THIS school
  if not fn_is_superadmin()
     and coalesce(fn_resolve_my_role(p_school_id), '') not in ('admin', 'director') then
    raise exception 'PERMISSION_DENIED';
  end if;

  -- A school has at most one current year: unmark the others first.
  if p_is_current then
    update academic_years
    set is_current = false
    where school_id = p_school_id and is_current = true;
  end if;

  insert into academic_years (school_id, name, is_current)
  values (p_school_id, trim(p_name), coalesce(p_is_current, false))
  returning id into v_year_id;

  return v_year_id;
end;
$$;

revoke all on function fn_create_academic_year(uuid, text, boolean) from public;
grant execute on function fn_create_academic_year(uuid, text, boolean) to authenticated;

-- ----------------------------------------------------------------------------
-- 2. fn_create_class — create a class/section under an academic year.
--    school_id is DERIVED from the academic_years row (never supplied by the
--    client), guaranteeing the class belongs to the same school as its year.
-- ----------------------------------------------------------------------------
create or replace function fn_create_class(
  p_academic_year_id uuid,
  p_name text,
  p_level text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_class_id uuid;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select school_id into v_school_id
  from academic_years
  where id = p_academic_year_id;

  if v_school_id is null then
    raise exception 'INVALID_ACADEMIC_YEAR';
  end if;

  if p_name is null or trim(p_name) = '' then
    raise exception 'CLASS_NAME_REQUIRED';
  end if;

  -- superadmin (platform) OR admin/director of the year's school
  if not fn_is_superadmin()
     and coalesce(fn_resolve_my_role(v_school_id), '') not in ('admin', 'director') then
    raise exception 'PERMISSION_DENIED';
  end if;

  insert into classes (school_id, academic_year_id, name, level)
  values (v_school_id, p_academic_year_id, trim(p_name), nullif(trim(coalesce(p_level, '')), ''))
  returning id into v_class_id;

  return v_class_id;
end;
$$;

revoke all on function fn_create_class(uuid, text, text) from public;
grant execute on function fn_create_class(uuid, text, text) to authenticated;

-- ============================================================================
-- END OF PHASE 10 ACADEMIC STRUCTURE MIGRATION
-- ============================================================================
