# Smart School V27

This package is the V26 runtime plus the V27 admin fixes.

Run once:
`supabase/migrations/phase37_admin_map_photo_audit.sql`

Then deploy the web files and test:
1. Admin > Tracking > previous trip: green boarding points and red drop-off points.
2. Student profile: choose a large phone image; it is resized/compressed automatically before upload.
3. Admin > Institution operation log: responsive aligned layout.

Do not rerun previous phases unnecessarily. Do not change timezone/time settings.
