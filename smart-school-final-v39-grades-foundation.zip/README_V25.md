# Smart School V25

Deploy the frontend files. Then run Phase35 once on the correct Smart School Supabase project.

Phase35 is MUTATING: it replaces two RPC definitions and grants execute to authenticated; it does not change time/timezone or delete data.
