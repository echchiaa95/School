# Smart School V25 — Admin Complete Runtime Fixes

- Fixed teacher schedule RPC 42702 `id is ambiguous` with SQL-language function.
- Teacher detail now shows actual lesson times and calculates weekly hours from starts_at/ends_at.
- Added + button in every empty timetable cell to add a lesson directly into that day/period.
- Kept edit/delete controls visible in the interactive timetable; print/PDF views remain clean.
- Improved previous-trip history: bus history now supports an explicit date filter and uses the school-wide trip RPC, then draws real GPS history for the selected trip.
- Added receipt print/save-as-PDF actions for student payments and teacher payroll payments.
- Added explicit student photo gallery/device and camera options (retained).
- Bumped frontend cache version to v31.
- No timezone/time changes and no data deletion.

Database: run `supabase/migrations/phase35_admin_schedule_history_receipts.sql` once.
