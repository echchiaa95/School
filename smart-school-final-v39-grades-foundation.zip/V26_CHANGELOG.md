# V26 — Admin Teacher / History / PDF Fix

- Adds Phase36 stable admin teacher schedule RPC with unambiguous output names.
- Admin teacher detail now reads scheduled timetable entries from fn_admin_get_teacher_schedule.
- Historical trip route RPC is explicitly school-scoped and returns only real stored GPS points.
- Historical trip UI filters invalid points and explains when the selected trip has no stored GPS history.
- PDF export hides edit/delete/add controls explicitly during html2canvas capture.
- Cache versions bumped to prevent mixed old/new admin modules.
- No timezone/time changes and no data deletion.
