# Smart School v23 — Admin Runtime Cleanup

- Fixed Admin schedule crash: declared `scEditingEntryId`.
- Added class schedule preview directly under the Years & Classes list: click a class name to show its weekly timetable with Print / PDF download.
- Driver passenger ordering now re-renders from persisted server order after save, keeping ↑/↓ controls visible.
- Notifications now show clear RPC errors instead of silently appearing empty, and use Arabic type labels.
- Audit log: backfills missing `actor_id` from existing `user_id`, future audit writes set both, and the school audit reader falls back to `user_id`.
- Tightened anonymous execute access on the admin school-location RPC.
- Frontend cache bumped to v29.
- No timezone/time changes. No Phase 29/30/31 rerun.
