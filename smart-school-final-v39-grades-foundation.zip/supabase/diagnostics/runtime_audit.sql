-- SMART SCHOOL — RUNTIME AUDIT (READ-ONLY)
-- Purpose: diagnose the remaining production RPC failures seen in v13.
-- This script does NOT create/replace/drop/update anything.
-- Run in Supabase SQL Editor on the production project.

-- 1) Exact signatures + grants for the affected RPCs.
select
  p.oid::regprocedure as function_signature,
  pg_get_function_result(p.oid) as return_type,
  pg_get_function_identity_arguments(p.oid) as identity_arguments,
  coalesce(array_to_string(p.proacl, ', '), '(default privileges)') as acl
from pg_proc p
where p.pronamespace = 'public'::regnamespace
  and p.proname in (
    'fn_get_class_attendance', 'fn_save_attendance',
    'fn_get_student_badge', 'fn_guard_reissue_badge',
    'fn_record_trip_event', 'fn_end_trip',
    'fn_get_map_overview', 'fn_update_school_location',
    'fn_list_bus_students_ordered', 'fn_list_school_trips'
  )
order by p.proname, p.oid::regprocedure::text;

-- 2) Required columns that can make badge/location operations fail at runtime.
select table_name, column_name, data_type, is_nullable, column_default
from information_schema.columns
where table_schema = 'public'
  and (
    (table_name = 'student_badges') or
    (table_name = 'schools' and column_name in ('latitude','longitude','location_label')) or
    (table_name = 'attendance_records') or
    (table_name = 'bus_trip_students')
  )
order by table_name, ordinal_position;

-- 3) Constraints/indexes on student_badges — especially uniqueness that could
-- make reissue fail after replacing the active badge.
select
  n.nspname as schema_name,
  c.relname as table_name,
  i.relname as index_name,
  ix.indisunique,
  pg_get_indexdef(ix.indexrelid) as index_definition
from pg_index ix
join pg_class c on c.oid = ix.indrelid
join pg_class i on i.oid = ix.indexrelid
join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public'
  and c.relname = 'student_badges'
order by i.relname;

-- 4) Triggers on tables involved in the failing flows.
select
  event_object_table,
  trigger_name,
  action_timing,
  event_manipulation,
  action_statement
from information_schema.triggers
where event_object_schema = 'public'
  and event_object_table in ('student_badges','schools','attendance_records','bus_trip_students')
order by event_object_table, trigger_name, event_manipulation;

-- 5) Function definitions for the exact production objects.
select
  p.oid::regprocedure as function_signature,
  pg_get_functiondef(p.oid) as definition
from pg_proc p
where p.pronamespace = 'public'::regnamespace
  and p.proname in (
    'fn_get_class_attendance', 'fn_save_attendance',
    'fn_get_student_badge', 'fn_guard_reissue_badge',
    'fn_record_trip_event', 'fn_end_trip',
    'fn_get_map_overview', 'fn_update_school_location',
    'fn_list_bus_students_ordered', 'fn_list_school_trips'
  )
order by p.proname, p.oid::regprocedure::text;
