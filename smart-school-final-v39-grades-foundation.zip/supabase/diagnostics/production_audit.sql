-- ============================================================================
-- PRODUCTION AUDIT — Smart School (v13 fixes)
-- READ-ONLY diagnostic script. Run in the Supabase SQL editor (or psql) as a
-- privileged read role. It contains ONLY SELECTs against system catalogs.
-- It NEVER modifies data, schema, functions, policies, grants or enums.
--
-- Purpose: compare the ACTUAL state of the production database against the
-- migrations shipped in this repo (phase12 … phase28). A migration file
-- existing in the ZIP does NOT mean it was applied to production — phase18
-- documents a history of partially-applied migrations on the live project.
--
-- How to read the output: every section is independent; run the whole file,
-- then compare with the "EXPECTED" notes in each section header.
-- ============================================================================

select now() as audited_at, current_database() as database, current_user as run_as;

-- ============================================================================
-- SECTION 1 — RPC inventory (all project functions)
-- EXPECTED: every fn_* used by the frontend exists EXACTLY ONCE with the
-- signature quoted in modules/school.js. Duplicated names = conflicting
-- overloads = runtime "could not choose the best candidate function" errors.
-- ============================================================================
select p.proname as function_name,
       pg_get_function_identity_arguments(p.oid) as identity_args,
       pg_get_function_result(p.oid) as return_type,
       p.prokind as kind,                       -- f = function
       p.prosecdef as security_definer,
       pg_get_userbyid(p.proowner) as owner
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname like 'fn\_%'
order by p.proname, identity_args;

-- Duplicate/overloaded names (more than one live version of the same RPC):
select proname, count(*) as live_versions,
       string_agg(pg_get_function_identity_arguments(p.oid), ' | ') as signatures
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and proname like 'fn\_%'
group by proname having count(*) > 1
order by live_versions desc, proname;

-- ============================================================================
-- SECTION 2 — TARGETED CHECKLIST (the bugs we fixed / features we added)
-- EXPECTED values come from the repo migrations:
--   A. fn_get_map_overview()        → identity_args EMPTY (phase25). If it
--      shows (p_school_id uuid) the DB still runs an older/newer overload.
--   B. fn_update_school_location    → EXISTS (phase20; defined there ONLY).
--   C. fn_record_trip_event         → (p_trip_id uuid, p_student_id uuid,
--      p_event_type text). body must reference 'DROP_OFF' and 'dropped_at'.
--   D. fn_get_class_attendance      → body must reference 'teacher_classes'
--      (phase27 assigned-teacher authorization). If absent → old phase12
--      version → teachers get PERMISSION_DENIED.
--   E. fn_list_bus_students_ordered → 13 return columns incl. photo_url
--      (phase20). If 12 columns (no photo_url) → the phase19 version is
--      still live (phase20's CREATE OR REPLACE failed on return-type change).
--   F. fn_list_school_trips         → EXISTS with 5 args (phase28). If
--      missing → the trip-history map section cannot load.
--   G. fn_guard_issue_badge / fn_guard_reissue_badge / fn_guard_suspend_badge
--      → exist (phase18; same signatures also in phase4_2 — latest wins).
--   H. fn_get_student_badge         → returns TABLE(id, status, secure_token,
--      created_at) (phase25 supersedes phase19 with same signature).
-- ============================================================================
with target as (
  select * from (values
    ('fn_get_map_overview'),
    ('fn_update_school_location'),
    ('fn_record_trip_event'),
    ('fn_get_student_badge'),
    ('fn_guard_issue_badge'),
    ('fn_guard_reissue_badge'),
    ('fn_guard_suspend_badge'),
    ('fn_list_bus_students_ordered'),
    ('fn_list_bus_trips'),
    ('fn_get_trip_route_history'),
    ('fn_child_payments'),
    ('fn_get_class_attendance'),
    ('fn_save_attendance'),
    ('fn_teacher_classes'),
    ('fn_teacher_class_roster'),
    ('fn_list_school_trips')
  ) as v(proname)
)
select t.proname,
       count(p.oid) as live_versions,
       string_agg(pg_get_function_identity_arguments(p.oid), ' | ') as signatures,
       string_agg(pg_get_function_result(p.oid), ' | ') as return_types,
       string_agg(case when p.prosrc ilike '%DROP_OFF%' then 'Y' else 'N' end, '') as body_mentions_drop_off,
       string_agg(case when p.prosrc ilike '%teacher_classes%' then 'Y' else 'N' end, '') as body_mentions_teacher_classes,
       string_agg(case when pg_get_function_result(p.oid) ilike '%photo_url%' then 'Y' else 'N' end, '') as returns_photo_url,
       left(string_agg(left(p.prosrc, 400), ' --- '), 400) as body_head
from target t
left join pg_proc p on p.proname = t.proname
                   and p.pronamespace = 'public'::regnamespace
group by t.proname
order by t.proname;

-- ============================================================================
-- SECTION 3 — TABLE / COLUMN inventory (never assume local schema == prod)
-- EXPECTED: all 15 tables exist; bus_trip_students must have boarded_at and
-- dropped_at; student_badges must have status + secure_token; schools must
-- have latitude/longitude/location_label (fn_update_school_location target).
-- ============================================================================
select c.relname as table_name,
       a.attname as column_name,
       format_type(a.atttypid, a.atttypmod) as data_type,
       a.attnotnull as not_null,
       pg_get_expr(d.adbin, d.adrelid) as default_value
from pg_class c
join pg_namespace n on n.oid = c.relnamespace
join pg_attribute a on a.attrelid = c.oid and a.attnum > 0 and not a.attisdropped
left join pg_attrdef d on d.adrelid = a.attrelid and d.adnum = a.attnum
where n.nspname = 'public'
  and c.relkind = 'r'
  and c.relname in ('schools','students','classes','teachers','teacher_classes',
                    'attendance_records','buses','bus_trips','bus_trip_students',
                    'bus_events','bus_routes','bus_route_stops','bus_trip_locations',
                    'student_badges','payments')
order by c.relname, a.attnum;

-- Missing tables (rows here = problem):
select v.expected_table
from (values ('schools'),('students'),('classes'),('teachers'),('teacher_classes'),
             ('attendance_records'),('buses'),('bus_trips'),('bus_trip_students'),
             ('bus_events'),('bus_routes'),('bus_route_stops'),('bus_trip_locations'),
             ('student_badges'),('payments')) as v(expected_table)
left join pg_class c on c.relname = v.expected_table
                    and c.relnamespace = 'public'::regnamespace and c.relkind = 'r'
where c.oid is null;

-- Critical columns probe (any 'MISSING' row = feature broken):
with cols as (
  select c.relname as tbl, a.attname as col
  from pg_class c join pg_namespace n on n.oid = c.relnamespace
  join pg_attribute a on a.attrelid = c.oid and a.attnum > 0 and not a.attisdropped
  where n.nspname='public'
)
select * from (values
  ('bus_trip_students','boarded_at'), ('bus_trip_students','dropped_at'),
  ('bus_trips','starts_at'), ('bus_trips','ends_at'),
  ('bus_trips','direction'), ('bus_trips','status'),
  ('student_badges','secure_token'), ('student_badges','status'),
  ('schools','latitude'), ('schools','longitude'), ('schools','location_label'),
  ('buses','code'), ('buses','plate_number')
-- (MISSING columns sort first within each table)
) as v(tbl, col)
left join cols on cols.tbl = v.tbl and cols.col = v.col
order by v.tbl, (cols.col is null) desc;

-- ============================================================================
-- SECTION 4 — ENUMS (actual production values; DO NOT MODIFY)
-- EXPECTED: bus_event_type = {BOARD, DROP_OFF}; trip_status =
-- {PLANNED, ACTIVE, COMPLETED, CANCELLED}; trip_direction = {TO_SCHOOL, TO_HOME}.
-- A bus_event_type without DROP_OFF explains "drop-off button dead".
-- ============================================================================
select t.typname as enum_name, e.enumlabel, e.enumsortorder
from pg_type t
join pg_enum e on e.enumtypid = t.oid
join pg_namespace n on n.oid = t.typnamespace
where n.nspname = 'public' and t.typname in ('bus_event_type','trip_status','trip_direction')
order by t.typname, e.enumsortorder;

-- Any unexpected event/status/direction enum:
select e.enumlabel as unexpected_value
from pg_enum e join pg_type t on t.oid = e.enumtypid
where t.typname = 'bus_event_type' and e.enumlabel not in ('BOARD','DROP_OFF')
union all
select e.enumlabel from pg_enum e join pg_type t on t.oid = e.enumtypid
where t.typname = 'trip_status' and e.enumlabel not in ('PLANNED','ACTIVE','COMPLETED','CANCELLED')
union all
select e.enumlabel from pg_enum e join pg_type t on t.oid = e.enumtypid
where t.typname = 'trip_direction' and e.enumlabel not in ('TO_SCHOOL','TO_HOME');

-- ============================================================================
-- SECTION 5 — RLS status + policies (display only)
-- ============================================================================
select c.relname as table_name,
       c.relrowsecurity as rls_enabled,
       c.relforcerowsecurity as rls_forced,
       pol.policyname as policy_name,
       pol.cmd as command,
       pol.roles as policy_roles,
       pol.qual as using_expression,
       pol.with_check as with_check_expression
from pg_class c
join pg_namespace n on n.oid = c.relnamespace
left join pg_policies pol on pol.schemaname = n.nspname and pol.tablename = c.relname
where n.nspname = 'public'
  and c.relkind = 'r'
  and c.relname in ('schools','students','classes','teachers','teacher_classes',
                    'attendance_records','buses','bus_trips','bus_trip_students',
                    'bus_events','student_badges','payments')
order by c.relname, pol.policyname;

-- Tables with RLS disabled (row here = RLS bypass risk):
select c.relname as rls_disabled_table
from pg_class c join pg_namespace n on n.oid = c.relnamespace
where n.nspname='public' and c.relkind='r' and not c.relrowsecurity
  and c.relname in ('schools','students','classes','teachers','teacher_classes',
                    'attendance_records','buses','bus_trips','bus_trip_students',
                    'bus_events','student_badges','payments')
order by c.relname;

-- ============================================================================
-- SECTION 6 — EXECUTE grants on the key RPCs (anon / authenticated /
-- service_role). Display only — nothing is granted or revoked here.
-- EXPECTED: EXECUTE to authenticated (frontend role). anon should NOT hold
-- EXECUTE on these. A missing authenticated grant = "permission denied".
-- ============================================================================
select p.proname as function_name,
       pg_get_function_identity_arguments(p.oid) as signature,
       r.rolname as grantee,
       a.privilege_type
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
cross join lateral aclexplode(p.proacl) a
join pg_roles r on r.oid = a.grantee
where n.nspname = 'public'
  and p.proname in ('fn_get_map_overview','fn_update_school_location','fn_record_trip_event',
                    'fn_get_student_badge','fn_guard_issue_badge','fn_guard_reissue_badge',
                    'fn_guard_suspend_badge','fn_list_bus_students_ordered','fn_list_bus_trips',
                    'fn_get_trip_route_history','fn_child_payments','fn_get_class_attendance',
                    'fn_save_attendance','fn_teacher_classes','fn_teacher_class_roster',
                    'fn_list_school_trips')
  and a.privilege_type = 'EXECUTE'
order by p.proname, r.rolname;

-- RPCs where 'authenticated' has NO EXECUTE grant (default-deny is possible if
-- a REVOKE FROM PUBLIC was issued instead — interpret alongside Section 6a):
select p.proname as function_name
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname='public'
  and p.proname in ('fn_get_map_overview','fn_update_school_location','fn_record_trip_event',
                    'fn_get_student_badge','fn_guard_issue_badge','fn_guard_reissue_badge',
                    'fn_guard_suspend_badge','fn_list_bus_students_ordered','fn_list_bus_trips',
                    'fn_get_trip_route_history','fn_child_payments','fn_get_class_attendance',
                    'fn_save_attendance','fn_teacher_classes','fn_teacher_class_roster',
                    'fn_list_school_trips')
  and not exists (
    select 1 from aclexplode(p.proacl) a join pg_roles r on r.oid = a.grantee
    where r.rolname = 'authenticated' and a.privilege_type = 'EXECUTE'
  )
order by p.proname;

-- ============================================================================
-- SECTION 7 — MIGRATION STATE (supabase_migrations tracking table)
-- NOTE: presence of a file in the repo does NOT prove it was applied. This
-- reads the CLI tracking table when present. EXPECTED applied versions
-- include the equivalents of phase18, phase19, phase20, phase22, phase23,
-- phase25, and (after deploy) phase27 + phase28.
-- ============================================================================
-- SAFE availability check — NEVER fails, even when the table is missing
-- (to_regclass returns NULL for a non-existent relation instead of erroring).
select to_regclass('supabase_migrations.schema_migrations') is not null as migration_history_table_available,
       case when to_regclass('supabase_migrations.schema_migrations') is null
            then 'Migration history could not be inspected from this table (it does not exist). Applied-migration state is unknown from the catalog; compare Sections 1-6 outputs against the repo migration files instead.'
            else 'Migration history table found. Run the FOLLOW-UP query below to list applied versions.'
       end as note;

-- FOLLOW-UP (run ONLY when migration_history_table_available = true).
-- Kept commented so running the whole file top-to-bottom can never abort:
-- select version, statements, name
-- from supabase_migrations.schema_migrations
-- order by version;

-- Never guess applied versions from file names — a file existing in the repo
-- does NOT prove it was applied to this database.

-- ============================================================================
-- SECTION 8 — INDEXES / CONSTRAINTS of interest (display only)
-- EXPECTED: PK or unique index on bus_trip_students(trip_id, student_id);
-- a partial unique index guaranteeing ONE active badge per student is a
-- recommended hardening (not yet in any phase — listed here so you can see
-- whether it exists on prod).
-- ============================================================================
select tablename, indexname, indexdef
from pg_indexes
where schemaname = 'public'
  and (tablename in ('bus_trip_students','student_badges','bus_trips','bus_events','payments','attendance_records'))
  and (indexdef ilike '%unique%' or indexname ilike '%pkey%')
order by tablename, indexname;

select conrelid::regclass as table_name, conname, contype,
       pg_get_constraintdef(oid) as definition
from pg_constraint
where connamespace = 'public'::regnamespace
  and conrelid::regclass::text in ('bus_trip_students','student_badges','bus_trips','payments')
order by conrelid::regclass::text, conname;

-- ============================================================================
-- SECTION 9 — QUICK VERDICTS (single-row summary flags for the report)
-- ============================================================================
select
  exists(select 1 from pg_proc where pronamespace='public'::regnamespace
         and proname='fn_get_map_overview'
         and pg_get_function_identity_arguments(oid) = '') as map_overview_zero_arg_ok,
  exists(select 1 from pg_proc where pronamespace='public'::regnamespace
         and proname='fn_update_school_location') as school_location_rpc_exists,
  exists(select 1 from pg_proc p where p.pronamespace='public'::regnamespace
         and p.proname='fn_record_trip_event' and p.prosrc ilike '%DROP_OFF%') as trip_event_dropoff_ok,
  exists(select 1 from pg_proc p where p.pronamespace='public'::regnamespace
         and p.proname='fn_get_class_attendance' and p.prosrc ilike '%teacher_classes%') as attendance_teacher_ok,
  exists(select 1 from pg_proc p where p.pronamespace='public'::regnamespace
         and p.proname='fn_list_bus_students_ordered'
         and pg_get_function_result(p.oid) ilike '%photo_url%') as roster_13col_ok,
  exists(select 1 from pg_proc p where p.pronamespace='public'::regnamespace
         and p.proname='fn_list_school_trips') as school_trips_rpc_exists,
  (select count(distinct proname) from pg_proc where pronamespace='public'::regnamespace
     and proname in ('fn_guard_issue_badge','fn_guard_reissue_badge','fn_guard_suspend_badge')) = 3 as badge_guard_rpcs_exist,
  (select count(*) from pg_enum e join pg_type t on t.oid=e.enumtypid
    where t.typname='bus_event_type' and e.enumlabel='DROP_OFF') = 1 as enum_dropoff_ok;

-- ============================================================================
-- SECTION 10 — PRODUCTION RPC RECONCILIATION DETAILS
-- Purpose: explain WHY the Section 9 verdicts failed, by inspecting the LIVE
-- functions only (never inferred from repo files). READ-ONLY.
-- Mobile-friendly: several small result sets, short aliases.
-- ============================================================================

-- 10.1 — Per-function fact sheet (one row per live OVERLOAD; functions that
-- do not exist at all still appear with function_exists = false).
with target as (
  select * from (values
    ('fn_get_map_overview'),
    ('fn_update_school_location'),
    ('fn_get_class_attendance'),
    ('fn_list_bus_students_ordered'),
    ('fn_list_school_trips')
  ) as v(fname)
),
live as (
  select p.oid, n.nspname as sname, p.proname,
         pg_get_function_identity_arguments(p.oid) as id_args,
         pg_get_function_result(p.oid) as ret,
         p.prokind, p.prosecdef, pg_get_userbyid(p.proowner) as owner,
         (select count(*) from pg_proc x
           where x.pronamespace = p.pronamespace and x.proname = p.proname) as n_overloads
  from pg_proc p
  join pg_namespace n on n.oid = p.pronamespace
  where n.nspname = 'public'
    and p.proname in (select fname from target)
)
select t.fname as function_name,
       (l.oid is not null) as exists,
       coalesce(l.sname, 'public') as schema,
       l.oid,
       l.id_args,
       case when l.oid is null then null
            when nullif(trim(l.id_args), '') is null then 0
            else array_length(string_to_array(l.id_args, ','), 1) end as n_args,
       l.ret as return_type,
       l.prokind, l.prosecdef as secdef, l.owner,
       l.n_overloads as overloads
from target t
left join live l on l.proname = t.fname
order by t.fname, l.id_args;

-- 10.2 — fn_get_map_overview: zero-argument overload + every live signature.
select exists(select 1 from pg_proc
              where pronamespace = 'public'::regnamespace
                and proname = 'fn_get_map_overview'
                and pg_get_function_identity_arguments(oid) = '') as zero_arg_overload,
       coalesce((select string_agg(pg_get_function_identity_arguments(oid), '  |  ')
                 from pg_proc
                 where pronamespace = 'public'::regnamespace
                   and proname = 'fn_get_map_overview'), '(function missing)') as all_live_signatures;

-- 10.3 — fn_update_school_location: dedicated existence row (Section 9 says
-- it is missing — this shows the live truth without assuming anything).
select (count(*) > 0) as exists,
       string_agg(pg_get_function_identity_arguments(oid), '  |  ') as id_args,
       string_agg(pg_get_function_result(oid), '  |  ') as return_type,
       string_agg(prosecdef::text, '  |  ') as secdef_flags
from pg_proc
where pronamespace = 'public'::regnamespace
  and proname = 'fn_update_school_location';

-- 10.4 — fn_get_class_attendance: signature + return columns + secdef, then
-- its FULL live definition (diagnostic only — nothing is modified).
select string_agg(pg_get_function_identity_arguments(oid), '  |  ') as id_args,
       string_agg(pg_get_function_result(oid), '  |  ') as return_columns,
       string_agg(prosecdef::text, '  |  ') as secdef_flags,
       (count(*) > 0) as exists
from pg_proc
where pronamespace = 'public'::regnamespace
  and proname = 'fn_get_class_attendance';

select pg_get_functiondef(oid) as live_function_definition
from pg_proc
where pronamespace = 'public'::regnamespace
  and proname = 'fn_get_class_attendance'
order by oid;

-- 10.5 — fn_list_school_trips: dedicated existence row (phase28 may never
-- have been applied — this confirms it from the catalog only).
select (count(*) > 0) as exists,
       string_agg(pg_get_function_identity_arguments(oid), '  |  ') as id_args,
       string_agg(pg_get_function_result(oid), '  |  ') as return_columns,
       string_agg(prosecdef::text, '  |  ') as secdef_flags
from pg_proc
where pronamespace = 'public'::regnamespace
  and proname = 'fn_list_school_trips';

-- 10.6 — fn_list_bus_students_ordered: EVERY returned column, positionally,
-- plus an explicit 12- vs 13-column indicator derived ONLY from the live
-- definition (no assumption about which one "should" be there).
with live_fn as (
  select p.oid, pg_get_function_result(p.oid) as rt
  from pg_proc p
  where p.pronamespace = 'public'::regnamespace
    and p.proname = 'fn_list_bus_students_ordered'
)
select (row_number() over (order by c.ord))::int as pos,
       split_part(trim(c.coldef), ' ', 1) as col_name,
       nullif(trim(substr(trim(c.coldef),
                          position(' ' in trim(c.coldef)) + 1)), '') as col_type,
       count(*) over () as total_cols,
       case when count(*) over () = 12 then '12-COLUMN VERSION'
            when count(*) over () = 13 then '13-COLUMN VERSION'
            else 'OTHER (' || count(*) over () || ' columns)' end as version_indicator
from live_fn
cross join lateral regexp_split_to_table(
       regexp_replace(live_fn.rt, '^\s*TABLE\((.*)\)\s*$', '\1'),
       ',') with ordinality as c(coldef, ord);

-- 10.7 — Overload listing for the same five functions (all versions live).
select p.proname as function_name,
       pg_get_function_identity_arguments(p.oid) as id_args,
       pg_get_function_result(p.oid) as return_type
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and p.proname in ('fn_get_map_overview','fn_update_school_location',
                    'fn_get_class_attendance','fn_list_bus_students_ordered',
                    'fn_list_school_trips')
order by p.proname, id_args;

-- End of audit. Everything above is read-only.
