-- PHASE 34 — runtime cleanup for audit actor visibility.
-- Mutating migration: backfills actor_id from user_id only where actor_id is NULL,
-- then ensures all future fn_write_audit entries populate both columns.
-- No timezone/time changes. No data deletion.

ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS actor_id uuid;

UPDATE public.audit_logs
SET actor_id = user_id
WHERE actor_id IS NULL
  AND user_id IS NOT NULL;

CREATE OR REPLACE FUNCTION public.fn_write_audit(
  p_school_id uuid,
  p_action text,
  p_entity text,
  p_entity_id uuid,
  p_old jsonb,
  p_new jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.audit_logs(
    school_id, user_id, actor_id, action, entity, entity_id, old_data, new_data
  )
  VALUES (
    p_school_id, auth.uid(), auth.uid(), p_action, p_entity, p_entity_id, p_old, p_new
  );
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_write_audit(uuid,text,text,uuid,jsonb,jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_write_audit(uuid,text,text,uuid,jsonb,jsonb) TO authenticated;

CREATE OR REPLACE FUNCTION public.fn_get_school_audit(p_limit int DEFAULT 50, p_offset int DEFAULT 0)
RETURNS TABLE(
  audit_id uuid,
  action text,
  entity text,
  entity_id uuid,
  actor_name text,
  created_at timestamptz
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_school_id uuid;
BEGIN
  v_school_id := fn_my_primary_school();
  IF v_school_id IS NULL THEN RAISE EXCEPTION 'NO_SCHOOL_CONTEXT'; END IF;
  IF NOT (fn_is_school_staff(v_school_id) OR fn_has_permission('audit.view', v_school_id)) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  RETURN QUERY
  SELECT
    al.id,
    al.action,
    al.entity,
    al.entity_id,
    (SELECT p.full_name FROM profiles p WHERE p.id = COALESCE(al.actor_id, al.user_id)),
    al.created_at
  FROM audit_logs al
  WHERE al.school_id = v_school_id
  ORDER BY al.created_at DESC
  LIMIT p_limit OFFSET p_offset;
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_get_school_audit(int,int) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_get_school_audit(int,int) TO authenticated;

-- Location RPC should not be executable by anonymous clients.
REVOKE ALL ON FUNCTION public.fn_admin_save_school_location(uuid,double precision,double precision,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_admin_save_school_location(uuid,double precision,double precision,text) TO authenticated;
