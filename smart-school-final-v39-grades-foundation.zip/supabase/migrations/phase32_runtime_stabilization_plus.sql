-- PHASE 32 — Runtime stabilization + universal guard incidents + notification UX
-- This migration is mutating. Run ONLY on the Smart School Supabase project.
BEGIN;

-- ============================================================
-- 1) Make audit triggers non-blocking
-- ============================================================
-- A failure in audit logging must never make the underlying business
-- operation fail (e.g. saving school location, lesson, trip event).
CREATE OR REPLACE FUNCTION public.fn_audit_row()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_row jsonb;
  v_old jsonb;
  v_new jsonb;
  v_school uuid;
BEGIN
  v_row := CASE WHEN TG_OP = 'DELETE' THEN to_jsonb(OLD) ELSE to_jsonb(NEW) END;
  v_old := CASE WHEN TG_OP IN ('UPDATE','DELETE') THEN to_jsonb(OLD) ELSE NULL END;
  v_new := CASE WHEN TG_OP IN ('INSERT','UPDATE') THEN to_jsonb(NEW) ELSE NULL END;

  IF TG_TABLE_NAME = 'student_badges' THEN
    v_old := CASE WHEN v_old IS NULL THEN NULL ELSE v_old - 'secure_token' END;
    v_new := CASE WHEN v_new IS NULL THEN NULL ELSE v_new - 'secure_token' END;
  END IF;

  v_school := NULLIF(v_row ->> 'school_id','')::uuid;

  IF v_school IS NULL AND v_row ? 'student_id' THEN
    SELECT s.school_id INTO v_school
    FROM public.students s
    WHERE s.id = (v_row ->> 'student_id')::uuid;
  END IF;

  BEGIN
    INSERT INTO public.audit_logs
      (school_id,user_id,actor_id,action,entity,entity_id,old_data,new_data)
    VALUES
      (v_school,auth.uid(),auth.uid(),TG_OP,TG_TABLE_NAME,
       NULLIF(v_row->>'id','')::uuid,v_old,v_new);
  EXCEPTION WHEN OTHERS THEN
    -- Audit is secondary. Never abort the business transaction.
    NULL;
  END;

  RETURN COALESCE(NEW,OLD);
END;
$$;

REVOKE ALL ON FUNCTION public.fn_audit_row() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_audit_row() TO authenticated;


-- ============================================================
-- 2) Institution location — robust save RPC
-- ============================================================
CREATE OR REPLACE FUNCTION public.fn_update_school_location(
  p_latitude double precision,
  p_longitude double precision,
  p_location_label text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;

  SELECT ur.school_id INTO v_school_id
  FROM public.user_roles ur
  WHERE ur.profile_id = auth.uid()
    AND ur.role IN ('admin','director')
  ORDER BY CASE WHEN ur.role = 'admin' THEN 0 ELSE 1 END
  LIMIT 1;

  IF v_school_id IS NULL THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  IF p_latitude IS NULL OR p_latitude < -90 OR p_latitude > 90 THEN
    RAISE EXCEPTION 'INVALID_LATITUDE';
  END IF;

  IF p_longitude IS NULL OR p_longitude < -180 OR p_longitude > 180 THEN
    RAISE EXCEPTION 'INVALID_LONGITUDE';
  END IF;

  UPDATE public.schools
  SET latitude = p_latitude,
      longitude = p_longitude,
      location_label = COALESCE(NULLIF(trim(p_location_label),''), location_label)
  WHERE id = v_school_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'INVALID_SCHOOL';
  END IF;

  -- Explicit audit is already safe via fn_safe_audit; row audit is also
  -- non-blocking after section 1 above.
  PERFORM public.fn_safe_audit(
    v_school_id,
    'SCHOOL_LOCATION_UPDATED',
    'schools',
    v_school_id,
    NULL,
    jsonb_build_object(
      'latitude',p_latitude,
      'longitude',p_longitude,
      'location_label',p_location_label,
      'updated_by',auth.uid()
    )
  );
END;
$$;

REVOKE ALL ON FUNCTION public.fn_update_school_location(double precision,double precision,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_update_school_location(double precision,double precision,text) TO authenticated;


-- ============================================================
-- 3) Incidents can target ANY school user, not only students
-- ============================================================
ALTER TABLE public.incidents
  ALTER COLUMN student_id DROP NOT NULL;

ALTER TABLE public.incidents
  ADD COLUMN IF NOT EXISTS target_profile_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS ix_incidents_target_profile
  ON public.incidents(target_profile_id, created_at DESC);


-- ============================================================
-- 4) Guard search: all users belonging to the guard's school
-- ============================================================
CREATE OR REPLACE FUNCTION public.fn_guard_search_users(p_query text)
RETURNS TABLE(
  profile_id uuid,
  full_name text,
  user_number text,
  phone text,
  role_name text
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_id uuid;
BEGIN
  v_school_id := public.fn_my_primary_school();
  IF v_school_id IS NULL THEN
    RAISE EXCEPTION 'NO_SCHOOL_CONTEXT';
  END IF;

  IF NOT (
    public.fn_is_school_staff(v_school_id)
    OR public.fn_has_permission('incidents.create', v_school_id)
  ) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  RETURN QUERY
  SELECT DISTINCT ON (p.id)
    p.id,
    p.full_name,
    p.user_number,
    p.phone,
    CASE
      WHEN EXISTS (SELECT 1 FROM user_roles ur WHERE ur.profile_id=p.id AND ur.school_id=v_school_id AND ur.role='admin') THEN 'مدير المؤسسة'
      WHEN EXISTS (SELECT 1 FROM user_roles ur WHERE ur.profile_id=p.id AND ur.school_id=v_school_id AND ur.role='teacher') THEN 'أستاذ'
      WHEN EXISTS (SELECT 1 FROM user_roles ur WHERE ur.profile_id=p.id AND ur.school_id=v_school_id AND ur.role='driver') THEN 'سائق'
      WHEN EXISTS (SELECT 1 FROM user_roles ur WHERE ur.profile_id=p.id AND ur.school_id=v_school_id AND ur.role='guard') THEN 'حارس'
      WHEN EXISTS (SELECT 1 FROM user_roles ur WHERE ur.profile_id=p.id AND ur.school_id=v_school_id AND ur.role='parent') THEN 'ولي أمر'
      ELSE 'مستخدم'
    END
  FROM profiles p
  JOIN user_roles ur ON ur.profile_id=p.id AND ur.school_id=v_school_id
  WHERE COALESCE(p.is_disabled,false) = false
    AND (
      COALESCE(trim(p_query),'') = ''
      OR p.full_name ILIKE '%'||trim(p_query)||'%'
      OR COALESCE(p.user_number,'') ILIKE '%'||trim(p_query)||'%'
      OR COALESCE(p.phone,'') ILIKE '%'||trim(p_query)||'%'
    )
  ORDER BY p.id, p.full_name
  LIMIT 30;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_guard_search_users(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_guard_search_users(text) TO authenticated;


-- ============================================================
-- 5) Report an incident against any school user + notify admins
-- ============================================================
CREATE OR REPLACE FUNCTION public.fn_report_user_incident(
  p_target_profile_id uuid,
  p_type text,
  p_title text,
  p_description text DEFAULT NULL,
  p_place text DEFAULT NULL,
  p_occurred_at timestamptz DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_id uuid;
  v_id uuid;
  v_target_name text;
  v_notification_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;

  v_school_id := public.fn_my_primary_school();
  IF v_school_id IS NULL THEN
    RAISE EXCEPTION 'NO_SCHOOL_CONTEXT';
  END IF;

  IF NOT (
    public.fn_is_school_staff(v_school_id)
    OR public.fn_has_permission('incidents.create', v_school_id)
  ) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  IF p_target_profile_id IS NULL THEN
    RAISE EXCEPTION 'TARGET_REQUIRED';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM user_roles ur
    WHERE ur.profile_id=p_target_profile_id
      AND ur.school_id=v_school_id
  ) THEN
    RAISE EXCEPTION 'INVALID_TARGET';
  END IF;

  SELECT full_name INTO v_target_name
  FROM profiles
  WHERE id=p_target_profile_id;

  IF p_title IS NULL OR trim(p_title)='' THEN
    RAISE EXCEPTION 'INCIDENT_TITLE_REQUIRED';
  END IF;

  INSERT INTO incidents(
    school_id,student_id,target_profile_id,type,title,description,place,occurred_at,reported_by
  )
  VALUES(
    v_school_id,
    NULL,
    p_target_profile_id,
    NULLIF(trim(coalesce(p_type,'مخالفة')),''),
    trim(p_title),
    NULLIF(trim(coalesce(p_description,'')),''),
    NULLIF(trim(coalesce(p_place,'')),''),
    coalesce(p_occurred_at,now()),
    auth.uid()
  )
  RETURNING id INTO v_id;

  -- Notify every admin/director in the same school.
  INSERT INTO notifications(school_id,title,body,type,target_role,created_by)
  VALUES(
    v_school_id,
    'بلاغ جديد من الحراسة العامة',
    'المستخدم المعني: '||coalesce(v_target_name,'مستخدم')||E'\nالنوع: '||coalesce(p_type,'مخالفة')||E'\n'||coalesce(p_description,''),
    'incident',
    'admin',
    auth.uid()
  )
  RETURNING id INTO v_notification_id;

  INSERT INTO notification_deliveries(notification_id,profile_id)
  SELECT v_notification_id, ur.profile_id
  FROM user_roles ur
  WHERE ur.school_id=v_school_id
    AND ur.role IN ('admin','director');

  PERFORM public.fn_safe_audit(
    v_school_id,
    'REPORT_INCIDENT',
    'incidents',
    v_id,
    NULL,
    jsonb_build_object(
      'target_profile_id',p_target_profile_id,
      'target_name',v_target_name,
      'type',p_type
    )
  );

  RETURN v_id;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_report_user_incident(uuid,text,text,text,text,timestamptz) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_report_user_incident(uuid,text,text,text,text,timestamptz) TO authenticated;


-- ============================================================
-- 6) Incident list: support both student and user targets
-- Keep the existing 12-column API shape for compatibility.
-- student_name becomes the displayed target name.
-- ============================================================
CREATE OR REPLACE FUNCTION public.fn_list_incidents(
  p_status text DEFAULT NULL,
  p_limit int DEFAULT 50,
  p_offset int DEFAULT 0
)
RETURNS TABLE(
  incident_id uuid,
  student_id uuid,
  student_name text,
  type text,
  title text,
  description text,
  place text,
  occurred_at timestamptz,
  action_taken text,
  status text,
  reporter_name text,
  created_at timestamptz
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_id uuid;
BEGIN
  v_school_id := public.fn_my_primary_school();
  IF v_school_id IS NULL THEN
    RAISE EXCEPTION 'NO_SCHOOL_CONTEXT';
  END IF;

  IF NOT (
    public.fn_is_school_staff(v_school_id)
    OR public.fn_has_permission('incidents.view', v_school_id)
    OR public.fn_has_permission('incidents.manage', v_school_id)
  ) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  RETURN QUERY
  SELECT
    i.id,
    i.student_id,
    COALESCE(tp.full_name, st.full_name, 'مستخدم غير معروف'),
    i.type,
    i.title,
    i.description,
    i.place,
    i.occurred_at,
    i.action_taken,
    i.status,
    rp.full_name,
    i.created_at
  FROM incidents i
  LEFT JOIN students st ON st.id=i.student_id
  LEFT JOIN profiles tp ON tp.id=i.target_profile_id
  LEFT JOIN profiles rp ON rp.id=i.reported_by
  WHERE i.school_id=v_school_id
    AND (p_status IS NULL OR p_status='' OR i.status=p_status)
  ORDER BY i.created_at DESC
  LIMIT p_limit OFFSET p_offset;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_list_incidents(text,int,int) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_list_incidents(text,int,int) TO authenticated;

COMMIT;
