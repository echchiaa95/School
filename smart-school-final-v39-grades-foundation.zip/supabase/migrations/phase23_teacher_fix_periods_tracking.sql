-- ============================================================================
-- PHASE 23 — TEACHER BUG FIX, LIVE-TRACKING ENRICHMENT, SCHOOL PERIOD CONFIG
-- ADDITIVE ONLY. All functions below are CREATE OR REPLACE with an
-- UNCHANGED signature except fn_get_active_bus_locations (adds columns,
-- so DROP+CREATE, same rule as before) and the two brand-new functions.
-- ============================================================================

-- ============================================================================
-- SECTION A — TEACHER BUG: root-cause audit findings + fixes
--
-- Found while tracing Teacher UI -> module JS -> RPC -> DB, per your
-- instruction:
--
-- 1) CONFIRMED MISSING (real bug, fixed in modules/school.js already in
--    this delivery, not SQL): GRADE_SUBJECT_REQUIRED and INVALID_SUBJECT
--    — two real error codes fn_add_grade already raises — were absent
--    from the frontend's error-code table, so BOTH fell through to the
--    generic "تعذر الاتصال..." message. A teacher submitting a grade
--    with an empty subject dropdown (which happens whenever
--    fn_my_teacher_subjects() returns nothing for them) hit exactly
--    this. Fixed by adding the two codes to the table.
--
-- 2) CONFIRMED GAP (fixed here): fn_save_attendance and fn_add_grade
--    require a TEACHER caller to ALSO hold a separately-granted
--    attendance.manage / grades.manage permission-catalog entry, on top
--    of being assigned to the class/subject. That permission-catalog
--    grant flow was built for GUARD accounts (Phase 18-22) — nothing in
--    this project's admin UI ever grants attendance.manage/grades.manage
--    to a TEACHER account. So a teacher who IS correctly assigned to
--    their own class could still get PERMISSION_DENIED trying to save
--    attendance or add a grade, with zero way to self-serve a fix. This
--    is fixed below: a teacher's own class/subject ASSIGNMENT is now
--    sufficient authorization on its own — the extra permission check is
--    now only required for a NON-teacher, NON-staff caller (i.e. it
--    still gates Guard/others exactly as before).
--
-- 3) DEFENSIVE FIX (safe either way): fn_save_attendance's
--    "ON CONFLICT (student_id, class_id, att_date)" requires a matching
--    unique constraint on attendance_records. That table isn't created
--    in any migration in this bundle (created outside it), so its exact
--    constraints can't be read from here. If that unique index is
--    missing on the live database, EVERY attendance save (not just
--    teachers') fails with a Postgres "no unique or exclusion constraint
--    matching ON CONFLICT" error — which is exactly the kind of raw,
--    unmapped error that falls through to the generic message. Adding
--    the index IF NOT EXISTS is a no-op if it's already there, and a
--    real fix if it wasn't.
-- ============================================================================

create unique index if not exists ux_attendance_records_student_class_date
  on attendance_records (student_id, class_id, att_date);

create or replace function fn_save_attendance(p_class_id uuid, p_date date, p_rows jsonb)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_row jsonb;
  v_count integer := 0;
  v_teacher_id uuid;
  v_teacher_assigned boolean := false;
begin
  select school_id into v_school_id from classes where id = p_class_id;
  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;

  select t.id into v_teacher_id
  from teachers t
  where t.school_id = v_school_id and t.profile_id = auth.uid() and t.deleted_at is null
  limit 1;

  if v_teacher_id is not null then
    v_teacher_assigned := exists (select 1 from teacher_classes tc
                                   where tc.teacher_id = v_teacher_id and tc.class_id = p_class_id)
                       or exists (select 1 from classes c
                                  where c.id = p_class_id and c.teacher_id = v_teacher_id);
  end if;

  -- FIX (item 2 above): a teacher genuinely assigned to this class no
  -- longer needs a SEPARATE attendance.manage grant — their assignment
  -- is the authorization. Anyone else still needs staff role or the
  -- explicit permission grant, exactly as before.
  if not (fn_is_school_staff(v_school_id)
          or v_teacher_assigned
          or fn_has_permission('attendance.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if v_teacher_id is not null and not fn_is_school_staff(v_school_id) and not v_teacher_assigned then
    -- A teacher account calling this for a class they are NOT assigned to
    -- still needs the explicit permission (covered by the check above);
    -- if neither held, this exception gives a precise reason.
    if not fn_has_permission('attendance.manage', v_school_id) then
      raise exception 'TEACHER_ASSIGNMENT_REQUIRED';
    end if;
  end if;

  if p_rows is null or jsonb_typeof(p_rows) <> 'array' then
    raise exception 'INVALID_ROWS';
  end if;

  for v_row in select * from jsonb_array_elements(p_rows)
  loop
    if not exists (
      select 1 from student_enrollments se
      where se.student_id = (v_row->>'student_id')::uuid
        and se.class_id = p_class_id
        and se.status = 'ACTIVE'
    ) then
      continue;
    end if;

    if coalesce(v_row->>'status', '') not in ('present', 'absent', 'late', 'excused') then
      continue;
    end if;

    insert into attendance_records
      (school_id, student_id, class_id, att_date, status, note, recorded_by)
    values (
      v_school_id,
      (v_row->>'student_id')::uuid,
      p_class_id,
      coalesce(p_date, current_date),
      v_row->>'status',
      nullif(trim(coalesce(v_row->>'note', '')), ''),
      auth.uid()
    )
    on conflict (student_id, class_id, att_date)
    do update set status = excluded.status,
                  note = excluded.note,
                  recorded_by = excluded.recorded_by,
                  updated_at = now();

    v_count := v_count + 1;
  end loop;

  perform fn_safe_audit(v_school_id, 'SAVE_ATTENDANCE', 'attendance_records', p_class_id,
    null, jsonb_build_object('date', coalesce(p_date, current_date), 'count', v_count));

  return v_count;
end;
$$;
revoke all on function fn_save_attendance(uuid, date, jsonb) from public;
grant execute on function fn_save_attendance(uuid, date, jsonb) to authenticated;


create or replace function fn_add_grade(
  p_student_id uuid, p_class_id uuid, p_subject_id uuid,
  p_period text, p_grade_type text, p_score numeric,
  p_max_score numeric default 20, p_note text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_id uuid;
  v_teacher_id uuid;
  v_subject_ok boolean := false;
  v_class_ok boolean := false;
begin
  select school_id into v_school_id from students where id = p_student_id;
  if v_school_id is null then raise exception 'INVALID_STUDENT'; end if;

  select t.id into v_teacher_id
  from teachers t
  where t.school_id = v_school_id and t.profile_id = auth.uid() and t.deleted_at is null
  limit 1;

  if v_teacher_id is not null then
    v_subject_ok := exists (select 1 from teacher_subjects ts
                             where ts.teacher_id = v_teacher_id and ts.subject_id = p_subject_id);
    v_class_ok := exists (select 1 from teacher_classes tc
                           where tc.teacher_id = v_teacher_id and tc.class_id = p_class_id)
               or exists (select 1 from classes c
                          where c.id = p_class_id and c.teacher_id = v_teacher_id);
  end if;

  -- FIX (item 2): assigned-to-subject-and-class is sufficient on its own
  -- for a teacher — no separate grades.manage grant required anymore.
  if not (fn_is_school_staff(v_school_id)
          or (v_teacher_id is not null and v_subject_ok and v_class_ok)
          or fn_has_permission('grades.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if p_subject_id is null then raise exception 'GRADE_SUBJECT_REQUIRED'; end if;
  if not exists (select 1 from subjects s where s.id = p_subject_id and s.school_id = v_school_id) then
    raise exception 'INVALID_SUBJECT';
  end if;
  if p_score is null or p_score < 0 then raise exception 'INVALID_SCORE'; end if;

  if v_teacher_id is not null and not fn_is_school_staff(v_school_id) and not (v_subject_ok and v_class_ok) then
    if not fn_has_permission('grades.manage', v_school_id) then
      raise exception 'TEACHER_ASSIGNMENT_REQUIRED';
    end if;
  end if;

  insert into student_grades
    (school_id, student_id, class_id, subject_id, period, grade_type, score, max_score, note, grade_date, teacher_id)
  values (
    v_school_id, p_student_id, p_class_id, p_subject_id,
    nullif(trim(coalesce(p_period, '')), ''),
    coalesce(nullif(trim(coalesce(p_grade_type, '')), ''), 'تقويم'),
    p_score, coalesce(p_max_score, 20),
    nullif(trim(coalesce(p_note, '')), ''),
    current_date, v_teacher_id
  )
  returning id into v_id;

  perform fn_safe_audit(v_school_id, 'ADD_GRADE', 'student_grades', v_id,
    null, jsonb_build_object('student_id', p_student_id, 'score', p_score));

  return v_id;
end;
$$;
revoke all on function fn_add_grade(uuid, uuid, uuid, text, text, numeric, numeric, text) from public;
grant execute on function fn_add_grade(uuid, uuid, uuid, text, text, numeric, numeric, text) to authenticated;


-- New, dedicated roster function for Grades/Incidents student pickers —
-- previously the frontend reused fn_get_class_attendance as a roster
-- source, coupling two unrelated features. This checks the SAME
-- authorization fn_add_grade/fn_save_attendance already trust (teacher
-- assigned to the class, or staff, or attendance.view/students.view).
create or replace function fn_teacher_class_roster(p_class_id uuid)
returns table(student_id uuid, full_name text, student_number text)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_teacher_id uuid;
  v_assigned boolean := false;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select school_id into v_school_id from classes where id = p_class_id;
  if v_school_id is null then raise exception 'INVALID_CLASS'; end if;

  select t.id into v_teacher_id from teachers t
  where t.school_id = v_school_id and t.profile_id = auth.uid() and t.deleted_at is null limit 1;
  if v_teacher_id is not null then
    v_assigned := exists (select 1 from teacher_classes tc where tc.teacher_id = v_teacher_id and tc.class_id = p_class_id)
               or exists (select 1 from classes c where c.id = p_class_id and c.teacher_id = v_teacher_id);
  end if;

  if not (fn_is_school_staff(v_school_id) or v_assigned
          or fn_has_permission('students.view', v_school_id)
          or fn_has_permission('attendance.view', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select st.id, st.full_name, st.student_number
  from student_enrollments se
  join students st on st.id = se.student_id and st.deleted_at is null
  where se.class_id = p_class_id and se.status = 'ACTIVE'
  order by st.full_name;
end;
$$;
revoke all on function fn_teacher_class_roster(uuid) from public;
grant execute on function fn_teacher_class_roster(uuid) to authenticated;


-- ============================================================================
-- SECTION B — LIVE BUS TRACKING ENRICHMENT (items 1-2): real passenger
-- count for the ACTIVE trip and a computed connection status, so the
-- frontend never has to guess "connected" from trip existence alone.
-- ============================================================================

drop function if exists fn_get_active_bus_locations();

create function fn_get_active_bus_locations()
returns table(
  bus_id uuid, bus_code text, bus_plate text,
  trip_id uuid, direction text, driver_name text, route_name text,
  latitude double precision, longitude double precision,
  accuracy double precision, speed double precision, heading double precision,
  recorded_at timestamptz, trip_started_at timestamptz,
  total_students int, boarded_count int, dropped_count int
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director', 'superadmin') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select b.id, b.code, b.plate_number,
         t.id, case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup' else 'dropoff' end,
         p.full_name, r.name,
         ll.latitude, ll.longitude, ll.accuracy, ll.speed, ll.heading, ll.recorded_at,
         t.starts_at,
         (select count(*) from student_transport_assignments sta where sta.bus_id = b.id and sta.is_active)::int,
         (select count(*) from bus_trip_students bts where bts.trip_id = t.id and bts.boarded_at is not null)::int,
         (select count(*) from bus_trip_students bts where bts.trip_id = t.id and bts.dropped_at is not null)::int
  from bus_trips t
  join buses b on b.id = t.bus_id
  left join bus_last_locations ll on ll.bus_id = b.id and ll.trip_id = t.id
  left join drivers d on d.id = t.driver_id
  left join profiles p on p.id = d.profile_id
  left join bus_routes r on r.id = t.route_id
  where t.school_id = v_school_id
    and t.status = 'ACTIVE'::trip_status
  order by t.starts_at desc;
end;
$$;
revoke all on function fn_get_active_bus_locations() from public;
grant execute on function fn_get_active_bus_locations() to authenticated;


-- fn_get_all_buses_status (item 1B — "غير متصلة" list): every bus, whether
-- or not it has an active trip right now, so Admin can see the FULL
-- fleet's status (idle / active+connected / active+stale) in one call.
create or replace function fn_get_all_buses_status()
returns table(
  bus_id uuid, bus_code text, bus_plate text,
  has_active_trip boolean, trip_id uuid, direction text,
  driver_name text, recorded_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director', 'superadmin') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select b.id, b.code, b.plate_number,
         t.id is not null, t.id,
         case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup'
              when t.direction = 'TO_HOME'::trip_direction then 'dropoff' else null end,
         p.full_name, ll.recorded_at
  from buses b
  left join bus_trips t on t.bus_id = b.id and t.status = 'ACTIVE'::trip_status
  left join bus_last_locations ll on ll.bus_id = b.id and ll.trip_id = t.id
  left join drivers d on d.id = coalesce(t.driver_id, b.driver_id)
  left join profiles p on p.id = d.profile_id
  where b.school_id = v_school_id
  order by b.code;
end;
$$;
revoke all on function fn_get_all_buses_status() from public;
grant execute on function fn_get_all_buses_status() to authenticated;


-- ============================================================================
-- SECTION C — BUS ROUTE HISTORY (item 3): list past trips + replay their
-- recorded GPS points. Uses bus_trip_locations (Phase 22) — real data
-- only; if a trip has no rows there, the frontend shows "لا توجد بيانات
-- GPS لهذه الرحلة." rather than inventing anything.
-- ============================================================================

create or replace function fn_list_bus_trips(p_bus_id uuid, p_limit int default 30)
returns table(
  trip_id uuid, direction text, status text, started_at timestamptz, ended_at timestamptz,
  driver_name text, route_name text, passenger_count int
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select school_id into v_school_id from buses where id = p_bus_id;
  if v_school_id is null then raise exception 'INVALID_BUS'; end if;
  if not fn_is_school_staff(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select t.id, case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup' else 'dropoff' end,
         t.status::text, t.starts_at, t.ends_at,
         p.full_name, r.name,
         (select count(*) from bus_trip_students bts where bts.trip_id = t.id and bts.boarded_at is not null)::int
  from bus_trips t
  left join drivers d on d.id = t.driver_id
  left join profiles p on p.id = d.profile_id
  left join bus_routes r on r.id = t.route_id
  where t.bus_id = p_bus_id
  order by t.starts_at desc
  limit greatest(1, least(p_limit, 100));
end;
$$;
revoke all on function fn_list_bus_trips(uuid, int) from public;
grant execute on function fn_list_bus_trips(uuid, int) to authenticated;


create or replace function fn_get_trip_route_history(p_trip_id uuid)
returns table(latitude double precision, longitude double precision, speed double precision, recorded_at timestamptz)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select school_id into v_school_id from bus_trips where id = p_trip_id;
  if v_school_id is null then raise exception 'INVALID_TRIP'; end if;
  if not fn_is_school_staff(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select btl.latitude, btl.longitude, btl.speed, btl.recorded_at
  from bus_trip_locations btl
  where btl.trip_id = p_trip_id
  order by btl.recorded_at;
end;
$$;
revoke all on function fn_get_trip_route_history(uuid) from public;
grant execute on function fn_get_trip_route_history(uuid) to authenticated;


-- ============================================================================
-- SECTION D — SIMPLE SCHOOL-WIDE PERIOD CONFIGURATION (items 4-5): the
-- Director sets morning/afternoon start time + lesson duration ONCE per
-- school; lesson TIME is then always computed, never typed by hand. This
-- is intentionally a simple per-school config row, not a per-class or
-- per-year table — additive, new, nothing existing is touched.
-- ============================================================================

create table if not exists school_period_configs (
  school_id uuid primary key references schools(id) on delete cascade,
  morning_start time not null default '08:00',
  morning_lesson_minutes int not null default 60,
  morning_lessons int not null default 4,
  afternoon_start time not null default '14:00',
  afternoon_lesson_minutes int not null default 60,
  afternoon_lessons int not null default 4,
  updated_at timestamptz not null default now()
);
alter table school_period_configs enable row level security;

do $$ begin
  if not exists (select 1 from pg_policies where schemaname = 'public' and tablename = 'school_period_configs'
                 and policyname = 'p_school_period_configs_member_read') then
    create policy p_school_period_configs_member_read on school_period_configs
      for select using (fn_is_school_member(school_id));
  end if;
end $$;

create or replace function fn_set_school_periods(
  p_morning_start time, p_morning_lesson_minutes int, p_morning_lessons int,
  p_afternoon_start time, p_afternoon_lesson_minutes int, p_afternoon_lessons int
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select school_id into v_school_id from user_roles
  where profile_id = auth.uid() and role in ('admin', 'director') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  if p_morning_lessons < 0 or p_afternoon_lessons < 0 or (p_morning_lessons + p_afternoon_lessons) > 8 then
    raise exception 'TOO_MANY_LESSONS';
  end if;

  insert into school_period_configs
    (school_id, morning_start, morning_lesson_minutes, morning_lessons,
     afternoon_start, afternoon_lesson_minutes, afternoon_lessons)
  values (v_school_id, p_morning_start, p_morning_lesson_minutes, p_morning_lessons,
          p_afternoon_start, p_afternoon_lesson_minutes, p_afternoon_lessons)
  on conflict (school_id) do update set
    morning_start = excluded.morning_start, morning_lesson_minutes = excluded.morning_lesson_minutes,
    morning_lessons = excluded.morning_lessons, afternoon_start = excluded.afternoon_start,
    afternoon_lesson_minutes = excluded.afternoon_lesson_minutes, afternoon_lessons = excluded.afternoon_lessons,
    updated_at = now();

  perform fn_safe_audit(v_school_id, 'SCHOOL_PERIODS_SET', 'school_period_configs', v_school_id, null,
    jsonb_build_object('morning_lessons', p_morning_lessons, 'afternoon_lessons', p_afternoon_lessons));
end;
$$;
revoke all on function fn_set_school_periods(time, int, int, time, int, int) from public;
grant execute on function fn_set_school_periods(time, int, int, time, int, int) to authenticated;

create or replace function fn_get_school_periods()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_result jsonb;
begin
  select school_id into v_school_id from user_roles where profile_id = auth.uid() limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  select to_jsonb(c) into v_result from school_period_configs c where c.school_id = v_school_id;
  return coalesce(v_result, jsonb_build_object(
    'school_id', v_school_id, 'morning_start', '08:00', 'morning_lesson_minutes', 60, 'morning_lessons', 4,
    'afternoon_start', '14:00', 'afternoon_lesson_minutes', 60, 'afternoon_lessons', 4
  ));
end;
$$;
revoke all on function fn_get_school_periods() from public;
grant execute on function fn_get_school_periods() to authenticated;


-- fn_add_lesson / fn_update_lesson: now take a simple p_period (1-8) and
-- compute the exact time from school_period_configs instead of the old
-- hardcoded "07:00 + (period-1)*45min" guess. Same names/params as
-- Phase 19 (p_period stays an int — the UI just no longer asks for a
-- time), only the internal time computation changes. Also enforces the
-- "max 8 lessons/day" rule from the config.
create or replace function fn_add_lesson(
  p_class_id uuid, p_weekday smallint, p_period smallint,
  p_subject_id uuid, p_teacher_id uuid default null, p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_year_id uuid;
  v_tt_id uuid;
  v_teacher uuid;
  v_weekday smallint;
  v_start time;
  v_end time;
  v_entry_id uuid;
  v_cfg record;
  v_max_period int;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select c.school_id, c.academic_year_id into v_school_id, v_year_id
  from classes c where c.id = p_class_id;
  if v_school_id is null then raise exception 'INVALID_CLASS'; end if;

  if not (fn_is_school_staff(v_school_id) or fn_has_permission('schedule.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if not exists (select 1 from subjects s where s.id = p_subject_id and s.school_id = v_school_id) then
    raise exception 'INVALID_SUBJECT';
  end if;

  v_teacher := coalesce(p_teacher_id, (select c.teacher_id from classes c where c.id = p_class_id));
  if v_teacher is null then raise exception 'SCHEDULE_TEACHER_REQUIRED'; end if;
  if not exists (select 1 from teachers t where t.id = v_teacher and t.school_id = v_school_id and t.deleted_at is null) then
    raise exception 'INVALID_TEACHER';
  end if;

  if p_weekday is null or p_weekday < 0 or p_weekday > 6 then raise exception 'INVALID_WEEKDAY'; end if;
  v_weekday := p_weekday + 1;

  select * into v_cfg from school_period_configs where school_id = v_school_id;
  if v_cfg is null then
    v_cfg.morning_start := time '08:00'; v_cfg.morning_lesson_minutes := 60; v_cfg.morning_lessons := 4;
    v_cfg.afternoon_start := time '14:00'; v_cfg.afternoon_lesson_minutes := 60; v_cfg.afternoon_lessons := 4;
  end if;
  v_max_period := v_cfg.morning_lessons + v_cfg.afternoon_lessons;
  if p_period is null or p_period < 1 or p_period > v_max_period then
    raise exception 'INVALID_PERIOD';
  end if;

  if p_period <= v_cfg.morning_lessons then
    v_start := v_cfg.morning_start + ((p_period - 1) * (v_cfg.morning_lesson_minutes || ' minutes')::interval);
    v_end := v_start + (v_cfg.morning_lesson_minutes || ' minutes')::interval;
  else
    v_start := v_cfg.afternoon_start + ((p_period - v_cfg.morning_lessons - 1) * (v_cfg.afternoon_lesson_minutes || ' minutes')::interval);
    v_end := v_start + (v_cfg.afternoon_lesson_minutes || ' minutes')::interval;
  end if;

  select t.id into v_tt_id from timetables t
  where t.school_id = v_school_id and t.academic_year_id = v_year_id
  order by t.created_at limit 1;
  if v_tt_id is null then
    insert into timetables (school_id, academic_year_id, name)
    values (v_school_id, v_year_id, 'Default')
    returning id into v_tt_id;
  end if;

  if exists (select 1 from timetable_entries te where te.timetable_id = v_tt_id and te.class_id = p_class_id
             and te.weekday = v_weekday and coalesce(te.period, 1) = p_period) then
    raise exception 'CLASS_SLOT_TAKEN';
  end if;
  if exists (select 1 from timetable_entries te where te.timetable_id = v_tt_id and te.teacher_id = v_teacher
             and te.weekday = v_weekday and coalesce(te.period, 1) = p_period) then
    raise exception 'TEACHER_SCHEDULE_CONFLICT';
  end if;

  insert into timetable_entries (timetable_id, class_id, subject_id, teacher_id, weekday, starts_at, ends_at, period)
  values (v_tt_id, p_class_id, p_subject_id, v_teacher, v_weekday, v_start, v_end, p_period)
  returning id into v_entry_id;

  perform fn_safe_audit(v_school_id, 'LESSON_ADDED', 'timetable_entries', v_entry_id, null,
    jsonb_build_object('class_id', p_class_id, 'weekday', p_weekday, 'period', p_period,
                        'subject_id', p_subject_id, 'teacher_id', v_teacher, 'added_by', auth.uid()));
  return v_entry_id;
end;
$$;
revoke all on function fn_add_lesson(uuid, smallint, smallint, uuid, uuid, text) from public;
grant execute on function fn_add_lesson(uuid, smallint, smallint, uuid, uuid, text) to authenticated;


create or replace function fn_update_lesson(
  p_entry_id uuid, p_weekday smallint, p_period smallint,
  p_subject_id uuid, p_teacher_id uuid default null, p_notes text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_class_id uuid;
  v_tt_id uuid;
  v_teacher uuid;
  v_weekday smallint;
  v_start time;
  v_end time;
  v_cfg record;
  v_max_period int;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select c.school_id, te.class_id, te.timetable_id into v_school_id, v_class_id, v_tt_id
  from timetable_entries te join classes c on c.id = te.class_id
  where te.id = p_entry_id;
  if v_school_id is null then raise exception 'INVALID_LESSON'; end if;

  if not (fn_is_school_staff(v_school_id) or fn_has_permission('schedule.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if not exists (select 1 from subjects s where s.id = p_subject_id and s.school_id = v_school_id) then
    raise exception 'INVALID_SUBJECT';
  end if;

  v_teacher := coalesce(p_teacher_id, (select c.teacher_id from classes c where c.id = v_class_id));
  if v_teacher is null then raise exception 'SCHEDULE_TEACHER_REQUIRED'; end if;
  if not exists (select 1 from teachers t where t.id = v_teacher and t.school_id = v_school_id and t.deleted_at is null) then
    raise exception 'INVALID_TEACHER';
  end if;
  if p_weekday is null or p_weekday < 0 or p_weekday > 6 then raise exception 'INVALID_WEEKDAY'; end if;
  v_weekday := p_weekday + 1;

  select * into v_cfg from school_period_configs where school_id = v_school_id;
  if v_cfg is null then
    v_cfg.morning_start := time '08:00'; v_cfg.morning_lesson_minutes := 60; v_cfg.morning_lessons := 4;
    v_cfg.afternoon_start := time '14:00'; v_cfg.afternoon_lesson_minutes := 60; v_cfg.afternoon_lessons := 4;
  end if;
  v_max_period := v_cfg.morning_lessons + v_cfg.afternoon_lessons;
  if p_period is null or p_period < 1 or p_period > v_max_period then raise exception 'INVALID_PERIOD'; end if;

  if p_period <= v_cfg.morning_lessons then
    v_start := v_cfg.morning_start + ((p_period - 1) * (v_cfg.morning_lesson_minutes || ' minutes')::interval);
    v_end := v_start + (v_cfg.morning_lesson_minutes || ' minutes')::interval;
  else
    v_start := v_cfg.afternoon_start + ((p_period - v_cfg.morning_lessons - 1) * (v_cfg.afternoon_lesson_minutes || ' minutes')::interval);
    v_end := v_start + (v_cfg.afternoon_lesson_minutes || ' minutes')::interval;
  end if;

  if exists (select 1 from timetable_entries te where te.timetable_id = v_tt_id and te.class_id = v_class_id
             and te.weekday = v_weekday and coalesce(te.period, 1) = p_period and te.id <> p_entry_id) then
    raise exception 'CLASS_SLOT_TAKEN';
  end if;
  if exists (select 1 from timetable_entries te where te.timetable_id = v_tt_id and te.teacher_id = v_teacher
             and te.weekday = v_weekday and coalesce(te.period, 1) = p_period and te.id <> p_entry_id) then
    raise exception 'TEACHER_SCHEDULE_CONFLICT';
  end if;

  update timetable_entries
     set subject_id = p_subject_id, teacher_id = v_teacher, weekday = v_weekday,
         period = p_period, starts_at = v_start, ends_at = v_end
   where id = p_entry_id;

  perform fn_safe_audit(v_school_id, 'LESSON_UPDATED', 'timetable_entries', p_entry_id, null,
    jsonb_build_object('class_id', v_class_id, 'weekday', p_weekday, 'period', p_period, 'updated_by', auth.uid()));
end;
$$;
revoke all on function fn_update_lesson(uuid, smallint, smallint, uuid, uuid, text) from public;
grant execute on function fn_update_lesson(uuid, smallint, smallint, uuid, uuid, text) to authenticated;

-- ============================================================================
-- END OF PHASE 23
-- ============================================================================
