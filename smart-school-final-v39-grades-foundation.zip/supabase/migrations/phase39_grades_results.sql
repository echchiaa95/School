-- PHASE 39 — Weighted assessments and professional term/year results
-- MUTATING SQL: run once on the correct Smart School Production project.
create table if not exists public.grade_assessments (
  id uuid primary key default gen_random_uuid(), school_id uuid not null references public.schools(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade, subject_id uuid not null references public.subjects(id) on delete cascade,
  academic_year_id uuid references public.academic_years(id), period text not null check (period in ('SEMESTER_1','SEMESTER_2')),
  title text not null, assessment_type text not null default 'QUIZ', coefficient numeric(8,3) not null default 1 check (coefficient>0),
  max_score numeric(8,3) not null check (max_score>0), assessment_date date, created_by uuid references auth.users(id), created_at timestamptz not null default now()
);
create table if not exists public.grade_marks (
  id uuid primary key default gen_random_uuid(), assessment_id uuid not null references public.grade_assessments(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade, score numeric(8,3) not null check(score>=0), teacher_note text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(assessment_id,student_id)
);
create index if not exists ix_grade_assessments_class_period on public.grade_assessments(class_id,period);
create index if not exists ix_grade_marks_student on public.grade_marks(student_id);
alter table public.grade_assessments enable row level security; alter table public.grade_marks enable row level security;
revoke all on public.grade_assessments, public.grade_marks from public;
grant select,insert,update,delete on public.grade_assessments, public.grade_marks to authenticated;
create or replace function public.fn_grade_results(p_class_id uuid,p_period text)
returns table(student_id uuid,student_name text,subject_id uuid,subject_name text,subject_coefficient numeric,subject_score numeric,teacher_note text,scale numeric)
language sql stable security definer set search_path=public as $f$
select s.id,s.full_name,su.id,su.name,coalesce(sum(ga.coefficient),0),
 case when sum(ga.coefficient)>0 then sum(gm.score/ga.max_score*100*ga.coefficient)/sum(ga.coefficient) else null end,
 string_agg(nullif(gm.teacher_note,''), ' | '),
 case when c.level ilike '%ابتدائي%' or c.level ilike '%primary%' then 10 else 20 end
from students s join student_enrollments se on se.student_id=s.id and se.class_id=p_class_id
join classes c on c.id=se.class_id cross join subjects su
left join grade_assessments ga on ga.class_id=p_class_id and ga.subject_id=su.id and ga.period=p_period
left join grade_marks gm on gm.assessment_id=ga.id and gm.student_id=s.id
where s.deleted_at is null group by s.id,s.full_name,su.id,su.name,c.level
order by s.full_name,su.name;$f$;
revoke all on function public.fn_grade_results(uuid,text) from public;
grant execute on function public.fn_grade_results(uuid,text) to authenticated;
