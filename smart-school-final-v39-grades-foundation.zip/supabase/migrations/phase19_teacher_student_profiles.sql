-- ============================================================================
-- PHASE 19 — TEACHER PROFILE / STUDENT PROFILE / BADGE DISPLAY: BACKEND
--
-- ADDITIVE ONLY. No DROP TABLE, no TRUNCATE, no data loss.
-- fn_get_class_schedule changes return TYPE (adds columns) so it is
-- DROP + CREATE (same rule you approved for signature changes) — every
-- other function here is CREATE OR REPLACE with an unchanged signature.
--
-- REAL BUG FOUND AND FIXED IN THIS FILE (not asked for, but directly
-- blocks your own test items 5-8):
-- The existing admin schedule screen (admin.html #sc-add-form ->
-- modules/adminConsole.js) calls setClassSchedule(classId, [oneEntry])
-- every time a lesson is added. fn_set_class_schedule DELETES ALL
-- existing entries for that class before inserting the ones you pass it
-- (it is a bulk "replace the whole timetable" function, by original
-- design). So adding a SECOND lesson to a class was silently deleting
-- the FIRST one. This is why item 6/7 ("add a lesson -> it should just
-- appear, editing one shouldn't nuke the rest") needed a real fix, not a
-- workaround: fn_set_class_schedule is left untouched for whoever still
-- needs a full bulk replace, and three new single-row functions are
-- added for real add/edit/delete of one lesson at a time. The frontend
-- (admin.html) is switched to use these new functions.
-- ============================================================================


-- ============================================================================
-- SECTION A — SINGLE-LESSON CRUD (fixes the silent data-loss bug above)
-- ============================================================================

create or replace function fn_add_lesson(
  p_class_id uuid,
  p_weekday smallint,      -- 0=Sunday..6=Saturday (same convention as fn_get_class_schedule)
  p_period smallint,
  p_subject_id uuid,
  p_teacher_id uuid default null,
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_year_id uuid;
  v_tt_id uuid;
  v_teacher uuid;
  v_weekday smallint;
  v_start time;
  v_entry_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select c.school_id, c.academic_year_id into v_school_id, v_year_id
  from classes c where c.id = p_class_id;
  if v_school_id is null then raise exception 'INVALID_CLASS'; end if;

  if not (fn_is_school_staff(v_school_id) or fn_has_permission('schedule.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if not exists (select 1 from subjects s where s.id = p_subject_id and s.school_id = v_school_id) then
    raise exception 'INVALID_SUBJECT';
  end if;

  v_teacher := coalesce(p_teacher_id, (select c.teacher_id from classes c where c.id = p_class_id));
  if v_teacher is null then raise exception 'SCHEDULE_TEACHER_REQUIRED'; end if;
  if not exists (select 1 from teachers t where t.id = v_teacher and t.school_id = v_school_id and t.deleted_at is null) then
    raise exception 'INVALID_TEACHER';
  end if;

  if p_weekday is null or p_weekday < 0 or p_weekday > 6 then
    raise exception 'INVALID_WEEKDAY';
  end if;
  v_weekday := p_weekday + 1; -- stored 1..7 like fn_set_class_schedule

  if p_period is null or p_period < 1 then raise exception 'INVALID_PERIOD'; end if;

  select t.id into v_tt_id from timetables t
  where t.school_id = v_school_id and t.academic_year_id = v_year_id
  order by t.created_at limit 1;
  if v_tt_id is null then
    insert into timetables (school_id, academic_year_id, name)
    values (v_school_id, v_year_id, 'Default')
    returning id into v_tt_id;
  end if;

  if exists (
    select 1 from timetable_entries te
    where te.timetable_id = v_tt_id and te.class_id = p_class_id
      and te.weekday = v_weekday and coalesce(te.period, 1) = p_period
  ) then
    raise exception 'CLASS_SLOT_TAKEN';
  end if;

  if exists (
    select 1 from timetable_entries te
    where te.timetable_id = v_tt_id and te.teacher_id = v_teacher
      and te.weekday = v_weekday and coalesce(te.period, 1) = p_period
  ) then
    raise exception 'TEACHER_SCHEDULE_CONFLICT';
  end if;

  v_start := time '07:00' + ((p_period - 1) * interval '45 minutes');

  insert into timetable_entries
    (timetable_id, class_id, subject_id, teacher_id, weekday, starts_at, ends_at, period)
  values
    (v_tt_id, p_class_id, p_subject_id, v_teacher, v_weekday, v_start, v_start + interval '45 minutes', p_period)
  returning id into v_entry_id;

  perform fn_safe_audit(v_school_id, 'LESSON_ADDED', 'timetable_entries', v_entry_id, null,
    jsonb_build_object('class_id', p_class_id, 'weekday', p_weekday, 'period', p_period,
                        'subject_id', p_subject_id, 'teacher_id', v_teacher, 'added_by', auth.uid()));

  return v_entry_id;
end;
$$;
revoke all on function fn_add_lesson(uuid, smallint, smallint, uuid, uuid, text) from public;
grant execute on function fn_add_lesson(uuid, smallint, smallint, uuid, uuid, text) to authenticated;


create or replace function fn_update_lesson(
  p_entry_id uuid,
  p_weekday smallint,
  p_period smallint,
  p_subject_id uuid,
  p_teacher_id uuid default null,
  p_notes text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_class_id uuid;
  v_tt_id uuid;
  v_teacher uuid;
  v_weekday smallint;
  v_start time;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select c.school_id, te.class_id, te.timetable_id
    into v_school_id, v_class_id, v_tt_id
  from timetable_entries te
  join classes c on c.id = te.class_id
  where te.id = p_entry_id;

  if v_school_id is null then raise exception 'INVALID_LESSON'; end if;
  if not (fn_is_school_staff(v_school_id) or fn_has_permission('schedule.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if not exists (select 1 from subjects s where s.id = p_subject_id and s.school_id = v_school_id) then
    raise exception 'INVALID_SUBJECT';
  end if;

  v_teacher := coalesce(p_teacher_id, (select c.teacher_id from classes c where c.id = v_class_id));
  if v_teacher is null then raise exception 'SCHEDULE_TEACHER_REQUIRED'; end if;
  if not exists (select 1 from teachers t where t.id = v_teacher and t.school_id = v_school_id and t.deleted_at is null) then
    raise exception 'INVALID_TEACHER';
  end if;

  if p_weekday is null or p_weekday < 0 or p_weekday > 6 then raise exception 'INVALID_WEEKDAY'; end if;
  v_weekday := p_weekday + 1;
  if p_period is null or p_period < 1 then raise exception 'INVALID_PERIOD'; end if;

  if exists (
    select 1 from timetable_entries te
    where te.timetable_id = v_tt_id and te.class_id = v_class_id
      and te.weekday = v_weekday and coalesce(te.period, 1) = p_period
      and te.id <> p_entry_id
  ) then
    raise exception 'CLASS_SLOT_TAKEN';
  end if;

  if exists (
    select 1 from timetable_entries te
    where te.timetable_id = v_tt_id and te.teacher_id = v_teacher
      and te.weekday = v_weekday and coalesce(te.period, 1) = p_period
      and te.id <> p_entry_id
  ) then
    raise exception 'TEACHER_SCHEDULE_CONFLICT';
  end if;

  v_start := time '07:00' + ((p_period - 1) * interval '45 minutes');

  update timetable_entries
     set subject_id = p_subject_id,
         teacher_id = v_teacher,
         weekday = v_weekday,
         period = p_period,
         starts_at = v_start,
         ends_at = v_start + interval '45 minutes'
   where id = p_entry_id;

  perform fn_safe_audit(v_school_id, 'LESSON_UPDATED', 'timetable_entries', p_entry_id, null,
    jsonb_build_object('class_id', v_class_id, 'weekday', p_weekday, 'period', p_period,
                        'subject_id', p_subject_id, 'teacher_id', v_teacher, 'updated_by', auth.uid()));
end;
$$;
revoke all on function fn_update_lesson(uuid, smallint, smallint, uuid, uuid, text) from public;
grant execute on function fn_update_lesson(uuid, smallint, smallint, uuid, uuid, text) to authenticated;


create or replace function fn_delete_lesson(p_entry_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select c.school_id into v_school_id
  from timetable_entries te join classes c on c.id = te.class_id
  where te.id = p_entry_id;

  if v_school_id is null then raise exception 'INVALID_LESSON'; end if;
  if not (fn_is_school_staff(v_school_id) or fn_has_permission('schedule.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  delete from timetable_entries where id = p_entry_id;

  perform fn_safe_audit(v_school_id, 'LESSON_DELETED', 'timetable_entries', p_entry_id, null,
    jsonb_build_object('deleted_by', auth.uid()));
end;
$$;
revoke all on function fn_delete_lesson(uuid) from public;
grant execute on function fn_delete_lesson(uuid) to authenticated;


-- fn_get_class_schedule now also returns the entry id + raw ids, needed for
-- edit/delete buttons. Same filtering/permission logic as before.
drop function if exists fn_get_class_schedule(uuid);

create function fn_get_class_schedule(p_class_id uuid)
returns table(
  id uuid, weekday smallint, period smallint,
  subject_id uuid, subject_name text,
  teacher_id uuid, teacher_name text
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select c.school_id into v_school_id from classes c where c.id = p_class_id;
  if v_school_id is null then raise exception 'INVALID_CLASS'; end if;
  if not fn_is_school_member(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select te.id, (te.weekday - 1)::smallint, coalesce(te.period, 1)::smallint,
         su.id, su.name,
         t.id, p.full_name
  from timetable_entries te
  join subjects su on su.id = te.subject_id
  left join teachers t on t.id = te.teacher_id
  left join profiles p on p.id = t.profile_id
  where te.class_id = p_class_id
  order by te.weekday, coalesce(te.period, 1);
end;
$$;
revoke all on function fn_get_class_schedule(uuid) from public;
grant execute on function fn_get_class_schedule(uuid) to authenticated;


-- ============================================================================
-- SECTION B — TEACHER PROFILE (read-only aggregation RPCs)
-- ============================================================================

create or replace function fn_get_teacher_full(p_teacher_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_result jsonb;
begin
  select school_id into v_school_id from teachers where id = p_teacher_id;
  if v_school_id is null then raise exception 'INVALID_TEACHER'; end if;
  if not fn_is_school_member(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;

  select jsonb_build_object(
    'teacher_id', t.id,
    'full_name', p.full_name,
    'phone', p.phone,
    'user_number', p.user_number,
    'is_disabled', p.is_disabled,
    'employee_number', t.employee_number,
    'hourly_rate', t.hourly_rate,
    'is_active', t.deleted_at is null,
    'school_name', s.name,
    'current_year_label', (select ay.label from academic_years ay where ay.school_id = v_school_id and ay.is_current limit 1),
    'subjects_count', (select count(*) from teacher_subjects ts where ts.teacher_id = t.id),
    'classes_count', (select count(*) from teacher_classes tc where tc.teacher_id = t.id)
  ) into v_result
  from teachers t
  join profiles p on p.id = t.profile_id
  join schools s on s.id = t.school_id
  where t.id = p_teacher_id;

  return v_result;
end;
$$;
revoke all on function fn_get_teacher_full(uuid) from public;
grant execute on function fn_get_teacher_full(uuid) to authenticated;


create or replace function fn_get_teacher_schedule(p_teacher_id uuid)
returns table(
  id uuid, weekday smallint, period smallint,
  class_id uuid, class_name text, subject_name text,
  starts_at time, ends_at time
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select school_id into v_school_id from teachers where id = p_teacher_id;
  if v_school_id is null then raise exception 'INVALID_TEACHER'; end if;
  if not fn_is_school_member(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select te.id, (te.weekday - 1)::smallint, coalesce(te.period, 1)::smallint,
         c.id, c.name, su.name, te.starts_at, te.ends_at
  from timetable_entries te
  join classes c on c.id = te.class_id
  join subjects su on su.id = te.subject_id
  where te.teacher_id = p_teacher_id
  order by te.weekday, coalesce(te.period, 1);
end;
$$;
revoke all on function fn_get_teacher_schedule(uuid) from public;
grant execute on function fn_get_teacher_schedule(uuid) to authenticated;


-- ============================================================================
-- SECTION C — STUDENT PROFILE: extend fn_get_student_full (unchanged return
-- type — jsonb — so plain CREATE OR REPLACE, no drop needed) with location
-- fields (Phase 18 columns) and the latest badge's id (not just its status
-- text), so the frontend can act on issue/reissue/suspend without a 2nd query.
-- ============================================================================

create or replace function fn_get_student_full(p_student_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_result jsonb;
begin
  select school_id into v_school_id from students where id = p_student_id;
  if v_school_id is null then raise exception 'INVALID_STUDENT'; end if;
  if not (fn_is_school_member(v_school_id) or fn_is_parent_of(p_student_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  select jsonb_build_object(
    'student_id', st.id,
    'full_name', st.full_name,
    'student_number', st.student_number,
    'photo_url', st.photo_url,
    'birth_date', st.birth_date,
    'gender', st.gender,
    'is_active', st.deleted_at is null,
    'address', st.address,
    'latitude', st.latitude,
    'longitude', st.longitude,
    'location_label', st.location_label,
    'class_id', (select se.class_id from student_enrollments se
                 where se.student_id = st.id and se.status = 'ACTIVE' limit 1),
    'class_name', (select c.name from student_enrollments se
                   join classes c on c.id = se.class_id
                   where se.student_id = st.id and se.status = 'ACTIVE' limit 1),
    'level', (select c.level from student_enrollments se
              join classes c on c.id = se.class_id
              where se.student_id = st.id and se.status = 'ACTIVE' limit 1),
    'year_name', (select ay.label from student_enrollments se
                  join classes c on c.id = se.class_id
                  join academic_years ay on ay.id = c.academic_year_id
                  where se.student_id = st.id and se.status = 'ACTIVE' limit 1),
    'badge_id', (select sb.id from student_badges sb
                 where sb.student_id = st.id order by sb.created_at desc limit 1),
    'badge_status', (select sb.status::text from student_badges sb
                     where sb.student_id = st.id order by sb.created_at desc limit 1),
    'attendance_30d', (select jsonb_build_object(
                         'present', count(*) filter (where ar.status = 'present'),
                         'absent', count(*) filter (where ar.status = 'absent'),
                         'late', count(*) filter (where ar.status = 'late'),
                         'excused', count(*) filter (where ar.status = 'excused'))
                       from attendance_records ar
                       where ar.student_id = st.id
                         and ar.att_date >= current_date - 30),
    'open_incidents', (select count(*) from incidents i
                       where i.student_id = st.id and i.status = 'open'),
    'parents', coalesce((select jsonb_agg(jsonb_build_object(
                   'name', p.full_name, 'phone', p.phone, 'relationship', ps.relationship))
                 from parent_students ps
                 join parents pa on pa.id = ps.parent_id
                 join profiles p on p.id = pa.profile_id
                 where ps.student_id = st.id), '[]'::jsonb),
    'transport', fn_student_transport_info(st.id)
  ) into v_result
  from students st
  where st.id = p_student_id;

  return v_result;
end;
$$;
revoke all on function fn_get_student_full(uuid) from public;
grant execute on function fn_get_student_full(uuid) to authenticated;


-- fn_get_student_badge — latest badge row with its secure_token, needed
-- client-side to render/print the actual QR code (not just its status text).
create or replace function fn_get_student_badge(p_student_id uuid)
returns table(id uuid, status text, secure_token uuid, created_at timestamptz)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select school_id into v_school_id from students where id = p_student_id and deleted_at is null;
  if v_school_id is null then raise exception 'INVALID_STUDENT'; end if;
  if not (fn_is_school_staff(v_school_id)
          or fn_has_permission('students.badge.view', v_school_id)
          or fn_has_permission('students.badge.issue', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select sb.id, sb.status::text, sb.secure_token, sb.created_at
  from student_badges sb
  where sb.student_id = p_student_id
  order by sb.created_at desc
  limit 1;
end;
$$;
revoke all on function fn_get_student_badge(uuid) from public;
grant execute on function fn_get_student_badge(uuid) to authenticated;

-- ============================================================================
-- SECTION D — DRIVER "مساري اليوم": STOP-ORDER FIX
-- fn_list_bus_students (Phase 12) orders its roster by student full_name.
-- Item G/13 requires the stop order (bus_route_stops.sequence_order). This
-- new function reuses the exact same data/permission logic and adds the
-- ordering + per-stop coordinates (for "Open in Google Maps", no API key
-- needed — a plain https://www.google.com/maps?q=lat,lng link). The
-- original fn_list_bus_students is untouched (nothing else depends on
-- changing its order).
-- ============================================================================

create or replace function fn_list_bus_students_ordered(p_bus_id uuid, p_trip_id uuid default null)
returns table(
  student_id uuid, full_name text, student_number text,
  pickup_stop text, dropoff_stop text,
  stop_order int, stop_latitude double precision, stop_longitude double precision,
  student_latitude double precision, student_longitude double precision,
  boarded_at timestamptz, alighted_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_ctx jsonb;
begin
  select school_id into v_school_id from buses where id = p_bus_id;
  if v_school_id is null then raise exception 'INVALID_BUS'; end if;

  v_ctx := fn_driver_context();
  if not (fn_is_school_member(v_school_id)
          or (v_ctx is not null and (v_ctx->>'bus_id')::uuid = p_bus_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select sta.student_id, s.full_name, s.student_number,
         bs_pick.name, bs_drop.name,
         brs.sequence_order,
         bs_pick.latitude, bs_pick.longitude,
         s.latitude, s.longitude,
         bts.boarded_at,
         bts.dropped_at
  from student_transport_assignments sta
  join students s on s.id = sta.student_id and s.deleted_at is null
  left join bus_stops bs_pick on bs_pick.id = sta.pickup_stop_id
  left join bus_stops bs_drop on bs_drop.id = sta.dropoff_stop_id
  left join bus_route_stops brs on brs.route_id = sta.route_id and brs.stop_id = sta.pickup_stop_id
  left join bus_trip_students bts on bts.trip_id = p_trip_id and bts.student_id = sta.student_id
  where sta.bus_id = p_bus_id
    and sta.is_active
  order by coalesce(brs.sequence_order, 999999), s.full_name;
end;
$$;
revoke all on function fn_list_bus_students_ordered(uuid, uuid) from public;
grant execute on function fn_list_bus_students_ordered(uuid, uuid) to authenticated;

-- ============================================================================
-- END OF PHASE 19
-- ============================================================================
