-- ============================================================================
-- PHASE 27 — TEACHER ROSTER / ATTENDANCE READ FIX
--
-- Root cause: the final fn_get_class_attendance (phase12 v5) authorizes only
-- school members (admin/director) or holders of the 'attendance.view'
-- permission. A teacher assigned to the class holds neither, so opening the
-- class roster raised PERMISSION_DENIED and the student list never rendered.
--
-- Fix: grant the SAME "assigned teacher" authorization already used by
-- fn_teacher_class_roster (phase23) and fn_save_attendance (phase23):
--   - homeroom:   classes.teacher_id = the calling teacher's teachers.id
--   - assignment: teacher_classes(teacher_id, class_id)
-- Everyone else still needs staff role or the explicit permission — nothing
-- is opened beyond the class the teacher is genuinely assigned to.
--
-- Signature and return type are UNCHANGED (same name, same args, same
-- columns) → CREATE OR REPLACE is safe; no migration-order conflict.
-- ============================================================================

create or replace function fn_get_class_attendance(p_class_id uuid, p_date date default null)
returns table(student_id uuid, full_name text, student_number text, status text, note text)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_teacher_id uuid;
  v_assigned boolean := false;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select school_id into v_school_id from classes where id = p_class_id;
  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;

  -- Assigned-teacher detection: identical logic to fn_teacher_class_roster.
  select t.id into v_teacher_id from teachers t
  where t.school_id = v_school_id and t.profile_id = auth.uid() and t.deleted_at is null
  limit 1;
  if v_teacher_id is not null then
    v_assigned := exists (select 1 from teacher_classes tc
                          where tc.teacher_id = v_teacher_id and tc.class_id = p_class_id)
               or exists (select 1 from classes c
                          where c.id = p_class_id and c.teacher_id = v_teacher_id);
  end if;

  if not (fn_is_school_staff(v_school_id)
          or v_assigned
          or fn_has_permission('attendance.view', v_school_id)
          or fn_has_permission('attendance.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select
    st.id, st.full_name, st.student_number,
    ar.status, ar.note
  from student_enrollments se
  join students st on st.id = se.student_id and st.deleted_at is null
  left join attendance_records ar
    on ar.student_id = st.id and ar.class_id = se.class_id
   and ar.att_date = coalesce(p_date, current_date)
  where se.class_id = p_class_id
    and se.status = 'ACTIVE'
  order by st.full_name;
end;
$$;

revoke all on function fn_get_class_attendance(uuid, date) from public;
grant execute on function fn_get_class_attendance(uuid, date) to authenticated;
