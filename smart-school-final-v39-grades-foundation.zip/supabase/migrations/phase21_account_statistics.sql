-- ============================================================================
-- PHASE 21 — ACCOUNT STATISTICS (items 19-22, scoped to what's schema-
-- confirmed). ADDITIVE ONLY — three new read-only RPCs, nothing else touched.
--
-- Honest scope note: guard_checks (used for QR/manual lookups in guard.html)
-- is inserted with only school_id/student_id/method/result from the
-- client — I could not confirm it has a per-guard attribution column from
-- anywhere else in this codebase, so a per-guard "number of scans" count
-- is NOT included here (guessing that column would risk a broken function,
-- against your instruction). Guard stats below use audit_logs.actor_id
-- instead, which IS confirmed (phase9), and only covers badge actions —
-- real numbers, just narrower than "every scan". Tell me the real
-- guard_checks schema if you want scan counts added.
-- ============================================================================

create or replace function fn_get_guard_stats(p_profile_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_result jsonb;
begin
  select school_id into v_school_id from guards where profile_id = p_profile_id;
  if v_school_id is null then raise exception 'INVALID_GUARD'; end if;
  if not fn_is_school_staff(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;

  select jsonb_build_object(
    'badges_issued', count(*) filter (where action = 'BADGE_ISSUED'),
    'badges_reissued', count(*) filter (where action = 'BADGE_REISSUED'),
    'badges_suspended', count(*) filter (where action = 'BADGE_STATUS_CHANGED'),
    'students_registered', count(*) filter (where action = 'STUDENT_REGISTERED')
  ) into v_result
  from audit_logs
  where school_id = v_school_id and actor_id = p_profile_id;

  return coalesce(v_result, '{}'::jsonb);
end;
$$;
revoke all on function fn_get_guard_stats(uuid) from public;
grant execute on function fn_get_guard_stats(uuid) to authenticated;


create or replace function fn_get_driver_stats(p_driver_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_result jsonb;
begin
  select school_id into v_school_id from drivers where id = p_driver_id;
  if v_school_id is null then raise exception 'INVALID_DRIVER'; end if;
  if not fn_is_school_staff(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;

  select jsonb_build_object(
    'total_trips', (select count(*) from bus_trips where driver_id = p_driver_id),
    'completed_trips', (select count(*) from bus_trips where driver_id = p_driver_id and status = 'COMPLETED'::trip_status),
    'total_boardings', (select count(*) from bus_events where driver_id = p_driver_id and event_type = 'BOARD'::bus_event_type),
    'total_dropoffs', (select count(*) from bus_events where driver_id = p_driver_id and event_type = 'DROP_OFF'::bus_event_type)
  ) into v_result;

  return v_result;
end;
$$;
revoke all on function fn_get_driver_stats(uuid) from public;
grant execute on function fn_get_driver_stats(uuid) to authenticated;


create or replace function fn_get_parent_stats(p_parent_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select school_id into v_school_id from parents where id = p_parent_id;
  if v_school_id is null then raise exception 'INVALID_PARENT'; end if;
  if not fn_is_school_staff(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;

  return jsonb_build_object(
    'children_count', (select count(*) from parent_students where parent_id = p_parent_id)
  );
end;
$$;
revoke all on function fn_get_parent_stats(uuid) from public;
grant execute on function fn_get_parent_stats(uuid) to authenticated;

-- ============================================================================
-- END OF PHASE 21
-- ============================================================================
