-- PHASE 33 — FINAL RUNTIME FIXES
-- Mutating migration. Run ONLY on the Smart School Supabase project.
-- Phase 31 and Phase 32 must already be applied.

BEGIN;

-- ============================================================
-- 1) TEACHER: LIST GRADES WITH CLASS-ASSIGNMENT AUTHORIZATION
-- ============================================================
-- The old fn_list_student_grades allowed staff/parent/grades.view only.
-- A normal assigned teacher therefore received PERMISSION_DENIED even
-- though fn_add_grade correctly allowed that teacher to enter the grade.
-- This new function preserves the old API and adds the missing teacher path.

CREATE OR REPLACE FUNCTION public.fn_list_student_grades_for_teacher(p_student_id uuid)
RETURNS TABLE(
  grade_id uuid,
  subject_name text,
  period text,
  grade_type text,
  score numeric,
  max_score numeric,
  note text,
  teacher_name text,
  created_at timestamptz
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_id uuid;
  v_class_id uuid;
  v_teacher_id uuid;
  v_assigned boolean := false;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;

  SELECT school_id INTO v_school_id
  FROM public.students
  WHERE id = p_student_id AND deleted_at IS NULL;

  IF v_school_id IS NULL THEN
    RAISE EXCEPTION 'INVALID_STUDENT';
  END IF;

  SELECT se.class_id INTO v_class_id
  FROM public.student_enrollments se
  WHERE se.student_id = p_student_id
    AND se.status = 'ACTIVE'
  LIMIT 1;

  SELECT t.id INTO v_teacher_id
  FROM public.teachers t
  WHERE t.school_id = v_school_id
    AND t.profile_id = auth.uid()
    AND t.deleted_at IS NULL
  LIMIT 1;

  IF v_teacher_id IS NOT NULL AND v_class_id IS NOT NULL THEN
    v_assigned :=
      EXISTS (
        SELECT 1 FROM public.teacher_classes tc
        WHERE tc.teacher_id = v_teacher_id
          AND tc.class_id = v_class_id
      )
      OR EXISTS (
        SELECT 1 FROM public.classes c
        WHERE c.id = v_class_id
          AND c.teacher_id = v_teacher_id
      );
  END IF;

  IF NOT (
    public.fn_is_school_staff(v_school_id)
    OR public.fn_has_permission('grades.view', v_school_id)
    OR public.fn_is_parent_of(p_student_id)
    OR v_assigned
  ) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  RETURN QUERY
  SELECT
    g.id,
    su.name,
    g.period,
    g.grade_type,
    g.score,
    g.max_score,
    g.note,
    (
      SELECT p.full_name
      FROM public.teachers t
      JOIN public.profiles p ON p.id = t.profile_id
      WHERE t.id = g.teacher_id
    ),
    g.created_at
  FROM public.student_grades g
  LEFT JOIN public.subjects su ON su.id = g.subject_id
  WHERE g.student_id = p_student_id
  ORDER BY g.created_at DESC
  LIMIT 200;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_list_student_grades_for_teacher(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_list_student_grades_for_teacher(uuid) TO authenticated;


-- ============================================================
-- 2) ADMIN: DEDICATED SCHOOL-LOCATION SAVE RPC
-- ============================================================
-- Uses explicit school_id supplied by the authenticated admin page,
-- then independently verifies that the caller is admin/director/superadmin
-- for that exact school. This removes dependence on role-selection ambiguity.

CREATE OR REPLACE FUNCTION public.fn_admin_save_school_location(
  p_school_id uuid,
  p_latitude double precision,
  p_longitude double precision,
  p_location_label text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;

  IF p_school_id IS NULL THEN
    RAISE EXCEPTION 'INVALID_SCHOOL';
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM public.schools s
    WHERE s.id = p_school_id
  ) THEN
    RAISE EXCEPTION 'INVALID_SCHOOL';
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM public.user_roles ur
    WHERE ur.profile_id = auth.uid()
      AND (
        ur.role::text = 'superadmin'
        OR (ur.school_id = p_school_id AND ur.role::text IN ('admin','director'))
      )
  ) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  IF p_latitude IS NULL OR p_latitude < -90 OR p_latitude > 90 THEN
    RAISE EXCEPTION 'INVALID_LATITUDE';
  END IF;

  IF p_longitude IS NULL OR p_longitude < -180 OR p_longitude > 180 THEN
    RAISE EXCEPTION 'INVALID_LONGITUDE';
  END IF;

  UPDATE public.schools
  SET latitude = p_latitude,
      longitude = p_longitude,
      location_label = COALESCE(
        NULLIF(trim(p_location_label), ''),
        location_label
      )
  WHERE id = p_school_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'INVALID_SCHOOL';
  END IF;

  -- Audit is deliberately best-effort and cannot block the save.
  PERFORM public.fn_safe_audit(
    p_school_id,
    'SCHOOL_LOCATION_UPDATED',
    'schools',
    p_school_id,
    NULL,
    jsonb_build_object(
      'latitude', p_latitude,
      'longitude', p_longitude,
      'location_label', p_location_label,
      'updated_by', auth.uid()
    )
  );
END;
$$;

REVOKE ALL
ON FUNCTION public.fn_admin_save_school_location(uuid,double precision,double precision,text)
FROM PUBLIC;

GRANT EXECUTE
ON FUNCTION public.fn_admin_save_school_location(uuid,double precision,double precision,text)
TO authenticated;


-- ============================================================
-- 3) ENSURE LOCATION COLUMNS EXIST
-- ============================================================
ALTER TABLE public.schools
  ADD COLUMN IF NOT EXISTS latitude double precision,
  ADD COLUMN IF NOT EXISTS longitude double precision,
  ADD COLUMN IF NOT EXISTS location_label text;


COMMIT;
