-- PHASE 37 — historical boarding/drop-off map points + event GPS capture + photo support
-- MUTATING. Run once on the correct Smart School project.
-- No timezone/time changes. No data deletion. Existing enum values are untouched.

-- 1) Capture the driver's latest GPS position when a boarding/drop-off event is recorded.
-- Existing signature and event enum mapping are preserved.
CREATE OR REPLACE FUNCTION public.fn_record_trip_event(
  p_trip_id uuid,
  p_student_id uuid,
  p_event_type text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_trip public.bus_trips%rowtype;
  v_driver_id uuid;
  v_type public.bus_event_type;
  v_boarded_at timestamptz;
  v_dropped_at timestamptz;
  v_lat double precision;
  v_lng double precision;
  v_location_text text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;

  SELECT * INTO v_trip FROM public.bus_trips WHERE id = p_trip_id;
  IF v_trip.id IS NULL THEN RAISE EXCEPTION 'INVALID_TRIP'; END IF;

  SELECT d.id INTO v_driver_id
  FROM public.drivers d
  WHERE d.profile_id = auth.uid() AND d.deleted_at IS NULL
  LIMIT 1;
  IF v_driver_id IS NULL OR v_trip.driver_id <> v_driver_id THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM public.student_transport_assignments sta
    WHERE sta.student_id = p_student_id
      AND sta.bus_id = v_trip.bus_id
      AND sta.is_active
  ) THEN
    RAISE EXCEPTION 'STUDENT_NOT_ON_THIS_ROUTE';
  END IF;

  v_type := CASE lower(trim(coalesce(p_event_type, '')))
    WHEN 'board' THEN 'BOARD'::public.bus_event_type
    WHEN 'alight' THEN 'DROP_OFF'::public.bus_event_type
    WHEN 'drop_off' THEN 'DROP_OFF'::public.bus_event_type
    WHEN 'dropoff' THEN 'DROP_OFF'::public.bus_event_type
    ELSE NULL
  END;
  IF v_type IS NULL THEN RAISE EXCEPTION 'INVALID_EVENT_TYPE'; END IF;

  INSERT INTO public.bus_trip_students (trip_id, student_id)
  VALUES (p_trip_id, p_student_id)
  ON CONFLICT (trip_id, student_id) DO NOTHING;

  SELECT boarded_at, dropped_at INTO v_boarded_at, v_dropped_at
  FROM public.bus_trip_students
  WHERE trip_id = p_trip_id AND student_id = p_student_id;

  IF v_type = 'BOARD'::public.bus_event_type THEN
    IF v_boarded_at IS NOT NULL THEN RAISE EXCEPTION 'ALREADY_BOARDED'; END IF;
    UPDATE public.bus_trip_students SET boarded_at = now()
    WHERE trip_id = p_trip_id AND student_id = p_student_id;
  ELSE
    IF v_boarded_at IS NULL THEN RAISE EXCEPTION 'NOT_BOARDED_YET'; END IF;
    IF v_dropped_at IS NOT NULL THEN RAISE EXCEPTION 'ALREADY_DROPPED'; END IF;
    UPDATE public.bus_trip_students SET dropped_at = now()
    WHERE trip_id = p_trip_id AND student_id = p_student_id;
  END IF;

  -- Use the most recent GPS point of this exact active trip, if available.
  SELECT bll.latitude, bll.longitude
    INTO v_lat, v_lng
  FROM public.bus_last_locations bll
  WHERE bll.bus_id = v_trip.bus_id
    AND bll.trip_id = p_trip_id
  ORDER BY bll.recorded_at DESC
  LIMIT 1;

  IF v_lat IS NOT NULL AND v_lng IS NOT NULL THEN
    v_location_text := CASE
      WHEN v_type = 'BOARD'::public.bus_event_type THEN 'موقع الصعود (GPS)'
      ELSE 'موقع النزول (GPS)'
    END;
  ELSE
    v_location_text := CASE
      WHEN v_type = 'BOARD'::public.bus_event_type THEN 'نقطة الصعود المسجلة'
      ELSE 'نقطة النزول المسجلة'
    END;
  END IF;

  INSERT INTO public.bus_events
    (trip_id, student_id, driver_id, event_type, source, latitude, longitude, location_text)
  VALUES
    (p_trip_id, p_student_id, v_driver_id, v_type, 'MANUAL'::public.record_source,
     v_lat, v_lng, v_location_text);

  PERFORM public.fn_safe_audit(
    v_trip.school_id,
    CASE WHEN v_type = 'BOARD'::public.bus_event_type
      THEN 'STUDENT_BOARDED' ELSE 'STUDENT_DROPPED_OFF' END,
    'bus_trip_students', p_student_id, NULL,
    jsonb_build_object('trip_id', p_trip_id, 'driver_id', v_driver_id,
                       'latitude', v_lat, 'longitude', v_lng)
  );
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_record_trip_event(uuid,uuid,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_record_trip_event(uuid,uuid,text) TO authenticated;

-- 2) Return map points for the selected historical trip.
-- Event GPS is preferred. When an older event has no GPS coordinates, the
-- appropriate configured pickup/drop-off stop is used as a truthful fallback.
DROP FUNCTION IF EXISTS public.fn_get_trip_boarding_dropoff_points(uuid);
CREATE FUNCTION public.fn_get_trip_boarding_dropoff_points(p_trip_id uuid)
RETURNS TABLE(
  point_id uuid,
  point_type text,
  student_id uuid,
  student_name text,
  latitude double precision,
  longitude double precision,
  recorded_at timestamptz,
  source text
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_school_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  SELECT bt.school_id INTO v_school_id FROM public.bus_trips bt WHERE bt.id = p_trip_id;
  IF v_school_id IS NULL THEN RAISE EXCEPTION 'INVALID_TRIP'; END IF;
  IF NOT public.fn_is_school_staff(v_school_id) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;

  RETURN QUERY
  SELECT
    be.id,
    CASE WHEN be.event_type = 'BOARD'::public.bus_event_type THEN 'BOARD' ELSE 'DROP_OFF' END,
    be.student_id,
    s.full_name,
    be.latitude,
    be.longitude,
    be.created_at,
    'EVENT_GPS'::text
  FROM public.bus_events be
  JOIN public.students s ON s.id = be.student_id
  WHERE be.trip_id = p_trip_id
    AND be.latitude IS NOT NULL
    AND be.longitude IS NOT NULL

  UNION ALL

  SELECT
    gen_random_uuid(),
    'BOARD'::text,
    sta.student_id,
    s.full_name,
    CASE WHEN bt.direction = 'TO_SCHOOL'::public.trip_direction
         THEN bsp.latitude ELSE sch.latitude END,
    CASE WHEN bt.direction = 'TO_SCHOOL'::public.trip_direction
         THEN bsp.longitude ELSE sch.longitude END,
    COALESCE(bts.boarded_at, bt.starts_at),
    'ASSIGNED_STOP'::text
  FROM public.bus_trips bt
  JOIN public.bus_trip_students bts ON bts.trip_id = bt.id
  JOIN public.student_transport_assignments sta
    ON sta.student_id = bts.student_id AND sta.bus_id = bt.bus_id AND sta.is_active
  JOIN public.students s ON s.id = sta.student_id
  LEFT JOIN public.bus_stops bsp ON bsp.id = sta.pickup_stop_id
  JOIN public.schools sch ON sch.id = bt.school_id
  WHERE bt.id = p_trip_id
    AND bts.boarded_at IS NOT NULL
    AND NOT EXISTS (
      SELECT 1 FROM public.bus_events be
      WHERE be.trip_id = p_trip_id
        AND be.student_id = sta.student_id
        AND be.event_type = 'BOARD'::public.bus_event_type
        AND be.latitude IS NOT NULL AND be.longitude IS NOT NULL
    )
    AND (
      (bt.direction = 'TO_SCHOOL'::public.trip_direction AND bsp.latitude IS NOT NULL AND bsp.longitude IS NOT NULL)
      OR (bt.direction = 'TO_HOME'::public.trip_direction AND sch.latitude IS NOT NULL AND sch.longitude IS NOT NULL)
    )

  UNION ALL

  SELECT
    gen_random_uuid(),
    'DROP_OFF'::text,
    sta.student_id,
    s.full_name,
    CASE WHEN bt.direction = 'TO_SCHOOL'::public.trip_direction
         THEN sch.latitude ELSE bsd.latitude END,
    CASE WHEN bt.direction = 'TO_SCHOOL'::public.trip_direction
         THEN sch.longitude ELSE bsd.longitude END,
    COALESCE(bts.dropped_at, bt.ends_at),
    'ASSIGNED_STOP'::text
  FROM public.bus_trips bt
  JOIN public.bus_trip_students bts ON bts.trip_id = bt.id
  JOIN public.student_transport_assignments sta
    ON sta.student_id = bts.student_id AND sta.bus_id = bt.bus_id AND sta.is_active
  JOIN public.students s ON s.id = sta.student_id
  LEFT JOIN public.bus_stops bsd ON bsd.id = sta.dropoff_stop_id
  JOIN public.schools sch ON sch.id = bt.school_id
  WHERE bt.id = p_trip_id
    AND bts.dropped_at IS NOT NULL
    AND NOT EXISTS (
      SELECT 1 FROM public.bus_events be
      WHERE be.trip_id = p_trip_id
        AND be.student_id = sta.student_id
        AND be.event_type = 'DROP_OFF'::public.bus_event_type
        AND be.latitude IS NOT NULL AND be.longitude IS NOT NULL
    )
    AND (
      (bt.direction = 'TO_SCHOOL'::public.trip_direction AND sch.latitude IS NOT NULL AND sch.longitude IS NOT NULL)
      OR (bt.direction = 'TO_HOME'::public.trip_direction AND bsd.latitude IS NOT NULL AND bsd.longitude IS NOT NULL)
    );
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_get_trip_boarding_dropoff_points(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_get_trip_boarding_dropoff_points(uuid) TO authenticated;
