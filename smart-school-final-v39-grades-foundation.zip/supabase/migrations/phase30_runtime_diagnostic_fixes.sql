-- PHASE 30 — Runtime fixes discovered by v14 Diagnostic
-- Safe/idempotent: fixes schema/function mismatches exposed by real user runtime errors.
-- Does not touch time/timezone, trip enums, trip data, or existing business rows.

BEGIN;

-- 1) Audit trigger compatibility: live audit_logs has no actor_id, while
--    the existing audit trigger and audit RPCs expect it.
ALTER TABLE public.audit_logs
  ADD COLUMN IF NOT EXISTS actor_id uuid;

-- 2) Keep BOTH map functions, but remove the DEFAULT from the UUID overload.
--    With both fn_get_map_overview() and fn_get_map_overview(uuid DEFAULT NULL),
--    PostgREST cannot choose the best candidate for a zero-argument RPC.
create or replace function fn_get_map_overview(p_school_id uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_school_id uuid;
  v_super boolean;
  v_result jsonb;
begin
  select exists (select 1 from user_roles where profile_id = auth.uid() and role = 'superadmin')
    into v_super;
  if v_super then
    if p_school_id is null then raise exception 'SCHOOL_REQUIRED'; end if;
    if not exists (select 1 from schools where id = p_school_id) then
      raise exception 'SCHOOL_NOT_FOUND';
    end if;
    v_school_id := p_school_id;          -- explicit, user-chosen school
  else
    select ur.school_id into v_school_id from user_roles ur
    where ur.profile_id = auth.uid() and ur.role in ('admin', 'director') limit 1;
    if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;
  end if;

  select jsonb_build_object(
    'school', (
      select jsonb_build_object('name', s.name, 'latitude', s.latitude,
               'longitude', s.longitude, 'location_label', s.location_label)
      from schools s where s.id = v_school_id),
    'homes', coalesce((
      select jsonb_agg(jsonb_build_object(
               'student_id', st.id, 'full_name', st.full_name, 'class_name', cls.name,
               'latitude', st.latitude, 'longitude', st.longitude,
               'location_label', st.location_label) order by st.full_name)
      from students st
      left join student_enrollments se on se.student_id = st.id and se.status = 'ACTIVE'
      left join classes cls on cls.id = se.class_id
      where st.school_id = v_school_id and st.deleted_at is null
        and st.latitude is not null and st.longitude is not null
      limit 1500), '[]'::jsonb),
    'buses', coalesce((
      select jsonb_agg(jsonb_build_object(
               'bus_id', b.id, 'bus_code', b.code, 'bus_plate', b.plate_number,
               'driver_name', prof.full_name, 'has_active_trip', t.id is not null,
               'trip_id', t.id,
               'direction', case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup'
                                 when t.direction = 'TO_HOME'::trip_direction then 'dropoff' else null end,
               'latitude', coalesce(ll_trip.latitude, ll_last.latitude),
               'longitude', coalesce(ll_trip.longitude, ll_last.longitude),
               'speed', ll_trip.speed,
               'recorded_at', coalesce(ll_trip.recorded_at, ll_last.recorded_at),
               'live', ll_trip.recorded_at is not null,
               'total_students', case when t.id is not null then
                 (select count(*) from student_transport_assignments sta
                   where sta.bus_id = b.id and sta.is_active)::int else null end,
               'boarded_count', case when t.id is not null then
                 (select count(*) from bus_trip_students bts
                   where bts.trip_id = t.id and bts.boarded_at is not null)::int else null end,
               'dropped_count', case when t.id is not null then
                 (select count(*) from bus_trip_students bts
                   where bts.trip_id = t.id and bts.dropped_at is not null)::int else null end
             ) order by b.code)
      from buses b
      left join bus_trips t on t.bus_id = b.id and t.status = 'ACTIVE'::trip_status
      left join bus_last_locations ll_trip on ll_trip.bus_id = b.id and ll_trip.trip_id = t.id
      left join lateral (
        select ll.latitude, ll.longitude, ll.recorded_at from bus_last_locations ll
        where ll.bus_id = b.id order by ll.recorded_at desc limit 1
      ) ll_last on t.id is null
      left join drivers d on d.id = coalesce(t.driver_id, b.driver_id)
      left join profiles prof on prof.id = d.profile_id
      where b.school_id = v_school_id), '[]'::jsonb),
    'stops', coalesce((
      select jsonb_agg(jsonb_build_object(
               'stop_id', bs.id, 'name', bs.name, 'latitude', bs.latitude,
               'longitude', bs.longitude, 'route_name', br.name)
             order by br.name, rs.sequence_order)
      from bus_route_stops rs
      join bus_stops bs on bs.id = rs.stop_id
      join bus_routes br on br.id = rs.route_id
      where br.school_id = v_school_id
        and bs.latitude is not null and bs.longitude is not null), '[]'::jsonb)
  ) into v_result;
  return v_result;
end; $$;
revoke all on function fn_get_map_overview(uuid) from public;
grant execute on function fn_get_map_overview(uuid) to authenticated;

-- 3) Avoid PL/pgSQL OUT-parameter/column-name ambiguity in badge retrieval.
create or replace function fn_get_student_badge(p_student_id uuid)
returns table(id uuid, status text, secure_token uuid, created_at timestamptz)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select school_id into v_school_id from students where id = p_student_id and deleted_at is null;
  if v_school_id is null then raise exception 'INVALID_STUDENT'; end if;
  if not (fn_is_school_staff(v_school_id)
          or fn_has_permission('students.badge.view', v_school_id)
          or fn_has_permission('students.badge.issue', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select x.badge_id, x.badge_status, x.badge_token, x.badge_created_at
  from (
    select sb.id as badge_id, sb.status::text as badge_status,
           sb.secure_token as badge_token, sb.created_at as badge_created_at
    from student_badges sb
    where sb.student_id = p_student_id
    order by sb.created_at desc
    limit 1
  ) x;
end;
$$;
revoke all on function fn_get_student_badge(uuid) from public;
grant execute on function fn_get_student_badge(uuid) to authenticated;

COMMIT;
