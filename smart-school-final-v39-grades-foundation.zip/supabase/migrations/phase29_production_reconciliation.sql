-- ============================================================================
-- PHASE 29 — PRODUCTION RECONCILIATION (audit-driven)
--
-- Basis: READ-ONLY production audit confirmed the live database state:
--   PASS : fn_record_trip_event (DROP_OFF), badge/guard RPCs, enum DROP_OFF
--   FAIL : fn_get_map_overview()            → zero-arg overload MISSING
--          fn_update_school_location        → MISSING entirely
--          fn_get_class_attendance          → 12-era authorization (no
--                                               teacher assignment logic)
--          fn_list_bus_students_ordered     → 12-column version live
--                                               (return-type change blocks
--                                               CREATE OR REPLACE → DROP+CREATE)
--          fn_list_school_trips             → MISSING entirely
--
-- This migration reconciles EXACTLY those five objects and nothing else.
-- It does NOT touch fn_record_trip_event, enums, badge/guard RPCs, RLS,
-- tables, time/timezone logic, or any frontend file.
--
-- Every implementation below is copied VERBATIM from the authoritative repo
-- migrations (phase25 / phase20 / phase23-assignment logic / phase27 / phase28)
-- — no invented business logic, columns, or permissions.
--
-- Safety: pre-flight DO blocks verify the audited baseline and abort the
-- whole migration (transactional) on any unexpected state. The roster
-- DROP is preceded by a pg_depend safety check — CASCADE is NEVER used.
-- ============================================================================

-- ============================================================================
-- §0 — PRE-FLIGHT ASSERTIONS (abort the whole migration on unexpected state)
-- ============================================================================

-- 0.1 The (uuid) map-overview overload must already exist (audited baseline).
do $$
begin
  if not exists (
    select 1 from pg_proc
    where pronamespace = 'public'::regnamespace
      and proname = 'fn_get_map_overview'
      and pg_get_function_identity_arguments(oid) = 'p_school_id uuid'
  ) then
    raise exception 'PREFLIGHT FAILED: fn_get_map_overview(uuid) baseline overload not found — production state differs from the audited baseline. Aborting.';
  end if;
end $$;

-- 0.2 fn_update_school_location: must be missing, or already have exactly
--     the phase20 signature (idempotent re-run). Any other shape = abort.
do $$
begin
  if exists (
    select 1 from pg_proc
    where pronamespace = 'public'::regnamespace
      and proname = 'fn_update_school_location'
      and pg_get_function_identity_arguments(oid)
          <> 'p_latitude double precision, p_longitude double precision, p_location_label text'
  ) then
    raise exception 'PREFLIGHT FAILED: fn_update_school_location exists with an unexpected signature. Aborting.';
  end if;
end $$;

-- 0.3 fn_get_class_attendance must exist with the audited signature.
do $$
begin
  if not exists (
    select 1 from pg_proc
    where pronamespace = 'public'::regnamespace
      and proname = 'fn_get_class_attendance'
      and pg_get_function_identity_arguments(oid) = 'p_class_id uuid, p_date date'
  ) then
    raise exception 'PREFLIGHT FAILED: fn_get_class_attendance(uuid,date) not found — production state differs from the audited baseline. Aborting.';
  end if;
end $$;

-- 0.4 fn_list_bus_students_ordered(uuid,uuid) must exist AND its live return
--     shape must be EXACTLY the audited 12-column baseline before the DROP.
--     Catalog-accurate: OUT parameters are read from pg_proc.proargmodes /
--     proargnames (no naive comma-splitting of the return-type text — immune
--     to typmod commas and type-alias rendering).
do $$
declare
  v_oid oid;
  v_actual text[];
  v_expected text[] := array[
    'student_id','full_name','student_number',
    'pickup_stop','dropoff_stop','stop_order',
    'stop_latitude','stop_longitude','student_latitude','student_longitude',
    'boarded_at','alighted_at'
  ];   -- audited 12-column production baseline, in exact order
begin
  select p.oid into v_oid
  from pg_proc p
  where p.pronamespace = 'public'::regnamespace
    and p.proname = 'fn_list_bus_students_ordered'
    and p.pronargs = 2
    and p.proargtypes = '2950 2950'::oidvector;      -- (uuid, uuid) — alias-proof
  if v_oid is null then
    raise exception 'PREFLIGHT FAILED: fn_list_bus_students_ordered(uuid,uuid) not found. Aborting.';
  end if;
  select array_agg(u.col_name order by u.ord) into v_actual
  from pg_proc p
  cross join lateral unnest(p.proargnames, p.proargmodes)
       with ordinality as u(col_name, col_mode, ord)
  where p.oid = v_oid and u.col_mode in ('o','t');  -- 't' = RETURNS TABLE columns
  if v_actual is distinct from v_expected then
    raise exception 'PREFLIGHT FAILED: fn_list_bus_students_ordered return shape is NOT the audited 12-column baseline (found % column(s): %). Aborting BEFORE any change.', coalesce(array_length(v_actual, 1), 0), coalesce(array_to_string(v_actual, ', '), '(none)');
  end if;
end $$;

-- 0.5 Roster dependency safety check — MUST pass BEFORE the DROP.
--     Any non-internal dependent object (view, function, etc.) = abort.
do $$
declare
  v_oid oid;
  v_deps int;
begin
  select oid into v_oid
  from pg_proc
  where pronamespace = 'public'::regnamespace
    and proname = 'fn_list_bus_students_ordered'
    and pg_get_function_identity_arguments(oid) = 'p_bus_id uuid, p_trip_id uuid';
  select count(*) into v_deps
  from pg_depend
  where refobjid = v_oid
    and refclassid = 'pg_proc'::regclass
    and deptype <> 'i';                 -- ignore internal dependencies only
  if v_deps > 0 then
    raise exception 'UNSAFE DEPENDENCY: % object(s) depend on fn_list_bus_students_ordered(uuid,uuid). Aborting BEFORE drop. Inspect pg_depend manually and reconcile first.', v_deps;
  end if;
end $$;

-- 0.6 fn_list_school_trips: target ONLY the exact intended signature
--     (p_bus_id uuid, p_from date, p_to date, p_limit integer, p_offset integer)
--     matched via catalog argument-type oids (alias-proof: int/integer/int4
--     are all oid 23). Other overloads of the same name are NOT the target
--     and are ignored here. If the exact signature exists, its OUT shape must
--     be compatible with the phase28 implementation (12 columns, last one
--     total_count) — otherwise abort. If missing, creation proceeds.
do $$
declare
  v_oid oid;
  v_cols text[];
begin
  select p.oid into v_oid
  from pg_proc p
  where p.pronamespace = 'public'::regnamespace
    and p.proname = 'fn_list_school_trips'
    and p.pronargs = 5
    and p.proargtypes = '2950 1082 1082 23 23'::oidvector;  -- uuid,date,date,int,int
  if v_oid is not null then
    select array_agg(u.col_name order by u.ord) into v_cols
    from pg_proc p
    cross join lateral unnest(p.proargnames, p.proargmodes)
         with ordinality as u(col_name, col_mode, ord)
    where p.oid = v_oid and u.col_mode in ('o','t');  -- 't' = RETURNS TABLE columns
    if coalesce(array_length(v_cols, 1), 0) <> 12
       or v_cols[array_length(v_cols, 1)] <> 'total_count' then
      raise exception 'PREFLIGHT FAILED: fn_list_school_trips exists with the exact intended signature but an incompatible return shape (expected 12 columns ending with total_count; found %). Aborting.', coalesce(array_to_string(v_cols, ', '), '(none)');
    end if;
    raise notice 'phase29: fn_list_school_trips already present with the exact signature and a compatible shape — re-run refreshes it with the phase28 body.';
  end if;
end $$;

-- ============================================================================
-- PART A — TRUE zero-argument overload for admin/director
-- Source: phase25_transport_parent_audit_schedule.sql (verbatim).
-- The existing (uuid) overload is NOT touched.
-- ============================================================================
create or replace function fn_get_map_overview()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_result jsonb;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director')
  limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  select jsonb_build_object(
    'school', (
      select jsonb_build_object(
        'name', s.name, 'latitude', s.latitude,
        'longitude', s.longitude, 'location_label', s.location_label
      )
      from schools s where s.id = v_school_id
    ),
    'homes', coalesce((
      select jsonb_agg(jsonb_build_object(
               'student_id', st.id, 'full_name', st.full_name,
               'class_name', cls.name, 'latitude', st.latitude,
               'longitude', st.longitude, 'location_label', st.location_label
             ) order by st.full_name)
      from students st
      left join student_enrollments se
        on se.student_id = st.id and se.status = 'ACTIVE'
      left join classes cls on cls.id = se.class_id
      where st.school_id = v_school_id
        and st.deleted_at is null
        and st.latitude is not null
        and st.longitude is not null
      limit 1500
    ), '[]'::jsonb),
    'buses', coalesce((
      select jsonb_agg(jsonb_build_object(
               'bus_id', b.id, 'bus_code', b.code, 'bus_plate', b.plate_number,
               'driver_name', prof.full_name,
               'has_active_trip', t.id is not null,
               'trip_id', t.id,
               'direction', case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup'
                                 when t.direction = 'TO_HOME'::trip_direction then 'dropoff'
                                 else null end,
               'latitude', coalesce(ll_trip.latitude, ll_last.latitude),
               'longitude', coalesce(ll_trip.longitude, ll_last.longitude),
               'speed', ll_trip.speed,
               'recorded_at', coalesce(ll_trip.recorded_at, ll_last.recorded_at),
               'live', ll_trip.recorded_at is not null,
               'total_students', case when t.id is not null then
                 (select count(*) from student_transport_assignments sta
                   where sta.bus_id = b.id and sta.is_active)::int
                 else null end,
               'boarded_count', case when t.id is not null then
                 (select count(*) from bus_trip_students bts
                   where bts.trip_id = t.id and bts.boarded_at is not null)::int
                 else null end,
               'dropped_count', case when t.id is not null then
                 (select count(*) from bus_trip_students bts
                   where bts.trip_id = t.id and bts.dropped_at is not null)::int
                 else null end
             ) order by b.code)
      from buses b
      left join bus_trips t on t.bus_id = b.id and t.status = 'ACTIVE'::trip_status
      left join bus_last_locations ll_trip on ll_trip.bus_id = b.id and ll_trip.trip_id = t.id
      left join lateral (
        select ll.latitude, ll.longitude, ll.recorded_at
        from bus_last_locations ll
        where ll.bus_id = b.id
        order by ll.recorded_at desc
        limit 1
      ) ll_last on t.id is null
      left join drivers d on d.id = coalesce(t.driver_id, b.driver_id)
      left join profiles prof on prof.id = d.profile_id
      where b.school_id = v_school_id
    ), '[]'::jsonb),
    'stops', coalesce((
      select jsonb_agg(jsonb_build_object(
               'stop_id', bs.id, 'name', bs.name,
               'latitude', bs.latitude, 'longitude', bs.longitude,
               'route_name', br.name
             ) order by br.name, rs.sequence_order)
      from bus_route_stops rs
      join bus_stops bs on bs.id = rs.stop_id
      join bus_routes br on br.id = rs.route_id
      where br.school_id = v_school_id
        and bs.latitude is not null
        and bs.longitude is not null
    ), '[]'::jsonb)
  ) into v_result;

  return v_result;
end;
$$;

revoke all on function fn_get_map_overview() from public;
grant execute on function fn_get_map_overview() to authenticated;

-- ============================================================================
-- PART B — missing fn_update_school_location
-- Source: phase20_badge_maps_transport_driver.sql (verbatim, incl. audit).
-- ============================================================================
create or replace function fn_update_school_location(
  p_latitude double precision,
  p_longitude double precision,
  p_location_label text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  if p_latitude < -90 or p_latitude > 90 then raise exception 'INVALID_LATITUDE'; end if;
  if p_longitude < -180 or p_longitude > 180 then raise exception 'INVALID_LONGITUDE'; end if;

  update schools
     set latitude = p_latitude, longitude = p_longitude,
         location_label = coalesce(p_location_label, location_label)
   where id = v_school_id;

  perform fn_safe_audit(v_school_id, 'SCHOOL_LOCATION_UPDATED', 'schools', v_school_id, null,
    jsonb_build_object('latitude', p_latitude, 'longitude', p_longitude, 'updated_by', auth.uid()));
end;
$$;

revoke all on function fn_update_school_location(double precision, double precision, text) from public;
grant execute on function fn_update_school_location(double precision, double precision, text) to authenticated;

-- ============================================================================
-- PART C — fn_get_class_attendance: add assigned-teacher authorization
-- Same name/signature/defaults/return columns/data query/STABLE/SECURITY
-- DEFINER/search_path. ONLY the authorization block changes: the original
-- (member OR attendance.view) is preserved and NARROWLY extended with the
-- exact teacher-assignment mechanism accepted by phase23/fn_save_attendance
-- (teachers → teacher_classes OR classes.teacher_id, scoped to the class's
-- school). No teacher gains access to unassigned classes or other schools.
-- ============================================================================
create or replace function fn_get_class_attendance(p_class_id uuid, p_date date default null)
returns table(student_id uuid, full_name text, student_number text, status text, note text)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_teacher_id uuid;
  v_teacher_assigned boolean := false;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select school_id into v_school_id from classes where id = p_class_id;
  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;

  -- Assigned-teacher detection: identical to phase23 fn_save_attendance.
  select t.id into v_teacher_id
  from teachers t
  where t.school_id = v_school_id and t.profile_id = auth.uid() and t.deleted_at is null
  limit 1;

  if v_teacher_id is not null then
    v_teacher_assigned := exists (select 1 from teacher_classes tc
                                   where tc.teacher_id = v_teacher_id and tc.class_id = p_class_id)
                       or exists (select 1 from classes c
                                  where c.id = p_class_id and c.teacher_id = v_teacher_id);
  end if;

  -- Original production authorization (member OR attendance.view) preserved;
  -- only the genuinely-assigned teacher is added. Nothing is weakened.
  if not (fn_is_school_member(v_school_id)
          or v_teacher_assigned
          or fn_has_permission('attendance.view', v_school_id)
          or fn_has_permission('attendance.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select
    st.id, st.full_name, st.student_number,
    ar.status, ar.note
  from student_enrollments se
  join students st on st.id = se.student_id and st.deleted_at is null
  left join attendance_records ar
    on ar.student_id = st.id and ar.class_id = se.class_id
   and ar.att_date = coalesce(p_date, current_date)
  where se.class_id = p_class_id
    and se.status = 'ACTIVE'
  order by st.full_name;
end;
$$;

revoke all on function fn_get_class_attendance(uuid, date) from public;
grant execute on function fn_get_class_attendance(uuid, date) to authenticated;

-- ============================================================================
-- PART D — roster 12→13 columns. DROP+CREATE is required (return-type
-- change); CASCADE is NEVER used and the dependency check in §0.5 already
-- ran BEFORE this point. Source: phase20 (verbatim 13-column implementation;
-- photo_url comes from students.photo_url — the real project schema).
-- ============================================================================
drop function public.fn_list_bus_students_ordered(uuid, uuid);

create function fn_list_bus_students_ordered(p_bus_id uuid, p_trip_id uuid default null)
returns table(
  student_id uuid, full_name text, student_number text, photo_url text,
  pickup_stop text, dropoff_stop text,
  stop_order int, stop_latitude double precision, stop_longitude double precision,
  student_latitude double precision, student_longitude double precision,
  boarded_at timestamptz, alighted_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_ctx jsonb;
  v_direction trip_direction;
begin
  select school_id into v_school_id from buses where id = p_bus_id;
  if v_school_id is null then raise exception 'INVALID_BUS'; end if;

  v_ctx := fn_driver_context();
  if not (fn_is_school_member(v_school_id)
          or (v_ctx is not null and (v_ctx->>'bus_id')::uuid = p_bus_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if p_trip_id is not null then
    select direction into v_direction from bus_trips where id = p_trip_id;
  end if;

  return query
  select sta.student_id, s.full_name, s.student_number, s.photo_url,
         coalesce(bs_pick.name,
           case when v_direction = 'TO_SCHOOL'::trip_direction or v_direction is null
                then 'منزل التلميذ' else (select sc.name from schools sc where sc.id = v_school_id) end),
         coalesce(bs_drop.name,
           case when v_direction = 'TO_SCHOOL'::trip_direction or v_direction is null
                then (select sc.name from schools sc where sc.id = v_school_id) else 'منزل التلميذ' end),
         brs.sequence_order,
         bs_pick.latitude, bs_pick.longitude,
         s.latitude, s.longitude,
         bts.boarded_at,
         bts.dropped_at
  from student_transport_assignments sta
  join students s on s.id = sta.student_id and s.deleted_at is null
  left join bus_stops bs_pick on bs_pick.id = sta.pickup_stop_id
  left join bus_stops bs_drop on bs_drop.id = sta.dropoff_stop_id
  left join bus_route_stops brs on brs.route_id = sta.route_id and brs.stop_id = sta.pickup_stop_id
  left join bus_trip_students bts on bts.trip_id = p_trip_id and bts.student_id = sta.student_id
  where sta.bus_id = p_bus_id
    and sta.is_active
  order by coalesce(brs.sequence_order, 999999), s.full_name;
end;
$$;

revoke all on function fn_list_bus_students_ordered(uuid, uuid) from public;
grant execute on function fn_list_bus_students_ordered(uuid, uuid) to authenticated;

-- ============================================================================
-- PART E — missing fn_list_school_trips
-- Source: phase28_school_trip_history.sql (verbatim). School scope derives
-- from the CALLER's user_roles row; bus filter validated against the same
-- school; fn_is_school_staff authorization (same as fn_list_bus_trips).
-- ============================================================================
create or replace function fn_list_school_trips(
  p_bus_id uuid default null,
  p_from date default null,
  p_to date default null,
  p_limit int default 25,
  p_offset int default 0
)
returns table(
  trip_id uuid, bus_id uuid, bus_label text, driver_name text,
  route_name text, direction text, status text,
  starts_at timestamptz, ends_at timestamptz,
  boarded_count int, dropped_count int, total_count bigint
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select school_id into v_school_id from user_roles
  where profile_id = auth.uid() limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;
  if not fn_is_school_staff(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;

  if p_bus_id is not null and not exists (
    select 1 from buses b where b.id = p_bus_id and b.school_id = v_school_id
  ) then
    raise exception 'INVALID_BUS';
  end if;

  return query
  select
    t.id,
    b.id,
    coalesce(nullif(b.code, ''), b.plate_number, 'غير متوفر'),
    coalesce(p.full_name, 'غير متوفر'),
    coalesce(r.name, 'غير متوفر'),
    case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup' else 'dropoff' end,
    t.status::text,
    t.starts_at,
    t.ends_at,
    (select count(*) from bus_trip_students x where x.trip_id = t.id and x.boarded_at is not null)::int,
    (select count(*) from bus_trip_students x where x.trip_id = t.id and x.dropped_at is not null)::int,
    count(*) over ()
  from bus_trips t
  join buses b on b.id = t.bus_id
  left join drivers d on d.id = t.driver_id
  left join profiles p on p.id = d.profile_id
  left join bus_routes r on r.id = t.route_id
  where t.school_id = v_school_id
    and (p_bus_id is null or t.bus_id = p_bus_id)
    and (p_from is null or t.starts_at::date >= p_from)
    and (p_to   is null or t.starts_at::date <= p_to)
  order by t.starts_at desc nulls last
  limit greatest(1, least(coalesce(p_limit, 25), 100))
  offset greatest(0, coalesce(p_offset, 0));
end;
$$;

revoke all on function fn_list_school_trips(uuid, date, date, int, int) from public;
grant execute on function fn_list_school_trips(uuid, date, date, int, int) to authenticated;

-- ============================================================================
-- §I — POST-DEPLOY VERIFICATION (READ-ONLY; run manually in SQL editor)
-- ============================================================================
-- 1) zero-arg overload exists:
--    select pg_get_function_identity_arguments(oid)
--    from pg_proc where pronamespace='public'::regnamespace and proname='fn_get_map_overview';
--    → expect BOTH '' and '(p_school_id uuid)'
--
-- 2) fn_update_school_location exists:
--    select pg_get_function_identity_arguments(oid), pg_get_function_result(oid)
--    from pg_proc where pronamespace='public'::regnamespace and proname='fn_update_school_location';
--
-- 3) teacher authorization present in the live body:
--    select prosrc ilike '%teacher_classes%' as has_teacher_assignment
--    from pg_proc where pronamespace='public'::regnamespace and proname='fn_get_class_attendance';
--
-- 4) roster returns exactly 13 columns:
--    select pg_get_function_result(oid)
--    from pg_proc where pronamespace='public'::regnamespace and proname='fn_list_bus_students_ordered';
--    → expect TABLE(... photo_url text, ...) with 13 entries
--
-- 5) fn_list_school_trips exists:
--    select pg_get_function_identity_arguments(oid)
--    from pg_proc where pronamespace='public'::regnamespace and proname='fn_list_school_trips';
--
-- 6) untouched guarantees:
--    select (select count(*) from pg_enum e join pg_type t on t.oid=e.enumtypid
--              where t.typname='bus_event_type' and e.enumlabel='DROP_OFF') = 1 as enum_dropoff_ok;
--    select (select count(distinct proname) from pg_proc
--             where pronamespace='public'::regnamespace
--               and proname in ('fn_guard_issue_badge','fn_guard_reissue_badge','fn_guard_suspend_badge')) = 3 as badge_guard_rpcs_exist;
--    select prosrc ilike '%DROP_OFF%' as trip_event_untouched
--    from pg_proc where pronamespace='public'::regnamespace and proname='fn_record_trip_event';
