-- ============================================================================
-- PHASE 17 (FIXED) — STUDENT REGISTRATION: ROOT CAUSE FIX (final, self-contained)
--
-- FIX ON TOP OF THE PREVIOUS DRAFT: the student_enrollments insert was
-- missing school_id (a required column per your confirmation of the real
-- schema). Corrected below. Nothing else in this file was changed for
-- this revision — the rest was already re-checked and has exactly one
-- other insert (into `students`), which already includes school_id.
--
-- ROOT CAUSE (confirmed by exhaustive search across every migration file in
-- this project, phase3_2 through phase16): fn_register_student_auto_number
-- (phase16) ends by calling:
--
--     v_student_id := fn_register_student(v_school_id, p_full_name, ...);
--
-- fn_register_student DOES NOT EXIST anywhere in the deployed migrations.
-- It is never CREATEd in this project's SQL history. Every call to
-- fn_register_student_auto_number therefore fails inside Postgres with
-- "function fn_register_student(...) does not exist" for EVERY caller —
-- admin and guard alike, which matches exactly what was observed. This has
-- nothing to do with Guard permissions; the underlying RPC was broken for
-- everyone.
--
-- FIX: fn_register_student_auto_number is rewritten to be fully
-- self-contained. It no longer calls any other registration RPC.
--
-- SAFETY: 100% additive.
--   - No DROP TABLE / TRUNCATE / column removal.
--   - No existing table structure changed.
--   - Only fn_register_student_auto_number is replaced (CREATE OR REPLACE
--     after dropping it, because its return type changes from `uuid` to a
--     table, which Postgres does not allow via bare CREATE OR REPLACE).
--   - No other RPC (fn_guard_*, fn_has_permission, fn_resolve_my_role,
--     fn_write_audit, fn_issue_badge, etc.) is touched.
--
-- SCHEMA NOTE — READ BEFORE DEPLOYING:
-- The base tables (students, student_enrollments, classes, academic_years,
-- schools, guards, parent_students, student_fee_assignments, student_badges,
-- student_status, audit_logs) are NOT created anywhere in the migration
-- files included in this project export — they must have been created in
-- an earlier phase (phase1/phase2) that is not part of this bundle, or
-- directly in the Supabase SQL editor. I cannot run `\d students` from
-- here (no database/network access in this environment), so the columns
-- used below are those with DIRECT EVIDENCE elsewhere in this same
-- codebase (working queries in modules/students.js, modules/adminConsole.js,
-- and the confirmed-schema comments left in phase8/phase9):
--   students:            id, school_id, full_name, student_number,
--                         photo_url, deleted_at  (confirmed in students.js)
--                         birth_date, gender      (confirmed by the existing
--                         add-student form / registerStudent() call, which
--                         predates this fix and already sends these two)
--   student_enrollments:  student_id, school_id, class_id, academic_year_id,
--                         status (school_id added per your confirmation —
--                         class_id still inferred from the classes(...)
--                         embed in students.js; please confirm the exact
--                         FK column name if registration still fails here)
--   classes:              id, school_id, academic_year_id (confirmed)
--   audit_logs / fn_write_audit(school_id, action, entity, entity_id,
--                         old, new) — confirmed in phase12/phase9
-- Per your instruction not to guess schema: parent linkage, transport
-- assignment, fee assignment, badge issuance and student_status are
-- deliberately NOT inserted here. None of those tables' columns are
-- confirmed anywhere in this bundle, AND the current frontend
-- (registerStudent() in modules/students.js / the add-student form in
-- admin.html / guard.html) never sends parent/transport/fee data — there
-- is nothing to insert. Badge issuance already exists as a separate,
-- deliberate action on the student's detail page (fn_guard_issue_badge),
-- and student_status is already treated as optional/informational
-- elsewhere in the app (fetchCurrentStatus tolerates no row). Adding
-- guessed inserts for these would risk breaking registration again on a
-- column name mismatch. If you want them wired into registration itself,
-- send me the real `\d parent_students`, `\d student_fee_assignments`,
-- `\d student_badges`, `\d student_status` output and I will add them.
-- ============================================================================

create table if not exists school_student_number_counters (
  school_id uuid primary key references schools(id) on delete cascade,
  next_number bigint not null default 0,
  updated_at timestamptz not null default now()
);
revoke all on table school_student_number_counters from public;

-- Backfill/sync counters from any existing numeric student numbers
-- (safe, additive, idempotent — same as phase16).
insert into school_student_number_counters (school_id, next_number)
select s.id,
       coalesce((
         select max(st.student_number::bigint)
         from students st
         where st.school_id = s.id
           and st.student_number ~ '^[0-9]+$'
       ), 0)
from schools s
on conflict (school_id) do update
set next_number = greatest(
  school_student_number_counters.next_number,
  excluded.next_number
),
updated_at = now();

-- Return type changes (uuid -> table), so the old function must be dropped
-- first. This drops ONLY this one function signature, nothing else.
drop function if exists fn_register_student_auto_number(text, uuid, uuid, date, text);

create function fn_register_student_auto_number(
  p_full_name text,
  p_class_id uuid,
  p_academic_year_id uuid,
  p_birth_date date default null,
  p_gender text default null
)
returns table(student_id uuid, student_number text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_class_year uuid;
  v_role text;
  v_next bigint;
  v_student_number text;
  v_student_id uuid;
begin
  -- 1. Authentication -------------------------------------------------------
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  -- 2. Basic input validation -------------------------------------------------
  if p_full_name is null or btrim(p_full_name) = '' then
    raise exception 'STUDENT_NAME_REQUIRED';
  end if;

  -- 3/4. Resolve school from class, verify class exists ----------------------
  select c.school_id, c.academic_year_id
    into v_school_id, v_class_year
  from classes c
  where c.id = p_class_id;

  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;

  -- 5. Academic year must exist and belong to the same school ---------------
  if not exists (
    select 1 from academic_years ay
    where ay.id = p_academic_year_id
      and ay.school_id = v_school_id
  ) then
    raise exception 'ACADEMIC_YEAR_SCHOOL_MISMATCH';
  end if;

  -- 6. Resolve caller's role in this school ----------------------------------
  v_role := fn_resolve_my_role(v_school_id);
  if v_role is null then
    raise exception 'PERMISSION_DENIED: no role in this school';
  end if;

  -- 7. Admin: always allowed. Guard: needs students.create. Anyone else: denied.
  if v_role = 'admin' then
    null; -- full administrative rights, no extra check
  elsif v_role = 'guard' then
    if not fn_has_permission('students.create', v_school_id) then
      raise exception 'PERMISSION_DENIED: missing students.create';
    end if;
  else
    raise exception 'PERMISSION_DENIED: role % cannot register students', v_role;
  end if;

  -- 8/9. Generate a unique, concurrency-safe student number ------------------
  -- Advisory lock scoped to this school: serializes concurrent registrations
  -- for the SAME school without blocking other schools.
  perform pg_advisory_xact_lock(hashtextextended(v_school_id::text, 0));

  select coalesce(max(st.student_number::bigint), 0)
    into v_next
  from students st
  where st.school_id = v_school_id
    and st.student_number ~ '^[0-9]+$';

  insert into school_student_number_counters (school_id, next_number)
  values (v_school_id, v_next)
  on conflict (school_id) do nothing;

  update school_student_number_counters c
     set next_number = greatest(c.next_number, v_next) + 1,
         updated_at = now()
   where c.school_id = v_school_id
  returning c.next_number into v_next;

  v_student_number := v_next::text;

  -- 10. Insert the student row -------------------------------------------------
  begin
    insert into students (school_id, full_name, student_number, birth_date, gender)
    values (v_school_id, btrim(p_full_name), v_student_number, p_birth_date, p_gender)
    returning id into v_student_id;
  exception
    when unique_violation then
      raise exception 'DUPLICATE_STUDENT_NUMBER';
    when others then
      raise exception 'STUDENT_INSERT_FAILED: %', sqlerrm;
  end;

  -- 11. Insert the active enrollment -------------------------------------------
  begin
    insert into student_enrollments (student_id, school_id, class_id, academic_year_id, status)
    values (v_student_id, v_school_id, p_class_id, p_academic_year_id, 'ACTIVE');
  exception
    when others then
      raise exception 'ENROLLMENT_INSERT_FAILED: %', sqlerrm;
  end;

  -- 12/13/14. Parent / transport / fee: intentionally NOT implemented here.
  -- See the SCHEMA NOTE at the top of this file — no confirmed schema and
  -- no data currently sent by any caller. Nothing to insert.

  -- 15/16. Badge / status: intentionally NOT implemented here — both are
  -- already handled as separate, deliberate actions elsewhere in the app
  -- (fn_guard_issue_badge on the student's detail page) and are treated
  -- as optional/absent-tolerant by the rest of the codebase.

  -- 17. Audit log (best-effort: reuses the existing fn_write_audit; if that
  -- function itself is missing this will surface as a clear error rather
  -- than a silently swallowed one, per your instruction #9) -----------------
  perform fn_write_audit(
    v_school_id,
    'STUDENT_REGISTERED',
    'students',
    v_student_id,
    null,
    jsonb_build_object(
      'student_number', v_student_number,
      'class_id', p_class_id,
      'academic_year_id', p_academic_year_id,
      'registered_by', auth.uid(),
      'registered_by_role', v_role
    )
  );

  -- 18. Return student_id + student_number directly, so the frontend never
  -- needs a second query to display the generated number.
  return query select v_student_id, v_student_number;
end;
$$;

revoke all on function fn_register_student_auto_number(text, uuid, uuid, date, text) from public;
grant execute on function fn_register_student_auto_number(text, uuid, uuid, date, text) to authenticated;

-- ============================================================================
-- END OF PHASE 17
-- ============================================================================
