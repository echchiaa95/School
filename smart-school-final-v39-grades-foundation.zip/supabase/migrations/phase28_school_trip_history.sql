-- ============================================================================
-- PHASE 28 — SCHOOL-WIDE TRIP HISTORY (all buses of the current school)
--
-- Why: fn_list_bus_trips(p_bus_id, p_limit) requires one bus, so the admin map
-- could only show per-bus history. This new RPC lists the whole fleet's past
-- trips with filters (bus / date range) and pagination (total_count).
--
-- Security: identical authorization to fn_list_bus_trips (phase23) —
-- fn_is_school_staff(v_school_id). The school is derived from the CALLER's
-- user_roles row, never from a client-supplied school_id, and every returned
-- row is filtered by that same school_id → cross-school reads are impossible.
--
-- Schema (verified against phase12 v5 + phase22):
--   bus_trips(id, school_id, bus_id, driver_id, route_id, direction,
--             status, starts_at, ends_at)
--   buses(code, plate_number) / profiles.full_name / bus_routes.name
--   bus_trip_students(boarded_at, dropped_at) — snapshot per trip
--   bus_trip_locations — GPS history, read via the EXISTING
--   fn_get_trip_route_history (phase22) on the details view.
-- ============================================================================

create or replace function fn_list_school_trips(
  p_bus_id uuid default null,
  p_from date default null,
  p_to date default null,
  p_limit int default 25,
  p_offset int default 0
)
returns table(
  trip_id uuid, bus_id uuid, bus_label text, driver_name text,
  route_name text, direction text, status text,
  starts_at timestamptz, ends_at timestamptz,
  boarded_count int, dropped_count int, total_count bigint
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  -- Caller's school (never client-supplied). Staff only, same as fn_list_bus_trips.
  select school_id into v_school_id from user_roles
  where profile_id = auth.uid() limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;
  if not fn_is_school_staff(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;

  -- Optional bus filter must belong to the same school.
  if p_bus_id is not null and not exists (
    select 1 from buses b where b.id = p_bus_id and b.school_id = v_school_id
  ) then
    raise exception 'INVALID_BUS';
  end if;

  return query
  select
    t.id,
    b.id,
    coalesce(nullif(b.code, ''), b.plate_number, 'غير متوفر'),
    coalesce(p.full_name, 'غير متوفر'),
    coalesce(r.name, 'غير متوفر'),
    case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup' else 'dropoff' end,
    t.status::text,
    t.starts_at,
    t.ends_at,
    (select count(*) from bus_trip_students x where x.trip_id = t.id and x.boarded_at is not null)::int,
    (select count(*) from bus_trip_students x where x.trip_id = t.id and x.dropped_at is not null)::int,
    count(*) over ()
  from bus_trips t
  join buses b on b.id = t.bus_id
  left join drivers d on d.id = t.driver_id
  left join profiles p on p.id = d.profile_id
  left join bus_routes r on r.id = t.route_id
  where t.school_id = v_school_id
    and (p_bus_id is null or t.bus_id = p_bus_id)
    and (p_from is null or t.starts_at::date >= p_from)
    and (p_to   is null or t.starts_at::date <= p_to)
  order by t.starts_at desc nulls last
  limit greatest(1, least(coalesce(p_limit, 25), 100))
  offset greatest(0, coalesce(p_offset, 0));
end;
$$;

revoke all on function fn_list_school_trips(uuid, date, date, int, int) from public;
grant execute on function fn_list_school_trips(uuid, date, date, int, int) to authenticated;
