-- PHASE 35 — Admin runtime/data fixes
-- MUTATING migration. Run once on the correct Smart School Supabase project.
-- No timezone/time changes. No data deletion.

-- 1) Fix teacher schedule RPC: the old PL/pgSQL RETURNS TABLE function exposed
--    an output variable named id and could raise 42702 "id is ambiguous".
--    SQL-language function has no PL/pgSQL output-variable collision.
DROP FUNCTION IF EXISTS public.fn_get_teacher_schedule(uuid);

CREATE FUNCTION public.fn_get_teacher_schedule(p_teacher_id uuid)
RETURNS TABLE(
  id uuid,
  weekday smallint,
  period smallint,
  class_id uuid,
  class_name text,
  subject_name text,
  starts_at time,
  ends_at time
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $function$
  SELECT
    te.id AS id,
    (te.weekday - 1)::smallint AS weekday,
    COALESCE(te.period, 1)::smallint AS period,
    c.id AS class_id,
    c.name AS class_name,
    su.name AS subject_name,
    te.starts_at AS starts_at,
    te.ends_at AS ends_at
  FROM public.timetable_entries AS te
  JOIN public.teachers AS t
    ON t.id = te.teacher_id
   AND t.deleted_at IS NULL
  JOIN public.classes AS c
    ON c.id = te.class_id
  JOIN public.subjects AS su
    ON su.id = te.subject_id
  WHERE te.teacher_id = p_teacher_id
    AND public.fn_is_school_member(t.school_id)
  ORDER BY te.weekday, COALESCE(te.period, 1), te.starts_at;
$function$;

REVOKE ALL ON FUNCTION public.fn_get_teacher_schedule(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_get_teacher_schedule(uuid) TO authenticated;

-- 2) Explicitly keep historical trip GPS readable by school staff.
--    This function returns the real bus_trip_locations points only; it never
--    fabricates coordinates. The route is ordered by recorded_at.
CREATE OR REPLACE FUNCTION public.fn_get_trip_route_history(p_trip_id uuid)
RETURNS TABLE(
  latitude double precision,
  longitude double precision,
  speed double precision,
  recorded_at timestamptz
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $function$
  SELECT
    btl.latitude,
    btl.longitude,
    btl.speed,
    btl.recorded_at
  FROM public.bus_trip_locations AS btl
  JOIN public.bus_trips AS bt ON bt.id = btl.trip_id
  WHERE btl.trip_id = p_trip_id
    AND public.fn_is_school_staff(bt.school_id)
  ORDER BY btl.recorded_at ASC;
$function$;

REVOKE ALL ON FUNCTION public.fn_get_trip_route_history(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_get_trip_route_history(uuid) TO authenticated;
