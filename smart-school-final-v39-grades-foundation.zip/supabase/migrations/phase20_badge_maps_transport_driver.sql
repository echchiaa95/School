-- ============================================================================
-- PHASE 20 — BADGE (photo+download), MAP PICKER BACKEND, SCHOOL LOCATION,
--            DIRECTION-AWARE TRANSPORT, DRIVER QR + DUPLICATE-PROOF BOARDING
--
-- ADDITIVE ONLY. No DROP TABLE, no TRUNCATE, no data loss.
-- Reused as-is (confirmed already existing, NOT rebuilt): buses, bus_routes,
-- bus_stops, bus_route_stops, bus_trips (direction enum: TO_SCHOOL/TO_HOME —
-- confirmed from fn_start_trip's own mapping), bus_trip_students, bus_events,
-- student_transport_assignments, student_badges, timetables, schools.logo_url
-- (already there, already editable from the school-profile screen),
-- fn_get_school_profile (returns to_jsonb(schools row) — new columns below
-- appear in it automatically, no function change needed).
-- ============================================================================


-- ============================================================================
-- SECTION A — REAL BUG FIX: fn_record_trip_event had no duplicate-boarding
-- guard and no drop-off-without-boarding guard (item 16), and checked only
-- "same school" instead of "student is actually on THIS bus's roster" (item
-- 13.3 / item 26 — server-side membership check). Also was never audited.
-- Same signature, CREATE OR REPLACE.
-- ============================================================================

create or replace function fn_record_trip_event(p_trip_id uuid, p_student_id uuid, p_event_type text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_trip bus_trips%rowtype;
  v_driver_id uuid;
  v_type bus_event_type;
  v_boarded_at timestamptz;
  v_dropped_at timestamptz;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select * into v_trip from bus_trips where id = p_trip_id;
  if v_trip.id is null then raise exception 'INVALID_TRIP'; end if;

  select d.id into v_driver_id from drivers d
  where d.profile_id = auth.uid() and d.deleted_at is null limit 1;
  if v_driver_id is null or v_trip.driver_id <> v_driver_id then
    raise exception 'PERMISSION_DENIED';
  end if;

  -- FIX: the student must actually be on THIS bus's active roster, not just
  -- "in the same school" — this is the real server-side check item 26 asks for.
  if not exists (
    select 1 from student_transport_assignments sta
    where sta.student_id = p_student_id
      and sta.bus_id = v_trip.bus_id
      and sta.is_active
  ) then
    raise exception 'STUDENT_NOT_ON_THIS_ROUTE';
  end if;

  v_type := case lower(trim(coalesce(p_event_type, '')))
              when 'board'    then 'BOARD'::bus_event_type
              when 'alight'   then 'DROP_OFF'::bus_event_type
              when 'drop_off' then 'DROP_OFF'::bus_event_type
              when 'dropoff'  then 'DROP_OFF'::bus_event_type
              else null
            end;
  if v_type is null then raise exception 'INVALID_EVENT_TYPE'; end if;

  insert into bus_trip_students (trip_id, student_id)
  values (p_trip_id, p_student_id)
  on conflict (trip_id, student_id) do nothing;

  select boarded_at, dropped_at into v_boarded_at, v_dropped_at
  from bus_trip_students where trip_id = p_trip_id and student_id = p_student_id;

  -- FIX: real duplicate/order guards with clear error codes (item 16).
  if v_type = 'BOARD'::bus_event_type then
    if v_boarded_at is not null then
      raise exception 'ALREADY_BOARDED';
    end if;
    update bus_trip_students set boarded_at = now()
    where trip_id = p_trip_id and student_id = p_student_id;
  else
    if v_boarded_at is null then
      raise exception 'NOT_BOARDED_YET';
    end if;
    if v_dropped_at is not null then
      raise exception 'ALREADY_DROPPED';
    end if;
    update bus_trip_students set dropped_at = now()
    where trip_id = p_trip_id and student_id = p_student_id;
  end if;

  insert into bus_events (trip_id, student_id, driver_id, event_type, source)
  values (p_trip_id, p_student_id, v_driver_id, v_type, 'MANUAL'::record_source);

  perform fn_safe_audit(v_trip.school_id,
    case when v_type = 'BOARD'::bus_event_type then 'STUDENT_BOARDED' else 'STUDENT_DROPPED_OFF' end,
    'bus_trip_students', p_student_id, null,
    jsonb_build_object('trip_id', p_trip_id, 'driver_id', v_driver_id));
end;
$$;
revoke all on function fn_record_trip_event(uuid, uuid, text) from public;
grant execute on function fn_record_trip_event(uuid, uuid, text) to authenticated;


-- ============================================================================
-- SECTION B — DRIVER QR SCAN: server-side lookup + membership check.
-- Guard's existing lookupByBadgeToken queries student_badges/students
-- directly (fine for guard — RLS already scopes it to their school). A
-- DRIVER must not be able to read arbitrary students/badges that way, so
-- this is a dedicated RPC that only ever returns a student if they are
-- actually on the CALLING driver's current active trip's bus.
-- ============================================================================

create or replace function fn_driver_lookup_badge(p_secure_token uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_driver_id uuid;
  v_trip record;
  v_student record;
  v_bts record;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select d.id into v_driver_id from drivers d
  where d.profile_id = auth.uid() and d.deleted_at is null limit 1;
  if v_driver_id is null then raise exception 'NOT_A_DRIVER'; end if;

  select t.id, t.bus_id, t.direction into v_trip
  from bus_trips t
  where t.driver_id = v_driver_id and t.status = 'ACTIVE'::trip_status
  order by t.starts_at desc limit 1;
  if v_trip.id is null then raise exception 'NO_ACTIVE_TRIP'; end if;

  select sb.student_id, sb.status into v_student
  from student_badges sb
  where sb.secure_token = p_secure_token
  limit 1;
  if v_student.student_id is null then raise exception 'UNKNOWN_BADGE'; end if;
  if v_student.status <> 'ACTIVE'::badge_status then raise exception 'BADGE_NOT_ACTIVE'; end if;

  if not exists (
    select 1 from student_transport_assignments sta
    where sta.student_id = v_student.student_id
      and sta.bus_id = v_trip.bus_id
      and sta.is_active
  ) then
    raise exception 'STUDENT_NOT_ON_THIS_ROUTE';
  end if;

  select bts.boarded_at, bts.dropped_at into v_bts
  from bus_trip_students bts
  where bts.trip_id = v_trip.id and bts.student_id = v_student.student_id;

  return jsonb_build_object(
    'trip_id', v_trip.id,
    'student_id', v_student.student_id,
    'full_name', (select st.full_name from students st where st.id = v_student.student_id),
    'student_number', (select st.student_number from students st where st.id = v_student.student_id),
    'photo_url', (select st.photo_url from students st where st.id = v_student.student_id),
    'class_name', (select c.name from student_enrollments se join classes c on c.id = se.class_id
                   where se.student_id = v_student.student_id and se.status = 'ACTIVE' limit 1),
    'boarded_at', v_bts.boarded_at,
    'dropped_at', v_bts.dropped_at
  );
end;
$$;
revoke all on function fn_driver_lookup_badge(uuid) from public;
grant execute on function fn_driver_lookup_badge(uuid) to authenticated;


-- ============================================================================
-- SECTION C — STUDENT/SCHOOL PHOTOS: Supabase Storage (not base64 in the DB,
-- per your instruction), plus the RPC that records the resulting URL.
-- Bucket is public-READ (badge cards / lists need to just <img src>), but
-- writes are locked down by a storage.objects RLS policy that only allows
-- school staff to upload/replace under their OWN school's folder — path
-- convention: student-photos/<school_id>/<student_id>.<ext>
-- ============================================================================

insert into storage.buckets (id, name, public)
values ('student-photos', 'student-photos', true)
on conflict (id) do nothing;

do $$ begin
  if not exists (
    select 1 from pg_policies where schemaname = 'storage' and tablename = 'objects'
      and policyname = 'p_student_photos_public_read'
  ) then
    create policy p_student_photos_public_read on storage.objects
      for select using (bucket_id = 'student-photos');
  end if;
  if not exists (
    select 1 from pg_policies where schemaname = 'storage' and tablename = 'objects'
      and policyname = 'p_student_photos_staff_write'
  ) then
    create policy p_student_photos_staff_write on storage.objects
      for insert to authenticated
      with check (
        bucket_id = 'student-photos'
        and fn_is_school_staff((storage.foldername(name))[1]::uuid)
      );
  end if;
  if not exists (
    select 1 from pg_policies where schemaname = 'storage' and tablename = 'objects'
      and policyname = 'p_student_photos_staff_update'
  ) then
    create policy p_student_photos_staff_update on storage.objects
      for update to authenticated
      using (bucket_id = 'student-photos' and fn_is_school_staff((storage.foldername(name))[1]::uuid));
  end if;
end $$;

create or replace function fn_update_student_photo(p_student_id uuid, p_photo_url text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select school_id into v_school_id from students where id = p_student_id and deleted_at is null;
  if v_school_id is null then raise exception 'INVALID_STUDENT'; end if;

  v_role := fn_resolve_my_role(v_school_id);
  if v_role is null then raise exception 'PERMISSION_DENIED: no role in this school'; end if;
  if v_role <> 'admin' and not fn_has_permission('students.photo.manage', v_school_id) then
    raise exception 'PERMISSION_DENIED: missing students.photo.manage';
  end if;

  update students set photo_url = p_photo_url where id = p_student_id;

  perform fn_safe_audit(v_school_id, 'STUDENT_PHOTO_UPDATED', 'students', p_student_id, null,
    jsonb_build_object('photo_url', p_photo_url, 'updated_by', auth.uid()));
end;
$$;
revoke all on function fn_update_student_photo(uuid, text) from public;
grant execute on function fn_update_student_photo(uuid, text) to authenticated;


-- ============================================================================
-- SECTION D — SCHOOL LOCATION (new, additive columns on the existing
-- schools table; already auto-exposed by fn_get_school_profile since it
-- does `select to_jsonb(s)` — no function change needed there).
-- ============================================================================

alter table schools add column if not exists latitude double precision;
alter table schools add column if not exists longitude double precision;
alter table schools add column if not exists location_label text;

create or replace function fn_update_school_location(
  p_latitude double precision,
  p_longitude double precision,
  p_location_label text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  if p_latitude < -90 or p_latitude > 90 then raise exception 'INVALID_LATITUDE'; end if;
  if p_longitude < -180 or p_longitude > 180 then raise exception 'INVALID_LONGITUDE'; end if;

  update schools
     set latitude = p_latitude, longitude = p_longitude,
         location_label = coalesce(p_location_label, location_label)
   where id = v_school_id;

  perform fn_safe_audit(v_school_id, 'SCHOOL_LOCATION_UPDATED', 'schools', v_school_id, null,
    jsonb_build_object('latitude', p_latitude, 'longitude', p_longitude, 'updated_by', auth.uid()));
end;
$$;
revoke all on function fn_update_school_location(double precision, double precision, text) from public;
grant execute on function fn_update_school_location(double precision, double precision, text) to authenticated;


-- ============================================================================
-- SECTION E — DIRECTION-AWARE PICKUP/DROPOFF (items 7-10, 24): the
-- underlying table already allows pickup_stop_id/dropoff_stop_id to be
-- NULL (confirmed — fn_assign_student_transport already treats them as
-- optional). This section only changes how the label is DISPLAYED: if no
-- explicit stop was chosen, derive it from the trip's direction instead of
-- showing a blank. The physical route order (sequence_order) is untouched.
-- ============================================================================

create or replace function fn_list_bus_students_ordered(p_bus_id uuid, p_trip_id uuid default null)
returns table(
  student_id uuid, full_name text, student_number text, photo_url text,
  pickup_stop text, dropoff_stop text,
  stop_order int, stop_latitude double precision, stop_longitude double precision,
  student_latitude double precision, student_longitude double precision,
  boarded_at timestamptz, alighted_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_ctx jsonb;
  v_direction trip_direction;
begin
  select school_id into v_school_id from buses where id = p_bus_id;
  if v_school_id is null then raise exception 'INVALID_BUS'; end if;

  v_ctx := fn_driver_context();
  if not (fn_is_school_member(v_school_id)
          or (v_ctx is not null and (v_ctx->>'bus_id')::uuid = p_bus_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if p_trip_id is not null then
    select direction into v_direction from bus_trips where id = p_trip_id;
  end if;

  return query
  select sta.student_id, s.full_name, s.student_number, s.photo_url,
         coalesce(bs_pick.name,
           case when v_direction = 'TO_SCHOOL'::trip_direction or v_direction is null
                then 'منزل التلميذ' else (select sc.name from schools sc where sc.id = v_school_id) end),
         coalesce(bs_drop.name,
           case when v_direction = 'TO_SCHOOL'::trip_direction or v_direction is null
                then (select sc.name from schools sc where sc.id = v_school_id) else 'منزل التلميذ' end),
         brs.sequence_order,
         bs_pick.latitude, bs_pick.longitude,
         s.latitude, s.longitude,
         bts.boarded_at,
         bts.dropped_at
  from student_transport_assignments sta
  join students s on s.id = sta.student_id and s.deleted_at is null
  left join bus_stops bs_pick on bs_pick.id = sta.pickup_stop_id
  left join bus_stops bs_drop on bs_drop.id = sta.dropoff_stop_id
  left join bus_route_stops brs on brs.route_id = sta.route_id and brs.stop_id = sta.pickup_stop_id
  left join bus_trip_students bts on bts.trip_id = p_trip_id and bts.student_id = sta.student_id
  where sta.bus_id = p_bus_id
    and sta.is_active
  order by coalesce(brs.sequence_order, 999999), s.full_name;
end;
$$;
revoke all on function fn_list_bus_students_ordered(uuid, uuid) from public;
grant execute on function fn_list_bus_students_ordered(uuid, uuid) to authenticated;


-- fn_student_transport_info: same direction-aware default labels, for the
-- (non-trip-specific) Student Profile view — shown as "(تلقائي)" since
-- there's no single active trip to resolve direction from here.
create or replace function fn_student_transport_info(p_student_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_result jsonb;
begin
  select school_id into v_school_id from students where id = p_student_id;
  if v_school_id is null then raise exception 'INVALID_STUDENT'; end if;
  if not (fn_is_school_staff(v_school_id)
          or fn_has_permission('transport.view', v_school_id)
          or fn_is_parent_of(p_student_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  select jsonb_build_object(
    'bus_code', coalesce(b.code, b.plate_number), 'bus_plate', b.plate_number,
    'driver_name', (select p.full_name from drivers d join profiles p on p.id = d.profile_id
                    where d.id = b.driver_id),
    'route_name', r.name,
    'pickup_stop', coalesce((select rs.name from bus_stops rs where rs.id = sta.pickup_stop_id), 'المنزل (تلقائي حسب الاتجاه)'),
    'dropoff_stop', coalesce((select rs.name from bus_stops rs where rs.id = sta.dropoff_stop_id), 'المؤسسة (تلقائي حسب الاتجاه)'),
    'stops_are_automatic', (sta.pickup_stop_id is null and sta.dropoff_stop_id is null)
  ) into v_result
  from student_transport_assignments sta
  left join buses b on b.id = sta.bus_id
  left join bus_routes r on r.id = sta.route_id
  where sta.student_id = p_student_id
    and sta.is_active
  order by sta.starts_on desc
  limit 1;

  return v_result;
end;
$$;
revoke all on function fn_student_transport_info(uuid) from public;
grant execute on function fn_student_transport_info(uuid) to authenticated;

-- Register the two new permission keys if the catalog table exists (purely
-- additive; harmless no-op otherwise — same guarded pattern as Phase 18).
insert into permissions (permission_key, module, name, description)
select v.k, 'students', v.n, v.d
from (values
  ('students.photo.manage', 'تعديل صورة التلميذ', 'السماح بإضافة/تغيير صورة التلميذ'),
  ('transport.manage', 'إدارة النقل المدرسي', 'السماح بربط/تعديل نقل التلميذ (قد تكون موجودة أصلًا)')
) as v(k, n, d)
where exists (select 1 from information_schema.tables where table_name = 'permissions')
  and not exists (select 1 from permissions where permission_key = v.k);

-- ============================================================================
-- END OF PHASE 20
-- ============================================================================
