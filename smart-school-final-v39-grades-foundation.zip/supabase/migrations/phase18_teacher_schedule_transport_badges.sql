-- ============================================================================
-- PHASE 18 — TEACHER PAYROLL, STUDENT LOCATION, SCHEDULE CONFLICTS,
--            BADGE SYSTEM ROOT-CAUSE FIX, AUDIT SAFETY FIX
--
-- ADDITIVE ONLY. No DROP TABLE, no TRUNCATE, no data deletion.
-- Functions are only CREATE OR REPLACE with an IDENTICAL signature to the
-- deployed one, except where noted (badge functions: same signature too).
--
-- WHAT WAS ALREADY FOUND WORKING AND IS THEREFORE **NOT** REBUILT HERE
-- (per your instruction to reuse, not duplicate):
--   - Teacher ↔ Subject / Teacher ↔ Class links: teacher_subjects,
--     teacher_classes + fn_assign_teacher_subject/fn_remove_teacher_subject/
--     fn_list_teacher_subjects/fn_assign_teacher_class/fn_remove_teacher_class/
--     fn_list_teacher_classes (phase14_teacher_assignments.sql). Reuse as-is
--     for the Teacher Profile UI.
--   - Class timetable: timetables + timetable_entries + fn_set_class_schedule
--     + fn_get_class_schedule (phase12, section 11). This is ALREADY the
--     "derive, don't copy" design you asked for in item 6/7: a student's
--     timetable is the timetable of their CURRENT class, nothing is copied
--     per-student. Section D below only adds a small derived convenience
--     RPC + a teacher double-booking guard on top of the existing function.
--   - School transport: buses, bus_routes, bus_stops, bus_route_stops
--     (has sequence_order — stop order already supported), bus_trips,
--     bus_trip_students, bus_events, student_transport_assignments, plus
--     fn_create_route, fn_assign_student_transport, fn_student_transport_info,
--     fn_start_trip/fn_end_trip/fn_get_active_trip/fn_list_bus_students,
--     fn_driver_context (phase12, sections 9). fn_list_bus_students +
--     fn_get_active_trip already give a driver exactly "مساري اليوم" scoped
--     to their own bus — nothing new needed server-side for item 12/13.
--     "Open in Google Maps" is a plain URL
--     (https://www.google.com/maps?q=lat,lng) — no API key needed, so item
--     13's "don't invent an API key" requirement is naturally satisfied.
-- These are FRONTEND work (Teacher Profile / Student Profile / Driver
-- "my route today" pages wiring up these existing RPCs) — no schema change
-- needed for them, so they are not part of this SQL file.
-- ============================================================================


-- ============================================================================
-- SECTION A — AUDIT SAFETY FIX for Phase 17
-- fn_write_audit is referenced across several migrations but is NEVER
-- actually CREATEd anywhere in this project's SQL history (confirmed by
-- full-text search) — the exact same class of bug as fn_register_student
-- and fn_issue_badge. fn_safe_audit (phase12, confirmed to exist and to
-- swallow its own failure by design) is the resilient wrapper already used
-- everywhere else in phase12. Phase 17 called fn_write_audit directly,
-- which means a missing fn_write_audit would silently roll back the
-- ENTIRE student registration on an unrelated audit failure. Fixing that
-- now, same signature, nothing else in fn_register_student_auto_number
-- changes.
-- ============================================================================

create or replace function fn_register_student_auto_number(
  p_full_name text,
  p_class_id uuid,
  p_academic_year_id uuid,
  p_birth_date date default null,
  p_gender text default null
)
returns table(student_id uuid, student_number text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_class_year uuid;
  v_role text;
  v_next bigint;
  v_student_number text;
  v_student_id uuid;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  if p_full_name is null or btrim(p_full_name) = '' then
    raise exception 'STUDENT_NAME_REQUIRED';
  end if;

  select c.school_id, c.academic_year_id
    into v_school_id, v_class_year
  from classes c
  where c.id = p_class_id;

  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;

  if not exists (
    select 1 from academic_years ay
    where ay.id = p_academic_year_id
      and ay.school_id = v_school_id
  ) then
    raise exception 'ACADEMIC_YEAR_SCHOOL_MISMATCH';
  end if;

  v_role := fn_resolve_my_role(v_school_id);
  if v_role is null then
    raise exception 'PERMISSION_DENIED: no role in this school';
  end if;

  if v_role = 'admin' then
    null;
  elsif v_role = 'guard' then
    if not fn_has_permission('students.create', v_school_id) then
      raise exception 'PERMISSION_DENIED: missing students.create';
    end if;
  else
    raise exception 'PERMISSION_DENIED: role % cannot register students', v_role;
  end if;

  perform pg_advisory_xact_lock(hashtextextended(v_school_id::text, 0));

  select coalesce(max(st.student_number::bigint), 0)
    into v_next
  from students st
  where st.school_id = v_school_id
    and st.student_number ~ '^[0-9]+$';

  insert into school_student_number_counters (school_id, next_number)
  values (v_school_id, v_next)
  on conflict (school_id) do nothing;

  update school_student_number_counters c
     set next_number = greatest(c.next_number, v_next) + 1,
         updated_at = now()
   where c.school_id = v_school_id
  returning c.next_number into v_next;

  v_student_number := v_next::text;

  begin
    insert into students (school_id, full_name, student_number, birth_date, gender)
    values (v_school_id, btrim(p_full_name), v_student_number, p_birth_date, p_gender)
    returning id into v_student_id;
  exception
    when unique_violation then
      raise exception 'DUPLICATE_STUDENT_NUMBER';
    when others then
      raise exception 'STUDENT_INSERT_FAILED: %', sqlerrm;
  end;

  begin
    insert into student_enrollments (student_id, school_id, class_id, academic_year_id, status)
    values (v_student_id, v_school_id, p_class_id, p_academic_year_id, 'ACTIVE');
  exception
    when others then
      raise exception 'ENROLLMENT_INSERT_FAILED: %', sqlerrm;
  end;

  -- FIX: fn_safe_audit instead of fn_write_audit — never blocks registration.
  perform fn_safe_audit(
    v_school_id, 'STUDENT_REGISTERED', 'students', v_student_id, null,
    jsonb_build_object(
      'student_number', v_student_number, 'class_id', p_class_id,
      'academic_year_id', p_academic_year_id, 'registered_by', auth.uid(),
      'registered_by_role', v_role
    )
  );

  return query select v_student_id, v_student_number;
end;
$$;

revoke all on function fn_register_student_auto_number(text, uuid, uuid, date, text) from public;
grant execute on function fn_register_student_auto_number(text, uuid, uuid, date, text) to authenticated;


-- ============================================================================
-- SECTION B — STUDENT ID BADGE: REAL ROOT-CAUSE FIX
--
-- ROOT CAUSE (same pattern as Phase 17, confirmed by full-text search):
-- fn_guard_issue_badge / fn_guard_reissue_badge / fn_guard_suspend_badge
-- (phase4_2_permissions_system.sql) call fn_student_school(...) and
-- fn_issue_badge(...)/fn_reissue_badge(...)/fn_suspend_badge(...) — NONE of
-- these four helper functions are ever CREATEd anywhere in this project's
-- SQL history. The live error
--   "Could not find the function public.fn_guard_issue_badge(p_student_id)
--    in the schema cache"
-- means the CALLER function itself isn't visible to PostgREST on the
-- current project — consistent with phase4_2_permissions_system.sql never
-- having actually been applied against the current live database (this
-- project has previously had two different Supabase projects in play).
--
-- Confirmed real columns used below (from working queries already in
-- modules/students.js and the existing fn_guard_suspend_badge signature,
-- which only compiles if these are real):
--   students:       id, school_id, deleted_at            (confirmed)
--   student_badges: id, student_id, status, secure_token (confirmed)
--   badge_status:   an existing enum type (confirmed — fn_guard_suspend_badge
--                   already declares a parameter of this type); 'SUSPENDED'
--                   is a confirmed valid label (guard.html already sends it).
--                   'REPLACED' is used below for a badge superseded by
--                   reissue — this matches the badges lifecycle documented
--                   for this project (ACTIVE/LOST/SUSPENDED/EXPIRED/REPLACED)
--                   but is NOT independently re-confirmed from the live
--                   enum here. If reissue fails with an invalid-enum-label
--                   error, tell me the real labels (select enum_range(null::badge_status))
--                   and I will adjust just that one literal.
-- ============================================================================

create or replace function fn_guard_issue_badge(p_student_id uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
  v_existing_id uuid;
  v_badge_id uuid;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select school_id into v_school_id
  from students
  where id = p_student_id and deleted_at is null;

  if v_school_id is null then
    raise exception 'INVALID_STUDENT';
  end if;

  v_role := fn_resolve_my_role(v_school_id);
  if v_role is null then
    raise exception 'PERMISSION_DENIED: no role in this school';
  end if;
  if v_role <> 'admin' and not fn_has_permission('students.badge.issue', v_school_id) then
    raise exception 'PERMISSION_DENIED: missing students.badge.issue';
  end if;

  -- Idempotent: repeated clicks never create duplicate ACTIVE badges.
  select id into v_existing_id
  from student_badges
  where student_id = p_student_id and status = 'ACTIVE'::badge_status
  limit 1;

  if v_existing_id is not null then
    return v_existing_id;
  end if;

  begin
    insert into student_badges (student_id, status, secure_token)
    values (p_student_id, 'ACTIVE'::badge_status, gen_random_uuid())
    returning id into v_badge_id;
  exception
    when others then
      raise exception 'BADGE_INSERT_FAILED: %', sqlerrm;
  end;

  perform fn_safe_audit(
    v_school_id, 'BADGE_ISSUED', 'student_badges', v_badge_id, null,
    jsonb_build_object('student_id', p_student_id, 'issued_by', auth.uid(), 'role', v_role)
  );

  return v_badge_id;
end;
$$;

revoke all on function fn_guard_issue_badge(uuid) from public;
grant execute on function fn_guard_issue_badge(uuid) to authenticated;


create or replace function fn_guard_reissue_badge(p_student_id uuid, p_reason text default null)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
  v_badge_id uuid;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select school_id into v_school_id
  from students
  where id = p_student_id and deleted_at is null;

  if v_school_id is null then
    raise exception 'INVALID_STUDENT';
  end if;

  v_role := fn_resolve_my_role(v_school_id);
  if v_role is null then
    raise exception 'PERMISSION_DENIED: no role in this school';
  end if;
  if v_role <> 'admin' and not fn_has_permission('students.badge.reissue', v_school_id) then
    raise exception 'PERMISSION_DENIED: missing students.badge.reissue';
  end if;

  begin
    -- Supersede any currently ACTIVE badge(s) BEFORE inserting the new one,
    -- so a unique-active-badge-per-student constraint (documented for this
    -- project) is never violated by ordering.
    update student_badges
       set status = 'REPLACED'::badge_status
     where student_id = p_student_id
       and status = 'ACTIVE'::badge_status;

    insert into student_badges (student_id, status, secure_token)
    values (p_student_id, 'ACTIVE'::badge_status, gen_random_uuid())
    returning id into v_badge_id;
  exception
    when others then
      raise exception 'BADGE_REISSUE_FAILED: %', sqlerrm;
  end;

  perform fn_safe_audit(
    v_school_id, 'BADGE_REISSUED', 'student_badges', v_badge_id, null,
    jsonb_build_object('student_id', p_student_id, 'reason', p_reason,
                        'reissued_by', auth.uid(), 'role', v_role)
  );

  return v_badge_id;
end;
$$;

revoke all on function fn_guard_reissue_badge(uuid, text) from public;
grant execute on function fn_guard_reissue_badge(uuid, text) to authenticated;


create or replace function fn_guard_suspend_badge(
  p_badge_id uuid,
  p_new_status badge_status,
  p_reason text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_student_id uuid;
  v_school_id uuid;
  v_role text;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select student_id into v_student_id
  from student_badges
  where id = p_badge_id;

  if v_student_id is null then
    raise exception 'INVALID_BADGE';
  end if;

  select school_id into v_school_id
  from students
  where id = v_student_id and deleted_at is null;

  if v_school_id is null then
    raise exception 'INVALID_BADGE';
  end if;

  v_role := fn_resolve_my_role(v_school_id);
  if v_role is null then
    raise exception 'PERMISSION_DENIED: no role in this school';
  end if;
  if v_role <> 'admin' and not fn_has_permission('students.badge.suspend', v_school_id) then
    raise exception 'PERMISSION_DENIED: missing students.badge.suspend';
  end if;

  begin
    update student_badges set status = p_new_status where id = p_badge_id;
  exception
    when others then
      raise exception 'BADGE_STATUS_UPDATE_FAILED: %', sqlerrm;
  end;

  perform fn_safe_audit(
    v_school_id, 'BADGE_STATUS_CHANGED', 'student_badges', p_badge_id, null,
    jsonb_build_object('new_status', p_new_status::text, 'reason', p_reason,
                        'changed_by', auth.uid(), 'role', v_role)
  );
end;
$$;

revoke all on function fn_guard_suspend_badge(uuid, badge_status, text) from public;
grant execute on function fn_guard_suspend_badge(uuid, badge_status, text) to authenticated;


-- ============================================================================
-- SECTION C — TEACHER SCHEDULE: DOUBLE-BOOKING GUARD
-- CREATE OR REPLACE of the EXISTING fn_set_class_schedule, identical
-- signature (uuid, jsonb) and identical behavior, with exactly one addition:
-- before inserting an entry, reject it if the same teacher already has an
-- entry at the same weekday+period in a DIFFERENT class within the same
-- timetable (i.e. same school + academic year). Entries of the class being
-- replaced were already deleted earlier in the function, so this check
-- naturally only ever sees OTHER classes' entries.
-- ============================================================================

create or replace function fn_set_class_schedule(p_class_id uuid, p_entries jsonb)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_year_id uuid;
  v_tt_id uuid;
  v_entry record;
  v_weekday smallint;
  v_period smallint;
  v_subject uuid;
  v_teacher uuid;
  v_start time;
  v_count int := 0;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  select c.school_id, c.academic_year_id into v_school_id, v_year_id
  from classes c where c.id = p_class_id;
  if v_school_id is null then
    raise exception 'INVALID_CLASS';
  end if;
  if not (fn_is_school_staff(v_school_id)
          or fn_has_permission('schedule.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  select t.id into v_tt_id from timetables t
  where t.school_id = v_school_id and t.academic_year_id = v_year_id
  order by t.created_at
  limit 1;
  if v_tt_id is null then
    insert into timetables (school_id, academic_year_id, name)
    values (v_school_id, v_year_id, 'Default')
    returning id into v_tt_id;
  end if;

  delete from timetable_entries
  where timetable_id = v_tt_id and class_id = p_class_id;

  for v_entry in
    select value from jsonb_array_elements(coalesce(p_entries, '[]'::jsonb))
  loop
    v_weekday := (nullif(v_entry.value ->> 'weekday', '')::smallint + 1);
    if v_weekday is null or v_weekday < 1 or v_weekday > 7 then
      continue;
    end if;

    v_subject := nullif(v_entry.value ->> 'subject_id', '')::uuid;
    if v_subject is null then
      raise exception 'SCHEDULE_SUBJECT_REQUIRED';
    end if;
    if not exists (select 1 from subjects s
                   where s.id = v_subject and s.school_id = v_school_id) then
      raise exception 'INVALID_SUBJECT';
    end if;

    v_teacher := coalesce(
      nullif(v_entry.value ->> 'teacher_id', '')::uuid,
      (select c.teacher_id from classes c where c.id = p_class_id)
    );
    if v_teacher is null then
      raise exception 'SCHEDULE_TEACHER_REQUIRED';
    end if;
    if not exists (select 1 from teachers t
                   where t.id = v_teacher and t.school_id = v_school_id
                     and t.deleted_at is null) then
      raise exception 'INVALID_TEACHER';
    end if;

    v_period := coalesce(nullif(v_entry.value ->> 'period', '')::smallint, 1);
    v_start := time '07:00' + ((v_period - 1) * interval '45 minutes');

    -- NEW: reject if this teacher already teaches ANOTHER class at the
    -- same weekday+period within the same school timetable.
    if exists (
      select 1
      from timetable_entries te
      where te.timetable_id = v_tt_id
        and te.teacher_id = v_teacher
        and te.weekday = v_weekday
        and coalesce(te.period, 1) = v_period
    ) then
      raise exception 'TEACHER_SCHEDULE_CONFLICT';
    end if;

    insert into timetable_entries
      (timetable_id, class_id, subject_id, teacher_id, weekday, starts_at, ends_at, period)
    values
      (v_tt_id, p_class_id, v_subject, v_teacher, v_weekday,
       v_start, v_start + interval '45 minutes', v_period);
    v_count := v_count + 1;
  end loop;

  perform fn_safe_audit(v_school_id, 'SET_CLASS_SCHEDULE', 'timetable_entries', p_class_id,
    null, jsonb_build_object('entries', v_count));

  return v_count;
end;
$$;

revoke all on function fn_set_class_schedule(uuid, jsonb) from public;
grant execute on function fn_set_class_schedule(uuid, jsonb) to authenticated;


-- Small convenience wrapper: derive a STUDENT's timetable from their
-- CURRENT active class, reusing fn_get_class_schedule as-is (no per-student
-- copy is ever created, per item 7).
create or replace function fn_get_student_schedule(p_student_id uuid)
returns table(weekday smallint, period smallint, subject_name text, teacher_name text)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_class_id uuid;
begin
  select school_id into v_school_id from students where id = p_student_id and deleted_at is null;
  if v_school_id is null then
    raise exception 'INVALID_STUDENT';
  end if;
  if not fn_is_school_member(v_school_id) then
    raise exception 'PERMISSION_DENIED';
  end if;

  select class_id into v_class_id
  from student_enrollments
  where student_id = p_student_id and status = 'ACTIVE'
  limit 1;

  if v_class_id is null then
    return;
  end if;

  return query select * from fn_get_class_schedule(v_class_id);
end;
$$;

revoke all on function fn_get_student_schedule(uuid) from public;
grant execute on function fn_get_student_schedule(uuid) to authenticated;


-- ============================================================================
-- SECTION D — TEACHER PAYROLL (new, additive — no existing teacher-payroll
-- system was found, so nothing is merged/replaced; the existing
-- payments/expenses tables for STUDENT fees stay completely untouched)
-- ============================================================================

alter table teachers add column if not exists hourly_rate numeric(10,2);

create table if not exists teacher_payroll_months (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references teachers(id) on delete cascade,
  school_id uuid not null references schools(id) on delete cascade,
  period_month date not null, -- always the 1st of the month, e.g. 2026-09-01
  hourly_rate numeric(10,2) not null default 0,
  hours_worked numeric(6,2) not null default 0,
  amount_due numeric(10,2) generated always as (round(hourly_rate * hours_worked, 2)) stored,
  amount_paid numeric(10,2) not null default 0 check (amount_paid >= 0),
  balance numeric(10,2) generated always as (round(hourly_rate * hours_worked, 2) - amount_paid) stored,
  notes text,
  updated_at timestamptz not null default now(),
  unique (teacher_id, period_month)
);
alter table teacher_payroll_months enable row level security;

do $$ begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'teacher_payroll_months'
      and policyname = 'p_teacher_payroll_staff_read'
  ) then
    create policy p_teacher_payroll_staff_read on teacher_payroll_months
      for select using (fn_is_school_staff(school_id));
  end if;
end $$;

-- All writes go through RPCs (no direct INSERT/UPDATE policy — same model
-- already used for students/payments/salaries elsewhere in this project).

create or replace function fn_set_teacher_rate(p_teacher_id uuid, p_hourly_rate numeric)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select school_id into v_school_id from teachers where id = p_teacher_id and deleted_at is null;
  if v_school_id is null then raise exception 'INVALID_TEACHER'; end if;

  v_role := fn_resolve_my_role(v_school_id);
  if v_role is distinct from 'admin' and v_role is distinct from 'superadmin' then
    raise exception 'PERMISSION_DENIED';
  end if;
  if p_hourly_rate is null or p_hourly_rate < 0 then
    raise exception 'INVALID_AMOUNT';
  end if;

  update teachers set hourly_rate = p_hourly_rate where id = p_teacher_id;

  perform fn_safe_audit(v_school_id, 'TEACHER_RATE_SET', 'teachers', p_teacher_id, null,
    jsonb_build_object('hourly_rate', p_hourly_rate, 'set_by', auth.uid()));
end;
$$;
revoke all on function fn_set_teacher_rate(uuid, numeric) from public;
grant execute on function fn_set_teacher_rate(uuid, numeric) to authenticated;


create or replace function fn_upsert_teacher_month(
  p_teacher_id uuid,
  p_period_month date,
  p_hours_worked numeric,
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
  v_rate numeric;
  v_period date;
  v_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select school_id, coalesce(hourly_rate, 0) into v_school_id, v_rate
  from teachers where id = p_teacher_id and deleted_at is null;
  if v_school_id is null then raise exception 'INVALID_TEACHER'; end if;

  v_role := fn_resolve_my_role(v_school_id);
  if v_role is distinct from 'admin' and v_role is distinct from 'superadmin' then
    raise exception 'PERMISSION_DENIED';
  end if;
  if p_hours_worked is null or p_hours_worked < 0 then
    raise exception 'INVALID_AMOUNT';
  end if;

  v_period := date_trunc('month', p_period_month)::date;

  insert into teacher_payroll_months (teacher_id, school_id, period_month, hourly_rate, hours_worked, notes)
  values (p_teacher_id, v_school_id, v_period, v_rate, p_hours_worked, p_notes)
  on conflict (teacher_id, period_month) do update
    set hours_worked = excluded.hours_worked,
        hourly_rate = v_rate,
        notes = coalesce(excluded.notes, teacher_payroll_months.notes),
        updated_at = now()
  returning id into v_id;

  perform fn_safe_audit(v_school_id, 'TEACHER_PAYROLL_MONTH_SET', 'teacher_payroll_months', v_id, null,
    jsonb_build_object('teacher_id', p_teacher_id, 'period_month', v_period,
                        'hours_worked', p_hours_worked, 'set_by', auth.uid()));

  return v_id;
end;
$$;
revoke all on function fn_upsert_teacher_month(uuid, date, numeric, text) from public;
grant execute on function fn_upsert_teacher_month(uuid, date, numeric, text) to authenticated;


create or replace function fn_record_teacher_payment(
  p_teacher_id uuid,
  p_period_month date,
  p_amount numeric
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
  v_period date;
  v_row_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select school_id into v_school_id from teachers where id = p_teacher_id and deleted_at is null;
  if v_school_id is null then raise exception 'INVALID_TEACHER'; end if;

  v_role := fn_resolve_my_role(v_school_id);
  if v_role is distinct from 'admin' and v_role is distinct from 'superadmin' then
    raise exception 'PERMISSION_DENIED';
  end if;
  if p_amount is null or p_amount <= 0 then
    raise exception 'INVALID_AMOUNT';
  end if;

  v_period := date_trunc('month', p_period_month)::date;

  select id into v_row_id from teacher_payroll_months
  where teacher_id = p_teacher_id and period_month = v_period;

  if v_row_id is null then
    raise exception 'PAYROLL_MONTH_NOT_FOUND';
  end if;

  update teacher_payroll_months
     set amount_paid = amount_paid + p_amount,
         updated_at = now()
   where id = v_row_id;

  perform fn_safe_audit(v_school_id, 'TEACHER_PAYMENT_RECORDED', 'teacher_payroll_months', v_row_id, null,
    jsonb_build_object('teacher_id', p_teacher_id, 'period_month', v_period,
                        'amount', p_amount, 'recorded_by', auth.uid()));
end;
$$;
revoke all on function fn_record_teacher_payment(uuid, date, numeric) from public;
grant execute on function fn_record_teacher_payment(uuid, date, numeric) to authenticated;


create or replace function fn_list_teacher_payroll(p_teacher_id uuid)
returns setof teacher_payroll_months
language sql
stable
security definer
set search_path = public
as $$
  select tpm.*
  from teacher_payroll_months tpm
  join teachers t on t.id = tpm.teacher_id
  where tpm.teacher_id = p_teacher_id
    and fn_is_school_staff(t.school_id)
  order by tpm.period_month desc;
$$;
revoke all on function fn_list_teacher_payroll(uuid) from public;
grant execute on function fn_list_teacher_payroll(uuid) to authenticated;


-- ============================================================================
-- SECTION E — STUDENT HOME LOCATION (Google Maps)
-- ADD COLUMN IF NOT EXISTS is safe whether or not these columns already
-- exist from an earlier phase not included in this bundle — no data risk
-- either way.
-- ============================================================================

alter table students add column if not exists address text;
alter table students add column if not exists latitude double precision;
alter table students add column if not exists longitude double precision;
alter table students add column if not exists location_label text;

create or replace function fn_update_student_location(
  p_student_id uuid,
  p_latitude double precision,
  p_longitude double precision,
  p_address text default null,
  p_location_label text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select school_id into v_school_id from students where id = p_student_id and deleted_at is null;
  if v_school_id is null then raise exception 'INVALID_STUDENT'; end if;

  v_role := fn_resolve_my_role(v_school_id);
  if v_role is null then raise exception 'PERMISSION_DENIED: no role in this school'; end if;
  if v_role <> 'admin' and not fn_has_permission('students.location.manage', v_school_id) then
    raise exception 'PERMISSION_DENIED: missing students.location.manage';
  end if;

  if p_latitude is not null and (p_latitude < -90 or p_latitude > 90) then
    raise exception 'INVALID_LATITUDE';
  end if;
  if p_longitude is not null and (p_longitude < -180 or p_longitude > 180) then
    raise exception 'INVALID_LONGITUDE';
  end if;

  update students
     set latitude = p_latitude,
         longitude = p_longitude,
         address = coalesce(p_address, address),
         location_label = coalesce(p_location_label, location_label)
   where id = p_student_id;

  perform fn_safe_audit(v_school_id, 'STUDENT_LOCATION_UPDATED', 'students', p_student_id, null,
    jsonb_build_object('latitude', p_latitude, 'longitude', p_longitude,
                        'address', p_address, 'updated_by', auth.uid()));
end;
$$;
revoke all on function fn_update_student_location(uuid, double precision, double precision, text, text) from public;
grant execute on function fn_update_student_location(uuid, double precision, double precision, text, text) to authenticated;

-- Register the new permission key if the permissions catalog table exists
-- and doesn't already have it (purely additive; harmless no-op otherwise).
insert into permissions (permission_key, module, name, description)
select 'students.location.manage', 'students', 'تعديل موقع سكن التلميذ',
       'السماح بتعديل/حفظ إحداثيات موقع سكن التلميذ على الخريطة'
where exists (select 1 from information_schema.tables where table_name = 'permissions')
  and not exists (select 1 from permissions where permission_key = 'students.location.manage')
on conflict do nothing;

-- ============================================================================
-- END OF PHASE 18
-- ============================================================================
