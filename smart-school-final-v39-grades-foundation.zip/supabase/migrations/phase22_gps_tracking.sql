-- ============================================================================
-- PHASE 22 — LIVE GPS BUS TRACKING (items 17-26)
-- ADDITIVE ONLY. Checked first (per rule #7/44): no GPS/location-history
-- table exists anywhere in the project's SQL history (only bus_stops has
-- static lat/lng for fixed stops — unrelated). This is genuinely new.
--
-- Design: bus_trip_locations = full history (for audit/replay later, kept
-- lean); bus_last_locations = one row per bus, upserted on every ping, so
-- "where is bus X right now" is a single indexed lookup (item 21) instead
-- of scanning history. Both are written ONLY through
-- fn_record_gps_ping (security definer) — RLS on the tables themselves
-- grants staff SELECT and otherwise denies everything, so a driver cannot
-- write a GPS row for a trip/bus that isn't theirs no matter what the
-- client sends (item 26, checked again inside the function itself, not
-- just at the RLS layer).
-- ============================================================================

create table if not exists bus_trip_locations (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references bus_trips(id) on delete cascade,
  driver_id uuid not null references drivers(id) on delete cascade,
  bus_id uuid not null references buses(id) on delete cascade,
  school_id uuid not null references schools(id) on delete cascade,
  latitude double precision not null,
  longitude double precision not null,
  accuracy double precision,
  speed double precision,
  heading double precision,
  recorded_at timestamptz not null default now()
);
create index if not exists ix_bus_trip_locations_trip on bus_trip_locations (trip_id, recorded_at desc);
alter table bus_trip_locations enable row level security;

do $$ begin
  if not exists (select 1 from pg_policies where schemaname = 'public' and tablename = 'bus_trip_locations'
                 and policyname = 'p_bus_trip_locations_staff_read') then
    create policy p_bus_trip_locations_staff_read on bus_trip_locations
      for select using (fn_is_school_staff(school_id));
  end if;
end $$;
-- No insert/update/delete policy on purpose: all writes go through
-- fn_record_gps_ping (security definer) exactly like teacher_payroll_months
-- in Phase 18 and student_badges elsewhere in this project.

create table if not exists bus_last_locations (
  bus_id uuid primary key references buses(id) on delete cascade,
  trip_id uuid references bus_trips(id) on delete set null,
  driver_id uuid references drivers(id),
  school_id uuid not null references schools(id) on delete cascade,
  latitude double precision not null,
  longitude double precision not null,
  accuracy double precision,
  speed double precision,
  heading double precision,
  recorded_at timestamptz not null default now()
);
alter table bus_last_locations enable row level security;

do $$ begin
  if not exists (select 1 from pg_policies where schemaname = 'public' and tablename = 'bus_last_locations'
                 and policyname = 'p_bus_last_locations_staff_read') then
    create policy p_bus_last_locations_staff_read on bus_last_locations
      for select using (fn_is_school_staff(school_id));
  end if;
end $$;

create or replace function fn_record_gps_ping(
  p_trip_id uuid,
  p_latitude double precision,
  p_longitude double precision,
  p_accuracy double precision default null,
  p_speed double precision default null,
  p_heading double precision default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_trip bus_trips%rowtype;
  v_driver_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;

  select d.id into v_driver_id from drivers d
  where d.profile_id = auth.uid() and d.deleted_at is null limit 1;
  if v_driver_id is null then raise exception 'NOT_A_DRIVER'; end if;

  select * into v_trip from bus_trips where id = p_trip_id;
  -- Item 26: server-side check, not just RLS — the trip must be this
  -- driver's own AND currently active. A GPS ping for any other trip
  -- (even the driver's own past trip) is rejected outright.
  if v_trip.id is null or v_trip.driver_id <> v_driver_id then
    raise exception 'PERMISSION_DENIED';
  end if;
  if v_trip.status <> 'ACTIVE'::trip_status then
    raise exception 'TRIP_NOT_ACTIVE';
  end if;

  if p_latitude < -90 or p_latitude > 90 or p_longitude < -180 or p_longitude > 180 then
    raise exception 'INVALID_COORDINATES';
  end if;

  insert into bus_trip_locations (trip_id, driver_id, bus_id, school_id, latitude, longitude, accuracy, speed, heading)
  values (p_trip_id, v_driver_id, v_trip.bus_id, v_trip.school_id, p_latitude, p_longitude, p_accuracy, p_speed, p_heading);

  insert into bus_last_locations (bus_id, trip_id, driver_id, school_id, latitude, longitude, accuracy, speed, heading, recorded_at)
  values (v_trip.bus_id, p_trip_id, v_driver_id, v_trip.school_id, p_latitude, p_longitude, p_accuracy, p_speed, p_heading, now())
  on conflict (bus_id) do update
    set trip_id = excluded.trip_id, driver_id = excluded.driver_id,
        latitude = excluded.latitude, longitude = excluded.longitude,
        accuracy = excluded.accuracy, speed = excluded.speed, heading = excluded.heading,
        recorded_at = excluded.recorded_at;
end;
$$;
revoke all on function fn_record_gps_ping(uuid, double precision, double precision, double precision, double precision, double precision) from public;
grant execute on function fn_record_gps_ping(uuid, double precision, double precision, double precision, double precision, double precision) to authenticated;


-- fn_get_active_bus_locations — everything Admin's live map needs in one
-- call: only ACTIVE trips, only the caller's own school (item 40).
create or replace function fn_get_active_bus_locations()
returns table(
  bus_id uuid, bus_code text, bus_plate text,
  trip_id uuid, direction text, driver_name text, route_name text,
  latitude double precision, longitude double precision,
  accuracy double precision, speed double precision, heading double precision,
  recorded_at timestamptz, trip_started_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select ur.school_id into v_school_id from user_roles ur
  where ur.profile_id = auth.uid() and ur.role in ('admin', 'director', 'superadmin') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  return query
  select b.id, b.code, b.plate_number,
         t.id, case when t.direction = 'TO_SCHOOL'::trip_direction then 'pickup' else 'dropoff' end,
         p.full_name, r.name,
         ll.latitude, ll.longitude, ll.accuracy, ll.speed, ll.heading, ll.recorded_at,
         t.starts_at
  from bus_trips t
  join buses b on b.id = t.bus_id
  left join bus_last_locations ll on ll.bus_id = b.id and ll.trip_id = t.id
  left join drivers d on d.id = t.driver_id
  left join profiles p on p.id = d.profile_id
  left join bus_routes r on r.id = t.route_id
  where t.school_id = v_school_id
    and t.status = 'ACTIVE'::trip_status
  order by t.starts_at desc;
end;
$$;
revoke all on function fn_get_active_bus_locations() from public;
grant execute on function fn_get_active_bus_locations() to authenticated;

-- ============================================================================
-- END OF PHASE 22
-- ============================================================================
