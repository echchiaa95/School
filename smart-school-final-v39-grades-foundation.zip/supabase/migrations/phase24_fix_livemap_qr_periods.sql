-- ============================================================================
-- PHASE 24 — SCHEDULE: LOCK THE PERIOD MODEL TO EXACTLY 4 + 4 (item 5)
-- ADDITIVE / SAFE. school_period_configs (Phase 23) is not dropped, no data
-- lost — existing rows are simply normalized to 4+4 here, and the RPC that
-- sets them no longer accepts a lesson-count parameter at all, so it can
-- never be set to anything else again.
-- ============================================================================

-- Normalize any existing config rows to the fixed 4+4 model (safe UPDATE,
-- not a destructive rebuild — every other column is left untouched).
update school_period_configs
set morning_lessons = 4, afternoon_lessons = 4
where morning_lessons <> 4 or afternoon_lessons <> 4;

do $$ begin
  if not exists (
    select 1 from pg_constraint where conname = 'chk_school_period_configs_4_4'
  ) then
    alter table school_period_configs
      add constraint chk_school_period_configs_4_4
      check (morning_lessons = 4 and afternoon_lessons = 4);
  end if;
end $$;

-- fn_set_school_periods: signature simplified (drop the lesson-count
-- params entirely — Admin can no longer set them to anything but 4+4).
drop function if exists fn_set_school_periods(time, int, int, time, int, int);

create function fn_set_school_periods(
  p_morning_start time,
  p_morning_lesson_minutes int,
  p_afternoon_start time,
  p_afternoon_lesson_minutes int
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  select school_id into v_school_id from user_roles
  where profile_id = auth.uid() and role in ('admin', 'director') limit 1;
  if v_school_id is null then raise exception 'PERMISSION_DENIED'; end if;

  if p_morning_lesson_minutes is null or p_morning_lesson_minutes < 15 then raise exception 'INVALID_DURATION'; end if;
  if p_afternoon_lesson_minutes is null or p_afternoon_lesson_minutes < 15 then raise exception 'INVALID_DURATION'; end if;

  insert into school_period_configs
    (school_id, morning_start, morning_lesson_minutes, morning_lessons,
     afternoon_start, afternoon_lesson_minutes, afternoon_lessons)
  values (v_school_id, p_morning_start, p_morning_lesson_minutes, 4,
          p_afternoon_start, p_afternoon_lesson_minutes, 4)
  on conflict (school_id) do update set
    morning_start = excluded.morning_start, morning_lesson_minutes = excluded.morning_lesson_minutes,
    afternoon_start = excluded.afternoon_start, afternoon_lesson_minutes = excluded.afternoon_lesson_minutes,
    morning_lessons = 4, afternoon_lessons = 4,
    updated_at = now();

  perform fn_safe_audit(v_school_id, 'SCHOOL_PERIODS_SET', 'school_period_configs', v_school_id, null,
    jsonb_build_object('morning_start', p_morning_start, 'afternoon_start', p_afternoon_start));
end;
$$;
revoke all on function fn_set_school_periods(time, int, time, int) from public;
grant execute on function fn_set_school_periods(time, int, time, int) to authenticated;

-- fn_get_school_periods / fn_add_lesson / fn_update_lesson are UNCHANGED —
-- they already read morning_lessons/afternoon_lessons from the config row
-- rather than assuming a number, so locking those two columns to 4 here
-- automatically caps every school at 8 lessons/day with zero other code
-- changes needed.

-- ============================================================================
-- END OF PHASE 24
-- ============================================================================
