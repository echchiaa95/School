-- PHASE 36 — Admin teacher schedule + timetable PDF runtime hardening
-- MUTATING migration. Run once on the correct Smart School Supabase project.
-- No timezone/time changes. No data deletion.

-- 1) Stable admin-only teacher schedule reader.
-- Uses unique output names (entry_id) so PL/pgSQL output variables can never
-- collide with table columns named id. The frontend normalizes entry_id -> id.
DROP FUNCTION IF EXISTS public.fn_admin_get_teacher_schedule(uuid);

CREATE FUNCTION public.fn_admin_get_teacher_schedule(p_teacher_id uuid)
RETURNS TABLE(
  entry_id uuid,
  weekday smallint,
  period smallint,
  class_id uuid,
  class_name text,
  subject_id uuid,
  subject_name text,
  teacher_id uuid,
  starts_at time,
  ends_at time
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_school_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;

  SELECT t.school_id
    INTO v_school_id
  FROM public.teachers AS t
  WHERE t.id = p_teacher_id
    AND t.deleted_at IS NULL;

  IF v_school_id IS NULL THEN
    RAISE EXCEPTION 'INVALID_TEACHER';
  END IF;

  IF NOT public.fn_is_school_staff(v_school_id) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  RETURN QUERY
  SELECT
    te.id AS entry_id,
    (te.weekday - 1)::smallint AS weekday,
    COALESCE(te.period, 1)::smallint AS period,
    c.id AS class_id,
    c.name AS class_name,
    su.id AS subject_id,
    su.name AS subject_name,
    te.teacher_id AS teacher_id,
    te.starts_at AS starts_at,
    te.ends_at AS ends_at
  FROM public.timetable_entries AS te
  JOIN public.classes AS c
    ON c.id = te.class_id
  JOIN public.subjects AS su
    ON su.id = te.subject_id
  WHERE te.teacher_id = p_teacher_id
  ORDER BY te.weekday, COALESCE(te.period, 1), te.starts_at, te.id;
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_admin_get_teacher_schedule(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_admin_get_teacher_schedule(uuid) TO authenticated;

-- 2) Make the historical route RPC explicitly stable and school-scoped.
-- It returns only recorded GPS points. A missing route therefore means that
-- the selected trip has no stored trip GPS points; no coordinates are invented.
DROP FUNCTION IF EXISTS public.fn_get_trip_route_history(uuid);

CREATE FUNCTION public.fn_get_trip_route_history(p_trip_id uuid)
RETURNS TABLE(
  latitude double precision,
  longitude double precision,
  speed double precision,
  recorded_at timestamptz
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_school_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;

  SELECT bt.school_id
    INTO v_school_id
  FROM public.bus_trips AS bt
  WHERE bt.id = p_trip_id;

  IF v_school_id IS NULL THEN
    RAISE EXCEPTION 'INVALID_TRIP';
  END IF;

  IF NOT public.fn_is_school_staff(v_school_id) THEN
    RAISE EXCEPTION 'PERMISSION_DENIED';
  END IF;

  RETURN QUERY
  SELECT
    btl.latitude,
    btl.longitude,
    btl.speed,
    btl.recorded_at
  FROM public.bus_trip_locations AS btl
  WHERE btl.trip_id = p_trip_id
  ORDER BY btl.recorded_at ASC, btl.id ASC;
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_get_trip_route_history(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_get_trip_route_history(uuid) TO authenticated;
