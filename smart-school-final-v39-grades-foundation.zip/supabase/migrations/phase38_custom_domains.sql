-- ============================================================================
-- PHASE 38 — CUSTOM DOMAINS & TENANT RESOLUTION
-- Smart School SaaS
--
-- Adds domain mapping without changing existing school/user/GPS/schedule data.
-- Supports:
--   1) platform subdomains: school-code.elbordiji.com
--   2) customer domains: ecole-alamal.ma / school.ecole-alamal.ma
--
-- SECURITY:
--   * Domain management is SuperAdmin-only through SECURITY DEFINER RPCs.
--   * Public resolver exposes only active verified school branding.
--   * A hostname NEVER grants access by itself; authenticated user_roles.school_id
--     is still checked by the application and existing RLS/RPC authorization.
-- ============================================================================

create extension if not exists pgcrypto;

create table if not exists public.school_domains (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  domain text not null,
  domain_type text not null default 'custom' check (domain_type in ('custom','platform_subdomain')),
  status text not null default 'pending' check (status in ('pending','active','disabled')),
  verification_token text not null default encode(gen_random_bytes(18), 'hex'),
  verified_at timestamptz,
  is_primary boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint school_domains_domain_unique unique(domain)
);

create index if not exists idx_school_domains_school on public.school_domains(school_id);
create index if not exists idx_school_domains_active on public.school_domains(domain) where status = 'active';

alter table public.school_domains enable row level security;

-- No direct policies: all management goes through RPCs.

create or replace function public.fn_normalize_school_domain(p_domain text)
returns text
language plpgsql
immutable
as $$
declare v text;
begin
  v := lower(trim(coalesce(p_domain, '')));
  v := regexp_replace(v, '^https?://', '', 'i');
  v := split_part(v, '/', 1);
  v := split_part(v, '?', 1);
  v := split_part(v, '#', 1);
  v := regexp_replace(v, ':\d+$', '');
  v := regexp_replace(v, '^\.+|\.+$', '', 'g');
  return v;
end;
$$;

create or replace function public.fn_superadmin_list_school_domains(p_school_id uuid default null)
returns table(
  id uuid,
  school_id uuid,
  domain text,
  domain_type text,
  status text,
  verification_token text,
  verified_at timestamptz,
  is_primary boolean,
  created_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not exists (select 1 from user_roles ur where ur.profile_id = auth.uid() and ur.role = 'superadmin') then
    raise exception 'PERMISSION_DENIED';
  end if;
  return query
  select d.id,d.school_id,d.domain,d.domain_type,d.status,d.verification_token,d.verified_at,d.is_primary,d.created_at
  from school_domains d
  where p_school_id is null or d.school_id = p_school_id
  order by d.is_primary desc, d.created_at desc;
end;
$$;

create or replace function public.fn_superadmin_add_school_domain(
  p_school_id uuid,
  p_domain text,
  p_domain_type text default 'custom'
)
returns table(id uuid, domain text, domain_type text, status text, verification_token text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_domain text := fn_normalize_school_domain(p_domain);
  v_id uuid;
  v_status text;
  v_token text;
begin
  if not exists (select 1 from user_roles ur where ur.profile_id = auth.uid() and ur.role = 'superadmin') then
    raise exception 'PERMISSION_DENIED';
  end if;
  if not exists (select 1 from schools s where s.id = p_school_id) then raise exception 'INVALID_SCHOOL'; end if;
  if v_domain = '' or position('.' in v_domain) = 0 or v_domain !~ '^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$' then
    raise exception 'INVALID_DOMAIN';
  end if;
  if p_domain_type not in ('custom','platform_subdomain') then raise exception 'INVALID_DOMAIN_TYPE'; end if;
  if p_domain_type = 'platform_subdomain' and (v_domain !~ '\.elbordiji\.com$' or v_domain = 'elbordiji.com') then
    raise exception 'INVALID_PLATFORM_DOMAIN';
  end if;
  if p_domain_type = 'custom' and v_domain ~ '\.elbordiji\.com$' then raise exception 'USE_PLATFORM_TYPE'; end if;

  select d.id into v_id from school_domains d where d.domain = v_domain;
  if v_id is not null then raise exception 'DOMAIN_EXISTS'; end if;

  v_status := case when p_domain_type = 'platform_subdomain' then 'active' else 'pending' end;
  insert into school_domains(school_id,domain,domain_type,status,verified_at,is_primary)
  values(p_school_id,v_domain,p_domain_type,v_status,case when v_status='active' then now() else null end,false)
  returning school_domains.id, school_domains.verification_token into v_id,v_token;

  perform fn_write_audit(p_school_id,'ADD_CUSTOM_DOMAIN','school_domains',v_id,null,
    jsonb_build_object('domain',v_domain,'domain_type',p_domain_type,'status',v_status));

  return query select v_id,v_domain,p_domain_type,v_status,v_token;
end;
$$;

create or replace function public.fn_superadmin_confirm_school_domain(p_domain_id uuid)
returns table(id uuid, domain text, status text, verified_at timestamptz)
language plpgsql
security definer
set search_path = public
as $$
declare v_school_id uuid; v_domain text;
begin
  if not exists (select 1 from user_roles ur where ur.profile_id = auth.uid() and ur.role = 'superadmin') then
    raise exception 'PERMISSION_DENIED';
  end if;
  select d.school_id,d.domain into v_school_id,v_domain from school_domains d where d.id=p_domain_id;
  if v_school_id is null then raise exception 'DOMAIN_NOT_FOUND'; end if;
  if v_domain ~ '\.elbordiji\.com$' then
    update school_domains set status='active',verified_at=coalesce(verified_at,now()),updated_at=now() where id=p_domain_id;
  else
    -- The browser/server verifies the DNS TXT token first; this RPC only commits
    -- the already-verified result and is intentionally SuperAdmin-only.
    update school_domains set status='active',verified_at=now(),updated_at=now() where id=p_domain_id;
  end if;
  perform fn_write_audit(v_school_id,'VERIFY_CUSTOM_DOMAIN','school_domains',p_domain_id,null,
    jsonb_build_object('domain',v_domain,'status','active'));
  return query select d.id,d.domain,d.status,d.verified_at from school_domains d where d.id=p_domain_id;
end;
$$;

create or replace function public.fn_superadmin_disable_school_domain(p_domain_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare v_school_id uuid; v_domain text;
begin
  if not exists (select 1 from user_roles ur where ur.profile_id = auth.uid() and ur.role = 'superadmin') then raise exception 'PERMISSION_DENIED'; end if;
  select school_id,domain into v_school_id,v_domain from school_domains where id=p_domain_id;
  if v_school_id is null then raise exception 'DOMAIN_NOT_FOUND'; end if;
  update school_domains set status='disabled',is_primary=false,updated_at=now() where id=p_domain_id;
  perform fn_write_audit(v_school_id,'DISABLE_CUSTOM_DOMAIN','school_domains',p_domain_id,null,jsonb_build_object('domain',v_domain));
end;
$$;

create or replace function public.fn_superadmin_set_primary_domain(p_domain_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare v_school_id uuid;
begin
  if not exists (select 1 from user_roles ur where ur.profile_id = auth.uid() and ur.role = 'superadmin') then raise exception 'PERMISSION_DENIED'; end if;
  select school_id into v_school_id from school_domains where id=p_domain_id and status='active';
  if v_school_id is null then raise exception 'DOMAIN_NOT_FOUND'; end if;
  update school_domains set is_primary=false,updated_at=now() where school_id=v_school_id;
  update school_domains set is_primary=true,updated_at=now() where id=p_domain_id;
end;
$$;

-- Public tenant resolver: safe to call before authentication.
create or replace function public.fn_resolve_school_domain(p_hostname text)
returns table(
  school_id uuid,
  school_name text,
  logo_url text,
  domain text
)
language sql
stable
security definer
set search_path = public
as $$
  select d.school_id, s.name, s.logo_url, d.domain
  from school_domains d
  join schools s on s.id=d.school_id
  where d.domain = fn_normalize_school_domain(p_hostname)
    and d.status='active'
    and coalesce(s.is_disabled,false)=false
  limit 1;
$$;

revoke all on function public.fn_normalize_school_domain(text) from public;
revoke all on function public.fn_superadmin_list_school_domains(uuid) from public;
revoke all on function public.fn_superadmin_add_school_domain(uuid,text,text) from public;
revoke all on function public.fn_superadmin_confirm_school_domain(uuid) from public;
revoke all on function public.fn_superadmin_disable_school_domain(uuid) from public;
revoke all on function public.fn_superadmin_set_primary_domain(uuid) from public;
revoke all on function public.fn_resolve_school_domain(text) from public;

grant execute on function public.fn_superadmin_list_school_domains(uuid) to authenticated;
grant execute on function public.fn_superadmin_add_school_domain(uuid,text,text) to authenticated;
grant execute on function public.fn_superadmin_confirm_school_domain(uuid) to authenticated;
grant execute on function public.fn_superadmin_disable_school_domain(uuid) to authenticated;
grant execute on function public.fn_superadmin_set_primary_domain(uuid) to authenticated;
grant execute on function public.fn_resolve_school_domain(text) to anon, authenticated;

comment on table public.school_domains is 'Smart School SaaS custom/platform domain mappings; managed only through SuperAdmin RPCs.';
