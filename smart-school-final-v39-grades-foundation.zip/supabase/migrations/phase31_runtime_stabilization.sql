-- PHASE 31 — Runtime stabilization
-- Additive/safe. Do NOT rerun Phase 29.
BEGIN;

-- 1) Audit trigger: live audit_logs uses old_data/new_data, not old_value/new_value.
CREATE OR REPLACE FUNCTION public.fn_audit_row()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_row jsonb;
  v_old jsonb;
  v_new jsonb;
  v_school uuid;
BEGIN
  v_row := CASE WHEN TG_OP = 'DELETE' THEN to_jsonb(OLD) ELSE to_jsonb(NEW) END;
  v_old := CASE WHEN TG_OP IN ('UPDATE','DELETE') THEN to_jsonb(OLD) ELSE NULL END;
  v_new := CASE WHEN TG_OP IN ('INSERT','UPDATE') THEN to_jsonb(NEW) ELSE NULL END;
  IF TG_TABLE_NAME = 'student_badges' THEN
    v_old := CASE WHEN v_old IS NULL THEN NULL ELSE v_old - 'secure_token' END;
    v_new := CASE WHEN v_new IS NULL THEN NULL ELSE v_new - 'secure_token' END;
  END IF;
  v_school := NULLIF(v_row ->> 'school_id','')::uuid;
  IF v_school IS NULL AND v_row ? 'student_id' THEN
    SELECT s.school_id INTO v_school FROM public.students s WHERE s.id = (v_row ->> 'student_id')::uuid;
  END IF;
  INSERT INTO public.audit_logs(school_id,user_id,actor_id,action,entity,entity_id,old_data,new_data)
  VALUES(v_school,auth.uid(),auth.uid(),TG_OP,TG_TABLE_NAME,NULLIF(v_row->>'id','')::uuid,v_old,v_new);
  RETURN COALESCE(NEW,OLD);
END;
$$;
REVOKE ALL ON FUNCTION public.fn_audit_row() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_audit_row() TO authenticated;

-- 2) Driver-controlled passenger order. Route stop order remains untouched.
ALTER TABLE public.student_transport_assignments
  ADD COLUMN IF NOT EXISTS driver_order integer;
CREATE INDEX IF NOT EXISTS ix_sta_bus_driver_order
  ON public.student_transport_assignments(bus_id, driver_order);

CREATE OR REPLACE FUNCTION public.fn_set_driver_passenger_order(p_bus_id uuid, p_student_ids jsonb)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_ctx jsonb;
  v_school uuid;
  v_id uuid;
  v_i integer := 0;
BEGIN
  SELECT school_id INTO v_school FROM public.buses WHERE id=p_bus_id;
  IF v_school IS NULL THEN RAISE EXCEPTION 'INVALID_BUS'; END IF;
  v_ctx := public.fn_driver_context();
  IF v_ctx IS NULL OR (v_ctx->>'bus_id')::uuid <> p_bus_id THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  IF jsonb_typeof(p_student_ids) <> 'array' THEN RAISE EXCEPTION 'INVALID_ORDER'; END IF;

  FOR v_id IN SELECT value::uuid FROM jsonb_array_elements_text(p_student_ids)
  LOOP
    v_i := v_i + 1;
    UPDATE public.student_transport_assignments
      SET driver_order = v_i
    WHERE bus_id=p_bus_id AND student_id=v_id AND is_active=true;
  END LOOP;
  RETURN v_i;
END;
$$;
REVOKE ALL ON FUNCTION public.fn_set_driver_passenger_order(uuid,jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_set_driver_passenger_order(uuid,jsonb) TO authenticated;

-- Keep the audited 13-column return shape; only change ordering.
CREATE OR REPLACE FUNCTION public.fn_list_bus_students_ordered(p_bus_id uuid, p_trip_id uuid DEFAULT NULL)
RETURNS TABLE(student_id uuid, full_name text, student_number text, pickup_stop text, dropoff_stop text, stop_order int, stop_latitude double precision, stop_longitude double precision, student_latitude double precision, student_longitude double precision, boarded_at timestamptz, alighted_at timestamptz)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_school_id uuid; v_ctx jsonb;
BEGIN
  SELECT school_id INTO v_school_id FROM buses WHERE id=p_bus_id;
  IF v_school_id IS NULL THEN RAISE EXCEPTION 'INVALID_BUS'; END IF;
  v_ctx := fn_driver_context();
  IF NOT (fn_is_school_member(v_school_id) OR (v_ctx IS NOT NULL AND (v_ctx->>'bus_id')::uuid=p_bus_id)) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  RETURN QUERY
  SELECT sta.student_id,s.full_name,s.student_number,bs_pick.name,bs_drop.name,brs.sequence_order,
         bs_pick.latitude,bs_pick.longitude,s.latitude,s.longitude,bts.boarded_at,bts.dropped_at
  FROM student_transport_assignments sta
  JOIN students s ON s.id=sta.student_id AND s.deleted_at IS NULL
  LEFT JOIN bus_stops bs_pick ON bs_pick.id=sta.pickup_stop_id
  LEFT JOIN bus_stops bs_drop ON bs_drop.id=sta.dropoff_stop_id
  LEFT JOIN bus_route_stops brs ON brs.route_id=sta.route_id AND brs.stop_id=sta.pickup_stop_id
  LEFT JOIN bus_trip_students bts ON bts.trip_id=p_trip_id AND bts.student_id=sta.student_id
  WHERE sta.bus_id=p_bus_id AND sta.is_active
  ORDER BY coalesce(sta.driver_order,999999), coalesce(brs.sequence_order,999999), s.full_name;
END;
$$;
REVOKE ALL ON FUNCTION public.fn_list_bus_students_ordered(uuid,uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_list_bus_students_ordered(uuid,uuid) TO authenticated;

-- 3) Teacher: server resolves the authenticated teacher; never exposes other teachers' lessons.
CREATE OR REPLACE FUNCTION public.fn_get_my_teacher_schedule()
RETURNS TABLE(weekday smallint, period smallint, class_id uuid, class_name text, subject_name text, starts_at time, ends_at time)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_teacher_id uuid;
BEGIN
  SELECT t.id INTO v_teacher_id FROM teachers t WHERE t.profile_id=auth.uid() AND t.deleted_at IS NULL LIMIT 1;
  IF v_teacher_id IS NULL THEN RAISE EXCEPTION 'INVALID_TEACHER'; END IF;
  RETURN QUERY
  SELECT (te.weekday-1)::smallint, coalesce(te.period,1)::smallint, c.id,c.name,su.name,te.starts_at,te.ends_at
  FROM timetable_entries te
  JOIN classes c ON c.id=te.class_id
  JOIN subjects su ON su.id=te.subject_id
  WHERE te.teacher_id=v_teacher_id AND NOT c.is_disabled
  ORDER BY te.weekday,te.starts_at,coalesce(te.period,1);
END;
$$;
REVOKE ALL ON FUNCTION public.fn_get_my_teacher_schedule() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_get_my_teacher_schedule() TO authenticated;

-- 4) Parent: student timetable including exact lesson times.
CREATE OR REPLACE FUNCTION public.fn_get_student_schedule_with_time(p_student_id uuid)
RETURNS TABLE(weekday smallint, period smallint, subject_name text, teacher_name text, starts_at time, ends_at time)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public
AS $$
DECLARE v_school_id uuid; v_class_id uuid;
BEGIN
  SELECT school_id INTO v_school_id FROM students WHERE id=p_student_id AND deleted_at IS NULL;
  IF v_school_id IS NULL THEN RAISE EXCEPTION 'INVALID_STUDENT'; END IF;
  IF NOT fn_is_school_member(v_school_id) AND NOT fn_is_parent_of(p_student_id) THEN RAISE EXCEPTION 'PERMISSION_DENIED'; END IF;
  SELECT class_id INTO v_class_id FROM student_enrollments WHERE student_id=p_student_id AND status='ACTIVE' LIMIT 1;
  IF v_class_id IS NULL THEN RETURN; END IF;
  RETURN QUERY
  SELECT (te.weekday-1)::smallint,coalesce(te.period,1)::smallint,su.name,
         (SELECT p.full_name FROM teachers t JOIN profiles p ON p.id=t.profile_id WHERE t.id=te.teacher_id),
         te.starts_at,te.ends_at
  FROM timetable_entries te JOIN subjects su ON su.id=te.subject_id
  WHERE te.class_id=v_class_id
  ORDER BY te.weekday,te.starts_at,coalesce(te.period,1);
END;
$$;
REVOKE ALL ON FUNCTION public.fn_get_student_schedule_with_time(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_get_student_schedule_with_time(uuid) TO authenticated;

COMMIT;
