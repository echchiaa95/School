V24 — Admin runtime fixes

- Unified frontend cache version to v30 to eliminate mixed v28/v29 module deployments.
- Fixed admin schedule runtime error scEditingEntryId and made schedule selector binding defensive.
- Teacher detail now shows both actual timetable entries and academic class/subject assignments.
- Student photo upload now explicitly offers Gallery/Device and Camera.
- Previous-trip GPS route is persistent and separate from active-trip route polling; it no longer disappears on refresh.
- No database/time/timezone changes.
