# Smart School V38

## Phase 38 — Custom Domains & Tenant Resolution

- Added `school_domains` tenant-domain mapping table.
- Added SuperAdmin RPCs for add/list/verify/disable/set-primary.
- Added safe public hostname resolver.
- Added custom-domain tenant isolation check to authenticated school pages.
- Added custom-domain branding on the login page.
- Added SuperAdmin UI inside school details for domain management.
- Added DNS TXT ownership verification through DNS-over-HTTPS.
- Added mobile-friendly domain cards and verification instructions.
- Added deployment notes for wildcard platform subdomains, customer domains, Nginx and Cloudflare edge routing.

## Compatibility
- Existing `school.elbordiji.com` remains usable as the platform host.
- No changes to GPS, trips, schedules, attendance, payments, students or time/timezone settings.
