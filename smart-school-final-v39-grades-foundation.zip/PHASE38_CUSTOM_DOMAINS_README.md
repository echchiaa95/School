# Smart School — Phase 38: Custom Domains

## What this adds
- SuperAdmin can attach a platform subdomain or customer-owned domain to a school.
- Public hostname resolution maps an active verified hostname to `school_id` and safe branding.
- Authenticated school users are blocked when they use a custom domain belonging to another school.
- Login page displays the school's name/logo on a mapped custom domain.
- DNS TXT ownership verification is shown in SuperAdmin and checked through DNS-over-HTTPS before activation.
- Existing `school.elbordiji.com` remains a platform host and keeps working during rollout.

## Database
Run once on the correct Smart School Supabase project:
`supabase/migrations/phase38_custom_domains.sql`

This migration is mutating. Do not rerun it unnecessarily.

## Domain examples
### Platform subdomain
`mssalla.elbordiji.com`

DNS:
- `A` or wildcard `*.elbordiji.com` -> the same server IP used by the current Smart School host.
- The web server must accept `*.elbordiji.com` and have a matching TLS certificate.

Platform subdomains are activated immediately by SuperAdmin after registration because ownership is controlled by the platform DNS zone.

### Customer-owned domain
`ecole-alamal.ma` or `school.ecole-alamal.ma`

1. Add the domain in SuperAdmin.
2. Add the displayed TXT record:
   `_smartschool-verify.<domain>` = the generated token.
3. Point the web traffic to the Smart School edge/server.
4. Press **تحقق وتفعيل**.
5. The application marks the domain active.

For an apex/root domain, use the DNS provider's supported `A`, `ALIAS`, or `ANAME` mechanism. A normal CNAME at the root is not supported by many DNS providers.

## HTTPS / edge routing
The SQL and frontend cannot issue TLS certificates or modify Nginx by themselves. The production edge must also accept the new hostname.

Recommended production architecture for many customer domains:

`Customer DNS -> Cloudflare Custom Hostname/SSL -> Smart School origin -> static app`

Alternative for a small number of domains:
- Add each verified hostname to the Nginx `server_name` list.
- Issue/renew its certificate with Certbot.

For platform subdomains, a wildcard certificate such as `*.elbordiji.com` is recommended.

## Important security rule
The domain is never treated as proof of authorization. It only resolves a tenant hint. The authenticated account's `user_roles.school_id`, existing RLS and existing RPC permission checks remain authoritative.

## Rollout order
1. Run Phase 38 SQL once.
2. Deploy the V38 web files.
3. Configure wildcard/platform DNS and TLS.
4. Register a test platform subdomain.
5. Test login and a school user.
6. Register one real customer domain and complete TXT verification.
7. Configure the edge/TLS for that customer hostname.
8. Test all role pages from the custom hostname.

## Supabase Auth configuration
Because password recovery uses the current browser origin, every production hostname must be allowed in the Supabase Auth URL/Redirect URL configuration. Add the platform host and each active customer hostname (or an appropriately restricted wildcard supported by the Supabase project). Do not use an unrestricted wildcard such as `*` in production.
