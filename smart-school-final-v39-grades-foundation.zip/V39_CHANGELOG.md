# V39 — Weighted Grades Foundation
- Added weighted assessment and mark tables.
- Added teacher notes per mark.
- Added semester result aggregation RPC.
- Preserved existing transport, attendance, timezone, and domain functionality.
