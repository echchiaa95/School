// ============================================================================
// modules/tenant.js — Phase 38 tenant/domain resolution.
// Hostname is only a tenant hint. Authorization remains school_id + RLS/RPC.
// ============================================================================
import { supabase } from './supabase.js?v=38';

const PLATFORM_HOSTS = new Set([
  'elbordiji.com',
  'www.elbordiji.com',
  'school.elbordiji.com',
  'localhost',
  '127.0.0.1',
]);

function normalizeHost(host) {
  return String(host || window.location.hostname || '').trim().toLowerCase().replace(/\.$/, '');
}

export function isPlatformHost(host = window.location.hostname) {
  const h = normalizeHost(host);
  return PLATFORM_HOSTS.has(h);
}

export function isPlatformSubdomain(host = window.location.hostname) {
  const h = normalizeHost(host);
  return h.endsWith('.elbordiji.com');
}

export async function resolveTenant(host = window.location.hostname) {
  const hostname = normalizeHost(host);
  if (!hostname) return { ok: false, kind: 'invalid', error: 'عنوان الموقع غير صالح.' };

  try {
    const { data, error } = await supabase.rpc('fn_resolve_school_domain', { p_hostname: hostname });
    if (error) {
      // Keep the current platform host usable while Phase 38 is being deployed.
      if (isPlatformHost(hostname)) return { ok: true, platform: true, tenant: null };
      return { ok: false, kind: 'resolver_error', error: 'تعذر التحقق من المؤسسة المرتبطة بهذا الدومين.' };
    }
    const row = Array.isArray(data) ? data[0] : data;
    if (row?.school_id) return { ok: true, platform: false, tenant: row };

    if (isPlatformHost(hostname)) return { ok: true, platform: true, tenant: null };
    return { ok: false, kind: 'unregistered_domain', error: 'هذا الدومين غير مرتبط بمؤسسة نشطة في Smart School.' };
  } catch (e) {
    console.error('resolveTenant error:', e);
    if (isPlatformHost(hostname)) return { ok: true, platform: true, tenant: null };
    return { ok: false, kind: 'resolver_error', error: 'تعذر التحقق من الدومين.' };
  }
}

export async function assertTenantForContext(ctx) {
  const result = await resolveTenant();
  if (!result.ok) return result;
  if (!result.tenant) return result;
  if (ctx?.role === 'superadmin') return result;
  if (!ctx?.schoolId || ctx.schoolId !== result.tenant.school_id) {
    return { ok: false, kind: 'school_mismatch', error: 'هذا الحساب لا ينتمي إلى المؤسسة المرتبطة بهذا الدومين.' };
  }
  return result;
}

export function applyTenantBrand(tenant) {
  if (!tenant?.school_name) return;
  document.title = tenant.school_name + ' — Smart School';
  const label = document.querySelector('[data-tenant-school-name]');
  if (label) label.textContent = tenant.school_name;
  const logos = document.querySelectorAll('[data-tenant-logo]');
  logos.forEach((img) => {
    if (tenant.logo_url) {
      img.src = tenant.logo_url;
      img.hidden = false;
    }
  });
}
