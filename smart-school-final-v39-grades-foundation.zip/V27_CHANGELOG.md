# V27 — Admin map points, mobile student photo resize, audit layout

## Fixes
- Historical bus-trip map now shows boarding (green) and drop-off (red) points.
- New trip-event RPC records the latest GPS position of the exact active trip when a BOARD/DROP_OFF event is created; existing enum values are unchanged.
- Historical map falls back to configured pickup/drop-off/school coordinates when an older event has no GPS coordinate, so it never invents a route.
- Student photo upload accepts large phone photos and automatically resizes/compresses them to JPEG before Storage upload (max dimension 1000px, target <= ~1.2MB).
- Institution audit log redesigned into aligned responsive rows/cards with action, entity, actor and date/time.
- JS cache version bumped to v33 for admin/live map/photo modules.

## SQL
- `supabase/migrations/phase37_admin_map_photo_audit.sql` is MUTATING and must be run once on the correct Smart School Supabase project.
- No timezone/time changes.
- No data deletion.
- Existing `BOARD` / `DROP_OFF` enum values are preserved.
