# Smart School v23

## Frontend
Upload the contents of this package to the same static hosting root used by the current Smart School deployment.

## Database migration
Run **only**:
`supabase/migrations/phase34_audit_notifications_schedule.sql`

This migration is MUTATING (it backfills `audit_logs.actor_id` and updates audit RPC behavior). It does not delete data and does not modify time/timezone values.

Do not rerun Phase 29/30/31.
