// ============================================================================
// modules/adminConsole.js — full school console (Phase 15: ADMIN = DIRECTOR).
// Powers admin.html — the ONLY administrative dashboard of the school.
// Every view reads/writes through RLS-scoped queries or SECURITY DEFINER
// RPCs — never a client-asserted school_id.
// ============================================================================

import { requireAuth, logout } from './auth.js';
import { supabase } from './supabase.js';
import {
  el, esc, fmtDate, fmtDateTime, fmtMoney, toast, confirmDialog, showView,
  initPageHeader, statCard, roleAr, loadingHtml, emptyHtml, downloadCSV, attStatusAr,
  armViewHistory, armErrorBoundary, showInitError, phoneActions,
} from './ui.js';
import {
  schoolDashboard, getSchoolProfile, updateSchool, updateSchoolLocation,
  getGuardStats,
  listMyAcademicYears, createAcademicYearMy, setCurrentAcademicYear, updateAcademicYear,
  listMyClasses, createClassMy, updateClass,
  listSubjects, createSubject,
  saveAttendance, getClassAttendance, getStudentAttendance, schoolAttendanceToday, reportAttendance,
  addGrade, listStudentGrades,
  reportIncident, listIncidents, updateIncident,
  sendNotification, listMyNotifications, markNotificationRead, unreadNotificationsCount,
  createBus, listBuses, createRoute, listRoutes, assignStudentTransport, studentTransportInfo,
  recordPayment, listPayments, recordExpense, listExpenses, financeSummary,
  setClassSchedule, getClassSchedule, addLesson, updateLesson, deleteLesson,
  getSchoolPeriods, setSchoolPeriods,
  getStudentFull, getUserPermissions, grantUserPermission, revokeUserPermission,
  assignTeacherSubject, removeTeacherSubject, listTeacherSubjects,
  assignTeacherClass, removeTeacherClass, listTeacherClasses,
  getTeacherFull, getTeacherSchedule, getStudentSchedule, getStudentBadge,
  updateStudentLocation, setTeacherRate, upsertTeacherMonth, recordTeacherPayment, listTeacherPayroll,
  schoolAudit, mapRpcError,
} from './school.js';
import { searchStudents, registerStudent, filterStudents, issueBadge, reissueBadge, suspendBadge } from './students.js';
import { renderBadgeCard } from './badgeCard.js';
import { openMapPicker } from './mapPicker.js';
import { renderStudentPhotoBox } from './photoUpload.js';
import { renderLiveMap } from './liveMap.js';
import { listTeachers, listDrivers, listParents, createStaffAccount } from './accounts.js';
import { listGuards, createGuardAccount, listAllPermissions, setGuardStatus } from './admin.js';

let ctx = null;
let schoolId = null;
let cache = { years: null, classes: null, teachers: null, drivers: null, subjects: null, buses: null, routes: null };
let currentStaffType = 'teacher';
let currentGuard = null;
let currentStudentId = null;
let selectedLinks = [];      // parent-student links for staff-add form
let pickedStudent = null;    // student picked for payment/incident forms
let auditOffset = 0;
const PAGE_SIZE = 30;

// ===== INIT =====
(async () => {
  try {
    armErrorBoundary();
    ctx = await requireAuth('admin.html');
    if (!ctx) return;
    schoolId = ctx.schoolId;
    const profile = await getSchoolProfile(schoolId);
    initPageHeader(ctx, profile.ok && profile.data ? profile.data.name : null, logout);
    el('app-body').hidden = false;
    armViewHistory('home');
    showView('home');
    loadDashboard();
    refreshNotifCount();
  } catch (error) {
    console.error('admin init error:', error);
    // Never kick back to the login page on a transient post-auth failure:
    // the session is valid — surface the real error inside the dashboard.
    showInitError(error);
  }
})();

// ===== NAV =====
document.querySelectorAll('[data-go]').forEach((b) => b.addEventListener('click', () => openModule(b.dataset.go)));
document.querySelectorAll('[data-back]').forEach((b) => b.addEventListener('click', () => {
  if (liveMapCleanup) { liveMapCleanup(); liveMapCleanup = null; }
  showView(b.dataset.back);
  if (b.dataset.back === 'home') loadDashboard();
  if (b.dataset.back === 'students') loadStudents();
  if (b.dataset.back === 'incidents') loadIncidentsView();
  if (b.dataset.back === 'guards') loadGuards();
}));

let liveMapCleanup = null;
function openModule(name) {
  if (liveMapCleanup) { liveMapCleanup(); liveMapCleanup = null; }
  showView(name);
  const loaders = {
    institution: loadInstitution, academic: loadAcademic, subjects: loadSubjects,
    students: loadStudents, teachers: () => loadStaffList('teachers'),
    drivers: () => loadStaffList('drivers'), parents: () => loadStaffList('parents'),
    guards: loadGuards, attendance: loadAttendanceView, schedule: loadScheduleView,
    transport: loadTransport, finance: loadFinance, incidents: loadIncidentsView,
    reports: loadReportsView, notifications: loadNotificationsView, audit: loadAuditView,
    'live-tracking': async () => { liveMapCleanup = await renderLiveMap(el('live-map-host')); },
  };
  loaders[name]?.();
}

async function refreshNotifCount() {
  const res = await unreadNotificationsCount();
  if (res.ok && res.data > 0) {
    el('notif-count').hidden = false;
    el('notif-count').textContent = res.data;
  }
}
el('notif-btn').addEventListener('click', () => openModule('notifications'));

// ===== DASHBOARD =====
async function loadDashboard() {
  const host = el('dash-stats');
  host.innerHTML = loadingHtml();
  const res = await schoolDashboard();
  if (!res.ok) { host.innerHTML = emptyHtml(res.error); return; }
  const d = res.data || {};
  const att = d.attendance_today || {};
  host.innerHTML = '<div class="stats-grid">'
    + statCard(d.students ?? 0, 'التلاميذ')
    + statCard(att.present ?? 0, 'حاضرون اليوم', 'tone-green')
    + statCard((att.absent ?? 0) + (att.late ?? 0), 'غياب/تأخر اليوم', 'tone-red')
    + statCard(d.teachers ?? 0, 'الأساتذة')
    + statCard(d.guards ?? 0, 'الحراس')
    + statCard(d.drivers ?? 0, 'السائقون')
    + statCard(d.parents ?? 0, 'أولياء الأمور')
    + statCard(d.classes ?? 0, 'الأقسام')
    + statCard(d.buses ?? 0, 'الحافلات')
    + statCard(fmtMoney(d.payments_month), 'أداءات الشهر', 'tone-green')
    + statCard(fmtMoney(d.expenses_month), 'مصاريف الشهر', 'tone-red')
    + statCard(d.open_incidents ?? 0, 'مخالفات مفتوحة', 'tone-gold')
    + '</div>';
}

// §30-31: normalize the school website client-side (the schools trigger in
// phase25 is the authoritative guard). example.ma → https://example.ma;
// dangerous schemes (javascript:/data:/vbscript:/file:) are rejected.
function normalizeWebsite(input) {
  let v = String(input || '').trim();
  if (!v) return '';
  if (/^(javascript|data|vbscript|file):/i.test(v)) { toast('رابط غير آمن مرفوض.', 'error'); return null; }
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(v)) v = 'https://' + v;
  try { new URL(v); return v; } catch { toast('صيغة الرابط غير صالحة.', 'error'); return null; }
}

// ===== INSTITUTION =====
async function loadInstitution() {
  const body = el('institution-body');
  body.innerHTML = loadingHtml();
  const res = await getSchoolProfile(schoolId);
  if (!res.ok) { body.innerHTML = emptyHtml(res.error); return; }
  const s = res.data;
  const row = (k, v) => `<div class="detail-row"><span class="k">${k}</span><span class="v">${esc(v || '—')}</span></div>`;
  body.innerHTML = '<div class="panel">'
    + (s.logo_url ? `<div style="text-align:center; margin-bottom:10px;"><img src="${esc(s.logo_url)}" alt="الشعار" style="max-height:80px; border-radius:10px;"></div>` : '')
    + row('الاسم', s.name) + row('الاسم القانوني', s.legal_name) + row('النوع', s.school_type)
    + row('العنوان', s.address) + row('المدينة', s.city) + row('الجهة', s.region)
    + row('الهاتف', s.phone) + row('البريد', s.email)
    + (s.website ? `<div class="detail-row"><span class="k">الموقع</span><span class="v"><a href="${esc(s.website)}" target="_blank" rel="noopener">🔗 ${esc(s.website)}</a></span></div>` : row('الموقع', null))
    + row('المدير', s.director_name) + row('ICE', s.ice) + row('معلومات إضافية', s.notes)
    + '</div>';
  el('in-name').value = s.name || ''; el('in-legal').value = s.legal_name || '';
  el('in-type').value = s.school_type || ''; el('in-city').value = s.city || '';
  el('in-region').value = s.region || ''; el('in-address').value = s.address || '';
  el('in-phone').value = s.phone || ''; el('in-email').value = s.email || '';
  el('in-website').value = s.website || ''; el('in-ice').value = s.ice || '';
  el('in-logo').value = s.logo_url || ''; el('in-notes').value = s.notes || '';
  renderSchoolLocation(s);
  renderPeriodsConfig();
}

async function renderPeriodsConfig() {
  const host = el('periods-panel');
  host.innerHTML = loadingHtml();
  const res = await getSchoolPeriods();
  const cfg = res.ok ? res.data : {};
  host.innerHTML = `
    <div class="form-grid">
      <div><label>🌅 بداية الصباح</label><input type="time" id="pc-m-start" class="search-input" value="${(cfg.morning_start || '08:00').slice(0, 5)}"></div>
      <div><label>مدة حصة الصباح (دقيقة)</label><input type="number" id="pc-m-min" class="search-input" min="15" step="5" value="${cfg.morning_lesson_minutes ?? 60}"></div>
      <div><label>☀️ بداية الزوال</label><input type="time" id="pc-a-start" class="search-input" value="${(cfg.afternoon_start || '14:00').slice(0, 5)}"></div>
      <div><label>مدة حصة الزوال (دقيقة)</label><input type="number" id="pc-a-min" class="search-input" min="15" step="5" value="${cfg.afternoon_lesson_minutes ?? 60}"></div>
    </div>
    <p class="empty-state" style="margin-top:6px;">النظام ثابت: 4 حصص صباحًا + 4 حصص زوالًا = 8 حصص/يوم. سيُحسب توقيت كل حصة تلقائيًا من هذا الإعداد.</p>
    <button type="button" class="quick-action-btn" id="pc-save" style="width:100%; margin-top:6px;">حفظ توقيت الحصص</button>`;
  el('pc-save').addEventListener('click', async () => {
    const payload = {
      morningStart: el('pc-m-start').value, morningLessonMinutes: Number(el('pc-m-min').value),
      afternoonStart: el('pc-a-start').value, afternoonLessonMinutes: Number(el('pc-a-min').value),
    };
    const r = await setSchoolPeriods(payload);
    if (!r.ok) { toast(r.error, 'error'); return; }
    toast('تم حفظ توقيت الحصص.', 'success');
    schoolPeriodsCache = null;
  });
}

function renderSchoolLocation(s) {
  const host = el('school-location-panel');
  const hasLoc = s.latitude != null && s.longitude != null;
  host.innerHTML = hasLoc
    ? `<iframe src="https://maps.google.com/maps?q=${s.latitude},${s.longitude}&z=15&output=embed" style="width:100%; height:160px; border:0; border-radius:8px;" loading="lazy"></iframe>
       <button type="button" class="quick-action-btn secondary" id="school-loc-btn" style="width:100%; margin-top:8px;">📍 تغيير موقع المؤسسة</button>`
    : `${emptyHtml('لم يُحدَّد موقع المؤسسة بعد — هذا هو نقطة البداية/النهاية الافتراضية للنقل المدرسي.')}<button type="button" class="quick-action-btn" id="school-loc-btn" style="width:100%;">📍 تحديد موقع المؤسسة</button>`;
  el('school-loc-btn').addEventListener('click', () => {
    openMapPicker({
      lat: s.latitude, lng: s.longitude, label: s.location_label,
      onSave: async ({ lat, lng, label }) => {
        const res = await updateSchoolLocation(lat, lng, label || null);
        if (!res.ok) { toast(res.error, 'error'); return; }
        toast('تم حفظ موقع المؤسسة.', 'success');
        loadInstitution();
      },
    });
  });
}

el('institution-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    name: el('in-name').value, legal_name: el('in-legal').value, school_type: el('in-type').value,
    city: el('in-city').value, region: el('in-region').value, address: el('in-address').value,
    phone: el('in-phone').value, email: el('in-email').value,
    website: normalizeWebsite(el('in-website').value),
    ice: el('in-ice').value, logo_url: el('in-logo').value, notes: el('in-notes').value,
  };
  if (payload.website === null) return; // رابط غير آمن/غير صالح — لا يُرسل أصلًا (§31)
  const res = await updateSchool(schoolId, payload);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم حفظ بيانات المؤسسة.', 'success');
  loadInstitution();
});

// ===== ACADEMIC YEARS & CLASSES =====
async function refreshYearsClasses() {
  const [y, c] = await Promise.all([listMyAcademicYears(), listMyClasses(null)]);
  cache.years = y.ok ? y.data || [] : [];
  cache.classes = c.ok ? c.data || [] : [];
  return { years: cache.years, classes: cache.classes };
}

async function loadAcademic() {
  el('years-panel').innerHTML = loadingHtml();
  el('classes-panel').innerHTML = loadingHtml();
  const { years, classes } = await refreshYearsClasses();

  // Years
  el('years-panel').innerHTML = years.length
    ? years.map((y) => `<div class="history-item">
        <div><strong>${esc(y.year_name)}</strong>
          ${y.is_current ? '<span class="badge badge-green">الحالية</span>' : ''}
          ${y.is_disabled ? '<span class="badge badge-red">معطلة</span>' : ''}
          <span class="time">${y.class_count} قسمًا</span></div>
        <div style="display:flex; gap:6px;">
          ${!y.is_current && !y.is_disabled ? `<button type="button" class="att-btn" data-set-current="${y.year_id}">تعيين كحالية</button>` : ''}
          <button type="button" class="att-btn" data-rename-year="${y.year_id}" data-year-name="${esc(y.year_name)}">تعديل</button>
          <button type="button" class="att-btn" data-toggle-year="${y.year_id}" data-year-disabled="${y.is_disabled}">${y.is_disabled ? 'تفعيل' : 'تعطيل'}</button>
        </div>
      </div>`).join('')
    : emptyHtml('لا توجد سنوات دراسية. أنشئ السنة الأولى أدناه.');

  el('years-panel').querySelectorAll('[data-set-current]').forEach((b) => b.addEventListener('click', async () => {
    const res = await setCurrentAcademicYear(b.dataset.setCurrent);
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast('تم تعيين السنة الحالية.', 'success');
    loadAcademic();
  }));
  el('years-panel').querySelectorAll('[data-rename-year]').forEach((b) => b.addEventListener('click', async () => {
    const name = prompt('اسم السنة الدراسية:', b.dataset.yearName);
    if (name === null) return;
    const res = await updateAcademicYear(b.dataset.renameYear, name, null);
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast('تم التعديل.', 'success');
    loadAcademic();
  }));
  el('years-panel').querySelectorAll('[data-toggle-year]').forEach((b) => b.addEventListener('click', async () => {
    const disabling = b.dataset.yearDisabled !== 'true';
    const ok = await confirmDialog(disabling ? 'تعطيل هذه السنة؟ (لا يمكن تعطيل السنة الحالية)' : 'تفعيل هذه السنة؟');
    if (!ok) return;
    const res = await updateAcademicYear(b.dataset.toggleYear, null, disabling);
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast('تم.', 'success');
    loadAcademic();
  }));

  // Classes
  el('no-years-hint').hidden = years.length > 0;
  el('add-class-form').style.display = years.length ? '' : 'none';
  el('cl-year').innerHTML = years.filter((y) => !y.is_disabled).map((y) => `<option value="${y.year_id}">${esc(y.year_name)}${y.is_current ? ' (الحالية)' : ''}</option>`).join('');

  el('classes-panel').innerHTML = classes.length
    ? '<div class="data-table-wrap"><table class="data-table"><thead><tr><th>القسم</th><th>المستوى</th><th>السنة</th><th>الأستاذ</th><th>تلاميذ</th><th>إجراءات</th></tr></thead><tbody>'
      + classes.map((c) => `<tr>
          <td><strong>${esc(c.class_name)}</strong>${c.is_disabled ? ' <span class="badge badge-red">معطل</span>' : ''}</td>
          <td>${esc(c.level || '—')}</td><td>${esc(c.year_name || '—')}</td>
          <td>${esc(c.teacher_name || '—')}</td><td>${c.student_count}/${c.capacity ?? '—'}</td>
          <td><button type="button" class="att-btn" data-edit-class="${c.class_id}">تعديل</button></td>
        </tr>`).join('')
      + '</tbody></table></div>'
    : emptyHtml(years.length ? 'لا توجد أقسام بعد.' : 'أنشئ سنة دراسية أولاً.');

  el('classes-panel').querySelectorAll('[data-edit-class]').forEach((b) => b.addEventListener('click', () => editClassDialog(b.dataset.editClass)));

  // Teacher select for class form
  const teachers = await ensureTeachers();
  el('cl-teacher').innerHTML = '<option value="">—</option>' + teachers.map((t) => `<option value="${t.id}">${esc(t.profiles?.full_name || '—')}</option>`).join('');
}

async function editClassDialog(classId) {
  const c = cache.classes.find((x) => x.class_id === classId);
  if (!c) return;
  const teachers = await ensureTeachers();

  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal-card" role="dialog" aria-modal="true" style="max-width:480px;">
      <p style="margin:0 0 12px; font-weight:700;">تعديل القسم: ${esc(c.class_name)}</p>
      <div class="form-grid">
        <label>الاسم<input type="text" id="ec-name" class="search-input" value="${esc(c.class_name)}"></label>
        <label>المستوى<input type="text" id="ec-level" class="search-input" value="${esc(c.level || '')}"></label>
        <label>السعة<input type="number" id="ec-capacity" class="search-input" min="1" value="${c.capacity ?? ''}"></label>
        <label>الأستاذ
          <select id="ec-teacher" class="search-input">
            <option value="__keep__">— بدون تغيير —</option>
            <option value="">بدون أستاذ (إزالة)</option>
            ${teachers.map((t) => `<option value="${t.id}" ${t.id === c.teacher_id ? 'selected' : ''}>${esc(t.profiles?.full_name || '—')}</option>`).join('')}
          </select>
        </label>
      </div>
      <label style="display:flex; gap:8px; align-items:center; margin-top:10px;">
        <input type="checkbox" id="ec-disabled" ${c.is_disabled ? 'checked' : ''}> تعطيل القسم
      </label>
      <div style="display:flex; gap:8px; margin-top:14px;">
        <button type="button" class="quick-action-btn" id="ec-save" style="flex:1;">حفظ</button>
        <button type="button" class="back-link" id="ec-cancel" style="flex:1; text-align:center;">إلغاء</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);

  const close = () => overlay.remove();
  overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
  overlay.querySelector('#ec-cancel').addEventListener('click', close);
  overlay.querySelector('#ec-save').addEventListener('click', async () => {
    const patch = {
      name: overlay.querySelector('#ec-name').value.trim(),
      level: overlay.querySelector('#ec-level').value.trim(),
      isDisabled: overlay.querySelector('#ec-disabled').checked,
    };
    const cap = overlay.querySelector('#ec-capacity').value;
    if (cap !== '') patch.capacity = parseInt(cap, 10);
    const teacherSel = overlay.querySelector('#ec-teacher').value;
    if (teacherSel !== '__keep__') patch.teacherId = teacherSel === '' ? null : teacherSel;

    const res = await updateClass(classId, patch);
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast('تم تعديل القسم.', 'success');
    close();
    loadAcademic();
  });
}

el('add-year-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = el('add-year-submit');
  btn.disabled = true;
  const res = await createAcademicYearMy(el('ay-name').value, el('ay-current').checked);
  btn.disabled = false;
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم إنشاء السنة الدراسية.', 'success');
  el('ay-name').value = '';
  el('ay-current').checked = false;
  loadAcademic();
});

el('add-class-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = el('add-class-submit');
  btn.disabled = true;
  const res = await createClassMy(
    el('cl-year').value, el('cl-name').value, el('cl-level').value,
    el('cl-capacity').value ? Number(el('cl-capacity').value) : null,
    el('cl-teacher').value || null,
  );
  btn.disabled = false;
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم إنشاء القسم.', 'success');
  el('cl-name').value = ''; el('cl-level').value = ''; el('cl-capacity').value = '';
  loadAcademic();
});

// ===== SUBJECTS =====
async function loadSubjects() {
  const panel = el('subjects-panel');
  panel.innerHTML = loadingHtml();
  const res = await listSubjects();
  cache.subjects = res.ok ? res.data || [] : [];
  panel.innerHTML = res.ok
    ? (cache.subjects.length
      ? cache.subjects.map((s) => `<div class="history-item"><span>${esc(s.subject_name)}</span></div>`).join('')
      : emptyHtml('لا توجد مواد بعد.'))
    : emptyHtml(res.error);
}

el('add-subject-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const res = await createSubject(el('sb-name').value);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تمت إضافة المادة.', 'success');
  el('sb-name').value = '';
  loadSubjects();
});

async function ensureTeachers() {
  if (!cache.teachers) cache.teachers = await listTeachers('');
  return cache.teachers;
}
async function ensureDrivers() {
  if (!cache.drivers) cache.drivers = await listDrivers('');
  return cache.drivers;
}
async function ensureSubjects() {
  if (!cache.subjects) { const r = await listSubjects(); cache.subjects = r.ok ? r.data || [] : []; }
  return cache.subjects;
}
async function ensureClasses() {
  if (!cache.classes) await refreshYearsClasses();
  return cache.classes;
}

// ===== STUDENTS =====
async function loadStudents() {
  const panel = el('students-panel');
  panel.innerHTML = loadingHtml();
  const classes = await ensureClasses();
  el('students-class').innerHTML = '<option value="">كل الأقسام</option>'
    + classes.map((c) => `<option value="${c.class_id}">${esc(c.class_name)} — ${esc(c.year_name || '')}</option>`).join('');

  const results = await filterStudents({
    query: el('students-search').value,
    classId: el('students-class').value || null,
    limit: 100,
  });
  panel.innerHTML = results.length
    ? results.map((r) => `<div class="history-item" data-student-id="${r.studentId}" style="cursor:pointer;">
        <div><strong>${esc(r.student?.fullName || '—')}</strong> <span class="time">#${esc(r.student?.studentNumber || '—')}</span></div>
        <div class="time">${esc(r.student?.className || 'بدون قسم')} ${r.resultType === 'AUTHORIZED' ? '<span class="badge badge-green">نشط</span>' : '<span class="badge badge-red">غير نشط</span>'}</div>
      </div>`).join('')
    : emptyHtml('لا يوجد تلاميذ مطابقون.');
  panel.querySelectorAll('[data-student-id]').forEach((it) => it.addEventListener('click', () => openStudentDetail(it.dataset.studentId)));
}
el('students-search').addEventListener('input', loadStudents);
el('students-class').addEventListener('change', loadStudents);

el('btn-add-student').addEventListener('click', async () => {
  const { years, classes } = await refreshYearsClasses();
  if (!years.length) { toast('يجب إنشاء سنة دراسية أولاً.', 'error'); openModule('academic'); return; }
  el('st-year').innerHTML = years.filter((y) => !y.is_disabled).map((y) => `<option value="${y.year_id}">${esc(y.year_name)}</option>`).join('');
  const fillClasses = () => {
    const yid = el('st-year').value;
    el('st-class').innerHTML = classes.filter((c) => c.academic_year_id === yid && !c.is_disabled)
      .map((c) => `<option value="${c.class_id}">${esc(c.class_name)}</option>`).join('');
  };
  el('st-year').onchange = fillClasses;
  fillClasses();
  showView('student-add');
});

el('add-student-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = el('add-student-error');
  errEl.hidden = true;
  const btn = el('add-student-submit');
  if (!el('st-class').value) { errEl.hidden = false; errEl.textContent = 'اختر القسم (أنشئ قسمًا أولاً).'; return; }
  btn.disabled = true;
  const res = await registerStudent({
    fullName: el('st-name').value.trim(),
    classId: el('st-class').value,
    academicYearId: el('st-year').value,
    birthDate: el('st-birth').value || null,
    gender: el('st-gender').value || null,
  });
  btn.disabled = false;
  if (!res.ok) { errEl.hidden = false; errEl.textContent = res.error; return; }
  toast(`تم تسجيل التلميذ بنجاح. رقم التلميذ: ${res.studentNumber || 'تم توليده تلقائيًا'}`, 'success');
  e.target.reset();
  showView('students');
  loadStudents();
});

async function openStudentDetail(studentId) {
  currentStudentId = studentId;
  showView('student-detail');
  const body = el('student-detail-body');
  body.innerHTML = loadingHtml();
  const res = await getStudentFull(studentId);
  if (!res.ok || !res.data) { body.innerHTML = emptyHtml(res.error || 'تعذر تحميل ملف التلميذ.'); return; }
  const s = res.data;
  const att = s.attendance_30d || {};
  const row = (k, v) => `<div class="detail-row"><span class="k">${k}</span><span class="v">${esc(v ?? '—')}</span></div>`;

  body.innerHTML = `
    <div id="sd-photo-box" class="panel"></div>
    <div class="panel">
      ${row('الاسم', s.full_name)}${row('رقم التلميذ', s.student_number)}
      ${row('القسم', s.class_name)}${row('المستوى', s.level)}${row('السنة', s.year_name)}
      ${row('تاريخ الميلاد', fmtDate(s.birth_date))}${row('البطاقة', BADGE_STATUS_AR[s.badge_status] || (s.badge_status || 'بدون بطاقة'))}
      ${row('الحالة', s.is_active ? 'نشط' : 'محذوف')}
    </div>
    <p class="section-title">الحضور (آخر 30 يومًا)</p>
    <div class="stats-grid">
      ${statCard(att.present ?? 0, 'حاضر', 'tone-green')}${statCard(att.absent ?? 0, 'غائب', 'tone-red')}
      ${statCard(att.late ?? 0, 'متأخر', 'tone-gold')}${statCard(att.excused ?? 0, 'مبرر')}
    </div>
    <div id="sd-att-list"></div>
    <p class="section-title">النقط</p>
    <div id="sd-grades"></div>
    <div class="panel">
      <p class="section-title" style="margin-top:0;">إضافة نقطة</p>
      <form id="sd-grade-form" novalidate>
        <div class="form-grid">
          <div><label>المادة</label><select id="gd-subject" class="search-input"><option value="">—</option></select></div>
          <div><label>الفترة</label><input type="text" id="gd-period" class="search-input" placeholder="الأسدوس الأول"></div>
          <div><label>نوع التقييم</label><input type="text" id="gd-type" class="search-input" placeholder="فرض / امتحان"></div>
          <div><label>النقطة *</label><input type="number" id="gd-score" class="search-input" min="0" step="0.25" required></div>
        </div>
        <button type="submit" class="quick-action-btn" style="width:100%; margin-top:10px;">حفظ النقطة</button>
      </form>
    </div>
    <p class="section-title">أولياء الأمور</p>
    <div class="panel">${(s.parents || []).length ? s.parents.map((p) => `<div class="history-item"><span>${esc(p.name)}</span><span class="time">${esc(p.phone || '')} ${esc(p.relationship || '')}</span><span style="display:inline-flex; gap:4px;">${phoneActions(p.phone)}</span></div>`).join('') : emptyHtml('لا يوجد ولي أمر مرتبط.')}</div>
    <p class="section-title">النقل المدرسي</p>
    <div class="panel" id="sd-transport"></div>
    <p class="section-title">المخالفات المفتوحة: ${s.open_incidents ?? 0}</p>`;

  renderStudentPhotoBox(el('sd-photo-box'), { studentId, schoolId, photoUrl: s.photo_url }, () => openStudentDetail(studentId));

  // Attendance history
  const attRes = await getStudentAttendance(studentId, null, null);
  el('sd-att-list').innerHTML = attRes.ok && attRes.data.length
    ? '<div class="panel">' + attRes.data.slice(0, 15).map((a) => `<div class="detail-row"><span class="k">${fmtDate(a.att_date)} — ${esc(a.class_name || '')}</span><span class="v">${attStatusAr(a.status)}</span></div>`).join('') + '</div>'
    : emptyHtml('لا توجد سجلات حضور.');

  // Grades
  const grRes = await listStudentGrades(studentId);
  el('sd-grades').innerHTML = grRes.ok && grRes.data.length
    ? '<div class="panel">' + grRes.data.map((g) => `<div class="detail-row"><span class="k">${esc(g.subject_name || '—')} — ${esc(g.period || '')} ${esc(g.grade_type || '')}</span><span class="v">${g.score}/${g.max_score}</span></div>`).join('') + '</div>'
    : emptyHtml('لا توجد نقط بعد.');

  const subjects = await ensureSubjects();
  el('gd-subject').innerHTML = '<option value="">—</option>' + subjects.map((su) => `<option value="${su.subject_id}">${esc(su.subject_name)}</option>`).join('');
  el('sd-grade-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const res2 = await addGrade({
      studentId, subjectId: el('gd-subject').value || null, period: el('gd-period').value,
      gradeType: el('gd-type').value, score: Number(el('gd-score').value),
    });
    if (!res2.ok) { toast(res2.error, 'error'); return; }
    toast('تم حفظ النقطة.', 'success');
    openStudentDetail(studentId);
  });

  // Transport
  renderStudentTransport(s);
  // Schedule (Phase 19 — derived from class timetable, never a per-student copy)
  renderStudentSchedule(studentId);
  // Home location (Google Maps coordinates)
  renderStudentLocation(s);
  // ID badge / QR (Phase 17/18/19 real fix)
  renderStudentBadgeSection(s);
}

async function renderStudentSchedule(studentId) {
  const host = el('sd-schedule');
  host.innerHTML = loadingHtml();
  const res = await getStudentSchedule(studentId);
  const rows = res.ok ? res.data || [] : [];
  el('sd-schedule-summary').textContent = rows.length ? `${rows.length} حصة/أسبوع` : '';
  host.innerHTML = rows.length
    ? '<div class="data-table-wrap"><table class="data-table"><thead><tr><th>اليوم</th><th>الحصة</th><th>المادة</th><th>الأستاذ</th></tr></thead><tbody>'
      + rows.map((r) => `<tr><td>${WEEKDAYS_AR[r.weekday] || r.weekday}</td><td>${r.period}</td><td>${esc(r.subject_name || '—')}</td><td>${esc(r.teacher_name || '—')}</td></tr>`).join('')
      + '</tbody></table></div>'
    : emptyHtml('لا يوجد جدول دراسي (لم يُسند التلميذ إلى قسم له حصص بعد).');
}

// Google Maps location — SIMPLIFIED (Phase 20): one tap on an in-app map,
// no manual lat/lng typing. See modules/mapPicker.js for why Leaflet/OSM is
// used instead of the Google Maps JS API (no API key exists in this
// project, and inventing one was explicitly ruled out).
function mapEmbedUrl(lat, lng) {
  return `https://maps.google.com/maps?q=${lat},${lng}&z=16&output=embed`;
}
function renderStudentLocation(s) {
  const host = el('sd-location');
  const hasLoc = s.latitude != null && s.longitude != null;
  host.innerHTML = `
    ${hasLoc
      ? `<iframe src="${mapEmbedUrl(s.latitude, s.longitude)}" style="width:100%; height:180px; border:0; border-radius:8px;" loading="lazy"></iframe>
         <div style="display:flex; gap:8px; margin-top:8px;">
           <button type="button" class="quick-action-btn secondary" id="loc-change-btn" style="flex:1;">📍 تغيير الموقع</button>
           <a href="https://www.google.com/maps?q=${s.latitude},${s.longitude}" target="_blank" rel="noopener" class="quick-action-btn secondary" style="flex:1; text-align:center; text-decoration:none;">🧭 فتح في Google Maps</a>
         </div>`
      : `${emptyHtml('لم يُحدَّد موقع السكن بعد.')}<button type="button" class="quick-action-btn" id="loc-change-btn" style="width:100%;">📍 تحديد موقع السكن</button>`}
  `;
  el('loc-change-btn').addEventListener('click', () => {
    openMapPicker({
      lat: s.latitude, lng: s.longitude, label: s.location_label,
      onSave: async ({ lat, lng, label }) => {
        const res = await updateStudentLocation({ studentId: currentStudentId, latitude: lat, longitude: lng, locationLabel: label || null });
        if (!res.ok) { toast(res.error, 'error'); return; }
        toast('تم حفظ الموقع.', 'success');
        openStudentDetail(currentStudentId);
      },
    });
  });
}

const BADGE_STATUS_AR = { ACTIVE: 'سارية', SUSPENDED: 'موقوفة', LOST: 'مفقودة', EXPIRED: 'منتهية', REPLACED: 'مستبدلة' };

async function renderStudentBadgeSection(s) {
  const actionsHost = el('sd-badge-actions');
  const cardHost = el('sd-badge-card');
  cardHost.innerHTML = '';
  const badgeRes = await getStudentBadge(s.student_id);
  const badge = badgeRes.ok && badgeRes.data && badgeRes.data.length ? badgeRes.data[0] : null;

  actionsHost.innerHTML = `
    <p class="empty-state" id="sd-badge-error" hidden style="color:#dc2626;"></p>
    <div class="quick-actions" id="sd-badge-buttons"></div>`;
  const buttons = [];
  if (badge && badge.status === 'ACTIVE') {
    buttons.push('<button type="button" class="quick-action-btn secondary" id="sd-badge-reissue">🔄 إعادة إصدار</button>');
    buttons.push('<button type="button" class="quick-action-btn secondary" id="sd-badge-suspend">🚫 تعليق البطاقة</button>');
  } else {
    buttons.push('<button type="button" class="quick-action-btn" id="sd-badge-issue" style="grid-column:1 / -1;">🆔 إصدار بطاقة</button>');
  }
  el('sd-badge-buttons').innerHTML = buttons.join('');

  async function run(fn) {
    el('sd-badge-error').hidden = true;
    el('sd-badge-buttons').querySelectorAll('button').forEach((b) => (b.disabled = true));
    const res = await fn();
    if (!res.ok) {
      el('sd-badge-error').hidden = false;
      el('sd-badge-error').textContent = res.error;
      el('sd-badge-buttons').querySelectorAll('button').forEach((b) => (b.disabled = false));
      return;
    }
    toast('تم بنجاح.', 'success');
    openStudentDetail(s.student_id);
  }
  if (badge && badge.status === 'ACTIVE') {
    el('sd-badge-reissue').addEventListener('click', () => run(() => reissueBadge(s.student_id, 'إعادة إصدار من طرف الإدارة')));
    el('sd-badge-suspend').addEventListener('click', () => run(() => suspendBadge(badge.id, 'SUSPENDED', 'تعليق من طرف الإدارة')));
  } else {
    el('sd-badge-issue').addEventListener('click', () => run(() => issueBadge(s.student_id)));
  }

  if (badge && badge.status === 'ACTIVE') {
    const schoolRes = await getSchoolProfile(schoolId);
    renderBadgeCard(cardHost, {
      full_name: s.full_name, student_number: s.student_number, class_name: s.class_name,
      year_name: s.year_name, photo_url: s.photo_url,
      school_name: schoolRes.ok ? schoolRes.data?.name : '',
      school_logo_url: schoolRes.ok ? schoolRes.data?.logo_url : null,
    }, badge);
  }
}

async function renderStudentTransport(s) {
  const host = el('sd-transport');
  const t = s.transport;
  const [busesRes, routesRes] = await Promise.all([listBuses(), listRoutes()]);
  const buses = busesRes.ok ? busesRes.data || [] : [];
  const routes = routesRes.ok ? routesRes.data || [] : [];

  host.innerHTML = `
    ${t ? `<div class="detail-row"><span class="k">الحافلة</span><span class="v">${esc(t.bus_code || '—')} (${esc(t.bus_plate || '')})</span></div>
      <div class="detail-row"><span class="k">المسار</span><span class="v">${esc(t.route_name || '—')}</span></div>
      <div class="detail-row"><span class="k">محطة الصعود</span><span class="v">${esc(t.pickup_stop || '—')}</span></div>
      <div class="detail-row"><span class="k">محطة النزول</span><span class="v">${esc(t.dropoff_stop || '—')}</span></div>
      <div class="detail-row"><span class="k">السائق</span><span class="v">${esc(t.driver_name || '—')}</span></div>`
    : emptyHtml('غير مسجل في النقل المدرسي.')}
    <form id="sd-transport-form" novalidate style="margin-top:10px;">
      <div class="form-grid">
        <div><label>الحافلة</label><select id="tr-bus" class="search-input"><option value="">—</option>
          ${buses.map((b) => `<option value="${b.bus_id}">${esc(b.code)}</option>`).join('')}</select></div>
        <div><label>المسار</label><select id="tr-route" class="search-input"><option value="">—</option>
          ${routes.map((r) => `<option value="${r.route_id}">${esc(r.route_name)}</option>`).join('')}</select></div>
        <div><label>محطة الصعود</label><select id="tr-pickup" class="search-input"><option value="">—</option></select></div>
        <div><label>محطة النزول</label><select id="tr-dropoff" class="search-input"><option value="">—</option></select></div>
      </div>
      <button type="submit" class="quick-action-btn" style="width:100%; margin-top:10px;">حفظ النقل</button>
    </form>`;

  const fillStops = () => {
    const r = routes.find((x) => x.route_id === el('tr-route').value);
    const stops = r ? (Array.isArray(r.stops) ? r.stops : []) : [];
    const opts = '<option value="">—</option>' + stops.map((st) => `<option value="${st.stop_id}">${esc(st.name)}</option>`).join('');
    el('tr-pickup').innerHTML = opts;
    el('tr-dropoff').innerHTML = opts;
  };
  el('tr-route').addEventListener('change', fillStops);
  fillStops();

  el('sd-transport-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const res = await assignStudentTransport(currentStudentId, {
      busId: el('tr-bus').value || null, routeId: el('tr-route').value || null,
      pickupStopId: el('tr-pickup').value || null, dropoffStopId: el('tr-dropoff').value || null,
    });
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast('تم حفظ النقل.', 'success');
    openStudentDetail(currentStudentId);
  });
}

// ===== STAFF LISTS (teachers / drivers / parents) =====
const STAFF_CONF = {
  teachers: { label: 'أستاذ', type: 'teacher', list: listTeachers, panel: 'teachers-panel', search: 'teachers-search', extra: 'رقم الموظف' },
  drivers: { label: 'سائق', type: 'driver', list: listDrivers, panel: 'drivers-panel', search: 'drivers-search', extra: 'رقم رخصة القيادة' },
  parents: { label: 'ولي أمر', type: 'parent', list: listParents, panel: 'parents-panel', search: 'parents-search', extra: null },
};

async function loadStaffList(kind) {
  const conf = STAFF_CONF[kind];
  const panel = el(conf.panel);
  panel.innerHTML = loadingHtml();
  const rows = await conf.list(el(conf.search).value);
  panel.innerHTML = rows.length
    ? rows.map((r, i) => `<div class="history-item" ${kind === 'teachers' ? `data-teacher-idx="${i}" style="cursor:pointer;"` : ''}>
        <div><strong>${esc(r.profiles?.full_name || '—')}</strong> <span class="time">${esc(r.profiles?.user_number || '')}</span></div>
        <div style="display:flex; gap:8px; align-items:center;">
          <span class="time">${esc(r.profiles?.phone || '')}</span>
        </div>
      </div>`).join('')
    : emptyHtml('لا توجد نتائج.');
  if (kind === 'teachers') {
    panel.querySelectorAll('[data-teacher-idx]').forEach((it) => it.addEventListener('click', () => {
      const t = rows[Number(it.dataset.teacherIdx)];
      openTeacherDetail(t.id);
    }));
  }
}
['teachers', 'drivers', 'parents'].forEach((kind) => {
  el(STAFF_CONF[kind].search).addEventListener('input', () => loadStaffList(kind));
});

// ===== STAFF ADD (teacher/driver/parent/guard) =====
function openStaffAdd(type) {
  currentStaffType = type;
  selectedLinks = [];
  const labels = { teacher: 'إضافة أستاذ', driver: 'إضافة سائق', parent: 'إضافة ولي أمر', guard: 'إضافة حارس' };
  el('staff-add-title').textContent = labels[type];
  el('staff-add-error').hidden = true;
  el('staff-add-form').reset();
  el('sf-children-selected').innerHTML = '';
  el('sf-child-results').innerHTML = '';

  const extra = el('sf-extra-1');
  if (type === 'teacher') { extra.hidden = false; el('sf-extra-1-label').textContent = 'رقم الموظف'; }
  else if (type === 'driver') { extra.hidden = false; el('sf-extra-1-label').textContent = 'رقم رخصة القيادة'; }
  else extra.hidden = true;

  el('sf-children-wrap').hidden = type !== 'parent';

  const backTargets = { teacher: 'teachers', driver: 'drivers', parent: 'parents', guard: 'guards' };
  el('staff-add-back').dataset.back = backTargets[type];
  showView('staff-add');
}
el('btn-add-teacher').addEventListener('click', () => openStaffAdd('teacher'));
el('btn-add-driver').addEventListener('click', () => openStaffAdd('driver'));
el('btn-add-parent').addEventListener('click', () => openStaffAdd('parent'));
el('btn-add-guard').addEventListener('click', () => openStaffAdd('guard'));

// parent-children picker
let childSearchTimer = null;
el('sf-child-search').addEventListener('input', () => {
  clearTimeout(childSearchTimer);
  childSearchTimer = setTimeout(async () => {
    const q = el('sf-child-search').value;
    const host = el('sf-child-results');
    if (!q.trim()) { host.innerHTML = ''; return; }
    const rows = await searchStudents(q);
    host.innerHTML = rows.map((s) => `<div class="search-result-item" data-pick-child="${s.id}" data-child-name="${esc(s.full_name)}">
      ${esc(s.full_name)} <span class="time">#${esc(s.student_number || '')}</span></div>`).join('');
    host.querySelectorAll('[data-pick-child]').forEach((it) => it.addEventListener('click', () => {
      if (selectedLinks.some((l) => l.studentId === it.dataset.pickChild)) return;
      selectedLinks.push({ studentId: it.dataset.pickChild, relationship: 'ولي' });
      renderSelectedChildren();
    }));
  }, 300);
});
function renderSelectedChildren() {
  el('sf-children-selected').innerHTML = selectedLinks.map((l, i) =>
    `<span class="badge badge-blue">${esc(l.name || 'تلميذ')} <a href="#" data-unlink="${i}" style="color:#991b1b;">×</a></span>`).join(' ');
  el('sf-children-selected').querySelectorAll('[data-unlink]').forEach((a) => a.addEventListener('click', (e) => {
    e.preventDefault();
    selectedLinks.splice(Number(a.dataset.unlink), 1);
    renderSelectedChildren();
  }));
}
// keep names for display
el('sf-child-results').addEventListener('click', (e) => {
  const it = e.target.closest('[data-pick-child]');
  if (it) {
    const last = selectedLinks[selectedLinks.length - 1];
    if (last && last.studentId === it.dataset.pickChild) last.name = it.dataset.childName;
    renderSelectedChildren();
  }
});

el('staff-add-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = el('staff-add-error');
  errEl.hidden = true;
  const btn = el('staff-add-submit');
  btn.disabled = true;
  try {
    const base = {
      fullName: el('sf-name').value.trim(),
      email: el('sf-email').value.trim(),
      password: el('sf-password').value,
      phone: el('sf-phone').value.trim() || undefined,
    };
    let result;
    if (currentStaffType === 'guard') {
      result = await createGuardAccount(base);
    } else {
      result = await createStaffAccount({
        ...base,
        accountType: currentStaffType,
        employeeNumber: currentStaffType === 'teacher' ? el('sf-extra-1-input').value.trim() || undefined : undefined,
        licenseNumber: currentStaffType === 'driver' ? el('sf-extra-1-input').value.trim() || undefined : undefined,
        parentStudentLinks: currentStaffType === 'parent' ? selectedLinks.map(({ studentId, relationship }) => ({ studentId, relationship })) : undefined,
      });
    }
    if (!result.ok) { errEl.hidden = false; errEl.textContent = result.error; return; }
    toast('تم إنشاء الحساب بنجاح.', 'success');
    cache.teachers = null; cache.drivers = null;
    showView({ teacher: 'teachers', driver: 'drivers', parent: 'parents', guard: 'guards' }[currentStaffType]);
    if (currentStaffType === 'guard') loadGuards(); else loadStaffList(currentStaffType + 's');
  } finally {
    btn.disabled = false;
  }
});

// ===== GUARDS + PERMISSIONS =====
async function loadGuards() {
  const panel = el('guards-panel');
  panel.innerHTML = loadingHtml();
  const rows = await listGuards(el('guards-search').value);
  panel.innerHTML = rows.length
    ? rows.map((g) => `<div class="history-item" data-guard-idx="${rows.indexOf(g)}" style="cursor:pointer;">
        <div><strong>${esc(g.fullName)}</strong> <span class="time">${esc(g.userNumber)}</span></div>
        <div>${g.isDisabled ? '<span class="badge badge-red">معطل</span>' : '<span class="badge badge-green">نشط</span>'}</div>
      </div>`).join('')
    : emptyHtml('لا يوجد حراس.');
  panel.querySelectorAll('[data-guard-idx]').forEach((it) => it.addEventListener('click', () => openGuardDetail(rows[Number(it.dataset.guardIdx)])));
}
el('guards-search').addEventListener('input', loadGuards);

async function openGuardDetail(guard) {
  currentGuard = guard;
  showView('guard-detail');
  el('guard-detail-title').textContent = guard.fullName;
  el('guard-detail-body').innerHTML = `<div class="panel">
    <div class="detail-row"><span class="k">الاسم</span><span class="v">${esc(guard.fullName)}</span></div>
    <div class="detail-row"><span class="k">البريد</span><span class="v">${esc(guard.userNumber)}</span></div>
    <div class="detail-row"><span class="k">الحالة</span><span class="v">${guard.isDisabled ? 'معطل' : 'نشط'}</span></div>
    <button type="button" class="quick-action-btn" id="gd-toggle" style="width:100%; margin-top:10px; ${guard.isDisabled ? '' : 'background:#b91c1c;'}">
      ${guard.isDisabled ? 'إعادة تفعيل' : 'تعطيل الحساب'}</button>
  </div>
  <p class="section-title" style="margin-top:12px;">إحصائيات</p>
  <div class="stats-grid" id="guard-stats"><div class="loading-state">جارٍ التحميل...</div></div>`;
  getGuardStats(guard.profileId).then((res) => {
    const st = res.ok ? res.data || {} : {};
    el('guard-stats').innerHTML = statCard(st.badges_issued ?? 0, 'بطاقات صادرة')
      + statCard(st.badges_reissued ?? 0, 'إعادة إصدار')
      + statCard(st.badges_suspended ?? 0, 'بطاقات معلّقة')
      + statCard(st.students_registered ?? 0, 'تلاميذ مسجَّلون');
  });
  el('gd-toggle').addEventListener('click', async () => {
    const target = !guard.isDisabled;
    const ok = await confirmDialog(target ? 'تعطيل هذا الحارس؟' : 'إعادة تفعيل هذا الحارس؟');
    if (!ok) return;
    const res = await setGuardStatus(guard.profileId, target);
    if (!res.ok) { toast(res.error, 'error'); return; }
    toast('تم.', 'success');
    guard.isDisabled = target;
    openGuardDetail(guard);
  });

  // Permissions matrix
  const panel = el('guard-perms-panel');
  panel.innerHTML = loadingHtml();
  const [catalog, grantedRes] = await Promise.all([
    listAllPermissions(),
    getUserPermissions(guard.profileId, guard.schoolId),
  ]);
  const granted = grantedRes.ok ? new Set(grantedRes.data || []) : new Set();
  const byModule = {};
  (catalog || []).forEach((p) => { (byModule[p.module] = byModule[p.module] || []).push(p); });

  panel.innerHTML = Object.entries(byModule).map(([mod, perms]) => `
    <div class="perm-module">${esc(mod)}</div>
    <div class="perm-grid">${perms.map((p) => `
      <label class="perm-item"><input type="checkbox" data-perm="${esc(p.permission_key)}" ${granted.has(p.permission_key) ? 'checked' : ''}>
      ${esc(p.name)}</label>`).join('')}</div>`).join('');

  const updateCount = () => {
    const n = panel.querySelectorAll('[data-perm]:checked').length;
    el('perm-count').textContent = n + ' صلاحية';
  };
  updateCount();

  panel.querySelectorAll('[data-perm]').forEach((cb) => cb.addEventListener('change', async () => {
    cb.disabled = true;
    const res = cb.checked
      ? await grantUserPermission(guard.profileId, guard.schoolId, cb.dataset.perm)
      : await revokeUserPermission(guard.profileId, guard.schoolId, cb.dataset.perm);
    cb.disabled = false;
    if (!res.ok) { cb.checked = !cb.checked; toast(mapRpcError(res.error), 'error'); return; }
    toast(cb.checked ? 'تم منح الصلاحية.' : 'تم إلغاء الصلاحية.', 'success');
    updateCount();
  }));
}

// ===== ATTENDANCE =====
async function loadAttendanceView() {
  const host = el('att-today');
  host.innerHTML = loadingHtml();
  const res = await schoolAttendanceToday();
  const t = res.ok && res.data?.length ? res.data[0] : {};
  host.innerHTML = '<div class="stats-grid">'
    + statCard(t.present ?? 0, 'حاضر', 'tone-green') + statCard(t.absent ?? 0, 'غائب', 'tone-red')
    + statCard(t.late ?? 0, 'متأخر', 'tone-gold') + statCard(t.excused ?? 0, 'مبرر')
    + statCard(t.total_marked ?? 0, 'إجمالي المسجلين') + '</div>';

  const classes = await ensureClasses();
  el('att-class').innerHTML = classes.filter((c) => !c.is_disabled).map((c) => `<option value="${c.class_id}">${esc(c.class_name)} — ${esc(c.year_name || '')}</option>`).join('');
  el('att-date').value = new Date().toISOString().slice(0, 10);
  el('att-roster').hidden = true;
}

el('att-load').addEventListener('click', async () => {
  const classId = el('att-class').value;
  const date = el('att-date').value;
  const host = el('att-roster');
  if (!classId) { toast('اختر القسم.', 'error'); return; }
  host.hidden = false;
  host.innerHTML = loadingHtml();
  const res = await getClassAttendance(classId, date);
  if (!res.ok) { host.innerHTML = emptyHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا يوجد تلاميذ في هذا القسم.'); return; }

  const state = {};
  rows.forEach((r) => { state[r.student_id] = r.status || 'present'; });

  const render = () => {
    host.innerHTML = rows.map((r) => `
      <div class="history-item" style="align-items:flex-start; flex-direction:column; gap:6px;">
        <div><strong>${esc(r.full_name)}</strong> <span class="time">#${esc(r.student_number || '')}</span></div>
        <div style="display:flex; gap:6px;">
          ${['present', 'absent', 'late', 'excused'].map((st) => `<button type="button" class="att-btn ${state[r.student_id] === st ? 'active-' + st : ''}" data-st="${r.student_id}" data-val="${st}">${attStatusAr(st)}</button>`).join('')}
        </div>
      </div>`).join('')
      + '<button type="button" class="quick-action-btn" id="att-save" style="width:100%; margin-top:10px;">حفظ الحضور</button>';
    host.querySelectorAll('[data-st]').forEach((b) => b.addEventListener('click', () => { state[b.dataset.st] = b.dataset.val; render(); }));
    el('att-save').addEventListener('click', async () => {
      const payload = Object.entries(state).map(([student_id, status]) => ({ student_id, status }));
      const res2 = await saveAttendance(classId, date, payload);
      if (!res2.ok) { toast(res2.error, 'error'); return; }
      toast(`تم حفظ حضور ${res2.data} تلميذًا.`, 'success');
      loadAttendanceView();
    });
  };
  render();
});

// ===== SCHEDULE =====
const WEEKDAYS_AR = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
let schoolPeriodsCache = null;
let scheduleSchoolProfile = null;

async function loadScheduleView() {
  const classes = await ensureClasses();
  el('sc-class').innerHTML = '<option value="">— اختر القسم —</option>'
    + classes.filter((c) => !c.is_disabled).map((c) => `<option value="${c.class_id}">${esc(c.class_name)} — ${esc(c.year_name || '')}</option>`).join('');
  el('sc-panel').innerHTML = emptyHtml('اختر القسم لعرض الجدول الأسبوعي.');
  el('sc-add-panel').hidden = true;
  const subjects = await ensureSubjects();
  el('sc-subject').innerHTML = '<option value="">— اختر المادة —</option>' + subjects.map((s) => `<option value="${s.subject_id}">${esc(s.subject_name)}</option>`).join('');
  const teachers = await ensureTeachers();
  el('sc-teacher').innerHTML = '<option value="">— اختر الأستاذ —</option>' + teachers.map((t) => `<option value="${t.id}">${esc(t.profiles?.full_name || '—')}</option>`).join('');
  // §28: after picking a SUBJECT, the teacher dropdown shows only teachers
  // actually assigned to that subject (fn_add_lesson stays the final
  // server-side authority — TEACHER_ASSIGNMENT_REQUIRED).
  const teacherSubjects = {};
  await Promise.all(teachers.map(async (t) => {
    const r = await listTeacherSubjects(t.id);
    teacherSubjects[t.id] = (r.ok ? r.data || [] : []).map((x) => x.subject_id);
  }));
  el('sc-subject').addEventListener('change', () => {
    const sid = el('sc-subject').value;
    const sel = el('sc-teacher');
    const prev = sel.value;
    sel.innerHTML = '<option value="">— اختر الأستاذ —</option>' + teachers
      .filter((t) => !sid || (teacherSubjects[t.id] || []).includes(sid))
      .map((t) => `<option value="${t.id}">${esc(t.profiles?.full_name || '—')}</option>').join('');
    if ([...sel.options].some((o) => o.value === prev)) sel.value = prev;
  });
  const [periodsRes, profileRes] = await Promise.all([getSchoolPeriods(), getSchoolProfile(schoolId)]);
  schoolPeriodsCache = periodsRes.ok ? periodsRes.data : null;
  scheduleSchoolProfile = profileRes.ok ? profileRes.data : null;
  await fillPeriodOptions();
}

// ===== SIMPLE 4+4 WEEKLY TIMETABLE =====
function periodTimeRange(period, cfg = schoolPeriodsCache) {
  const n = Number(period);
  if (!cfg || !n || n < 1 || n > 8) return { start: '—', end: '—' };
  if (n <= 4) {
    const mins = Number(cfg.morning_lesson_minutes || 60);
    return {
      start: addMinutes(String(cfg.morning_start || '08:00'), (n - 1) * mins),
      end: addMinutes(String(cfg.morning_start || '08:00'), n * mins),
    };
  }
  const mins = Number(cfg.afternoon_lesson_minutes || 60);
  const i = n - 4;
  return {
    start: addMinutes(String(cfg.afternoon_start || '14:00'), (i - 1) * mins),
    end: addMinutes(String(cfg.afternoon_start || '14:00'), i * mins),
  };
}

function timetableCellHtml(row) {
  if (!row) return '<div class="schedule-empty">—</div>';
  return `<div class="schedule-cell-content">
    <strong>${esc(row.subject_name || '—')}</strong>
    <span>${esc(row.teacher_name || '—')}</span>
    <div class="schedule-cell-actions">
      <button type="button" class="icon-btn" data-edit-lesson="${esc(row.id)}" data-weekday="${esc(row.weekday)}" data-period="${esc(row.period)}" data-subject="${esc(row.subject_id || '')}" data-teacher="${esc(row.teacher_id || '')}" title="تعديل">✏️</button>
      <button type="button" class="icon-btn" data-del-lesson="${esc(row.id)}" title="حذف">🗑️</button>
    </div>
  </div>`;
}

function buildWeeklyTimetable(rows, className) {
  const bySlot = new Map();
  (rows || []).forEach((r) => bySlot.set(`${Number(r.weekday)}-${Number(r.period)}`, r));
  const days = [0, 1, 2, 3, 4, 5, 6];
  const dayNames = WEEKDAYS_AR;
  const periods = Array.from({ length: 8 }, (_, i) => i + 1);
  let html = `<div class="schedule-toolbar">
      <div><strong>الجدول الأسبوعي</strong><span class="schedule-subtitle">${esc(className || '')}</span></div>
      <div class="schedule-actions">
        <button type="button" class="quick-action-btn secondary" id="sc-print">🖨️ طباعة الجدول</button>
        <button type="button" class="quick-action-btn" id="sc-pdf">⬇️ تحميل PDF</button>
      </div>
    </div>
    <div class="schedule-scroll"><table class="weekly-schedule"><thead><tr><th class="period-head">الحصة</th>`;
  days.forEach((d) => { html += `<th>${dayNames[d]}</th>`; });
  html += '</tr></thead><tbody>';
  periods.forEach((period) => {
    const t = periodTimeRange(period);
    const group = period <= 4 ? 'morning' : 'afternoon';
    html += `<tr class="schedule-${group}"><th class="period-head"><span>الحصة ${period}</span><small>${t.start} – ${t.end}</small></th>`;
    days.forEach((d) => { html += `<td>${timetableCellHtml(bySlot.get(`${d}-${period}`))}</td>`; });
    html += '</tr>';
    if (period === 4) html += '<tr class="schedule-break"><td colspan="8">☀️ فترة الزوال</td></tr>';
  });
  html += '</tbody></table></div>';
  html += `<div class="schedule-legend"><span>🌅 الصباح: 4 حصص</span><span>☀️ الزوال: 4 حصص</span><span>${rows.length} حصة مسجلة هذا الأسبوع</span></div>`;
  return html;
}

function extractWeeklyTable(rows, className) {
  const html = buildWeeklyTimetable(rows, className);
  const match = html.match(/<div class="schedule-scroll">([\s\S]*?)<\/div>\s*<div class="schedule-legend">/);
  return match ? match[1] : '';
}

function printWeeklyTimetable(rows, className) {
  const school = scheduleSchoolProfile || {};
  const grid = extractWeeklyTable(rows, className);
  const win = window.open('', '_blank', 'width=1200,height=800');
  if (!win) { toast('اسمح بفتح النوافذ المنبثقة لطباعة الجدول.', 'error'); return; }
  win.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>الجدول الدراسي</title>
    <style>body{font-family:Arial,Tahoma,sans-serif;color:#14212e;margin:24px;direction:rtl}header{text-align:center;margin-bottom:18px}header img{max-height:70px;max-width:180px}h1{font-size:24px;margin:6px 0}h2{font-size:18px;margin:4px 0;color:#475569}.weekly-schedule{width:100%;border-collapse:collapse;table-layout:fixed}.weekly-schedule th,.weekly-schedule td{border:1px solid #cbd5e1;padding:7px;text-align:center;vertical-align:middle}.weekly-schedule thead th{background:#e2e8f0}.weekly-schedule .period-head{width:125px;background:#f8fafc}.weekly-schedule .period-head span{display:block;font-weight:700}.weekly-schedule .period-head small{display:block;margin-top:4px;color:#475569}.schedule-cell-content strong{display:block;font-size:13px}.schedule-cell-content>span{display:block;font-size:11px;color:#64748b;margin-top:4px}.schedule-cell-actions{display:none}.schedule-break td{background:#fffbeb;font-weight:700;color:#92400e;padding:5px}.schedule-scroll{width:100%}@media print{body{margin:10mm}.weekly-schedule{font-size:11px}}</style></head><body>
    <header>${school.logo_url ? `<img src="${esc(school.logo_url)}" crossorigin="anonymous" alt="الشعار">` : ''}<h1>${esc(school.name || 'المؤسسة')}</h1><h2>الجدول الدراسي — ${esc(className || '')}</h2><div>${esc(school.current_academic_year || '')}</div></header>${grid}
    <script>window.onload=function(){setTimeout(function(){window.print()},300)};</script></body></html>`);
  win.document.close();
}

function loadExternalScript(src, globalName) {
  return new Promise((resolve, reject) => {
    if (window[globalName]) return resolve(window[globalName]);
    const existing = document.querySelector(`script[data-ss-lib="${globalName}"]`);
    if (existing) { existing.addEventListener('load', () => resolve(window[globalName])); existing.addEventListener('error', reject); return; }
    const s = document.createElement('script');
    s.src = src; s.async = true; s.dataset.ssLib = globalName;
    s.onload = () => window[globalName] ? resolve(window[globalName]) : reject(new Error(`${globalName} unavailable`));
    s.onerror = reject; document.head.appendChild(s);
  });
}

async function downloadWeeklyTimetablePdf(rows, className) {
  const school = scheduleSchoolProfile || {};
  const wrap = document.createElement('div');
  wrap.dir = 'rtl';
  wrap.style.cssText = 'position:fixed;left:-100000px;top:0;width:1120px;padding:28px;background:#fff;color:#14212e;font-family:Arial,Tahoma,sans-serif;z-index:-1;';
  const title = document.createElement('div');
  title.style.cssText = 'text-align:center;margin-bottom:18px;';
  title.innerHTML = `${school.logo_url ? `<img src="${esc(school.logo_url)}" crossorigin="anonymous" style="max-height:70px;max-width:180px;display:block;margin:0 auto 8px" alt="الشعار">` : ''}<h1 style="margin:0;font-size:25px">${esc(school.name || 'المؤسسة')}</h1><h2 style="margin:6px 0;font-size:18px">الجدول الدراسي — ${esc(className || '')}</h2><div style="font-size:13px;color:#64748b">${esc(school.current_academic_year || '')}</div>`;
  wrap.appendChild(title);
  const content = document.createElement('div');
  content.className = 'schedule-pdf-table';
  content.innerHTML = `<div class="schedule-scroll">${extractWeeklyTable(rows, className)}</div>`;
  wrap.appendChild(content);
  document.body.appendChild(wrap);
  try {
    await loadExternalScript('https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js', 'html2canvas');
    await loadExternalScript('https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js', 'jspdf');
    const canvas = await window.html2canvas(wrap, { scale: 2, useCORS: true, backgroundColor: '#ffffff', logging: false });
    const pdfApi = window.jspdf?.jsPDF || window.jsPDF;
    if (!pdfApi) throw new Error('PDF library unavailable');
    const pdf = new pdfApi({ orientation: 'landscape', unit: 'mm', format: 'a4' });
    const pageW = pdf.internal.pageSize.getWidth();
    const pageH = pdf.internal.pageSize.getHeight();
    const margin = 7;
    const ratio = Math.min((pageW - margin * 2) / canvas.width, (pageH - margin * 2) / canvas.height);
    const w = canvas.width * ratio, h = canvas.height * ratio;
    const x = (pageW - w) / 2, y = (pageH - h) / 2;
    pdf.addImage(canvas.toDataURL('image/jpeg', 0.92), 'JPEG', x, y, w, h);
    pdf.save(`الجدول-${String(className || 'القسم').replace(/[^\u0600-\u06FF\w\-]+/g, '_')}.pdf`);
    toast('تم تحميل ملف PDF.', 'success');
  } catch (error) {
    console.error('schedule PDF error:', error);
    toast('تعذر إنشاء PDF مباشرة؛ سيتم فتح نسخة الطباعة لحفظها كـ PDF.', 'info');
    printWeeklyTimetable(rows, className);
  } finally { wrap.remove(); }
}

// Phase 23 — the admin no longer types a lesson's time; it is computed from the school's 4+4 configuration.
function addMinutes(hhmm, minutes) {
  const [h, m] = hhmm.slice(0, 5).split(':').map(Number);
  const total = h * 60 + m + minutes;
  const hh = Math.floor((total % 1440) / 60).toString().padStart(2, '0');
  const mm = (total % 60).toString().padStart(2, '0');
  return `${hh}:${mm}`;
}
async function fillPeriodOptions() {
  if (!schoolPeriodsCache) {
    const res = await getSchoolPeriods();
    schoolPeriodsCache = res.ok ? res.data : null;
  }
  const cfg = schoolPeriodsCache;
  const opts = [];
  for (let i = 1; i <= 4; i++) {
    const start = addMinutes(String(cfg?.morning_start || '08:00'), (i - 1) * Number(cfg?.morning_lesson_minutes || 60));
    const end = addMinutes(String(cfg?.morning_start || '08:00'), i * Number(cfg?.morning_lesson_minutes || 60));
    opts.push(`<option value="${i}">🌅 الحصة ${i} (${start}–${end})</option>`);
  }
  for (let i = 1; i <= 4; i++) {
    const period = 4 + i;
    const start = addMinutes(String(cfg?.afternoon_start || '14:00'), (i - 1) * Number(cfg?.afternoon_lesson_minutes || 60));
    const end = addMinutes(String(cfg?.afternoon_start || '14:00'), i * Number(cfg?.afternoon_lesson_minutes || 60));
    opts.push(`<option value="${period}">☀️ الحصة ${period} (${start}–${end})</option>`);
  }
  el('sc-period').innerHTML = opts.join('');
}

function resetScheduleForm() {
  scEditingEntryId = null;
  el('sc-add-form').reset();
  const btn = el('sc-add-form').querySelector('button[type="submit"]');
  if (btn) btn.textContent = 'إضافة الحصة';
}

async function renderClassSchedule() {
  const classId = el('sc-class').value;
  if (!classId) { el('sc-panel').innerHTML = emptyHtml('اختر القسم لعرض الجدول الأسبوعي.'); el('sc-add-panel').hidden = true; return; }
  el('sc-add-panel').hidden = false;
  if (!schoolPeriodsCache) { const pr = await getSchoolPeriods(); schoolPeriodsCache = pr.ok ? pr.data : null; }
  const res = await getClassSchedule(classId);
  if (!res.ok) { el('sc-panel').innerHTML = emptyHtml(res.error); return; }
  const rows = res.data || [];
  const selected = el('sc-class').selectedOptions[0];
  const className = selected ? selected.textContent : '';
  el('sc-panel').innerHTML = buildWeeklyTimetable(rows, className);

  const editButtons = el('sc-panel').querySelectorAll('[data-edit-lesson]');
  editButtons.forEach((b) => b.addEventListener('click', () => {
    scEditingEntryId = b.dataset.editLesson;
    el('sc-weekday').value = b.dataset.weekday;
    el('sc-period').value = b.dataset.period;
    el('sc-subject').value = b.dataset.subject;
    el('sc-teacher').value = b.dataset.teacher;
    el('sc-add-form').querySelector('button[type="submit"]').textContent = 'تحديث الحصة';
    el('sc-add-form').scrollIntoView({ behavior: 'smooth' });
  }));
  el('sc-panel').querySelectorAll('[data-del-lesson]').forEach((b) => b.addEventListener('click', async () => {
    const ok = await confirmDialog('حذف هذه الحصة؟');
    if (!ok) return;
    const res2 = await deleteLesson(b.dataset.delLesson);
    if (!res2.ok) { toast(res2.error, 'error'); return; }
    toast('تم حذف الحصة.', 'success');
    if (scEditingEntryId === b.dataset.delLesson) resetScheduleForm();
    renderClassSchedule();
  }));
  el('sc-print')?.addEventListener('click', () => printWeeklyTimetable(rows, className));
  el('sc-pdf')?.addEventListener('click', () => downloadWeeklyTimetablePdf(rows, className));
}

el('sc-class').addEventListener('change', () => { resetScheduleForm(); renderClassSchedule(); });

// PHASE 19 FIX: this used to call setClassSchedule(classId, [oneEntry]),
// which REPLACES the whole class timetable and silently deleted every
// other lesson already saved for this class. Now uses single-row
// fn_add_lesson / fn_update_lesson (server-side conflict checks included).
el('sc-add-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const classId = el('sc-class').value;
  if (!classId) { toast('اختر القسم أولاً.', 'error'); return; }
  const payload = {
    classId, weekday: Number(el('sc-weekday').value), period: Number(el('sc-period').value),
    subjectId: el('sc-subject').value || null, teacherId: el('sc-teacher').value || null,
  };
  const res = scEditingEntryId
    ? await updateLesson({ entryId: scEditingEntryId, ...payload })
    : await addLesson(payload);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast(scEditingEntryId ? 'تم تحديث الحصة.' : 'تمت إضافة الحصة.', 'success');
  resetScheduleForm();
  renderClassSchedule();
});

// ===== TRANSPORT =====
async function loadTransport() {
  const bp = el('buses-panel');
  const rp = el('routes-panel');
  bp.innerHTML = loadingHtml();
  rp.innerHTML = loadingHtml();
  const [busesRes, routesRes, drivers] = await Promise.all([listBuses(), listRoutes(), ensureDrivers()]);
  cache.buses = busesRes.ok ? busesRes.data || [] : [];
  cache.routes = routesRes.ok ? routesRes.data || [] : [];

  bp.innerHTML = cache.buses.length
    ? cache.buses.map((b) => `<div class="history-item">
        <div><strong>${esc(b.code)}</strong> <span class="time">${esc(b.plate || '')}</span></div>
        <div class="time">${esc(b.driver_name || 'بدون سائق')} · ${b.student_count} تلميذًا ${b.is_active ? '' : '· <span class="badge badge-red">موقوفة</span>'}</div>
      </div>`).join('')
    : emptyHtml('لا توجد حافلات.');

  rp.innerHTML = cache.routes.length
    ? cache.routes.map((r) => {
      const stops = Array.isArray(r.stops) ? r.stops : [];
      return `<div class="history-item" style="flex-direction:column; align-items:flex-start; gap:4px;">
        <div><strong>${esc(r.route_name)}</strong> <span class="time">${r.student_count} تلميذًا</span></div>
        <div class="time">${stops.map((s) => esc(s.name)).join(' ← ') || 'بدون محطات'}</div>
      </div>`;
    }).join('')
    : emptyHtml('لا توجد مسارات.');

  el('bus-driver').innerHTML = '<option value="">—</option>' + drivers.map((d) => `<option value="${d.id}">${esc(d.profiles?.full_name || '—')}</option>`).join('');
}

el('add-bus-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const res = await createBus({
    code: el('bus-code').value, plate: el('bus-plate').value,
    capacity: el('bus-capacity').value ? Number(el('bus-capacity').value) : null,
    driverId: el('bus-driver').value || null,
  });
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم حفظ الحافلة.', 'success');
  e.target.reset();
  loadTransport();
});

el('add-route-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const stops = el('rt-stops').value.split('\n').map((s) => s.trim()).filter(Boolean);
  const res = await createRoute(el('rt-name').value, stops);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم حفظ المسار.', 'success');
  e.target.reset();
  loadTransport();
});

// ===== FINANCE =====
async function loadFinance() {
  const sum = el('finance-summary');
  sum.innerHTML = loadingHtml();
  const res = await financeSummary(null, null);
  const f = res.ok && res.data?.length ? res.data[0] : {};
  sum.innerHTML = '<div class="stats-grid">'
    + statCard(fmtMoney(f.total_due), 'مستحق') + statCard(fmtMoney(f.total_paid), 'مؤدى', 'tone-green')
    + statCard(fmtMoney((f.total_due || 0) - (f.total_paid || 0)), 'متبقٍ', 'tone-gold')
    + statCard(fmtMoney(f.total_expenses), 'مصاريف', 'tone-red')
    + statCard(fmtMoney(f.net), 'الصافي') + '</div>';

  loadPaymentsList();
  loadExpensesList();
}

async function loadPaymentsList() {
  const panel = el('payments-panel');
  panel.innerHTML = loadingHtml();
  const res = await listPayments(null, 30);
  const rows = res.ok ? res.data || [] : [];
  panel.innerHTML = rows.length
    ? rows.map((p) => `<div class="history-item">
        <div><strong>${esc(p.student_name)}</strong> <span class="time">${esc(p.fee_type)}</span></div>
        <div class="time">${fmtMoney(p.amount_paid)} / ${fmtMoney(p.amount_due)} · ${fmtDate(p.payment_date)} · ${esc(p.receipt_no || '')}</div>
      </div>`).join('')
    : emptyHtml('لا توجد أداءات.');
}

async function loadExpensesList() {
  const panel = el('expenses-panel');
  panel.innerHTML = loadingHtml();
  const res = await listExpenses(30);
  const rows = res.ok ? res.data || [] : [];
  panel.innerHTML = rows.length
    ? rows.map((x) => `<div class="history-item">
        <div><strong>${esc(x.category)}</strong> <span class="time">${esc(x.description || '')}</span></div>
        <div class="time">${fmtMoney(x.amount)} · ${fmtDate(x.expense_date)}</div>
      </div>`).join('')
    : emptyHtml('لا توجد مصاريف.');
}

// student picker shared by payment & incident forms
function wireStudentPicker(inputId, resultsId, onPick) {
  let timer = null;
  el(inputId).addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const q = el(inputId).value;
      const host = el(resultsId);
      if (!q.trim()) { host.innerHTML = ''; return; }
      const rows = await searchStudents(q);
      host.innerHTML = rows.map((s) => `<div class="search-result-item" data-pick="${s.id}" data-name="${esc(s.full_name)}">${esc(s.full_name)} <span class="time">#${esc(s.student_number || '')}</span></div>`).join('');
      host.querySelectorAll('[data-pick]').forEach((it) => it.addEventListener('click', () => {
        onPick(it.dataset.pick, it.dataset.name);
        el(inputId).value = it.dataset.name;
        host.innerHTML = '';
      }));
    }, 300);
  });
}

wireStudentPicker('pay-student-search', 'pay-student-results', (id) => { pickedStudent = id; });

el('add-payment-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = el('add-payment-error');
  errEl.hidden = true;
  if (!pickedStudent) { errEl.hidden = false; errEl.textContent = 'اختر التلميذ من نتائج البحث.'; return; }
  const res = await recordPayment({
    studentId: pickedStudent, feeType: el('pay-type').value,
    amountDue: Number(el('pay-due').value || 0), amountPaid: Number(el('pay-paid').value || 0),
    method: el('pay-method').value,
  });
  if (!res.ok) { errEl.hidden = false; errEl.textContent = res.error; return; }
  toast('تم تسجيل الأداء.', 'success');
  e.target.reset();
  pickedStudent = null;
  loadFinance();
});

el('add-expense-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = el('add-expense-error');
  errEl.hidden = true;
  const res = await recordExpense({
    category: el('ex-category').value, amount: Number(el('ex-amount').value || 0),
    description: el('ex-desc').value,
  });
  if (!res.ok) { errEl.hidden = false; errEl.textContent = res.error; return; }
  toast('تم تسجيل المصروف.', 'success');
  e.target.reset();
  loadFinance();
});

// ===== INCIDENTS =====
async function loadIncidentsView() {
  const panel = el('incidents-panel');
  panel.innerHTML = loadingHtml();
  const res = await listIncidents(el('inc-status').value || null, 50, 0);
  const rows = res.ok ? res.data || [] : [];
  panel.innerHTML = rows.length
    ? rows.map((i) => `<div class="history-item" style="flex-direction:column; align-items:flex-start; gap:4px;">
        <div><strong>${esc(i.title)}</strong> <span class="badge ${i.status === 'open' ? 'badge-red' : 'badge-green'}">${i.status === 'open' ? 'مفتوحة' : 'مغلقة'}</span></div>
        <div class="time">${esc(i.student_name)} · ${esc(i.type)} · ${fmtDateTime(i.occurred_at)} · سجلها: ${esc(i.reporter_name || '—')}</div>
        ${i.description ? `<div class="time">${esc(i.description)}</div>` : ''}
        ${i.action_taken ? `<div class="time">الإجراء: ${esc(i.action_taken)}</div>` : ''}
        ${i.status === 'open' ? `<button type="button" class="att-btn" data-close-inc="${i.incident_id}">إغلاق المخالفة</button>` : ''}
      </div>`).join('')
    : emptyHtml('لا توجد مخالفات.');
  panel.querySelectorAll('[data-close-inc]').forEach((b) => b.addEventListener('click', async () => {
    const action = prompt('الإجراء المتخذ (اختياري):') ?? '';
    const res2 = await updateIncident(b.dataset.closeInc, 'closed', action || null);
    if (!res2.ok) { toast(res2.error, 'error'); return; }
    toast('تم إغلاق المخالفة.', 'success');
    loadIncidentsView();
  }));
}
el('inc-status').addEventListener('change', loadIncidentsView);
el('btn-add-incident').addEventListener('click', () => { pickedStudent = null; el('add-incident-form').reset(); showView('incident-add'); });

wireStudentPicker('inc-student-search', 'inc-student-results', (id) => { pickedStudent = id; });

el('add-incident-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = el('add-incident-error');
  errEl.hidden = true;
  if (!pickedStudent) { errEl.hidden = false; errEl.textContent = 'اختر التلميذ من نتائج البحث.'; return; }
  const res = await reportIncident({
    studentId: pickedStudent, type: el('inc-type').value, title: el('inc-title').value,
    description: el('inc-desc').value, place: el('inc-place').value,
  });
  if (!res.ok) { errEl.hidden = false; errEl.textContent = res.error; return; }
  toast('تم تسجيل المخالفة.', 'success');
  e.target.reset();
  pickedStudent = null;
  showView('incidents');
  loadIncidentsView();
});

// ===== REPORTS =====
async function loadReportsView() {
  const classes = await ensureClasses();
  el('rp-class').innerHTML = '<option value="">كل الأقسام</option>'
    + classes.map((c) => `<option value="${c.class_id}">${esc(c.class_name)} — ${esc(c.year_name || '')}</option>`).join('');
  const now = new Date();
  el('rp-to').value = now.toISOString().slice(0, 10);
  el('rp-from').value = new Date(now.getTime() - 30 * 86400000).toISOString().slice(0, 10);
  el('report-result').hidden = true;
}

function renderReport(title, headers, rows, filename) {
  const host = el('report-result');
  host.hidden = false;
  host.innerHTML = `<p class="section-title" style="margin-top:0;">${esc(title)} (${rows.length})</p>`
    + (rows.length
      ? '<div class="data-table-wrap"><table class="data-table"><thead><tr>' + headers.map((h) => `<th>${esc(h)}</th>`).join('') + '</tr></thead><tbody>'
        + rows.map((r) => '<tr>' + r.map((c) => `<td>${esc(c)}</td>`).join('') + '</tr>').join('') + '</tbody></table></div>'
        + `<button type="button" class="quick-action-btn" id="rp-csv" style="width:100%; margin-top:10px;">تصدير CSV</button>`
         + `<button type="button" class="back-link" id="rp-print" style="width:100%; margin-top:6px;">طباعة</button>`
      : emptyHtml('لا توجد بيانات في هذا النطاق.'));
  const csvBtn = el('rp-csv');
  if (csvBtn) csvBtn.addEventListener('click', () => downloadCSV(filename, headers, rows));
  const printBtn = el('rp-print');
  if (printBtn) printBtn.addEventListener('click', () => window.print());
}

el('rp-attendance').addEventListener('click', async () => {
  const res = await reportAttendance(el('rp-from').value, el('rp-to').value, el('rp-class').value || null);
  if (!res.ok) { toast(res.error, 'error'); return; }
  renderReport('تقرير الحضور', ['التاريخ', 'التلميذ', 'الرقم', 'القسم', 'الحالة', 'ملاحظة'],
    (res.data || []).map((r) => [fmtDate(r.att_date), r.student_name, r.student_number, r.class_name, attStatusAr(r.status), r.note || '']),
    'attendance-report.csv');
});
el('rp-payments').addEventListener('click', async () => {
  const res = await listPayments(null, 500);
  if (!res.ok) { toast(res.error, 'error'); return; }
  renderReport('تقرير الأداءات', ['التلميذ', 'النوع', 'مستحق', 'مؤدى', 'التاريخ', 'الطريقة', 'إيصال'],
    (res.data || []).map((p) => [p.student_name, p.fee_type, p.amount_due, p.amount_paid, fmtDate(p.payment_date), p.method || '', p.receipt_no || '']),
    'payments-report.csv');
});
el('rp-expenses').addEventListener('click', async () => {
  const res = await listExpenses(500);
  if (!res.ok) { toast(res.error, 'error'); return; }
  renderReport('تقرير المصاريف', ['التصنيف', 'المبلغ', 'التاريخ', 'الوصف', 'الموظف'],
    (res.data || []).map((x) => [x.category, x.amount, fmtDate(x.expense_date), x.description || '', x.recorder_name || '']),
    'expenses-report.csv');
});
el('rp-incidents').addEventListener('click', async () => {
  const res = await listIncidents(null, 500, 0);
  if (!res.ok) { toast(res.error, 'error'); return; }
  renderReport('تقرير المخالفات', ['التلميذ', 'النوع', 'العنوان', 'التاريخ', 'الحالة', 'الإجراء'],
    (res.data || []).map((i) => [i.student_name, i.type, i.title, fmtDate(i.occurred_at), i.status === 'open' ? 'مفتوحة' : 'مغلقة', i.action_taken || '']),
    'incidents-report.csv');
});
el('rp-students').addEventListener('click', async () => {
  const rows = await filterStudents({ limit: 500 });
  renderReport('تقرير التلاميذ', ['الاسم', 'الرقم', 'القسم', 'الحالة'],
    rows.map((r) => [r.student?.fullName || '', r.student?.studentNumber || '', r.student?.className || '', r.resultType === 'AUTHORIZED' ? 'نشط' : 'غير نشط']),
    'students-report.csv');
});

// ===== NOTIFICATIONS =====
async function loadNotificationsView() {
  const panel = el('my-notifs-panel');
  panel.innerHTML = loadingHtml();
  const res = await listMyNotifications(50);
  const rows = res.ok ? res.data || [] : [];
  panel.innerHTML = rows.length
    ? rows.map((n) => `<div class="history-item" data-notif="${n.notification_id}" style="cursor:pointer; ${n.is_read ? 'opacity:.65;' : ''}">
        <div><strong>${esc(n.title)}</strong> <span class="badge badge-blue">${esc(n.type)}</span></div>
        <div class="time">${fmtDateTime(n.created_at)}${n.student_name ? ' · ' + esc(n.student_name) : ''}</div>
        ${n.body ? `<div class="time">${esc(n.body)}</div>` : ''}
      </div>`).join('')
    : emptyHtml('لا توجد إشعارات.');
  panel.querySelectorAll('[data-notif]').forEach((it) => it.addEventListener('click', async () => {
    await markNotificationRead(it.dataset.notif);
    it.style.opacity = '.65';
    refreshNotifCount();
  }));
}

el('send-notif-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = el('send-notif-error');
  errEl.hidden = true;
  const res = await sendNotification({
    title: el('nt-title').value, body: el('nt-body').value,
    type: el('nt-type').value, targetRole: el('nt-target').value || null,
  });
  if (!res.ok) { errEl.hidden = false; errEl.textContent = res.error; return; }
  toast('تم إرسال الإشعار.', 'success');
  e.target.reset();
  loadNotificationsView();
});

// ===== AUDIT =====
async function loadAuditView() {
  const panel = el('audit-panel');
  panel.innerHTML = loadingHtml();
  const res = await schoolAudit(PAGE_SIZE, auditOffset);
  const rows = res.ok ? res.data || [] : [];
  panel.innerHTML = rows.length
    ? rows.map((r) => `<div class="history-item">
        <div><strong>${esc(r.action)}</strong> <span class="time">${esc(r.entity || '')}</span></div>
        <div class="time">${esc(r.actor_name || '—')} | ${fmtDateTime(r.created_at)}</div>
      </div>`).join('')
    : emptyHtml('لا توجد سجلات.');
  el('audit-page-info').textContent = 'الصفحة ' + (Math.floor(auditOffset / PAGE_SIZE) + 1);
  el('audit-prev').disabled = auditOffset === 0;
  el('audit-next').disabled = rows.length < PAGE_SIZE;
}
el('audit-prev').addEventListener('click', () => { auditOffset = Math.max(0, auditOffset - PAGE_SIZE); loadAuditView(); });
el('audit-next').addEventListener('click', () => { auditOffset += PAGE_SIZE; loadAuditView(); });

// ===== TEACHER ACADEMIC ASSIGNMENTS (PHASE 14) =====
// Director/admin links a teacher to subjects and classes. The server
// re-verifies school membership and same-school subject/class on every call.
let assignTeacherId = null;
let currentTeacherId = null;
let currentTeacherName = '';

async function openTeacherAssign(teacherId, name) {
  assignTeacherId = teacherId;
  el('ta-title').textContent = 'الربط الأكاديمي — ' + (name || '');
  showView('teacher-assign');
  await Promise.all([renderAssignSubjects(), renderAssignClasses()]);
}
el('ta-back').addEventListener('click', () => showView('teacher-detail'));

// ===== TEACHER PROFILE (Phase 19) =====
async function openTeacherDetail(teacherId) {
  currentTeacherId = teacherId;
  showView('teacher-detail');
  const infoHost = el('td-info');
  infoHost.innerHTML = loadingHtml();
  const res = await getTeacherFull(teacherId);
  if (!res.ok || !res.data) { infoHost.innerHTML = emptyHtml(res.error || 'تعذر تحميل ملف الأستاذ.'); return; }
  const t = res.data;
  currentTeacherName = t.full_name || '';
  const row = (k, v) => `<div class="detail-row"><span class="k">${k}</span><span class="v">${esc(v ?? '—')}</span></div>`;
  infoHost.innerHTML = `
    ${row('الاسم', t.full_name)}${row('الهاتف', t.phone)}${row('رقم الحساب', t.user_number)}
    ${row('رقم الموظف', t.employee_number)}${row('المؤسسة', t.school_name)}${row('السنة الدراسية الحالية', t.current_year_label)}
    ${row('الحالة', t.is_active ? 'نشط' : 'معطل')}`;

  el('td-subjects-classes-summary').innerHTML =
    `<div class="detail-row"><span class="k">عدد المواد</span><span class="v">${t.subjects_count ?? 0}</span></div>
     <div class="detail-row"><span class="k">عدد الأقسام</span><span class="v">${t.classes_count ?? 0}</span></div>`;

  el('td-rate').value = t.hourly_rate ?? '';
  el('td-month').value = new Date().toISOString().slice(0, 7);

  await renderTeacherSchedule(teacherId);
  await renderTeacherPayroll(teacherId);
}

el('td-open-assign').addEventListener('click', () => {
  if (!currentTeacherId) return;
  openTeacherAssign(currentTeacherId, currentTeacherName);
});

async function renderTeacherSchedule(teacherId) {
  const host = el('td-schedule');
  host.innerHTML = loadingHtml();
  const res = await getTeacherSchedule(teacherId);
  const rows = res.ok ? res.data || [] : [];
  const totalMinutes = rows.length * 45; // fixed 45-min period, same convention as fn_add_lesson
  el('td-hours-summary').textContent = `${rows.length} حصة — ${(totalMinutes / 60).toFixed(2)} ساعة/أسبوع`;
  host.innerHTML = rows.length
    ? '<div class="data-table-wrap"><table class="data-table"><thead><tr><th>اليوم</th><th>الحصة</th><th>القسم</th><th>المادة</th></tr></thead><tbody>'
      + rows.map((r) => `<tr><td>${WEEKDAYS_AR[r.weekday] || r.weekday}</td><td>${r.period}</td><td>${esc(r.class_name || '—')}</td><td>${esc(r.subject_name || '—')}</td></tr>`).join('')
      + '</tbody></table></div>'
    : emptyHtml('لا توجد حصص مسندة لهذا الأستاذ.');
}

el('td-rate-save').addEventListener('click', async () => {
  if (!currentTeacherId) return;
  const rate = Number(el('td-rate').value);
  if (!Number.isFinite(rate) || rate < 0) { toast('أدخل سعرًا صالحًا.', 'error'); return; }
  const res = await setTeacherRate(currentTeacherId, rate);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم حفظ سعر الساعة.', 'success');
});

el('td-month-save').addEventListener('click', async () => {
  if (!currentTeacherId) return;
  const month = el('td-month').value; // yyyy-mm
  const hours = Number(el('td-month-hours').value);
  if (!month) { toast('اختر الشهر.', 'error'); return; }
  if (!Number.isFinite(hours) || hours < 0) { toast('أدخل عدد ساعات صالح.', 'error'); return; }
  const res = await upsertTeacherMonth(currentTeacherId, month + '-01', hours, el('td-month-notes').value || null);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم حفظ الشهر.', 'success');
  el('td-month-hours').value = '';
  el('td-month-notes').value = '';
  renderTeacherPayroll(currentTeacherId);
});

async function renderTeacherPayroll(teacherId) {
  const host = el('td-payroll-list');
  host.innerHTML = loadingHtml();
  const res = await listTeacherPayroll(teacherId);
  const rows = res.ok ? res.data || [] : [];
  host.innerHTML = rows.length
    ? rows.map((r) => `<div class="history-item" style="flex-direction:column; align-items:stretch; gap:4px;">
        <div style="display:flex; justify-content:space-between;">
          <strong>${new Date(r.period_month).toLocaleDateString('ar', { year: 'numeric', month: 'long' })}</strong>
          <span class="time">${r.hours_worked} ساعة × ${fmtMoney(r.hourly_rate)}</span>
        </div>
        <div class="detail-row"><span class="k">المستحق</span><span class="v">${fmtMoney(r.amount_due)}</span></div>
        <div class="detail-row"><span class="k">المدفوع</span><span class="v">${fmtMoney(r.amount_paid)}</span></div>
        <div class="detail-row"><span class="k">الباقي</span><span class="v" style="font-weight:700; color:${r.balance > 0 ? '#dc2626' : '#16a34a'};">${fmtMoney(r.balance)}</span></div>
        ${r.balance > 0 ? `<button type="button" class="quick-action-btn secondary" data-pay-month="${r.period_month}" data-pay-balance="${r.balance}">تسجيل دفعة</button>` : ''}
      </div>`).join('')
    : emptyHtml('لا يوجد سجل بعد. أدخل ساعات الشهر أعلاه.');

  host.querySelectorAll('[data-pay-month]').forEach((b) => b.addEventListener('click', async () => {
    const amountStr = prompt('المبلغ المدفوع (الباقي: ' + b.dataset.payBalance + ')');
    if (!amountStr) return;
    const amount = Number(amountStr);
    if (!Number.isFinite(amount) || amount <= 0) { toast('مبلغ غير صالح.', 'error'); return; }
    const res2 = await recordTeacherPayment(currentTeacherId, b.dataset.payMonth, amount);
    if (!res2.ok) { toast(res2.error, 'error'); return; }
    toast('تم تسجيل الدفعة.', 'success');
    renderTeacherPayroll(currentTeacherId);
  }));
}

async function renderAssignSubjects() {
  const list = el('ta-subjects-list');
  list.innerHTML = loadingHtml();
  const [assignedRes, allRes] = await Promise.all([listTeacherSubjects(assignTeacherId), listSubjects()]);
  const assigned = assignedRes.ok ? assignedRes.data || [] : [];
  const all = allRes.ok ? allRes.data || [] : [];
  const assignedIds = new Set(assigned.map((s) => s.subject_id));

  list.innerHTML = assigned.length
    ? assigned.map((s) => `<div class="history-item"><strong>${esc(s.subject_name)}</strong>
        <button type="button" class="quick-action-btn secondary" data-ta-unsubject="${s.subject_id}">إزالة</button></div>`).join('')
    : emptyHtml('لا توجد مواد مسندة.');

  const sel = el('ta-subject-select');
  const remaining = all.filter((s) => !assignedIds.has(s.subject_id));
  sel.innerHTML = remaining.length
    ? remaining.map((s) => `<option value="${s.subject_id}">${esc(s.subject_name)}</option>`).join('')
    : '<option value="">كل المواد مسندة</option>';

  list.querySelectorAll('[data-ta-unsubject]').forEach((b) => b.addEventListener('click', async () => {
    b.disabled = true;
    const res = await removeTeacherSubject(assignTeacherId, b.dataset.taUnsubject);
    if (!res.ok) { toast(res.error, 'error'); b.disabled = false; return; }
    toast('تمت إزالة المادة.', 'success');
    renderAssignSubjects();
  }));
}

async function renderAssignClasses() {
  const list = el('ta-classes-list');
  list.innerHTML = loadingHtml();
  const [assignedRes, classesRes] = await Promise.all([listTeacherClasses(assignTeacherId), ensureClasses()]);
  const assigned = assignedRes.ok ? assignedRes.data || [] : [];
  const all = (classesRes || []).filter((c) => !c.is_disabled);
  const assignedIds = new Set(assigned.map((c) => c.class_id));

  list.innerHTML = assigned.length
    ? assigned.map((c) => `<div class="history-item"><strong>${esc(c.class_name)}${c.level ? ' — ' + esc(c.level) : ''}</strong>
        <span class="time">${esc(c.year_name || '')}</span>
        <button type="button" class="quick-action-btn secondary" data-ta-unclass="${c.class_id}">إزالة</button></div>`).join('')
    : emptyHtml('لا توجد أقسام مسندة.');

  const sel = el('ta-class-select');
  const remaining = all.filter((c) => !assignedIds.has(c.class_id));
  sel.innerHTML = remaining.length
    ? remaining.map((c) => `<option value="${c.class_id}">${esc(c.class_name)}${c.level ? ' — ' + esc(c.level) : ''}</option>`).join('')
    : '<option value="">كل الأقسام مسندة</option>';

  list.querySelectorAll('[data-ta-unclass]').forEach((b) => b.addEventListener('click', async () => {
    b.disabled = true;
    const res = await removeTeacherClass(assignTeacherId, b.dataset.taUnclass);
    if (!res.ok) { toast(res.error, 'error'); b.disabled = false; return; }
    toast('تمت إزالة القسم.', 'success');
    renderAssignClasses();
  }));
}

el('ta-subject-add').addEventListener('click', async () => {
  const subjectId = el('ta-subject-select').value;
  if (!subjectId || !assignTeacherId) return;
  const res = await assignTeacherSubject(assignTeacherId, subjectId);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم ربط المادة بالأستاذ.', 'success');
  renderAssignSubjects();
});
el('ta-class-add').addEventListener('click', async () => {
  const classId = el('ta-class-select').value;
  if (!classId || !assignTeacherId) return;
  const res = await assignTeacherClass(assignTeacherId, classId);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم ربط القسم بالأستاذ.', 'success');
  renderAssignClasses();
});
