const CACHE_NAME = 'smart-school-v2';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/director.html',
  '/guard.html',
  '/teacher.html',
  '/driver.html',
  '/parent.html',
  '/superadmin.html',
  '/assets/css/auth.css',
  '/assets/css/dashboard.css',
  '/modules/supabase.js',
  '/modules/auth.js',
  '/modules/device.js',
  '/modules/permissions.js',
  '/modules/students.js',
  '/modules/accounts.js',
  '/modules/admin.js',
  '/modules/admin-students.js',
  '/modules/admin-audit.js',
  '/modules/teacher.js',
  '/modules/driver.js',
  '/modules/parent.js',
  '/modules/superadmin.js',
  '/modules/transport-admin.js',
  '/modules/attendance-admin.js',
  '/modules/notifications.js',
  '/modules/qrScanner.js',
];

self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache) {
      return cache.addAll(STATIC_ASSETS);
    }).catch(function() {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', function(event) {
  event.waitUntil(
    caches.keys().then(function(keys) {
      return Promise.all(
        keys.filter(function(k) { return k !== CACHE_NAME; })
            .map(function(k) { return caches.delete(k); })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', function(event) {
  const req = event.request;
  if (req.method !== 'GET') return;
  if (req.url.includes('supabase.co') || 
      req.url.includes('googleapis') || 
      req.url.includes('cdn.jsdelivr.net') ||
      req.url.includes('/auth/') ||
      req.url.includes('/rest/')) {
    return;
  }
  
  if (req.destination === 'document' || req.url.endsWith('.html')) {
    event.respondWith(
      fetch(req).then(function(response) {
        if (response && response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(function(cache) { cache.put(req, clone); });
        }
        return response;
      }).catch(function() {
        return caches.match(req).then(function(cached) {
          return cached || caches.match('/index.html');
        });
      })
    );
    return;
  }
  
  event.respondWith(
    caches.match(req).then(function(cached) {
      const fetchPromise = fetch(req).then(function(response) {
        if (response && response.status === 200 && response.type === 'basic') {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(function(cache) { cache.put(req, clone); });
        }
        return response;
      }).catch(function() { return cached; });
      return cached || fetchPromise;
    })
  );
});
