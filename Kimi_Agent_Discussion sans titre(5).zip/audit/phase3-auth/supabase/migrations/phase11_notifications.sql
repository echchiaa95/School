-- phase11_notifications.sql
-- Additive only. Safe. No DROP. No TRUNCATE.

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id uuid REFERENCES schools(id) ON DELETE CASCADE,
  title text NOT NULL,
  body text NOT NULL,
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES profiles(id)
);

CREATE TABLE IF NOT EXISTS notification_deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  notification_id uuid REFERENCES notifications(id) ON DELETE CASCADE,
  profile_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  read_at timestamptz,
  created_at timestamptz DEFAULT now(),
  UNIQUE(notification_id, profile_id)
);

CREATE INDEX IF NOT EXISTS idx_notification_deliveries_profile_read 
  ON notification_deliveries(profile_id, read_at);
CREATE INDEX IF NOT EXISTS idx_notifications_school_created 
  ON notifications(school_id, created_at);
