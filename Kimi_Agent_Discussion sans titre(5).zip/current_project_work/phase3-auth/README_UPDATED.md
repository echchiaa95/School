# README — Phase 12.1 Production Hardening (v1.1)

## الجديد في هذه النسخة

### Migration جديدة واحدة فقط
`supabase/migrations/phase12_1_hardening.sql` — تنفَّذ **بعد** كل migrations السابقة (phase3_2 … phase12_complete_platform).

محتواها:
1. `fn_list_permissions_catalog()` — كتالوج الصلاحيات عبر RPC (بدل القراءة المباشرة من جدول permissions)، متاح لـ superadmin وطاقم المؤسسة فقط.
2. `fn_update_class(uuid, jsonb)` — نسخة patch جديدة: المفتاح الغائب = لا تغيير، والمفتاح الحاضر بقيمة null = إزالة (إزالة أستاذ القسم). النسخة القديمة scalar تبقى دون تغيير.
3. `fn_update_academic_year` — تعطيل السنة الحالية أصبح ممنوعًا (`YEAR_IS_CURRENT`)؛ يجب تعيين سنة أخرى كحالية أولًا.
4. `fn_save_attendance` — الأستاذ (بدون صلاحية attendance.manage وبدون كونه طاقم إدارة) لا يسجّل حضورًا إلا لقسم يدرّسه (`NOT_YOUR_CLASS`).
5. `fn_get_class_attendance` — نفس تقييد الأستاذ عند قراءة اللائحة.
6. `fn_add_grade` — الأستاذ مقيّد بأقسامه، والتحقق من أن القسم يتبع مؤسسة التلميذ نفسها.

### تعديلات الواجهة
- `modules/permissions.js` — إزالة كاملة للـ fallback الثابت: عند فشل `fn_my_permissions` لا يحصل أي دور (بما فيه الحارس) على أي صلاحية. الحارس = منح `user_permissions` الفعلية فقط.
- `modules/admin.js` — `listAllPermissions` تستخدم `fn_list_permissions_catalog`.
- `modules/superadmin.js` — حذف `listAllUsers` القديمة؛ الواجهة تستخدم `fn_list_all_users_v2` حصريًا.
- `modules/school.js` — `updateClass` يرسل patch بصيغة jsonb؛ رسائل خطأ جديدة (NOT_YOUR_CLASS, YEAR_IS_CURRENT, CLASS_EXISTS, INVALID_CAPACITY, INVALID_PATCH).
- `modules/directorConsole.js` — نافذة تعديل قسم كاملة (الاسم، المستوى، السعة، تغيير/إزالة الأستاذ، تعطيل/تفعيل) بدل prompt.

## التحقق الأمني (موجود مسبقًا وأُعيدت مراجعته)
- العزل بين المؤسسات: كل RPC يستخرج school_id من `auth.uid()` أو من سلسلة المورد (class→school، student→school، trip→driver).
- ولي الأمر: `fn_is_parent_of` في كل قراءات الأبناء (الحضور، النقاط، النقل، الأداءات) — تغيير UUID لا يكشف بيانات غير أبنائه.
- السائق: `fn_driver_context` + التحقق أن الرحلة رحلته قبل تسجيل أي حدث.
- الإشعارات: `fn_list_my_notifications` يقيد بالمؤسسة والدور والاستهداف الشخصي.
- Audit: `fn_get_school_audit` مقيد بمؤسسة الطاقم فقط؛ لا تُسجل كلمات مرور.
- منع تعطيل/إزالة آخر SuperAdmin في الخادم.

## النشر
1. نفّذ `phase12_1_hardening.sql` في SQL Editor.
2. أعد نشر Edge Functions إن لم تكن منشورة من v1: `create-platform-user`، `create-staff-account`.
3. ارفع ملفات الواجهة.
