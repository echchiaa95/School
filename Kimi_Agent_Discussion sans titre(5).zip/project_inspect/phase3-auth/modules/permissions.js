// ============================================================================
// modules/permissions.js
// Client-side role constants and page routing ONLY.
//
// IMPORTANT: this file decides which PAGE to show. It grants no real
// permission by itself — every actual permission check happens in
// PostgreSQL (RLS policies + RPC functions in phase2_schema.sql). Treat
// everything here as a convenience for the UI, never as a security boundary.
// A role read from the client is never trusted server-side; the server
// always re-derives it from auth.uid() via user_roles.
// ============================================================================

export const ROLES = Object.freeze({
  ADMIN: 'admin',
  GUARD: 'guard',
  DIRECTOR: 'director',
  TEACHER: 'teacher',
  DRIVER: 'driver',
  PARENT: 'parent',
});

// Where each role lands after login. Admin reuses the director/guard console
// for now (no dedicated admin.html yet) — adjust once that page exists.
const ROLE_HOME_PAGE = Object.freeze({
  [ROLES.ADMIN]: 'director.html',
  [ROLES.GUARD]: 'guard.html',
  [ROLES.DIRECTOR]: 'director.html',
  [ROLES.TEACHER]: 'teacher.html',
  [ROLES.DRIVER]: 'driver.html',
  [ROLES.PARENT]: 'parent.html',
});

// Which page(s) are allowed to render for a given role. Used by requireRole()
// as a UX guard (redirect away from the wrong page) — NOT a security control.
const PAGE_ALLOWED_ROLES = Object.freeze({
  'guard.html': [ROLES.GUARD, ROLES.ADMIN],
  'director.html': [ROLES.DIRECTOR, ROLES.ADMIN],
  'teacher.html': [ROLES.TEACHER],
  'driver.html': [ROLES.DRIVER],
  'parent.html': [ROLES.PARENT],
});

export function homePageForRole(role) {
  return ROLE_HOME_PAGE[role] || null;
}

export function isRoleAllowedOnPage(role, pageFileName) {
  const allowed = PAGE_ALLOWED_ROLES[pageFileName];
  if (!allowed) return false;
  return allowed.includes(role);
}

// ----------------------------------------------------------------------------
// PHASE 3.2 — deterministic primary-role selection.
// A user can hold more than one role in `user_roles` (e.g. admin + teacher).
// Picking roles[0] is undefined behavior (Postgres does not guarantee row
// order without ORDER BY). This fixed priority list makes the choice
// deterministic and predictable everywhere it's used (login redirect,
// requireAuth, page init).
// ----------------------------------------------------------------------------
export const ROLE_PRIORITY = Object.freeze([
  ROLES.ADMIN,
  ROLES.DIRECTOR,
  ROLES.GUARD,
  ROLES.TEACHER,
  ROLES.DRIVER,
  ROLES.PARENT,
]);

/**
 * @param {{school_id: string, role: string}[]} roleRows - rows from user_roles
 * @returns {{school_id: string, role: string}|null} the highest-priority role, or null if empty
 */
export function pickPrimaryRole(roleRows) {
  if (!roleRows || roleRows.length === 0) return null;
  for (const role of ROLE_PRIORITY) {
    const match = roleRows.find((r) => r.role === role);
    if (match) return match;
  }
  // role exists in DB but isn't in our known priority list — fall back to
  // the first row rather than silently dropping the user.
  return roleRows[0];
}

// ============================================================================
// PHASE 4.2 — REAL PERMISSION SYSTEM (replaces the Phase 4.1 shim).
//
// Permissions are now genuinely stored in the database (`permissions` +
// `guard_permissions` tables, see supabase/migrations/
// phase4_2_permissions_system.sql) and enforced server-side: fn_has_
// permission() backs new fn_guard_* wrapper RPCs used by modules/
// students.js, and RLS on guard_permissions prevents a guard from ever
// granting/revoking their own permissions. This module is now a CACHE of
// what the server already decided, fetched once via fn_get_my_permissions
// — not a parallel authorization system, and never the actual security
// boundary (that's still entirely RLS/RPC, unchanged in spirit from
// before).
//
// FAIL-CLOSED: until loadMyPermissions() resolves, hasPermission() returns
// false for everything — a slow network never accidentally shows a button
// it shouldn't.
// ============================================================================
import { supabase } from './supabase.js';

let cachedPermissions = null; // Set<string> | null (null = not loaded yet)

/**
 * Fetch the current user's real, server-computed permission set for a
 * school and cache it. Call once after login, before rendering any
 * permission-gated UI.
 * @returns {Promise<Set<string>>}
 */
export async function loadMyPermissions(schoolId) {
  const { data, error } = await supabase.rpc('fn_get_my_permissions', { p_school_id: schoolId });
  if (error) {
    console.error('loadMyPermissions error:', error);
    cachedPermissions = new Set(); // fail-closed on error too
    return cachedPermissions;
  }
  cachedPermissions = new Set((data || []).map((row) => row.permission_key));
  return cachedPermissions;
}

/**
 * Synchronous check against the cache populated by loadMyPermissions().
 * Returns false (not "assume yes") if permissions haven't been loaded yet.
 * @param {string} permissionKey e.g. 'students.create'
 */
export function hasPermission(permissionKey) {
  if (!cachedPermissions) return false;
  return cachedPermissions.has(permissionKey);
}

/** For tests/debugging only — forces a reload on next check if needed. */
export function clearPermissionsCache() {
  cachedPermissions = null;
}
