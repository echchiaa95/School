// ============================================================================
// modules/admin.js
// Guard management helpers for the admin dashboard.
// All reads use the RLS-scoped Supabase client; account creation uses the
// existing create-staff-account Edge Function.
// ============================================================================

import { supabase } from './supabase.js?v=23';

export async function listGuards(query) {
  try {
    const { data: guards, error } = await supabase
      .from('guards')
      .select('id, profile_id, school_id, profiles(full_name, phone, user_number, is_disabled)')
      .order('id');

    if (error) {
      console.error('listGuards error:', error);
      return [];
    }

    const rows = (guards ?? []).map((guard) => ({
      guardId: guard.id,
      profileId: guard.profile_id,
      schoolId: guard.school_id,
      fullName: guard.profiles?.full_name || '—',
      userNumber: guard.profiles?.user_number || '—',
      isDisabled: Boolean(guard.profiles?.is_disabled),
      permissionCount: 0,
    }));

    const needle = (query || '').trim().toLowerCase();
    if (!needle) return rows;
    return rows.filter((guard) =>
      guard.fullName.toLowerCase().includes(needle) ||
      guard.userNumber.toLowerCase().includes(needle)
    );
  } catch (error) {
    console.error('listGuards error:', error);
    return [];
  }
}

export async function listAllPermissions() {
  try {
    const { data, error } = await supabase.rpc('fn_list_permissions_catalog');

    if (error) {
      console.error('listAllPermissions error:', error);
      return [];
    }
    return data ?? [];
  } catch (error) {
    console.error('listAllPermissions error:', error);
    return [];
  }
}

/** Read the effective per-user permission grants for a user inside a school. */
export async function getGuardPermissions(profileId, schoolId) {
  try {
    const { data, error } = await supabase.rpc('fn_get_user_permissions', {
      p_profile_id: profileId,
      p_school_id: schoolId,
    });
    if (error) {
      console.error('getGuardPermissions error:', error);
      return new Set();
    }
    return new Set((data ?? []).map((row) => row.permission_key ?? row));
  } catch (error) {
    console.error('getGuardPermissions error:', error);
    return new Set();
  }
}

export async function createGuardAccount({ fullName, email, password, phone }) {
  try {
    const { data, error } = await supabase.functions.invoke('create-staff-account', {
      body: { accountType: 'guard', fullName, email, password, phone },
    });

    if (error) {
      let message = 'تعذر إنشاء الحساب';
      try {
        const bodyText = await error.context?.text?.();
        const parsed = bodyText ? JSON.parse(bodyText) : null;
        if (parsed?.error) message = parsed.error;
      } catch {
        // Keep the generic message if the response body is unavailable.
      }
      return { ok: false, error: message };
    }

    if (!data?.ok) {
      return { ok: false, error: data?.error || 'تعذر إنشاء الحساب' };
    }
    return { ok: true, profileId: data.profileId, email: data.email };
  } catch (error) {
    console.error('createGuardAccount error:', error);
    return { ok: false, error: 'تعذر إنشاء الحساب' };
  }
}

export async function setGuardStatus(profileId, isDisabled) {
  try {
    const { error } = await supabase.rpc('fn_set_guard_status', {
      p_profile_id: profileId,
      p_is_disabled: isDisabled,
    });
    if (error) return { ok: false, error: error.message };
    return { ok: true };
  } catch (error) {
    console.error('setGuardStatus error:', error);
    return { ok: false, error: error.message || 'تعذّرت العملية' };
  }
}

/** Grant one permission key to a user inside a school (server-verified). */
export async function grantPermission(profileId, schoolId, permissionKey) {
  const { error } = await supabase.rpc('fn_grant_user_permission', {
    p_profile_id: profileId,
    p_school_id: schoolId,
    p_permission_key: permissionKey,
  });
  if (error) {
    console.error('grantPermission error:', error);
    return { ok: false, error: error.message };
  }
  return { ok: true };
}

/** Revoke one permission key from a user inside a school. */
export async function revokePermission(profileId, schoolId, permissionKey) {
  const { error } = await supabase.rpc('fn_revoke_user_permission', {
    p_profile_id: profileId,
    p_school_id: schoolId,
    p_permission_key: permissionKey,
  });
  if (error) {
    console.error('revokePermission error:', error);
    return { ok: false, error: error.message };
  }
  return { ok: true };
}
