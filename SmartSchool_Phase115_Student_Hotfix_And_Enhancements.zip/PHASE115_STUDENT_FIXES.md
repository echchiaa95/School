# Phase 115 — Student module hotfix

- Replaced the discount form's lexical selection variable with `window.__pickedDiscountStudentId`; selection is cleared whenever the search text changes, preventing stale IDs and eliminating the reported ReferenceError when the current assets are deployed.
- Bumped the admin console module URL from `v=95.1` to `v=115.0` so browsers request the corrected module rather than reuse the old script URL.
- Added a browser `Image`/canvas fallback when `createImageBitmap` cannot decode a phone gallery image.
- Improved photo upload diagnostics for missing bucket, Storage RLS, size, decode, and RPC failures.
- Added an idempotent Storage policy migration for the `student-photos` bucket.
- Fixed age display for infants under one year (age 0 is no longer treated as missing).

## Deployment
1. Upload/replace the complete project contents, not only the ZIP file.
2. Run `supabase/migrations/phase115_student_photo_storage_policies.sql` in Supabase SQL Editor.
3. Open `admin.html` with a hard refresh; the module URL now uses `v=115.0`.
4. Test with an ordinary JPG/PNG photo and confirm a student discount selection.

## Validation
JavaScript syntax checks and ZIP integrity checks are performed for this package. A live Supabase upload cannot be verified without access to the project's authenticated database and Storage.
