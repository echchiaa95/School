# V56 — Manager grades report selectors fix

- Fixed manager grades report section dropdown.
- Replaced direct `classes` and `student_enrollments` reads with secure RPCs.
- Selecting a section now loads its active students for individual report selection.
- Added clear loading and error states.
