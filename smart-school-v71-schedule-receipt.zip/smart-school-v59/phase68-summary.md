# Phase 68 — إصلاحات بصرية + إشعارات Push حقيقية

## 1) إصلاح تخطيط بطاقة الإشعارات (خلل بصري حقيقي، من الصور المُرسَلة)

**السبب الجذري**: بطاقات الإشعار في الملفات الثلاثة (admin/parent/teacher)
كانت تُعاد استعمال أصناف CSS جاهزة (`.history-item` في admin، `.detail-row`
في parent/teacher) — كلاهما `display:flex; justify-content:space-between؛`،
مصمَّمتان لصف بسيط (تسمية + قيمة واحدة)، وليس لمحتوى متعدد الأسطر (عنوان +
نص + صورة). هذا كان يُسبب انضغاط كل العناصر أفقيًا بدل التكديس رأسيًا —
بالضبط ما ظهر في الصورة (تراكب النص مع "🗑 حذف" ودوائر غريبة).

**الإصلاح**: صنف `.notif-card` جديد ومستقل تمامًا في `theme.css`
(`flex-direction:column`) — لا علاقة له بـ `.history-item`/`.detail-row`.
طُبِّق على الملفات الثلاثة، مع **ترجمة نوع الإشعار للعربية** في
`parentConsole.js`/`teacherConsole.js` (كانت تعرض `transport`/`announcement`
كما هي بالإنجليزية — `adminConsole.js` وحدها كانت مُترجَمة، الآن الثلاثة متّسقة).

## 2) إصلاح زر "الوصل" في جدول الأداءات
كان بأنماط يدوية مضغوطة (`font-size:.78em`) غير متجاوبة. أصبح صنف
`.receipt-btn` موحَّد (ارتفاع لمس مريح ≥34px، عرض كامل داخل الخلية، متجاوب).

## 3) إشعارات Push حقيقية (تصل حتى والتطبيق مغلق) — الإضافة الكبرى

### كيف تعمل
```
حدث (بدء رحلة/طلب موعد) → fn_send_notification → صف جديد في
notification_deliveries → trigger SQL → استدعاء Edge Function (pg_net) →
Edge Function تُرسل Push فعلي عبر مكتبة web-push → Service Worker في متصفح
ولي الأمر يعرض الإشعار حتى لو التطبيق/المتصفح مغلق تمامًا.
```

### الملفات الجديدة
- `supabase/migrations/phase68_web_push.sql`: جدول `push_subscriptions` +
  RPC (حفظ/حذف/فحص اشتراك) + trigger يستدعي Edge Function تلقائيًا عند كل
  إشعار جديد (محمي بـ exception — لا يُفشل الإشعار نفسه أبدًا إن تعطّل Push).
- `supabase/functions/send-web-push/index.ts`: Edge Function (Deno) تستعمل
  مكتبة `web-push` الموثوقة (عبر `npm:` specifier) بدل تطبيق تشفير Web Push
  يدويًا (معقّد وخطير الأخطاء). تحذف تلقائيًا أي اشتراك لم يعد صالحًا (404/410).
- `sw.js` (جذر المشروع): Service Worker خفيف، يعرض الإشعار فقط عند وصول Push.
- `modules/pushNotifications.js`: `enablePushNotifications()` /
  `disablePushNotifications()` / `isPushEnabled()` — جاهزة للاستعمال في أي صفحة.
- `parent.html` + `parentConsole.js`: زر "🔔 تفعيل إشعارات الهاتف" في قسم
  الإشعارات (أول طلب مباشر — يمكن إضافة نفس الزر بـ3 أسطر لأي صفحة أخرى
  لاحقًا: admin/teacher/driver/guard، بنفس الوحدة `pushNotifications.js`).

### 🔑 مفاتيح VAPID (ولّدتها محليًا الآن، صالحة وجاهزة للاستعمال مباشرة)
```
VAPID_PUBLIC_KEY  = BNhRbMDDP48zJrfEFrlS8zjsvQ_xGsik4GS5S49QDXXr2a9O5Y6Wr8x7HHxKoFXqfU3cB2hULjjL-1w-pMcJz54
VAPID_PRIVATE_KEY = VnI4ZL2pr1qRJzOSct45Rr_5UeZuhjYrCM4W2m3Usaw
```
- **PUBLIC**: موجود بالفعل في `modules/pushNotifications.js` (آمن في كود العميل).
- **PRIVATE**: **لا تضعه أبدًا في أي ملف يُرفع لـ GitHub** — فقط كـ secret في Supabase (الخطوة 2 أدناه).

### خطوات التفعيل (بالترتيب، إلزامية بالكامل)
1. نفّذ `phase68_web_push.sql` في SQL Editor.
2. انشر الـ Edge Function:
   ```bash
   supabase functions deploy send-web-push
   supabase secrets set VAPID_PUBLIC_KEY="BNhRbMDDP48zJrfEFrlS8zjsvQ_xGsik4GS5S49QDXXr2a9O5Y6Wr8x7HHxKoFXqfU3cB2hULjjL-1w-pMcJz54"
   supabase secrets set VAPID_PRIVATE_KEY="VnI4ZL2pr1qRJzOSct45Rr_5UeZuhjYrCM4W2m3Usaw"
   supabase secrets set VAPID_CONTACT_EMAIL="mailto:you@elbordiji.com"
   ```
3. في SQL Editor، نفّذ (استبدل بقيمك الحقيقية من Project Settings → API):
   ```sql
   alter database postgres set app.settings.service_role_key = 'YOUR_SERVICE_ROLE_KEY';
   alter database postgres set app.settings.push_edge_url = 'https://YOUR_PROJECT_REF.functions.supabase.co/send-web-push';
   ```
4. ارفع `sw.js` (يجب أن يبقى في **جذر** المشروع)، `modules/pushNotifications.js`، والتعديلات على `parent.html`/`parentConsole.js`.
5. جرّب: افتح `parent.html`، فعّل الإشعارات، أغلق المتصفح تمامًا، اطلب من سائق بدء رحلة (Phase 61) — يجب أن يصل إشعار حقيقي على الهاتف رغم إغلاق التطبيق.

## قيود معروفة
- **iOS Safari**: يدعم Web Push فقط إذا كان الموقع **مُثبَّتًا كـ PWA** (Add to Home Screen) — من متصفح عادي بدون تثبيت، لن يعمل على آيفون (قيد نظام iOS نفسه، ليس خطأً في الكود). يعمل بشكل طبيعي على Android/Chrome/Firefox دون أي تثبيت.
- لا توجد أيقونة مخصَّصة للإشعار بعد (`icon`) — يعرض المتصفح أيقونة افتراضية. أضف صورة لاحقًا إن رغبت.
- الزر مُفعَّل حاليًا في `parent.html` فقط (الطلب الصريح) — إضافته لبقية الصفحات بسيطة جدًا (نفس 3 استيرادات + زر واحد).
