# V58 — Manager grades report selector fix

- Reworked the manager grades-report class selector.
- Added direct `classes` query fallback when the class RPC returns no rows.
- Added direct `student_enrollments` + `students` fallback when the roster RPC returns no rows.
- Added visible loading and permission/empty-state messages.
- Updated cache-busting query strings.
