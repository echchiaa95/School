// ============================================================================
// sw.js — Service Worker خفيف مخصَّص لعرض إشعارات Push فقط (Phase 68).
// يجب أن يبقى في جذر المشروع (نفس مستوى admin.html) — نطاق Service Worker
// الافتراضي هو مجلد الملف نفسه، وكل صفحات المنصة على نفس المستوى.
// ============================================================================

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('push', (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch {
    data = { title: 'إشعار جديد', body: event.data ? event.data.text() : '' };
  }

  const title = data.title || 'إشعار جديد — Smart School';
  const options = {
    body: data.body || '',
    icon: data.icon || undefined,
    dir: 'rtl',
    lang: 'ar',
    tag: 'smart-school-notification',
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) return client.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow('./');
      return undefined;
    }),
  );
});
