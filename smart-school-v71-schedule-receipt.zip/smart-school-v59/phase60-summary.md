# Phase 60 — إشعارات محسّنة (صور + حذف شخصي)

## ما تم إضافته

### SQL (`phase60_notifications_images_delete.sql`)
- عمود `image_url` على `notifications` (إضافي).
- عمود `deleted_at` على `notification_deliveries` (إضافي) — حذف **شخصي**: يُخفي الإشعار عند صاحب الطلب فقط.
- Bucket تخزين جديد `notification-images` (public-read، staff-write بنفس نمط `student-photos`/`school-logos`).
- `fn_send_notification`: تمت إعادة إنشائها (DROP+CREATE ضروري لتغيير التوقيع — نفس أسلوب Phase 3.4 السابق) لإضافة `p_image_url`.
- `fn_list_my_notifications`: أعيد إنشاؤها لإضافة `image_url` في المخرجات، واستبعاد الإشعارات المحذوفة شخصيًا.
- `fn_delete_my_notification(id)`: جديدة — تضع `deleted_at` على سطر التسليم الخاص بالمستخدم الحالي فقط.
- `fn_unread_notifications_count`: محدَّثة لتستبعد المحذوف شخصيًا من العدّاد.

### JS
- `modules/school.js`: `sendNotification` أصبحت تقبل `imageUrl`، + `deleteMyNotification`، + `uploadNotificationImage(schoolId, file)` — **تضغط الصورة تلقائيًا** (canvas، أقصى عرض 1280px، جودة 72%) قبل الرفع.
- `modules/adminConsole.js`: حقل رفع صورة في نموذج الإرسال (`admin.html`)، وعرض الصورة داخل كل إشعار، + **حذف بالسحب لليسار** (swipe) على كل بطاقة إشعار.
- `modules/parentConsole.js` و`modules/teacherConsole.js`: نفس ميزتي الصورة والسحب للحذف، **+ إصلاح خطأ موجود مسبقًا**: كانا يستعملان `n.id` (عمود غير موجود في مخرجات RPC) بدل `n.notification_id`، فكان "تعليم كمقروء" لا يُخزَّن فعليًا في القاعدة رغم تغيّر المظهر بصريًا.

## خطوات التفعيل
1. نفّذ `phase60_notifications_images_delete.sql` في Supabase SQL Editor.
2. لا حاجة لتعديل `admin.html` غير ما أُضيف تلقائيًا (حقل الصورة) — بقية الواجهات (parent.html/teacher.html) تعمل بدون أي تعديل HTML لأن `notif-list` موجود مسبقًا.
3. جرّب: أرسل إشعارًا بصورة من لوحة المدير، تحقق من ظهورها عند ولي الأمر، ثم جرّب السحب لليسار للحذف.

## قيد معروف
- السحب للحذف مبني بلمسات اللمس (`touchstart/touchmove/touchend`) فقط — يعمل على الهاتف (وهو الاستخدام الأساسي)، لا يعمل بالماوس على الحاسوب (يمكن إضافة زر 🗑 احتياطي للحاسوب لاحقًا إذا لزم).

## المرحلة التالية المقترحة
Phase 3: إشعار تلقائي عند انطلاق الحافلة (يُبنى على نظام الإشعارات هذا مباشرة).
