# V57 — Manager grades report selector fix

- Fixed manager grades report class dropdown by using the existing `fn_list_my_classes` RPC.
- Fixed student dropdown by using the existing `fn_get_class_attendance` roster RPC.
- Kept Phase 56 RPCs as fallbacks for compatibility.
- No additional SQL migration is required for this selector fix.
