-- Phase 48: teacher assessment period normalization
-- The UI uses canonical values expected by grade_assessments_period_check.

drop function if exists public.fn_create_grade_assessment(uuid, uuid, uuid, uuid, text, text, text, numeric, numeric, date);

create or replace function public.fn_create_grade_assessment(
  p_school_id uuid,
  p_class_id uuid,
  p_subject_id uuid,
  p_academic_year_id uuid,
  p_period text,
  p_title text,
  p_assessment_type text,
  p_coefficient numeric,
  p_max_score numeric,
  p_assessment_date date default null
)
returns public.grade_assessments
language plpgsql
security definer
set search_path = public
as $$
declare
  v_assessment public.grade_assessments;
  v_period text;
begin
  v_period := case
    when p_period in ('1', 'SEMESTER_1', 'الأسدوس الأول') then 'SEMESTER_1'
    when p_period in ('2', 'SEMESTER_2', 'الأسدوس الثاني') then 'SEMESTER_2'
    when p_period in ('ANNUAL', 'النتيجة السنوية') then 'ANNUAL'
    else p_period
  end;

  if p_coefficient <= 0 then raise exception 'معامل التقييم يجب أن يكون أكبر من صفر'; end if;
  if p_max_score <= 0 then raise exception 'النقطة القصوى يجب أن تكون أكبر من صفر'; end if;
  if trim(coalesce(p_title, '')) = '' then raise exception 'عنوان التقييم مطلوب'; end if;

  insert into public.grade_assessments(
    school_id, class_id, subject_id, academic_year_id, period, title,
    assessment_type, coefficient, max_score, assessment_date, created_by
  ) values (
    p_school_id, p_class_id, p_subject_id, p_academic_year_id, v_period,
    trim(p_title), p_assessment_type, p_coefficient, p_max_score,
    p_assessment_date, auth.uid()
  ) returning * into v_assessment;

  return v_assessment;
end;
$$;

grant execute on function public.fn_create_grade_assessment(uuid, uuid, uuid, uuid, text, text, text, numeric, numeric, date) to authenticated;
