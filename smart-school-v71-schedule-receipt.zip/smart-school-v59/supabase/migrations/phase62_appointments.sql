-- ============================================================================
-- phase62_appointments.md.sql — نظام طلب المواعيد (ولي الأمر ← مدير/حارس عام)
-- إضافي 100%: جدولان جديدان + RPC فقط، بدون لمس أي شيء موجود.
-- ============================================================================

-- 1) إعدادات التوفر لكل مدرسة (أيام العمل + السعة اليومية)
create table if not exists public.appointment_settings (
  school_id uuid primary key references public.schools(id),
  working_weekdays smallint[] not null default '{2,3,4,5,6}', -- 1=أحد..7=سبت (نفس اصطلاح الجدول الزمني)
  max_per_day integer not null default 4 check (max_per_day > 0),
  min_days_ahead integer not null default 1 check (min_days_ahead >= 0),
  max_days_ahead integer not null default 30 check (max_days_ahead > 0),
  updated_at timestamptz not null default now()
);

-- 2) طلبات المواعيد
create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id),
  requested_by uuid not null references public.profiles(id),
  target_role text not null check (target_role in ('admin', 'guard')),
  appointment_date date not null,
  reason text,
  status text not null default 'PENDING' check (status in ('PENDING', 'APPROVED', 'REJECTED', 'CANCELLED')),
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  review_note text,
  created_at timestamptz not null default now()
);

create index if not exists idx_appointments_school_date
  on public.appointments(school_id, appointment_date)
  where status in ('PENDING', 'APPROVED');

create index if not exists idx_appointments_requester
  on public.appointments(requested_by, appointment_date);

alter table public.appointment_settings enable row level security;
alter table public.appointments enable row level security;
-- RLS مفعّل بدون أي policy — كل الوصول عبر RPC فقط (نفس نمط المشروع)

-- 3) إعدادات مدرسة (تُنشأ تلقائيًا بالقيم الافتراضية عند أول استعمال)
create or replace function public.fn_get_appointment_settings()
returns public.appointment_settings
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_row public.appointment_settings;
begin
  v_school_id := fn_my_primary_school();
  if v_school_id is null then
    raise exception 'NO_SCHOOL_CONTEXT';
  end if;

  select * into v_row from appointment_settings where school_id = v_school_id;
  if v_row.school_id is null then
    insert into appointment_settings (school_id) values (v_school_id)
    returning * into v_row;
  end if;
  return v_row;
end;
$$;

grant execute on function public.fn_get_appointment_settings() to authenticated;

-- 4) تحديث الإعدادات (مدير فقط)
create or replace function public.fn_update_appointment_settings(
  p_working_weekdays smallint[],
  p_max_per_day integer,
  p_min_days_ahead integer,
  p_max_days_ahead integer
)
returns public.appointment_settings
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_row public.appointment_settings;
begin
  v_school_id := fn_my_primary_school();
  if v_school_id is null then
    raise exception 'NO_SCHOOL_CONTEXT';
  end if;
  if not fn_is_school_staff(v_school_id) then
    raise exception 'PERMISSION_DENIED';
  end if;

  insert into appointment_settings (school_id, working_weekdays, max_per_day, min_days_ahead, max_days_ahead, updated_at)
  values (v_school_id, p_working_weekdays, p_max_per_day, p_min_days_ahead, p_max_days_ahead, now())
  on conflict (school_id) do update
    set working_weekdays = excluded.working_weekdays,
        max_per_day = excluded.max_per_day,
        min_days_ahead = excluded.min_days_ahead,
        max_days_ahead = excluded.max_days_ahead,
        updated_at = now()
  returning * into v_row;

  return v_row;
end;
$$;

grant execute on function public.fn_update_appointment_settings(smallint[], integer, integer, integer) to authenticated;

-- 5) توفر الشهر (لعرض التقويم) — لكل يوم: عامل/عطلة، عدد المحجوز، السعة، ممتلئ أم لا
create or replace function public.fn_get_appointment_availability(
  p_month_start date,
  p_target_role text default null
)
returns table (
  day date,
  is_working boolean,
  is_past boolean,
  booked_count bigint,
  capacity integer,
  is_full boolean
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_settings public.appointment_settings;
  v_month_end date;
begin
  v_school_id := fn_my_primary_school();
  if v_school_id is null then
    raise exception 'NO_SCHOOL_CONTEXT';
  end if;

  v_settings := public.fn_get_appointment_settings();
  v_month_end := (date_trunc('month', p_month_start) + interval '1 month - 1 day')::date;

  return query
  select
    d::date,
    (extract(dow from d)::int + 1) = any(v_settings.working_weekdays),
    d::date < current_date,
    coalesce(cnt.c, 0),
    v_settings.max_per_day,
    coalesce(cnt.c, 0) >= v_settings.max_per_day
  from generate_series(date_trunc('month', p_month_start)::date, v_month_end, interval '1 day') as d
  left join (
    select a.appointment_date, count(*) as c
    from appointments a
    where a.school_id = v_school_id
      and a.status in ('PENDING', 'APPROVED')
      and (p_target_role is null or a.target_role = p_target_role)
    group by a.appointment_date
  ) cnt on cnt.appointment_date = d::date
  order by 1;
end;
$$;

grant execute on function public.fn_get_appointment_availability(date, text) to authenticated;

-- 6) طلب موعد جديد (ولي الأمر)
create or replace function public.fn_request_appointment(
  p_target_role text,
  p_appointment_date date,
  p_reason text default null
)
returns public.appointments
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_settings public.appointment_settings;
  v_booked bigint;
  v_row public.appointments;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  v_school_id := fn_my_primary_school();
  if v_school_id is null then
    raise exception 'NO_SCHOOL_CONTEXT';
  end if;
  if p_target_role not in ('admin', 'guard') then
    raise exception 'INVALID_TARGET';
  end if;

  v_settings := public.fn_get_appointment_settings();

  if p_appointment_date < current_date + v_settings.min_days_ahead then
    raise exception 'DATE_TOO_SOON';
  end if;
  if p_appointment_date > current_date + v_settings.max_days_ahead then
    raise exception 'DATE_TOO_FAR';
  end if;
  if not ((extract(dow from p_appointment_date)::int + 1) = any(v_settings.working_weekdays)) then
    raise exception 'NOT_A_WORKING_DAY';
  end if;

  select count(*) into v_booked
  from appointments
  where school_id = v_school_id
    and appointment_date = p_appointment_date
    and target_role = p_target_role
    and status in ('PENDING', 'APPROVED');

  if v_booked >= v_settings.max_per_day then
    raise exception 'DAY_FULL';
  end if;

  insert into appointments (school_id, requested_by, target_role, appointment_date, reason)
  values (v_school_id, auth.uid(), p_target_role, p_appointment_date, nullif(trim(coalesce(p_reason, '')), ''))
  returning * into v_row;

  perform fn_safe_audit(v_school_id, 'APPOINTMENT_REQUESTED', 'appointments', v_row.id,
    null, jsonb_build_object('target_role', p_target_role, 'date', p_appointment_date));

  return v_row;
end;
$$;

grant execute on function public.fn_request_appointment(text, date, text) to authenticated;

-- 7) مواعيدي (ولي الأمر)
create or replace function public.fn_list_my_appointments()
returns table (
  id uuid, target_role text, appointment_date date, reason text,
  status text, review_note text, created_at timestamptz
)
language sql
security definer
set search_path = public
as $$
  select a.id, a.target_role, a.appointment_date, a.reason, a.status, a.review_note, a.created_at
  from appointments a
  where a.requested_by = auth.uid()
  order by a.appointment_date desc, a.created_at desc;
$$;

grant execute on function public.fn_list_my_appointments() to authenticated;

-- 8) إلغاء موعد من طرف ولي الأمر نفسه
create or replace function public.fn_cancel_my_appointment(p_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update appointments
  set status = 'CANCELLED'
  where id = p_id and requested_by = auth.uid() and status in ('PENDING', 'APPROVED');
  if not found then
    raise exception 'APPOINTMENT_NOT_FOUND';
  end if;
end;
$$;

grant execute on function public.fn_cancel_my_appointment(uuid) to authenticated;

-- 9) قائمة الطلبات لإدارة المدير/الحارس (المدير: كل الطلبات، الحارس: يحتاج صلاحية appointments.manage)
create or replace function public.fn_list_school_appointments(
  p_status text default null,
  p_target_role text default null
)
returns table (
  id uuid, requester_name text, requester_phone text, target_role text,
  appointment_date date, reason text, status text, created_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
begin
  v_school_id := fn_my_primary_school();
  if v_school_id is null then
    raise exception 'NO_SCHOOL_CONTEXT';
  end if;
  if not fn_is_school_staff(v_school_id) then
    if not fn_has_permission('appointments.manage', v_school_id) then
      raise exception 'PERMISSION_DENIED';
    end if;
    p_target_role := 'guard';
  end if;

  return query
  select a.id, p.full_name, p.phone, a.target_role, a.appointment_date, a.reason, a.status, a.created_at
  from appointments a
  join profiles p on p.id = a.requested_by
  where a.school_id = v_school_id
    and (p_status is null or a.status = p_status)
    and (p_target_role is null or a.target_role = p_target_role)
  order by a.appointment_date, a.created_at;
end;
$$;

grant execute on function public.fn_list_school_appointments(text, text) to authenticated;

-- 10) قبول/رفض طلب موعد
create or replace function public.fn_review_appointment(
  p_id uuid,
  p_status text,
  p_note text default null
)
returns public.appointments
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_row public.appointments;
begin
  if p_status not in ('APPROVED', 'REJECTED') then
    raise exception 'INVALID_STATUS';
  end if;

  select school_id into v_school_id from appointments where id = p_id;
  if v_school_id is null then
    raise exception 'APPOINTMENT_NOT_FOUND';
  end if;

  if not (fn_is_school_staff(v_school_id) or fn_has_permission('appointments.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;

  update appointments
  set status = p_status, reviewed_by = auth.uid(), reviewed_at = now(), review_note = nullif(trim(coalesce(p_note, '')), '')
  where id = p_id
  returning * into v_row;

  perform fn_safe_audit(v_school_id, 'APPOINTMENT_REVIEWED', 'appointments', p_id,
    null, jsonb_build_object('status', p_status));

  return v_row;
end;
$$;

grant execute on function public.fn_review_appointment(uuid, text, text) to authenticated;

-- 11) إضافة الصلاحية الجديدة لكتالوج الصلاحيات — تظهر تلقائيًا في مصفوفة
--     صلاحيات الحارس بلوحة المدير (admin.html) بدون أي تعديل UI إضافي.
insert into permissions (permission_key, module, name, description)
values ('appointments.manage', 'المواعيد', 'إدارة طلبات المواعيد', 'قبول/رفض طلبات المواعيد الموجهة للحراسة العامة')
on conflict (permission_key) do nothing;
