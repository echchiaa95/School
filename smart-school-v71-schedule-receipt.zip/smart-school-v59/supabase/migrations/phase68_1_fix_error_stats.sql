-- ============================================================================
-- phase68_1_fix_error_stats.sql
-- إصلاح: fn_client_error_stats كانت تُرجع خطأ "تعذر تحميل الإحصائيات" في
-- الواجهة. أعدت كتابتها بمنطق أبسط (select...into بدل CTE + subqueries
-- متعددة) لإزالة أي التباس محتمل في الأنواع، وأضفت amcast صريح للتواريخ.
-- CREATE OR REPLACE بنفس التوقيع تمامًا — آمن، لا يكسر شيئًا.
-- ============================================================================

create or replace function public.fn_client_error_stats()
returns table (
  errors_today bigint,
  errors_this_week bigint,
  errors_total bigint,
  top_page text,
  top_page_count bigint
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_today bigint := 0;
  v_week bigint := 0;
  v_total bigint := 0;
  v_top_page text := null;
  v_top_count bigint := 0;
begin
  if not fn_is_superadmin() then
    raise exception 'PERMISSION_DENIED';
  end if;

  select count(*) into v_total from client_error_logs;
  select count(*) into v_today from client_error_logs where created_at >= date_trunc('day', now());
  select count(*) into v_week from client_error_logs where created_at >= (now() - interval '7 days');

  select l.page, count(*) into v_top_page, v_top_count
  from client_error_logs l
  where l.created_at >= (now() - interval '7 days')
  group by l.page
  order by count(*) desc
  limit 1;

  return query select v_today, v_week, v_total, v_top_page, coalesce(v_top_count, 0);
end;
$$;

grant execute on function public.fn_client_error_stats() to authenticated;
