-- Phase 58: detailed student subject results for report card
create or replace function public.fn_student_subject_final_results(
  p_class_id uuid,
  p_student_id uuid,
  p_period text
)
returns table(
  student_id uuid,
  student_name text,
  subject_id uuid,
  subject_name text,
  coefficient numeric,
  final_score numeric,
  teacher_note text
)
language sql
stable
security definer
set search_path = public
as $$
with periods as (
  select case
    when p_period = 'annual' then array['SEMESTER_1','SEMESTER_2']::text[]
    else array[p_period]::text[]
  end as values
), subject_period_scores as (
  select
    st.id as student_id,
    st.full_name as student_name,
    sub.id as subject_id,
    sub.name as subject_name,
    coalesce(gsc.coefficient, 1)::numeric as coefficient,
    ga.period,
    sum((gm.score / nullif(ga.max_score,0)) *
        case when c.level ilike '%ابتدائي%' or c.level ilike '%primary%' then 10 else 20 end *
        ga.coefficient) / nullif(sum(ga.coefficient),0) as score,
    max(gm.teacher_note) as teacher_note
  from public.students st
  join public.student_enrollments se on se.student_id = st.id and se.class_id = p_class_id
  join public.classes c on c.id = se.class_id
  join public.grade_assessments ga on ga.class_id = p_class_id
  join public.grade_marks gm on gm.assessment_id = ga.id and gm.student_id = st.id
  join public.subjects sub on sub.id = ga.subject_id
  left join public.grade_subject_coefficients gsc
    on gsc.class_id = p_class_id and gsc.subject_id = ga.subject_id
  where st.id = p_student_id
    and st.deleted_at is null
    and ga.period = any((select values from periods))
  group by st.id, st.full_name, sub.id, sub.name, gsc.coefficient, ga.period
), final_scores as (
  select
    student_id, student_name, subject_id, subject_name, coefficient,
    case when p_period = 'annual'
      then round(avg(score)::numeric, 2)
      else round(max(score)::numeric, 2)
    end as final_score,
    string_agg(distinct teacher_note, ' / ') filter (where teacher_note is not null and teacher_note <> '') as teacher_note
  from subject_period_scores
  group by student_id, student_name, subject_id, subject_name, coefficient
)
select * from final_scores order by subject_name;
$$;

grant execute on function public.fn_student_subject_final_results(uuid,uuid,text) to authenticated;
