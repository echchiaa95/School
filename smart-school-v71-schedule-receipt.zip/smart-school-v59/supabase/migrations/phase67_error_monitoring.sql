-- ============================================================================
-- phase67_error_monitoring.sql
-- مراقبة أخطاء العميل (Client-side JS) بدل الاعتماد فقط على تقارير المستخدمين.
-- إضافي 100%. جدول خاص + RPC — بدون لمس أي شيء موجود.
-- ============================================================================

-- 1) جدول سجلات الأخطاء
create table if not exists public.client_error_logs (
  id uuid primary key default gen_random_uuid(),
  school_id uuid references public.schools(id),
  profile_id uuid references public.profiles(id),
  role text,
  page text not null,
  level text not null default 'error' check (level in ('error', 'warning')),
  message text not null,
  stack text,
  user_agent text,
  page_url text,
  created_at timestamptz not null default now()
);

create index if not exists idx_client_error_logs_created on public.client_error_logs(created_at desc);
create index if not exists idx_client_error_logs_school on public.client_error_logs(school_id, created_at desc);
create index if not exists idx_client_error_logs_page on public.client_error_logs(page, created_at desc);

-- RLS مفعّل بدون أي policy — كل الوصول عبر RPC فقط (نفس نمط المشروع)
alter table public.client_error_logs enable row level security;

-- 2) تسجيل خطأ (يُستدعى من كل صفحة، حتى قبل تسجيل الدخول — لذا anon مسموح)
--    لا يرفع استثناء أبدًا: تسجيل الخطأ نفسه يجب ألا يُسبب خطأً آخر.
create or replace function public.fn_log_client_error(
  p_page text,
  p_message text,
  p_stack text default null,
  p_level text default 'error',
  p_user_agent text default null,
  p_page_url text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_role text;
begin
  if auth.uid() is not null then
    select ur.school_id, ur.role::text into v_school_id, v_role
    from user_roles ur where ur.profile_id = auth.uid() limit 1;
  end if;

  insert into client_error_logs (school_id, profile_id, role, page, level, message, stack, user_agent, page_url)
  values (
    v_school_id, auth.uid(), v_role,
    left(coalesce(nullif(trim(p_page), ''), 'unknown'), 60),
    case when p_level = 'warning' then 'warning' else 'error' end,
    left(coalesce(nullif(trim(p_message), ''), 'UNKNOWN_ERROR'), 2000),
    left(p_stack, 4000),
    left(p_user_agent, 300),
    left(p_page_url, 500)
  );
exception when others then
  null; -- أبدًا لا نُفشل الصفحة بسبب فشل تسجيل خطأ
end;
$$;

-- anon مسموح لها أيضًا لأن أخطاء قد تحدث قبل تسجيل الدخول (صفحة index/auth)
grant execute on function public.fn_log_client_error(text, text, text, text, text, text) to authenticated, anon;

-- 3) ملخص سريع للوحة القيادة (SuperAdmin فقط)
create or replace function public.fn_client_error_stats()
returns table (
  errors_today bigint,
  errors_this_week bigint,
  errors_total bigint,
  top_page text,
  top_page_count bigint
)
language plpgsql
security definer
set search_path = public
as $$
begin
  if not fn_is_superadmin() then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  with weekly_top as (
    select page, count(*) as c
    from client_error_logs
    where created_at >= current_date - interval '7 days'
    group by page
    order by c desc
    limit 1
  )
  select
    (select count(*) from client_error_logs where created_at >= current_date),
    (select count(*) from client_error_logs where created_at >= current_date - interval '7 days'),
    (select count(*) from client_error_logs),
    (select page from weekly_top),
    (select c from weekly_top);
end;
$$;

grant execute on function public.fn_client_error_stats() to authenticated;

-- 4) قائمة الأخطاء مع فلاتر (SuperAdmin فقط)
create or replace function public.fn_list_client_errors(
  p_from timestamptz default null,
  p_to timestamptz default null,
  p_page text default null,
  p_school_id uuid default null,
  p_limit int default 100,
  p_offset int default 0
)
returns table (
  id uuid, school_name text, actor_name text, role text, page text,
  level text, message text, stack text, user_agent text, page_url text, created_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
begin
  if not fn_is_superadmin() then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select l.id, s.name, p.full_name, l.role, l.page, l.level, l.message, l.stack, l.user_agent, l.page_url, l.created_at
  from client_error_logs l
  left join schools s on s.id = l.school_id
  left join profiles p on p.id = l.profile_id
  where (p_from is null or l.created_at >= p_from)
    and (p_to is null or l.created_at <= p_to)
    and (p_page is null or l.page = p_page)
    and (p_school_id is null or l.school_id = p_school_id)
  order by l.created_at desc
  limit p_limit offset p_offset;
end;
$$;

grant execute on function public.fn_list_client_errors(timestamptz, timestamptz, text, uuid, int, int) to authenticated;

-- 5) تنظيف السجلات القديمة (SuperAdmin فقط، يدوي — بدون الحاجة لـ pg_cron)
create or replace function public.fn_purge_old_client_errors(p_older_than_days int default 90)
returns bigint
language plpgsql
security definer
set search_path = public
as $$
declare
  v_deleted bigint;
begin
  if not fn_is_superadmin() then
    raise exception 'PERMISSION_DENIED';
  end if;

  delete from client_error_logs where created_at < now() - (p_older_than_days || ' days')::interval;
  get diagnostics v_deleted = row_count;
  return v_deleted;
end;
$$;

grant execute on function public.fn_purge_old_client_errors(int) to authenticated;
