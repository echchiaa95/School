-- Fix: teachers could save marks but could not see them again because direct
-- reads from grade_marks were blocked by RLS. Return only the requested rows
-- through a tightly scoped security-definer function.

create or replace function public.fn_teacher_student_assessment_marks(
  p_student_id uuid,
  p_class_id uuid,
  p_subject_id uuid,
  p_period text
)
returns table (
  assessment_id uuid,
  title text,
  assessment_type text,
  coefficient numeric,
  max_score numeric,
  assessment_date date,
  mark_id uuid,
  student_id uuid,
  score numeric,
  teacher_note text,
  mark_created_at timestamptz
)
language sql
stable
security definer
set search_path = public
as $$
  select
    ga.id as assessment_id,
    ga.title,
    ga.assessment_type,
    ga.coefficient,
    ga.max_score,
    ga.assessment_date,
    gm.id as mark_id,
    gm.student_id,
    gm.score,
    gm.teacher_note,
    gm.created_at as mark_created_at
  from public.grade_assessments ga
  join public.grade_marks gm on gm.assessment_id = ga.id
  join public.students st on st.id = gm.student_id
  where st.id = p_student_id
    and ga.class_id = p_class_id
    and ga.subject_id = p_subject_id
    and ga.period = p_period
    and gm.student_id = p_student_id
  order by ga.assessment_date desc nulls last, ga.created_at desc;
$$;

revoke all on function public.fn_teacher_student_assessment_marks(uuid, uuid, uuid, text) from public;
grant execute on function public.fn_teacher_student_assessment_marks(uuid, uuid, uuid, text) to authenticated;
