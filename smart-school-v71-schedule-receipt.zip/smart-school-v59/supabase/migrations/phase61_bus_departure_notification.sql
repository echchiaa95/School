-- ============================================================================
-- phase61_bus_departure_notification.sql
-- إشعار تلقائي لأولياء الأمور عند انطلاق حافلة (نفس الحافلة/الرحلة) لجلب أو
-- إرجاع أبنائهم — 100% إضافي: fn_start_trip يُعاد إنشاؤها بنفس التوقيع تمامًا
-- (بدون DROP، فقط تعديل الجسم لإضافة استدعاء الإشعار).
-- ============================================================================

-- 1) الدالة الجديدة: تُنشئ إشعارًا واحدًا وتُوزّعه على كل أولياء أمور التلاميذ
--    المسجَّلين حاليًا (is_active) على نفس الحافلة.
create or replace function public.fn_notify_trip_started(p_trip_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_bus_id uuid;
  v_direction trip_direction;
  v_bus_label text;
  v_title text;
  v_body text;
  v_notif_id uuid;
begin
  select t.school_id, t.bus_id, t.direction,
         coalesce(b.code, b.plate_number, 'الحافلة')
    into v_school_id, v_bus_id, v_direction, v_bus_label
  from bus_trips t
  join buses b on b.id = t.bus_id
  where t.id = p_trip_id;

  if v_school_id is null then
    return; -- رحلة غير موجودة: لا داعي لكسر أي شيء
  end if;

  if v_direction = 'TO_SCHOOL'::trip_direction then
    v_title := '🚌 انطلقت الحافلة';
    v_body := 'انطلقت حافلة ' || v_bus_label || ' لاصطحاب ابنكم/ابنتكم إلى المدرسة. الرجاء الاستعداد عند نقطة الركوب.';
  else
    v_title := '🚌 الحافلة في الطريق';
    v_body := 'انطلقت حافلة ' || v_bus_label || ' لإرجاع ابنكم/ابنتكم إلى المنزل. الرجاء الاستعداد لاستقباله/ها.';
  end if;

  insert into notifications (school_id, title, body, type, created_by)
  values (v_school_id, v_title, v_body, 'transport', auth.uid())
  returning id into v_notif_id;

  insert into notification_deliveries (notification_id, profile_id)
  select distinct v_notif_id, pa.profile_id
  from student_transport_assignments sta
  join parent_students ps on ps.student_id = sta.student_id
  join parents pa on pa.id = ps.parent_id and pa.deleted_at is null
  where sta.bus_id = v_bus_id and sta.is_active;
end;
$$;

grant execute on function public.fn_notify_trip_started(uuid) to authenticated;

-- 2) fn_start_trip: نفس التوقيع بالضبط (uuid, text) → CREATE OR REPLACE آمن
--    بدون DROP. أضفنا فقط استدعاء الإشعار في نهايتها، محميًا بـ exception حتى
--    لا يفشل بدء الرحلة أبدًا بسبب مشكلة في الإشعارات.
create or replace function public.fn_start_trip(p_route_id uuid default null, p_direction text default 'pickup')
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_driver_id uuid;
  v_school_id uuid;
  v_bus_id uuid;
  v_direction trip_direction;
  v_trip_id uuid;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  select d.id, d.school_id into v_driver_id, v_school_id
  from drivers d
  where d.profile_id = auth.uid() and d.deleted_at is null
  limit 1;
  if v_driver_id is null then
    raise exception 'NOT_A_DRIVER';
  end if;

  select b.id into v_bus_id from buses b
  where b.driver_id = v_driver_id and b.is_active
  limit 1;
  if v_bus_id is null then
    raise exception 'NO_BUS_ASSIGNED';
  end if;

  v_direction := case lower(trim(coalesce(p_direction, 'pickup')))
                   when 'pickup'    then 'TO_SCHOOL'::trip_direction
                   when 'to_school' then 'TO_SCHOOL'::trip_direction
                   when 'dropoff'   then 'TO_HOME'::trip_direction
                   when 'to_home'   then 'TO_HOME'::trip_direction
                   else null
                 end;
  if v_direction is null then
    raise exception 'INVALID_DIRECTION';
  end if;

  if p_route_id is not null and not exists (
    select 1 from bus_routes where id = p_route_id and school_id = v_school_id
  ) then
    raise exception 'INVALID_ROUTE';
  end if;

  update bus_trips
  set status = 'COMPLETED'::trip_status, ends_at = now()
  where driver_id = v_driver_id and status = 'ACTIVE'::trip_status;

  insert into bus_trips (school_id, bus_id, driver_id, route_id, direction, status, starts_at)
  values (v_school_id, v_bus_id, v_driver_id, p_route_id,
          v_direction, 'ACTIVE'::trip_status, now())
  returning id into v_trip_id;

  perform fn_safe_audit(v_school_id, 'START_TRIP', 'bus_trips', v_trip_id,
    null, jsonb_build_object('direction', v_direction::text, 'bus_id', v_bus_id));

  -- === إشعار تلقائي لأولياء الأمور (Phase 61) — لا يُفشل بدء الرحلة أبدًا ===
  begin
    perform public.fn_notify_trip_started(v_trip_id);
  exception when others then
    null;
  end;

  return v_trip_id;
end;
$$;

revoke all on function public.fn_start_trip(uuid, text) from public;
grant execute on function public.fn_start_trip(uuid, text) to authenticated;
