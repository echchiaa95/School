-- Phase 57: إتاحة كشوف النتائج لمدير المؤسسة (إصلاح اختيار الأقسام)
-- نفّذ هذا الملف مرة واحدة في Supabase SQL Editor

-- 1) تعريف مدرسة المستخدم بشكل شامل (يشمل المدير المسجل في جدول schools)
create or replace function public.fn_my_primary_school()
returns uuid
language plpgsql stable security definer set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_sid uuid;
begin
  if v_uid is null then return null; end if;

  -- أ) المدير/المالك المرتبط مباشرة بسجل المدرسة
  select s.id into v_sid from public.schools s
  where s.manager_id = v_uid
     or s.director_id = v_uid
     or s.owner_id   = v_uid
     or s.created_by = v_uid
  limit 1;
  if v_sid is not null then return v_sid; end if;

  -- ب) عبر جدول الموظفين
  select st.school_id into v_sid from public.staff st
  where st.user_id = v_uid and st.deleted_at is null
  order by st.created_at asc limit 1;
  if v_sid is not null then return v_sid; end if;

  -- ج) عبر ملف المستخدم
  select up.school_id into v_sid from public.user_profiles up
  where up.id = v_uid limit 1;
  return v_sid;
end;
$$;

-- 2) التحقق من عضوية المستخدم في المدرسة بشكل شامل
create or replace function public.fn_is_school_member(p_school_id uuid)
returns boolean
language plpgsql stable security definer set search_path = public
as $$
declare v_uid uuid := auth.uid();
begin
  if v_uid is null or p_school_id is null then return false; end if;

  -- المدير/المالك المرتبط بالمدرسة
  if exists (select 1 from public.schools s where s.id = p_school_id
             and (s.manager_id = v_uid or s.director_id = v_uid
                  or s.owner_id = v_uid or s.created_by = v_uid))
  then return true; end if;

  -- الموظفون
  if exists (select 1 from public.staff st
             where st.school_id = p_school_id and st.user_id = v_uid
               and st.deleted_at is null)
  then return true; end if;

  -- ملف المستخدم
  if exists (select 1 from public.user_profiles up
             where up.id = v_uid and up.school_id = p_school_id)
  then return true; end if;

  -- السوبرأدمن
  if exists (select 1 from public.user_profiles up
             where up.id = v_uid and up.role = 'SUPERADMIN')
  then return true; end if;

  return false;
end;
$$;

-- 3) إعادة تعريف دالة أقسام الكشف: join مرن + عدم الفشل إذا غابت السنة الدراسية
create or replace function public.fn_report_classes()
returns table(class_id uuid, class_name text, level text,
            academic_year_id uuid, year_name text, student_count bigint)
language plpgsql stable security definer set search_path = public
as $$
declare v_school_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  v_school_id := public.fn_my_primary_school();
  if v_school_id is null then raise exception 'NO_SCHOOL_CONTEXT'; end if;
  if not public.fn_is_school_member(v_school_id) then
    raise exception 'PERMISSION_DENIED';
  end if;

  return query
  select c.id, c.name, c.level, c.academic_year_id,
         coalesce(ay.label, 'بدون سنة محددة'),
         (select count(*) from public.student_enrollments se
           where se.class_id = c.id and se.status = 'ACTIVE')
  from public.classes c
  left join public.academic_years ay on ay.id = c.academic_year_id
  where c.school_id = v_school_id
  order by ay.is_current desc nulls last, ay.label desc nulls last, c.name asc;
end;
$$;

grant execute on function public.fn_my_primary_school() to authenticated;
grant execute on function public.fn_is_school_member(uuid) to authenticated;
grant execute on function public.fn_report_classes() to authenticated;
