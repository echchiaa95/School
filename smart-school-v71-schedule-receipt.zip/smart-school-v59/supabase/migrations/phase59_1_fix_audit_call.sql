-- ============================================================================
-- phase59_1_fix_audit_call.sql
-- إصلاح: fn_mark_staff_attendance كانت تستدعي fn_safe_audit بعدد معاملات خاطئ
-- (4 بدل 6)، مما كان يُفشل كل عملية دخول/خروج/غياب بخطأ عام.
-- CREATE OR REPLACE بنفس التوقيع تمامًا — آمن، لا يكسر شيئًا.
-- ============================================================================

create or replace function public.fn_mark_staff_attendance(
  p_profile_id uuid,
  p_work_date date,
  p_status text,
  p_check_in_at timestamptz default null,
  p_check_out_at timestamptz default null,
  p_notes text default null
)
returns public.staff_attendance
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_row public.staff_attendance;
begin
  v_school_id := public.fn_staff_school_id(p_profile_id);

  if v_school_id is null then
    raise exception 'STAFF_NOT_FOUND';
  end if;

  if not public.fn_is_school_manager(v_school_id) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if p_status not in ('PRESENT','ABSENT','LATE','HALF_DAY','LEAVE') then
    raise exception 'INVALID_STATUS';
  end if;

  insert into public.staff_attendance (
    school_id, profile_id, work_date, status, check_in_at, check_out_at, notes, recorded_by
  ) values (
    v_school_id, p_profile_id, p_work_date, p_status, p_check_in_at, p_check_out_at, p_notes, auth.uid()
  )
  on conflict (profile_id, work_date) do update
    set status = excluded.status,
        check_in_at = excluded.check_in_at,
        check_out_at = excluded.check_out_at,
        notes = excluded.notes,
        recorded_by = excluded.recorded_by,
        updated_at = now()
  returning * into v_row;

  -- الإصلاح: الترتيب الصحيح هو (school_id, action, entity, entity_id, old, new)
  perform public.fn_safe_audit(
    v_school_id, 'STAFF_ATTENDANCE_MARKED', 'staff_attendance', v_row.id,
    null, to_jsonb(v_row)
  );

  return v_row;
end;
$$;

grant execute on function public.fn_mark_staff_attendance(uuid, date, text, timestamptz, timestamptz, text) to authenticated;
