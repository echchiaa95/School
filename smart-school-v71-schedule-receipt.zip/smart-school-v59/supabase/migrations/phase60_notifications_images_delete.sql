-- ============================================================================
-- phase60_notifications_images_delete.sql
-- إشعارات محسّنة: دعم صورة مرفقة + حذف شخصي (لا يؤثر على باقي المستلمين)
-- ============================================================================

-- 1) عمود الصورة على notifications (إضافي)
alter table public.notifications
  add column if not exists image_url text;

-- 2) عمود الحذف الشخصي على notification_deliveries (إضافي)
--    الحذف هنا "شخصي": يخفي الإشعار عند هذا المستخدم فقط، لا يحذفه من عند البقية
alter table public.notification_deliveries
  add column if not exists deleted_at timestamptz;

-- 3) Bucket تخزين صور الإشعارات (نفس نمط student-photos/school-logos تمامًا)
insert into storage.buckets (id, name, public)
values ('notification-images', 'notification-images', true)
on conflict (id) do nothing;

do $$ begin
  if not exists (
    select 1 from pg_policies where schemaname = 'storage' and tablename = 'objects'
      and policyname = 'p_notification_images_public_read'
  ) then
    create policy p_notification_images_public_read on storage.objects
      for select using (bucket_id = 'notification-images');
  end if;
  if not exists (
    select 1 from pg_policies where schemaname = 'storage' and tablename = 'objects'
      and policyname = 'p_notification_images_staff_write'
  ) then
    create policy p_notification_images_staff_write on storage.objects
      for insert to authenticated
      with check (
        bucket_id = 'notification-images'
        and fn_is_school_staff((storage.foldername(name))[1]::uuid)
      );
  end if;
end $$;

-- 4) fn_send_notification: تغيير التوقيع (إضافة p_image_url) يتطلب DROP+CREATE
--    (نفس ما فعلناه سابقًا في Phase 3.4 عند تغيير مخرجات دالة)
drop function if exists public.fn_send_notification(text, text, text, text, uuid, uuid);

create or replace function public.fn_send_notification(
  p_title text,
  p_body text default null,
  p_type text default 'announcement',
  p_target_role text default null,
  p_target_profile_id uuid default null,
  p_student_id uuid default null,
  p_image_url text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_id uuid;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  v_school_id := fn_my_primary_school();
  if v_school_id is null then
    raise exception 'NO_SCHOOL_CONTEXT';
  end if;
  if not (fn_is_school_staff(v_school_id)
          or fn_has_permission('notifications.manage', v_school_id)) then
    raise exception 'PERMISSION_DENIED';
  end if;
  if p_title is null or trim(p_title) = '' then
    raise exception 'TITLE_REQUIRED';
  end if;

  insert into notifications
    (school_id, title, body, type, target_role, target_profile_id, student_id, created_by, image_url)
  values (
    v_school_id, trim(p_title), p_body,
    coalesce(nullif(trim(coalesce(p_type, '')), ''), 'announcement'),
    nullif(trim(coalesce(p_target_role, '')), ''),
    p_target_profile_id, p_student_id, auth.uid(),
    nullif(trim(coalesce(p_image_url, '')), '')
  )
  returning id into v_id;

  if p_target_profile_id is not null then
    insert into notification_deliveries (notification_id, profile_id)
    select v_id, p_target_profile_id
    where exists (select 1 from user_roles ur
                  where ur.profile_id = p_target_profile_id and ur.school_id = v_school_id);
  elsif p_target_role is not null and trim(p_target_role) <> '' then
    insert into notification_deliveries (notification_id, profile_id)
    select distinct v_id, ur.profile_id
    from user_roles ur
    where ur.school_id = v_school_id
      and ur.role::text = lower(trim(p_target_role));
  elsif p_student_id is not null then
    insert into notification_deliveries (notification_id, profile_id)
    select distinct v_id, pa.profile_id
    from parent_students ps
    join parents pa on pa.id = ps.parent_id and pa.deleted_at is null
    where ps.student_id = p_student_id;
  else
    insert into notification_deliveries (notification_id, profile_id)
    select distinct v_id, ur.profile_id
    from user_roles ur
    where ur.school_id = v_school_id;
  end if;

  perform fn_safe_audit(v_school_id, 'SEND_NOTIFICATION', 'notifications', v_id,
    null, jsonb_build_object('title', trim(p_title), 'type', p_type,
                             'target_role', p_target_role, 'has_image', p_image_url is not null));

  return v_id;
end;
$$;

revoke all on function public.fn_send_notification(text, text, text, text, uuid, uuid, text) from public;
grant execute on function public.fn_send_notification(text, text, text, text, uuid, uuid, text) to authenticated;

-- 5) fn_list_my_notifications: تغيير المخرجات (إضافة image_url) يتطلب DROP+CREATE
--    + استبعاد الإشعارات المحذوفة شخصيًا (deleted_at is null)
drop function if exists public.fn_list_my_notifications(int);

create or replace function public.fn_list_my_notifications(p_limit int default 50)
returns table(
  notification_id uuid, title text, body text, type text,
  image_url text, created_at timestamptz, is_read boolean
)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  return query
  select n.id, n.title, n.body, n.type, n.image_url, n.created_at,
         (d.read_at is not null)
  from notification_deliveries d
  join notifications n on n.id = d.notification_id
  where d.profile_id = auth.uid()
    and d.deleted_at is null
  order by n.created_at desc
  limit p_limit;
end;
$$;

revoke all on function public.fn_list_my_notifications(int) from public;
grant execute on function public.fn_list_my_notifications(int) to authenticated;

-- 6) حذف شخصي: يخفي الإشعار عند صاحب الطلب فقط (سطر التسليم الخاص به)
create or replace function public.fn_delete_my_notification(p_notification_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  update notification_deliveries
  set deleted_at = now()
  where notification_id = p_notification_id
    and profile_id = auth.uid();

  if not found then
    raise exception 'NOTIFICATION_NOT_FOUND';
  end if;
end;
$$;

revoke all on function public.fn_delete_my_notification(uuid) from public;
grant execute on function public.fn_delete_my_notification(uuid) to authenticated;

-- 7) fn_unread_notifications_count: يجب استبعاد المحذوف شخصيًا أيضًا
create or replace function public.fn_unread_notifications_count()
returns bigint
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_count bigint;
begin
  if auth.uid() is null then
    return 0;
  end if;

  select count(*) into v_count
  from notification_deliveries d
  where d.profile_id = auth.uid()
    and d.read_at is null
    and d.deleted_at is null;

  return v_count;
end;
$$;

grant execute on function public.fn_unread_notifications_count() to authenticated;
