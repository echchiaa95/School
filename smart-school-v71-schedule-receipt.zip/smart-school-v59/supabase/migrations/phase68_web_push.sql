-- ============================================================================
-- phase68_web_push.sql — إشعارات Push حقيقية (تصل حتى والتطبيق مغلق)
-- إضافي 100%. جدول جديد + RPC + trigger يستدعي Edge Function عبر pg_net.
-- ============================================================================

create extension if not exists pg_net;

-- 1) جدول اشتراكات المتصفح (جهاز واحد = اشتراك واحد لكل مستخدم)
create table if not exists public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id),
  endpoint text not null,
  p256dh text not null,
  auth text not null,
  user_agent text,
  created_at timestamptz not null default now(),
  constraint push_subscriptions_unique unique (profile_id, endpoint)
);

create index if not exists idx_push_subscriptions_profile on public.push_subscriptions(profile_id);

-- RLS مفعّل بدون أي policy — RPC فقط من طرف العميل، service_role من طرف الخادم
alter table public.push_subscriptions enable row level security;

-- 2) حفظ/تحديث اشتراك (ذاتي الخدمة)
create or replace function public.fn_save_push_subscription(
  p_endpoint text,
  p_p256dh text,
  p_auth text,
  p_user_agent text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  insert into push_subscriptions (profile_id, endpoint, p256dh, auth, user_agent)
  values (auth.uid(), p_endpoint, p_p256dh, p_auth, p_user_agent)
  on conflict (profile_id, endpoint) do update
    set p256dh = excluded.p256dh, auth = excluded.auth, user_agent = excluded.user_agent;
end;
$$;

grant execute on function public.fn_save_push_subscription(text, text, text, text) to authenticated;

-- 3) إلغاء اشتراك
create or replace function public.fn_remove_push_subscription(p_endpoint text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  delete from push_subscriptions where profile_id = auth.uid() and endpoint = p_endpoint;
end;
$$;

grant execute on function public.fn_remove_push_subscription(text) to authenticated;

-- 4) هل لدى المستخدم الحالي اشتراك واحد على الأقل (لعرض حالة الزر في الواجهة)
create or replace function public.fn_has_push_subscription()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (select 1 from push_subscriptions where profile_id = auth.uid());
$$;

grant execute on function public.fn_has_push_subscription() to authenticated;

-- 5) Trigger: عند إنشاء أي "تسليم" إشعار جديد، استدعِ Edge Function لإرسال
--    Push فعلي. لا يُفشل إدراج الإشعار أبدًا مهما حدث (exception مُبتلَعة)،
--    ولا يفعل شيئًا إن لم يُهيَّأ Push بعد (الإعداد اليدوي في القسم أدناه).
create or replace function public.fn_trigger_web_push()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_url text := current_setting('app.settings.push_edge_url', true);
  v_key text := current_setting('app.settings.service_role_key', true);
begin
  if v_url is null or v_key is null or v_url = '' or v_key = '' then
    return new; -- Push غير مُهيَّأ بعد — سلوك طبيعي، لا خطأ
  end if;

  perform net.http_post(
    url := v_url,
    headers := jsonb_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer ' || v_key),
    body := jsonb_build_object('notification_id', new.notification_id, 'profile_id', new.profile_id)
  );
  return new;
exception when others then
  return new; -- فشل استدعاء Push يجب ألا يُفشل تسجيل الإشعار نفسه أبدًا
end;
$$;

drop trigger if exists trg_web_push on public.notification_deliveries;
create trigger trg_web_push
  after insert on public.notification_deliveries
  for each row execute function public.fn_trigger_web_push();

-- ============================================================================
-- ⚠️ إعداد يدوي لمرة واحدة (لا يمكن تضمينه في migration لأنه يحتاج مفاتيحك
-- الفعلية الحساسة). نفّذ هذين الأمرين في SQL Editor بعد نشر Edge Function:
--
-- alter database postgres set app.settings.service_role_key = 'YOUR_SERVICE_ROLE_KEY';
-- alter database postgres set app.settings.push_edge_url = 'https://YOUR_PROJECT_REF.functions.supabase.co/send-web-push';
--
-- (service_role key توجد في Project Settings → API. لا تضعها أبدًا في كود
-- العميل — فقط هنا، على مستوى قاعدة البيانات، ومن Edge Function نفسها كـ secret.)
-- ============================================================================
