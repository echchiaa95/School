-- PHASE 40 — Subject coefficients and grade permissions
-- MUTATING SQL: run once on Smart School Production.

create table if not exists public.grade_subject_coefficients (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  academic_year_id uuid references public.academic_years(id),
  coefficient numeric(8,3) not null default 1 check (coefficient > 0),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(class_id, subject_id, academic_year_id)
);

create index if not exists ix_grade_subject_coefficients_class
on public.grade_subject_coefficients(class_id, subject_id);

alter table public.grade_subject_coefficients enable row level security;
revoke all on public.grade_subject_coefficients from public;
grant select, insert, update, delete on public.grade_subject_coefficients to authenticated;

create or replace function public.fn_grade_subject_coefficients(p_class_id uuid)
returns table(subject_id uuid, subject_name text, coefficient numeric)
language sql stable security definer set search_path=public
as $$
  select s.id, s.name, coalesce(gsc.coefficient, 1)
  from public.subjects s
  left join public.grade_subject_coefficients gsc
    on gsc.subject_id=s.id and gsc.class_id=p_class_id
  order by s.name;
$$;

revoke all on function public.fn_grade_subject_coefficients(uuid) from public;
grant execute on function public.fn_grade_subject_coefficients(uuid) to authenticated;

create or replace function public.fn_upsert_grade_subject_coefficient(
  p_class_id uuid, p_subject_id uuid, p_coefficient numeric
) returns public.grade_subject_coefficients
language plpgsql security definer set search_path=public
as $$
declare v_row public.grade_subject_coefficients;
begin
  if p_coefficient is null or p_coefficient <= 0 then raise exception 'المعامل يجب أن يكون أكبر من صفر'; end if;
  insert into public.grade_subject_coefficients(school_id,class_id,subject_id,academic_year_id,coefficient,created_by)
  select c.school_id,c.id,p_subject_id,null, p_coefficient, auth.uid()
  from public.classes c where c.id=p_class_id
  on conflict (class_id,subject_id,academic_year_id) do update set coefficient=excluded.coefficient,updated_at=now()
  returning * into v_row;
  return v_row;
end; $$;
revoke all on function public.fn_upsert_grade_subject_coefficient(uuid,uuid,numeric) from public;
grant execute on function public.fn_upsert_grade_subject_coefficient(uuid,uuid,numeric) to authenticated;
