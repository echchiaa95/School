-- Phase 56: fix manager grades-report class and student selectors.
-- Direct table reads may be blocked by RLS; use controlled security-definer RPCs.

create or replace function public.fn_report_classes()
returns table(class_id uuid, class_name text, level text, academic_year_id uuid, year_name text, student_count bigint)
language plpgsql stable security definer set search_path = public
as $$
declare v_school_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  v_school_id := public.fn_my_primary_school();
  if v_school_id is null then raise exception 'NO_SCHOOL_CONTEXT'; end if;
  if not public.fn_is_school_member(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;
  return query
  select c.id, c.name, c.level, c.academic_year_id, ay.label,
         (select count(*) from public.student_enrollments se where se.class_id=c.id and se.status='ACTIVE')
  from public.classes c
  join public.academic_years ay on ay.id=c.academic_year_id
  where c.school_id=v_school_id
  order by ay.is_current desc, ay.label desc, c.name;
end;
$$;

grant execute on function public.fn_report_classes() to authenticated;

create or replace function public.fn_report_class_students(p_class_id uuid)
returns table(student_id uuid, full_name text, student_number text)
language plpgsql stable security definer set search_path = public
as $$
declare v_school_id uuid;
begin
  if auth.uid() is null then raise exception 'NOT_AUTHENTICATED'; end if;
  select c.school_id into v_school_id from public.classes c where c.id=p_class_id;
  if v_school_id is null then raise exception 'INVALID_CLASS'; end if;
  if not public.fn_is_school_member(v_school_id) then raise exception 'PERMISSION_DENIED'; end if;
  return query
  select st.id, st.full_name, st.student_number
  from public.student_enrollments se
  join public.students st on st.id=se.student_id
  where se.class_id=p_class_id and se.status='ACTIVE' and st.deleted_at is null
  order by st.full_name;
end;
$$;

grant execute on function public.fn_report_class_students(uuid) to authenticated;
