-- ============================================================================
-- phase59_staff_attendance.sql
-- نظام حضور الموظفين اليومي (تسجيل من طرف الحارس العام / المدير)
-- 100% إضافي: لا DROP، لا تعديل على جداول موجودة سوى ADD COLUMN IF NOT EXISTS
-- ============================================================================

-- 1) نوع التوظيف (بالساعة / دوام كامل) على الجداول الثلاث الحاملة للموظفين
alter table public.teachers
  add column if not exists employment_type text not null default 'FULL_TIME'
  check (employment_type in ('HOURLY', 'FULL_TIME'));

alter table public.guards
  add column if not exists employment_type text not null default 'FULL_TIME'
  check (employment_type in ('HOURLY', 'FULL_TIME'));

alter table public.drivers
  add column if not exists employment_type text not null default 'FULL_TIME'
  check (employment_type in ('HOURLY', 'FULL_TIME'));

-- 2) جدول حضور الموظفين اليومي
create table if not exists public.staff_attendance (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id),
  profile_id uuid not null references public.profiles(id),
  work_date date not null default current_date,
  status text not null check (status in ('PRESENT', 'ABSENT', 'LATE', 'HALF_DAY', 'LEAVE')),
  check_in_at timestamptz,
  check_out_at timestamptz,
  hours_worked numeric generated always as (
    case
      when check_in_at is not null and check_out_at is not null
        then round(extract(epoch from (check_out_at - check_in_at)) / 3600.0, 2)
      else null
    end
  ) stored,
  notes text,
  recorded_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint staff_attendance_one_per_day unique (profile_id, work_date)
);

create index if not exists idx_staff_attendance_school_date
  on public.staff_attendance(school_id, work_date);

create index if not exists idx_staff_attendance_profile
  on public.staff_attendance(profile_id, work_date);

-- RLS مفعّل بدون أي policy — كل الوصول عبر RPC فقط (نفس نمط المشروع)
alter table public.staff_attendance enable row level security;

-- 3) دالة مساعدة: هل المستخدم الحالي admin/director/guard في مدرسة معينة؟
create or replace function public.fn_is_school_manager(p_school_id uuid)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles ur
    where ur.profile_id = auth.uid()
      and ur.school_id = p_school_id
      and ur.role in ('admin', 'director', 'guard', 'superadmin')
  );
$$;

-- 4) دالة مساعدة: جلب school_id لموظف معيّن (يبحث في الجداول الثلاث)
create or replace function public.fn_staff_school_id(p_profile_id uuid)
returns uuid
language sql
security definer
set search_path = public
as $$
  select coalesce(
    (select school_id from public.teachers where profile_id = p_profile_id and deleted_at is null limit 1),
    (select school_id from public.guards where profile_id = p_profile_id limit 1),
    (select school_id from public.drivers where profile_id = p_profile_id and deleted_at is null limit 1)
  );
$$;

-- 5) قائمة موظفي المدرسة (لعرضها في واجهة التسجيل)
create or replace function public.fn_list_school_staff(p_school_id uuid)
returns table (
  profile_id uuid,
  full_name text,
  role text,
  employment_type text,
  phone text
)
language sql
security definer
set search_path = public
as $$
  select p.id, p.full_name, 'teacher', t.employment_type, p.phone
  from public.teachers t join public.profiles p on p.id = t.profile_id
  where t.school_id = p_school_id and t.deleted_at is null
    and public.fn_is_school_manager(p_school_id)
  union all
  select p.id, p.full_name, 'guard', g.employment_type, p.phone
  from public.guards g join public.profiles p on p.id = g.profile_id
  where g.school_id = p_school_id
    and public.fn_is_school_manager(p_school_id)
  union all
  select p.id, p.full_name, 'driver', d.employment_type, p.phone
  from public.drivers d join public.profiles p on p.id = d.profile_id
  where d.school_id = p_school_id and d.deleted_at is null
    and public.fn_is_school_manager(p_school_id)
  order by 2;
$$;

-- 6) تسجيل/تعديل حضور يوم واحد لموظف (upsert)
create or replace function public.fn_mark_staff_attendance(
  p_profile_id uuid,
  p_work_date date,
  p_status text,
  p_check_in_at timestamptz default null,
  p_check_out_at timestamptz default null,
  p_notes text default null
)
returns public.staff_attendance
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_row public.staff_attendance;
begin
  v_school_id := public.fn_staff_school_id(p_profile_id);

  if v_school_id is null then
    raise exception 'STAFF_NOT_FOUND';
  end if;

  if not public.fn_is_school_manager(v_school_id) then
    raise exception 'PERMISSION_DENIED';
  end if;

  if p_status not in ('PRESENT','ABSENT','LATE','HALF_DAY','LEAVE') then
    raise exception 'INVALID_STATUS';
  end if;

  insert into public.staff_attendance (
    school_id, profile_id, work_date, status, check_in_at, check_out_at, notes, recorded_by
  ) values (
    v_school_id, p_profile_id, p_work_date, p_status, p_check_in_at, p_check_out_at, p_notes, auth.uid()
  )
  on conflict (profile_id, work_date) do update
    set status = excluded.status,
        check_in_at = excluded.check_in_at,
        check_out_at = excluded.check_out_at,
        notes = excluded.notes,
        recorded_by = excluded.recorded_by,
        updated_at = now()
  returning * into v_row;

  perform public.fn_safe_audit(
    v_school_id, 'STAFF_ATTENDANCE_MARKED', 'staff_attendance', v_row.id,
    null, to_jsonb(v_row)
  );

  return v_row;
end;
$$;

-- 7) تسجيل حضور سريع (بصمة زمنية فقط دخول)
create or replace function public.fn_staff_check_in(p_profile_id uuid, p_work_date date default current_date)
returns public.staff_attendance
language plpgsql
security definer
set search_path = public
as $$
begin
  return public.fn_mark_staff_attendance(
    p_profile_id, p_work_date, 'PRESENT', now(), null, null
  );
end;
$$;

-- 8) تسجيل خروج (يكمل نفس سجل اليوم دون حذف وقت الدخول)
create or replace function public.fn_staff_check_out(p_profile_id uuid, p_work_date date default current_date)
returns public.staff_attendance
language plpgsql
security definer
set search_path = public
as $$
declare
  v_school_id uuid;
  v_row public.staff_attendance;
begin
  v_school_id := public.fn_staff_school_id(p_profile_id);
  if v_school_id is null then
    raise exception 'STAFF_NOT_FOUND';
  end if;
  if not public.fn_is_school_manager(v_school_id) then
    raise exception 'PERMISSION_DENIED';
  end if;

  update public.staff_attendance
    set check_out_at = now(), updated_at = now()
  where profile_id = p_profile_id and work_date = p_work_date
  returning * into v_row;

  if v_row.id is null then
    raise exception 'NO_CHECKIN_FOUND';
  end if;

  return v_row;
end;
$$;

-- 9) تقرير حضور موظف واحد بين تاريخين
create or replace function public.fn_get_staff_attendance_report(
  p_profile_id uuid,
  p_from date,
  p_to date
)
returns table (
  work_date date,
  status text,
  check_in_at timestamptz,
  check_out_at timestamptz,
  hours_worked numeric,
  notes text
)
language sql
security definer
set search_path = public
as $$
  select sa.work_date, sa.status, sa.check_in_at, sa.check_out_at, sa.hours_worked, sa.notes
  from public.staff_attendance sa
  where sa.profile_id = p_profile_id
    and sa.work_date between p_from and p_to
    and public.fn_is_school_manager(sa.school_id)
  order by sa.work_date desc;
$$;

-- 10) ملخص شهري لكل الموظفين (لوحة المدير)
create or replace function public.fn_get_school_attendance_summary(
  p_school_id uuid,
  p_from date,
  p_to date
)
returns table (
  profile_id uuid,
  full_name text,
  role text,
  employment_type text,
  present_days bigint,
  absent_days bigint,
  late_days bigint,
  total_hours numeric
)
language sql
security definer
set search_path = public
as $$
  select
    s.profile_id, s.full_name, s.role, s.employment_type,
    count(*) filter (where sa.status = 'PRESENT') as present_days,
    count(*) filter (where sa.status = 'ABSENT') as absent_days,
    count(*) filter (where sa.status = 'LATE') as late_days,
    coalesce(sum(sa.hours_worked), 0) as total_hours
  from public.fn_list_school_staff(p_school_id) s
  left join public.staff_attendance sa
    on sa.profile_id = s.profile_id
    and sa.work_date between p_from and p_to
  group by s.profile_id, s.full_name, s.role, s.employment_type
  order by s.full_name;
$$;

-- صلاحيات التنفيذ (نفس نمط بقية المشروع: RPC فقط، لا policy مباشرة على الجدول)
grant execute on function public.fn_is_school_manager(uuid) to authenticated;
grant execute on function public.fn_staff_school_id(uuid) to authenticated;
grant execute on function public.fn_list_school_staff(uuid) to authenticated;
grant execute on function public.fn_mark_staff_attendance(uuid, date, text, timestamptz, timestamptz, text) to authenticated;
grant execute on function public.fn_staff_check_in(uuid, date) to authenticated;
grant execute on function public.fn_staff_check_out(uuid, date) to authenticated;
grant execute on function public.fn_get_staff_attendance_report(uuid, date, date) to authenticated;
grant execute on function public.fn_get_school_attendance_summary(uuid, date, date) to authenticated;
