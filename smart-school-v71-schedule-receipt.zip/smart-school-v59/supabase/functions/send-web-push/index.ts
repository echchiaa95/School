// ============================================================================
// supabase/functions/send-web-push/index.ts
// تُستدعى تلقائيًا عبر trigger على notification_deliveries (انظر phase68).
// تستعمل مكتبة web-push الموثوقة (عبر npm: specifier المدعوم في Deno) بدل
// إعادة تطبيق تشفير Web Push (RFC 8291/8292) يدويًا — أكثر أمانًا وموثوقية.
// ============================================================================
import webpush from "npm:web-push@3.6.7";
import { createClient } from "npm:@supabase/supabase-js@2";

const VAPID_PUBLIC_KEY = Deno.env.get("VAPID_PUBLIC_KEY") ?? "";
const VAPID_PRIVATE_KEY = Deno.env.get("VAPID_PRIVATE_KEY") ?? "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const VAPID_CONTACT_EMAIL = Deno.env.get("VAPID_CONTACT_EMAIL") ?? "mailto:admin@example.com";

if (VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
  webpush.setVapidDetails(VAPID_CONTACT_EMAIL, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
}

Deno.serve(async (req) => {
  try {
    if (!VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) {
      return new Response(JSON.stringify({ error: "VAPID_NOT_CONFIGURED" }), { status: 500 });
    }

    const { notification_id, profile_id } = await req.json();
    if (!notification_id || !profile_id) {
      return new Response(JSON.stringify({ error: "MISSING_PARAMS" }), { status: 400 });
    }

    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

    const { data: notif, error: notifErr } = await supabase
      .from("notifications")
      .select("title, body, image_url")
      .eq("id", notification_id)
      .single();
    if (notifErr || !notif) {
      return new Response(JSON.stringify({ error: "NOTIFICATION_NOT_FOUND" }), { status: 404 });
    }

    const { data: subs, error: subsErr } = await supabase
      .from("push_subscriptions")
      .select("id, endpoint, p256dh, auth")
      .eq("profile_id", profile_id);
    if (subsErr) {
      return new Response(JSON.stringify({ error: subsErr.message }), { status: 500 });
    }
    if (!subs || subs.length === 0) {
      return new Response(JSON.stringify({ ok: true, sent: 0 }), { status: 200 });
    }

    const payload = JSON.stringify({
      title: notif.title,
      body: notif.body || "",
      icon: notif.image_url || undefined,
    });

    let sent = 0;
    for (const sub of subs) {
      try {
        await webpush.sendNotification(
          { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
          payload,
        );
        sent++;
      } catch (err) {
        // 404/410 = الاشتراك لم يعد صالحًا (المستخدم ألغى الإذن/غيّر المتصفح) — نحذفه بهدوء
        const status = (err as { statusCode?: number })?.statusCode;
        if (status === 404 || status === 410) {
          await supabase.from("push_subscriptions").delete().eq("id", sub.id);
        }
      }
    }

    return new Response(JSON.stringify({ ok: true, sent, total: subs.length }), { status: 200 });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 });
  }
});
