# Phase 59 — نظام حضور الموظفين اليومي

## ما تم إضافته (100% إضافي، لا شيء موجود تم لمسه)

### SQL (`phase59_staff_attendance.sql`)
- 3 أعمدة جديدة: `employment_type` على `teachers` / `guards` / `drivers` (HOURLY أو FULL_TIME، افتراضيًا FULL_TIME).
- جدول جديد `staff_attendance` (سجل واحد لكل موظف/يوم، RLS مفعّل بدون policies — كل الوصول عبر RPC فقط، نفس نمط بقية المشروع).
- 8 دوال RPC:
  - `fn_is_school_manager` / `fn_staff_school_id` — دوال مساعدة داخلية.
  - `fn_list_school_staff(school_id)` — قائمة كل الموظفين (أساتذة+حراس+سائقين) لعرضها في الواجهة.
  - `fn_mark_staff_attendance(...)` — تسجيل/تعديل حضور يوم (upsert، لا تكرار).
  - `fn_staff_check_in` / `fn_staff_check_out` — تسجيل سريع بضغطة واحدة.
  - `fn_get_staff_attendance_report(profile_id, from, to)` — تقرير موظف واحد (هذا ما يظهر عند الضغط على اسمه).
  - `fn_get_school_attendance_summary(school_id, from, to)` — ملخص شهري لكل الموظفين (للوحة المدير).
- الصلاحية: **admin / director / guard / superadmin فقط** من نفس المدرسة يمكنهم التسجيل أو الاطلاع (`fn_is_school_manager`). موظف عادي (أستاذ/سائق) لا يمكنه تسجيل حضور نفسه أو غيره عبر هذه الدوال.
- كل تسجيل يُدوَّن في `audit_logs` عبر `fn_safe_audit` الموجودة مسبقًا.

### JS (`modules/staffAttendance.js`)
دوال جاهزة للاستدعاء من `admin.html` و `guard.html`:
`listSchoolStaff`, `markStaffAttendance`, `staffCheckIn`, `staffCheckOut`, `getStaffAttendanceReport`, `getSchoolAttendanceSummary`
+ دالتا عرض جاهزتان: `renderStaffAttendanceTable` (الجدول اليومي) و `renderStaffReport` (نافذة التقرير عند الضغط على اسم الموظف).

## خطوات التفعيل (يدوية، بسيطة)
1. نفّذ `phase59_staff_attendance.sql` في Supabase SQL Editor.
2. في `admin.html` (وكذلك `guard.html` إذا أردت تفعيلها هناك أيضًا كما طلبت):
   - أضف تبويب/قسم جديد "حضور الموظفين".
   - استورد الوحدة: `import { listSchoolStaff, staffCheckIn, staffCheckOut, renderStaffAttendanceTable, getStaffAttendanceReport, renderStaffReport } from './modules/staffAttendance.js';`
   - عند فتح القسم: `const staff = await listSchoolStaff(schoolId);` ثم `renderStaffAttendanceTable(container, staff, todayMap)`.
   - اربط أزرار "دخول/خروج/غياب/التقرير" بالدوال المذكورة (event delegation على الجدول).
3. لا حاجة لأي تعديل على قاعدة البيانات غير خطوة 1، ولا أي تعديل على ملفات المصادقة أو الوحدات الأخرى.

## قيد معروف
- إذا أردت لاحقًا تفعيل تسجيل الحضور الذاتي (كل موظف يسجل حضور نفسه بنفسه)، هذا يتطلب دالة RPC إضافية بصلاحية مختلفة (self-service) — لم يُطلب في هذه المرحلة، وتُرك عمدًا خارج النطاق.

## المرحلة التالية المقترحة
Phase 2 من خطتنا: نظام الإشعارات المحسّن (صور + حذف) — يبنى عليه لاحقًا إشعار انطلاق الحافلة تلقائيًا.
