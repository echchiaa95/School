# Phase 67 — مراقبة الأخطاء (بدل الاعتماد فقط على تقارير المستخدمين)

## الفكرة
طبقتان مستقلتان تمامًا:
1. **تسجيل مجاني بالكامل** في جدول `client_error_logs` (Supabase) — يعمل من
   اليوم الأول بدون أي حساب خارجي أو إعداد، ويظهر مباشرة في لوحة SuperAdmin.
2. **Sentry (اختياري 100%)** — حقل `SENTRY_DSN` فارغ افتراضيًا في
   `modules/errorMonitor.js`. طالما فارغ، لا يُحمَّل أي سكريبت خارجي ولا توجد
   أي تكلفة أو اعتمادية إضافية. إذا رغبت لاحقًا بتتبع أعمق (stack trace
   مُفكَّك، تنبيهات بريدية فورية) أنشئ حسابًا مجانيًا على sentry.io والصق
   الـ DSN في نفس السطر — يُفعَّل تلقائيًا.

## ما تم إضافته

### SQL (`phase67_error_monitoring.sql`)
- جدول `client_error_logs` (RLS بدون policy — RPC فقط).
- `fn_log_client_error`: **لا يرفع استثناء أبدًا** (تسجيل الخطأ يجب ألا يُسبب
  خطأً آخر)، ومسموح لـ `anon` أيضًا لأن أخطاء قد تحدث قبل تسجيل الدخول.
- `fn_client_error_stats` / `fn_list_client_errors` / `fn_purge_old_client_errors`:
  **SuperAdmin فقط** (تتحقق عبر `fn_is_superadmin()` الموجودة أصلًا).

### JS
- `modules/errorMonitor.js` (جديد): نقطة الدخول الوحيدة `initErrorMonitor(pageName)`.
- `modules/ui.js`: `armErrorBoundary()` و`showInitError()` أصبحتا تقبلان
  callback اختياريًا — **متوافقتان تمامًا مع أي استدعاء قديم** لم يُعدَّل.
- **استُبدلت كل الاستدعاءات الستة** لـ `armErrorBoundary()` في المشروع
  (adminConsole.js، parentConsole.js، teacherConsole.js، driverConsole.js،
  guard.html، superadmin.html) بـ `initErrorMonitor('اسم-الصفحة.html')` — أي
  خطأ غير مُلتقط في **أي صفحة من صفحات المنصة السبع** يُسجَّل تلقائيًا الآن.
- `modules/superadmin.js`: 3 دوال جديدة (`getClientErrorStats`,
  `listClientErrors`, `purgeOldClientErrors`).

### واجهة SuperAdmin
قسم جديد "🐞 مراقبة الأخطاء": بطاقات إحصائية (أخطاء اليوم/الأسبوع/الإجمالي +
أكثر صفحة تعطُّلًا)، فلترة حسب الصفحة، قائمة مُفصَّلة (الرسالة، المدرسة،
المستخدم، الدور، الوقت) مع Stack Trace قابل للطي عند الحاجة، ترقيم صفحات،
وزر لحذف السجلات الأقدم من 90 يومًا.

## خطوات التفعيل
1. نفّذ `phase67_error_monitoring.sql`.
2. ارفع كل الملفات المذكورة أعلاه.
3. (اختياري) لتفعيل Sentry: أنشئ مشروعًا مجانيًا على sentry.io، انسخ DSN،
   الصقه في `SENTRY_DSN` أعلى `modules/errorMonitor.js`.

## ملاحظة تقنية
اكتُشف أثناء البحث عن نمط `fn_write_audit` أن هذه الدالة (يستدعيها
`fn_safe_audit` داخليًا) **غير موجودة في ملفات migrations المرفَقة بهذه
الحزمة** — على الأرجح مُعرَّفة في مرحلة أساسية سابقة (schema أولي) لم تُرفَق
ضمن هذا الأرشيف، تمامًا مثل جداول `schools`/`profiles` الأساسية المذكورة في
أول مراجعة للمشروع. هذا **ليس خطأً** بحد ذاته (النظام الحي يعمل بشكل طبيعي
واضح من لقطات الشاشة)، لكن يُفسِّر لماذا لا تظهر في هذا الأرشيف — للتأكد
الكامل، تحقق من وجودها في Supabase SQL Editor بالأمر:
`select proname from pg_proc where proname = 'fn_write_audit';`
