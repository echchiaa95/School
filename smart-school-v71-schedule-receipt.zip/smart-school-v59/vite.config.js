import { defineConfig } from 'vite';
import { resolve } from 'node:path';

// ============================================================================
// Vite config — Smart School Platform
// موقع متعدد الصفحات (Multi-Page App): كل ملف HTML موجود مُعرَّف كنقطة دخول
// مستقلة، بدون أي إطار عمل (framework) — نفس بنية الملفات الحالية تمامًا،
// فقط Vite يتكفّل بالتجميع (bundling) والـ cache-busting التلقائي بدل أرقام
// النسخ اليدوية (?v=NN) المنتشرة سابقًا في كل الملفات.
//
// base: './' يجعل كل الروابط نسبية — يعمل تلقائيًا سواء نشرت الموقع على
// جذر النطاق (مثل school.elbordiji.com) أو على مسار فرعي من GitHub Pages
// (مثل username.github.io/repo-name/) دون أي تعديل إضافي.
// ============================================================================

export default defineConfig({
  base: './',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    rollupOptions: {
      input: {
        index: resolve(__dirname, 'index.html'),
        admin: resolve(__dirname, 'admin.html'),
        director: resolve(__dirname, 'director.html'),
        driver: resolve(__dirname, 'driver.html'),
        'grades-report': resolve(__dirname, 'grades-report.html'),
        guard: resolve(__dirname, 'guard.html'),
        parent: resolve(__dirname, 'parent.html'),
        'reset-password': resolve(__dirname, 'reset-password.html'),
        superadmin: resolve(__dirname, 'superadmin.html'),
        teacher: resolve(__dirname, 'teacher.html'),
      },
    },
  },
});
