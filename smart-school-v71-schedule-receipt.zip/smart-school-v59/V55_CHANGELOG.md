# V55 — Teacher grade save button fix

- The teacher grade save button is no longer permanently disabled when the assessment selection is temporarily missing or mobile browser input events are inconsistent.
- The button becomes active after a student and valid score are entered.
- Clicking it now gives a clear validation message if an assessment still needs to be selected.
