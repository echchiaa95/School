# V50 — Professional teacher grades card

- Added a practical student picker with search by name or student number.
- Added a visible student roster with active selection state.
- Added selected-student information before entering the mark.
- Kept the existing assessment coefficient, maximum score, teacher note, and save workflow.
- Responsive layout for mobile and desktop.
- JavaScript syntax validated with Node.js.
