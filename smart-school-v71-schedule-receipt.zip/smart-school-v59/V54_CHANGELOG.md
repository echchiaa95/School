# V54 — Teacher grades read fix

- Fixed the teacher grades screen so previously saved assessment marks are loaded again when selecting a student.
- Added `fn_teacher_student_assessment_marks` security-definer RPC to avoid RLS blocking reads from `grade_marks`.
- Kept a backward-compatible direct-query fallback until the migration is applied.
