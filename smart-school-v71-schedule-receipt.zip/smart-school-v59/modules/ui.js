// ============================================================================
// modules/ui.js
// Shared UI helpers for all consoles: DOM shortcuts, toasts, confirm dialogs,
// formatting, CSV export, loading/empty/error states. RTL-first.
// ============================================================================

export function el(id) { return document.getElementById(id); }

export function esc(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

export function fmtDate(value) {
  if (!value) return '—';
  try {
    return new Intl.DateTimeFormat('ar', { year: 'numeric', month: 'short', day: 'numeric' }).format(new Date(value));
  } catch { return '—'; }
}

export function fmtDateTime(value) {
  if (!value) return '—';
  try {
    return new Intl.DateTimeFormat('ar', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(value));
  } catch { return '—'; }
}

export function fmtMoney(value) {
  const n = Number(value || 0);
  return n.toLocaleString('ar-MA', { maximumFractionDigits: 2 }) + ' د.م.';
}

export function fmtTime(value) {
  if (!value) return '—';
  try {
    return new Intl.DateTimeFormat('ar', { hour: '2-digit', minute: '2-digit' }).format(new Date(value));
  } catch { return '—'; }
}



/**
 * Show one notification in a consistent, mobile-friendly detail dialog.
 * The notification is marked read by the caller before opening this dialog.
 */
export function openNotificationDetails(notification) {
  const n = notification || {};
  const id = n.notification_id || n.id || '';
  const title = esc(n.title || 'إشعار');
  const body = esc((n.body || '').trim() || 'لا توجد تفاصيل إضافية لهذا الإشعار.');
  const typeLabels = { announcement:'إعلان', incident:'بلاغ', attendance:'حضور', grade:'نقطة', transport:'نقل', schedule:'جدول', system:'نظام' };
  const type = esc(typeLabels[n.type] || n.type || 'إشعار');
  const when = esc(fmtDateTime(n.created_at));
  const student = n.student_name ? `<div class="notif-detail-meta">👤 ${esc(n.student_name)}</div>` : '';
  const overlay = document.createElement('div');
  overlay.className = 'notification-modal-overlay';
  overlay.innerHTML = `<div class="notification-modal" role="dialog" aria-modal="true" aria-labelledby="notif-modal-title">
    <div class="notification-modal-head"><span class="notification-modal-icon">🔔</span><button type="button" class="icon-btn notification-modal-close" aria-label="إغلاق">✕</button></div>
    <div class="notification-modal-type">${type}</div>
    <h2 id="notif-modal-title">${title}</h2>
    <div class="notification-modal-body">${body}</div>
    <div class="notification-modal-meta">🕒 ${when}${student ? '<br>'+student : ''}</div>
    <button type="button" class="quick-action-btn notification-modal-ok">حسنًا</button>
  </div>`;
  if (!document.getElementById('notification-modal-style')) {
    const style = document.createElement('style');
    style.id = 'notification-modal-style';
    style.textContent = `
      .notification-modal-overlay{position:fixed;inset:0;z-index:10000;background:rgba(15,23,42,.58);display:flex;align-items:center;justify-content:center;padding:18px;backdrop-filter:blur(3px)}
      .notification-modal{width:min(520px,100%);max-height:min(78vh,680px);overflow:auto;background:#fff;border-radius:22px;padding:20px;box-shadow:0 18px 55px rgba(15,23,42,.25);direction:rtl}
      .notification-modal-head{display:flex;align-items:center;justify-content:space-between;gap:10px}
      .notification-modal-icon{width:48px;height:48px;border-radius:50%;display:grid;place-items:center;background:#eef5ff;font-size:24px}
      .notification-modal .notification-modal-close{color:#123b63;background:#f1f5f9;border:0;padding:8px 12px}
      .notification-modal-type{display:inline-block;margin-top:12px;padding:5px 10px;border-radius:999px;background:#e7effb;color:#1d4f7a;font-size:12px;font-weight:800}
      .notification-modal h2{margin:10px 0 8px;font-size:21px;color:#12315e}
      .notification-modal-body{white-space:pre-wrap;line-height:1.8;color:#334155;font-size:15px;border-top:1px solid #e5e7eb;border-bottom:1px solid #e5e7eb;padding:13px 0}
      .notification-modal-meta{margin:12px 0;color:#64748b;font-size:12px;line-height:1.8}
      .notif-detail-meta{display:inline-block;margin-top:3px}
      .notification-modal-ok{width:100%;margin-top:4px}
    `;
    document.head.appendChild(style);
  }
  const close = () => overlay.remove();
  overlay.querySelector('.notification-modal-close').addEventListener('click', close);
  overlay.querySelector('.notification-modal-ok').addEventListener('click', close);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
  document.addEventListener('keydown', function onKey(e){ if(e.key==='Escape'){close();document.removeEventListener('keydown',onKey);} });
  document.body.appendChild(overlay);
  return id;
}

export function todayAr() {
  return new Intl.DateTimeFormat('ar', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }).format(new Date());
}

const ATT_STATUS_AR = { present: 'حاضر', absent: 'غائب', late: 'متأخر', excused: 'مبرر' };
export function attStatusAr(s) { return ATT_STATUS_AR[s] || s || '—'; }

const ROLE_AR = {
  superadmin: 'SuperAdmin', admin: 'مدير المؤسسة', guard: 'حارس',
  teacher: 'أستاذ', driver: 'سائق', parent: 'ولي أمر',
};
export function roleAr(r) { return ROLE_AR[r] || r || '—'; }

/** Show a transient toast message (success | error | info). */
let toastHost = null;
// Dedupe: identical toasts within 4s render once only (error storms → one message).
const recentToasts = new Map();
export function toast(message, kind = 'info') {
  const key = kind + '|' + message;
  const now = Date.now();
  if (recentToasts.has(key) && now - recentToasts.get(key) < 4000) return;
  recentToasts.set(key, now);
  if (recentToasts.size > 50) recentToasts.delete(recentToasts.keys().next().value);
  if (!toastHost) {
    toastHost = document.createElement('div');
    toastHost.className = 'toast-host';
    document.body.appendChild(toastHost);
  }
  const item = document.createElement('div');
  item.className = `toast toast-${kind}`;
  item.textContent = message;
  toastHost.appendChild(item);
  setTimeout(() => item.classList.add('show'), 10);
  setTimeout(() => { item.classList.remove('show'); setTimeout(() => item.remove(), 300); }, 3500);
}

/** Promise-based confirmation dialog. Resolves true/false. */
export function confirmDialog(message) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal-card" role="dialog" aria-modal="true">
        <p style="margin:0 0 16px; font-weight:600;">${esc(message)}</p>
        <div style="display:flex; gap:8px;">
          <button type="button" class="quick-action-btn" data-act="ok" style="flex:1;">تأكيد</button>
          <button type="button" class="back-link" data-act="cancel" style="flex:1; text-align:center;">إلغاء</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay || e.target.dataset.act === 'cancel') { overlay.remove(); resolve(false); }
      if (e.target.dataset.act === 'ok') { overlay.remove(); resolve(true); }
    });
  });
}

/** Render helpers */
export function loadingHtml(text = 'جارٍ التحميل...') {
  return `<div class="loading-state">${esc(text)}</div>`;
}
export function emptyHtml(text) {
  return `<div class="empty-state">${esc(text)}</div>`;
}
export function errorHtml(text) {
  return `<div class="empty-state" style="color:#dc2626;">${esc(text)}</div>`;
}

export function statCard(value, label, tone = '') {
  return `<div class="stat-card ${tone}"><div class="stat-value">${esc(value)}</div><div class="stat-label">${esc(label)}</div></div>`;
}

/** Download rows as a CSV file (UTF-8 BOM for Excel Arabic support). */
export function downloadCSV(filename, headers, rows) {
  const escapeCell = (v) => {
    const s = String(v ?? '');
    return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  const csv = '﻿' + [headers, ...rows].map((r) => r.map(escapeCell).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

/** Set the standard page header (school name, user, date) and wire logout. */
export async function initPageHeader(ctx, schoolName, logoutFn) {
  const who = el('who-label');
  if (who) who.textContent = `${ctx.profile.full_name} - ${roleAr(ctx.role)}`;
  const dl = el('date-line');
  if (dl) dl.textContent = todayAr();
  const sn = el('school-name-label');
  if (sn && schoolName) sn.textContent = schoolName;
  const btn = el('logout-btn');
  if (btn) {
    btn.style.display = 'inline-block';
    btn.addEventListener('click', logoutFn);
  }
}

/** Simple view switcher: hides every [data-view] section, shows one. */
export function showView(name) {
  document.querySelectorAll('[data-view]').forEach((s) => { s.hidden = true; });
  const target = document.querySelector(`[data-view="${name}"]`);
  if (target) target.hidden = false;
  document.querySelectorAll('[data-nav]').forEach((b) => {
    b.classList.toggle('active', b.dataset.nav === name);
  });
  window.scrollTo({ top: 0 });
  pushViewState(name);
}

// ---------------------------------------------------------------------------
// In-app navigation history (browser/Android Back support).
// Every view shown through showView()/pushViewState() gets its own history
// entry, so Back returns to the PREVIOUS VIEW inside the app instead of
// leaving the page or landing on a blank screen. When no in-app state
// remains, the browser naturally leaves to the previous page (session,
// role and school are preserved — every page rebuilds its context from
// Supabase Auth on load, so re-entry is safe and never a redirect loop).
// ---------------------------------------------------------------------------
const VIEW_STATE_KEY = '__ssView';
let viewHistoryArmed = false;
let suppressViewPush = false;

/**
 * Arm the history integration for a page. initialView is the view the page
 * shows first (e.g. 'home' / 'dashboard'); the entry state is anchored to it
 * via replaceState (no extra history entry). Call ONCE per page, before or
 * right after the first showView().
 */
export function armViewHistory(initialView) {
  if (viewHistoryArmed) return;
  viewHistoryArmed = true;
  try { history.replaceState({ [VIEW_STATE_KEY]: initialView }, ''); } catch (_) { /* no-op */ }
  window.addEventListener('popstate', (event) => {
    // A state we pushed carries the target view; a foreign/empty state
    // safely falls back to the page's initial view (never a blank page).
    const view = (event.state && event.state[VIEW_STATE_KEY]) || initialView;
    suppressViewPush = true;
    try { showView(view); } finally { suppressViewPush = false; }
  });
}

/** Push a history entry for a view (no-op while replaying popstate). */
export function pushViewState(name) {
  if (!viewHistoryArmed || suppressViewPush || !name) return;
  try {
    if (!history.state || history.state[VIEW_STATE_KEY] !== name) {
      history.pushState({ [VIEW_STATE_KEY]: name }, '');
    }
  } catch (_) { /* no-op */ }
}

// ---------------------------------------------------------------------------
// Global error boundary: a failed module/RPC must never leave a white page.
// Shows a non-blocking Arabic banner with a retry button; the app shell,
// header and session stay intact. Full details always go to console.
// ---------------------------------------------------------------------------
let errorBoundaryArmed = false;
export function armErrorBoundary(onError) {
  if (errorBoundaryArmed) return;
  errorBoundaryArmed = true;

  const report = (type, message, stack) => {
    if (typeof onError !== 'function') return;
    try { onError({ type, message, stack }); } catch { /* أبدًا لا نكسر الصفحة بسبب مراقبة الأخطاء نفسها */ }
  };

  let banner = null;
  const showBanner = () => {
    if (banner) return;
    banner = document.createElement('div');
    banner.style.cssText = 'position:fixed;bottom:16px;left:16px;right:16px;z-index:9999;'
      + 'background:#7f1d1d;color:#fff;padding:12px 16px;border-radius:12px;'
      + 'display:flex;gap:12px;align-items:center;justify-content:space-between;'
      + 'box-shadow:0 8px 24px rgba(0,0,0,.25);font-size:14px;';
    const text = document.createElement('span');
    text.style.cssText = 'display:block;flex:1;min-width:0;white-space:pre-wrap;word-break:break-word;direction:rtl;';
    text.textContent = 'حدث خطأ في التطبيق.\nجاري عرض التفاصيل للتشخيص...';
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'إعادة المحاولة';
    btn.style.cssText = 'background:#fff;color:#7f1d1d;border:0;border-radius:8px;'
      + 'padding:8px 14px;font-weight:700;cursor:pointer;white-space:nowrap;';
    btn.addEventListener('click', () => window.location.reload());
    banner.append(text, btn);
    document.body.appendChild(banner);
    // Auto-dismiss after 12s (the shell is still fully usable).
    setTimeout(() => { banner?.remove(); banner = null; }, 12000);
  };

  const renderDiagnostic = (text, detail) => {
    if (!banner) return;
    const node = banner.querySelector('span');
    if (!node) return;
    const clean = String(detail || text || 'UNKNOWN_ERROR');
    const trimmed = clean.length > 1800 ? clean.slice(0, 1800) + '…' : clean;
    node.textContent = `خطأ التطبيق\n${trimmed}`;
  };

  window.addEventListener('error', (event) => {
    const err = event.error;
    const parts = [
      event.message || err?.message || 'UNKNOWN_ERROR',
      event.filename ? `FILE: ${event.filename}` : '',
      event.lineno ? `LINE: ${event.lineno}` : '',
      event.colno ? `COLUMN: ${event.colno}` : '',
      err?.stack ? `STACK: ${err.stack}` : ''
    ].filter(Boolean);
    const detail = parts.join('\n');
    console.error('Uncaught error:', err || event.message, detail);
    showBanner();
    renderDiagnostic(event.message, detail);
    report('error', event.message || err?.message || 'UNKNOWN_ERROR', err?.stack || detail);
  });
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    const detail = reason?.stack || reason?.message || String(reason || 'UNKNOWN_PROMISE_REJECTION');
    console.error('Unhandled rejection:', reason, detail);
    showBanner();
    renderDiagnostic('Unhandled Promise rejection', `UNHANDLED_REJECTION\n${detail}`);
    report('unhandledrejection', reason?.message || String(reason || 'UNHANDLED_PROMISE_REJECTION'), reason?.stack || detail);
  });
}

/**
 * Fatal initialization error handler: shows the REAL error inside the
 * dashboard instead of leaving the header stuck on "جارٍ التحقق...".
 * Session is kept; no redirect, no auth bypass. Technical detail stays
 * visible for diagnosis in a muted line and in the console.
 */
export function showInitError(error, onError) {
  if (typeof onError === 'function') {
    try { onError({ type: 'init', message: error?.message || String(error), stack: error?.stack }); } catch { /* لا نكسر عرض الخطأ بسبب المراقبة نفسها */ }
  }
  try {
    const who = el('who-label');
    if (who) who.textContent = 'تعذر تحميل اللوحة';
    const body = el('app-body');
    if (body) {
      body.hidden = false;
      body.innerHTML = '<div class="panel" style="margin:16px;">'
        + '<p class="section-title">تعذر تحميل اللوحة</p>'
        + '<p class="empty-state">حدث خطأ أثناء تهيئة الصفحة. جلستك محفوظة — أعد تحميل الصفحة أو حاول لاحقًا.</p>'
        + '<p class="time" style="direction:ltr; text-align:left; word-break:break-all;">' + esc(error && error.message ? error.message : error) + '</p>'
        + '<button type="button" class="quick-action-btn" style="width:100%; margin-top:10px;" onclick="window.location.reload()">إعادة التحميل</button></div>';
    }
  } catch (_) { /* never mask the original error */ }
}


// ============================================================================
// PHASE 25 §33 — direct contact actions for any account that has a phone.
// Moroccan numbers are normalized to international 212XXXXXXXXX form:
//   06XXXXXXXX → 2126XXXXXXXX | +212... → stripped '+' | 00212... → trimmed.
// No phone → empty string (the icons simply don't render).
// ============================================================================
export function normalizeMaPhone(phone) {
  let digits = String(phone || '').replace(/[^\d+]/g, '');
  if (!digits) return null;
  digits = digits.replace(/^\+/, '');
  if (digits.startsWith('00212')) digits = digits.slice(2);
  if (digits.startsWith('212')) return digits;
  if (digits.startsWith('0')) return '212' + digits.slice(1);
  return digits.length === 9 ? '212' + digits : null;
}

export function phoneActions(phone) {
  const intl = normalizeMaPhone(phone);
  if (!intl) return '';
  return `<a class="icon-btn" href="tel:+${intl}" title="اتصال" style="text-decoration:none;">📞</a>
    <a class="icon-btn" href="https://wa.me/${intl}" target="_blank" rel="noopener" title="WhatsApp" style="text-decoration:none;">💬</a>`;
}
