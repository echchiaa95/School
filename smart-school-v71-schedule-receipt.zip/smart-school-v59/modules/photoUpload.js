// ============================================================================
// modules/photoUpload.js
// Uploads a student photo to Supabase Storage (bucket "student-photos",
// created in phase20_badge_maps_transport_driver.sql) and saves the
// resulting public URL via fn_update_student_photo — never stores base64
// in the database, per instruction.
// ============================================================================

import { supabase } from './supabase.js';
import { updateStudentPhoto } from './school.js';

const MAX_INPUT_BYTES = 20 * 1024 * 1024; // Accept large phone photos; resize before upload.
const MAX_OUTPUT_BYTES = 1200 * 1024; // Keep the stored ID photo light for mobile.
const MAX_DIM = 1000;

/**
 * Render a photo box (existing photo or placeholder) with an "add/change
 * photo" control wired to Storage + fn_update_student_photo.
 * @param {HTMLElement} container
 * @param {{studentId:string, schoolId:string, photoUrl?:string}} p
 * @param {(newUrl:string)=>void} onSaved
 */
async function resizeStudentPhoto(file) {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, MAX_DIM / Math.max(bitmap.width, bitmap.height));
  const w = Math.max(1, Math.round(bitmap.width * scale));
  const h = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement('canvas');
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext('2d', { alpha: false });
  ctx.drawImage(bitmap, 0, 0, w, h);
  bitmap.close?.();
  let quality = 0.84;
  let blob = await new Promise(r => canvas.toBlob(r, 'image/jpeg', quality));
  while (blob && blob.size > MAX_OUTPUT_BYTES && quality > 0.55) {
    quality -= 0.07;
    blob = await new Promise(r => canvas.toBlob(r, 'image/jpeg', quality));
  }
  if (!blob) throw new Error('IMAGE_ENCODE_FAILED');
  return new File([blob], 'student-photo.jpg', { type: 'image/jpeg', lastModified: Date.now() });
}

export function renderStudentPhotoBox(container, p, onSaved) {
  const inputId = 'photo-input-' + Math.random().toString(36).slice(2, 8);
  container.innerHTML = `
    <div style="text-align:center;">
      <div id="${inputId}-preview" style="width:120px; height:120px; border-radius:50%; margin:0 auto; overflow:hidden; background:#e5e7eb; display:flex; align-items:center; justify-content:center; font-size:40px;">
        ${p.photoUrl ? `<img src="${p.photoUrl}" alt="" style="width:100%; height:100%; object-fit:cover;">` : '👤'}
      </div>
      <input type="file" id="${inputId}-gallery" accept="image/*" hidden>
      <input type="file" id="${inputId}-camera" accept="image/*" capture="environment" hidden>
      <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:8px;">
        <button type="button" class="quick-action-btn secondary" id="${inputId}-gallery-btn">🖼️ من الجهاز</button>
        <button type="button" class="quick-action-btn secondary" id="${inputId}-camera-btn">📷 التقاط صورة</button>
      </div>
      <div id="${inputId}-error" class="empty-state" style="color:#dc2626; display:none; margin-top:6px;"></div>
    </div>`;

  const galleryInput = container.querySelector(`#${inputId}-gallery`);
  const cameraInput = container.querySelector(`#${inputId}-camera`);
  const galleryBtn = container.querySelector(`#${inputId}-gallery-btn`);
  const cameraBtn = container.querySelector(`#${inputId}-camera-btn`);
  const preview = container.querySelector(`#${inputId}-preview`);
  const errorBox = container.querySelector(`#${inputId}-error`);

  galleryBtn.addEventListener('click', () => galleryInput.click());
  cameraBtn.addEventListener('click', () => cameraInput.click());
  const handleFile = async (file) => {
    if (!file) return;
    errorBox.style.display = 'none';
    if (!file.type.startsWith('image/')) {
      errorBox.textContent = 'الرجاء اختيار ملف صورة.'; errorBox.style.display = 'block'; return;
    }
    if (file.size > MAX_INPUT_BYTES) {
      errorBox.textContent = 'حجم الصورة الأصلي كبير جدًا.'; errorBox.style.display = 'block'; return;
    }

    // Resize/compress every phone image before upload. This also makes modern
    // high-resolution camera photos much smaller and faster on mobile data.
    let uploadFile = file;
    try {
      uploadFile = await resizeStudentPhoto(file);
    } catch (resizeErr) {
      console.warn('Photo resize fallback:', resizeErr);
      // If the browser cannot decode the image, keep the original file.
    }

    const localUrl = URL.createObjectURL(uploadFile);
    preview.innerHTML = `<img src="${localUrl}" alt="" style="width:100%; height:100%; object-fit:cover;">`;
    galleryBtn.disabled = true; cameraBtn.disabled = true;
    galleryBtn.textContent = 'جارٍ الرفع...';

    try {
      const ext = 'jpg';
      const path = `${p.schoolId}/${p.studentId}.${ext}`;
      const { error: upErr } = await supabase.storage
        .from('student-photos')
        .upload(path, uploadFile, { upsert: true, cacheControl: '3600', contentType: uploadFile.type });
      if (upErr) throw upErr;

      const { data: pub } = supabase.storage.from('student-photos').getPublicUrl(path);
      const publicUrl = pub.publicUrl + '?v=' + Date.now(); // cache-bust so "change photo" shows instantly

      const res = await updateStudentPhoto(p.studentId, publicUrl);
      if (!res.ok) throw new Error(res.error);

      galleryBtn.textContent = '🖼️ من الجهاز';
      cameraBtn.textContent = '📷 التقاط صورة';
      galleryBtn.disabled = false; cameraBtn.disabled = false;
      onSaved && onSaved(publicUrl);
    } catch (e) {
      console.error('Photo upload failed:', e);
      errorBox.textContent = 'تعذر رفع الصورة، حاول مرة أخرى.';
      errorBox.style.display = 'block';
      galleryBtn.textContent = '🖼️ من الجهاز';
      cameraBtn.textContent = '📷 التقاط صورة';
      galleryBtn.disabled = false; cameraBtn.disabled = false;
    }
  };
  galleryInput.addEventListener('change', () => handleFile(galleryInput.files?.[0]));
  cameraInput.addEventListener('change', () => handleFile(cameraInput.files?.[0]));
}
