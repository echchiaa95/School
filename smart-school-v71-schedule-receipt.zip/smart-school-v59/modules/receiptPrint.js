// ============================================================================
// modules/receiptPrint.js — Phase 69
// وصل احترافي موحَّد: ترويسة المؤسسة (شعار+اسم) بنفس هوية reportExport.js
// (كحلي+ذهبي، خط Tajawal) + باركود (Code128) لرقم الوصل في الأسفل.
// ============================================================================

const JSBARCODE_CDN = 'https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js';

/**
 * يفتح نافذة طباعة مستقلة لوصل احترافي مع باركود، ويُطلق الطباعة تلقائيًا.
 * rows: [[تسمية, قيمة], ...] — تُعرض كصفوف داخل الوصل.
 */
export function printReceipt({
  schoolName = '', logoUrl = '', title = 'وصل', receiptNo = '',
  rows = [], totalLabel = 'المجموع', totalValue = '', footerNote = '',
}) {
  const win = window.open('', '_blank', 'width=420,height=680');
  if (!win) { alert('يرجى السماح بالنوافذ المنبثقة لطباعة الوصل.'); return; }

  const escape = (v) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const rowsHtml = rows.filter(([, v]) => v !== null && v !== undefined && v !== '')
    .map(([k, v]) => `<div class="r"><span class="k">${escape(k)}</span><span class="v">${escape(v)}</span></div>`).join('');

  win.document.write(`<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${escape(title)}</title>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap" rel="stylesheet">
<style>
  :root{ --navy-900:#0b1f33; --navy-700:#16334e; --navy-600:#1d4265; --gold-500:#c9a227; --gold-400:#ddb84c;
    --ink:#14212e; --muted:#5b6b7c; --line:#e3e9f0; }
  @page { size: 80mm auto; margin: 6mm; }
  * { box-sizing: border-box; }
  body { font-family:'Tajawal','Segoe UI',Tahoma,Arial,sans-serif; color:var(--ink); margin:0; padding:14px; direction:rtl; }
  .letterhead { text-align:center; border-bottom:3px solid var(--navy-700); padding-bottom:10px; margin-bottom:12px; position:relative; }
  .letterhead::after { content:''; position:absolute; inset-inline-start:35%; bottom:-3px; width:30%; height:3px;
    background:linear-gradient(90deg,var(--gold-500),var(--gold-400)); }
  .letterhead img { width:52px; height:52px; object-fit:contain; border-radius:8px; margin-bottom:4px; }
  .letterhead h1 { margin:0; font-size:16px; color:var(--navy-700); font-weight:800; }
  h2.title { text-align:center; font-size:14px; color:var(--navy-900); margin:10px 0; font-weight:800; }
  h2.title::before, h2.title::after { content:'◆'; color:var(--gold-500); font-size:8px; margin:0 8px; vertical-align:middle; }
  .r { display:flex; justify-content:space-between; gap:10px; font-size:12.5px; padding:5px 0; border-bottom:1px dashed var(--line); }
  .r .k { color:var(--muted); }
  .r .v { font-weight:700; }
  .total-box { margin-top:10px; padding:10px; border-radius:10px; background:#f8fafc; border-inline-start:4px solid var(--gold-500);
    display:flex; justify-content:space-between; font-size:14px; font-weight:800; color:var(--navy-700); }
  .barcode-zone { text-align:center; margin-top:18px; }
  .barcode-zone svg { max-width:100%; }
  .receipt-no-fallback { font-family:monospace; font-size:12px; letter-spacing:2px; }
  .footer-note { margin-top:14px; font-size:10px; color:var(--muted); text-align:center; }
  @media print { body { padding:0; } }
</style></head>
<body>
  <div class="letterhead">
    ${logoUrl ? `<img src="${escape(logoUrl)}" alt="">` : ''}
    <h1>${escape(schoolName || 'المؤسسة التعليمية')}</h1>
  </div>
  <h2 class="title">${escape(title)}</h2>
  ${rowsHtml}
  <div class="total-box"><span>${escape(totalLabel)}</span><span>${escape(totalValue)}</span></div>
  <div class="barcode-zone">
    <svg id="barcode"></svg>
    <div class="receipt-no-fallback" id="barcode-fallback" style="display:none;">${escape(receiptNo)}</div>
  </div>
  ${footerNote ? `<div class="footer-note">${escape(footerNote)}</div>` : ''}
  <script src="${JSBARCODE_CDN}"><\/script>
  <script>
    (function () {
      var printed = false;
      function doPrint() { if (printed) return; printed = true; try { window.focus(); window.print(); } catch (e) {} }
      try {
        if (window.JsBarcode && ${JSON.stringify(!!receiptNo)}) {
          JsBarcode('#barcode', ${JSON.stringify(receiptNo)}, {
            format: 'CODE128', width: 1.6, height: 42, displayValue: true, fontSize: 11, margin: 0,
          });
        } else {
          document.getElementById('barcode-fallback').style.display = 'block';
        }
      } catch (e) {
        document.getElementById('barcode-fallback').style.display = 'block';
      }
      setTimeout(doPrint, 350);
    })();
  <\/script>
</body></html>`);
  win.document.close();
}
