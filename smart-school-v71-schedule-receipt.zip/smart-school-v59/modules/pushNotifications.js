// ============================================================================
// modules/pushNotifications.js — Phase 68
// تفعيل/إلغاء إشعارات Push الحقيقية (تصل حتى والتطبيق مغلق أو المتصفح مُطفأ
// الشاشة). يعمل مع أي صفحة تستورده، بشرط وجود sw.js في جذر المشروع.
// ============================================================================
import { supabase } from './supabase.js';

// المفتاح العام (Public Key) فقط — آمن تمامًا في كود العميل. المفتاح الخاص
// (Private Key) يبقى حصريًا في Supabase Edge Function كـ secret، لا يظهر هنا أبدًا.
const VAPID_PUBLIC_KEY = 'BNhRbMDDP48zJrfEFrlS8zjsvQ_xGsik4GS5S49QDXXr2a9O5Y6Wr8x7HHxKoFXqfU3cB2hULjjL-1w-pMcJz54';

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  return Uint8Array.from([...rawData].map((c) => c.charCodeAt(0)));
}

export function isPushSupported() {
  return 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
}

export async function isPushEnabled() {
  if (!isPushSupported()) return false;
  try {
    const reg = await navigator.serviceWorker.getRegistration('./');
    const sub = await reg?.pushManager.getSubscription();
    return !!sub;
  } catch {
    return false;
  }
}

/** يطلب الإذن، يُسجِّل Service Worker، يشترك في Push، ويحفظ الاشتراك في القاعدة. */
export async function enablePushNotifications() {
  if (!isPushSupported()) {
    return { ok: false, error: 'هذا المتصفح لا يدعم إشعارات Push.' };
  }
  try {
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') {
      return { ok: false, error: 'تم رفض إذن الإشعارات من إعدادات المتصفح.' };
    }

    const reg = await navigator.serviceWorker.register('./sw.js', { scope: './' });
    await navigator.serviceWorker.ready;

    let sub = await reg.pushManager.getSubscription();
    if (!sub) {
      sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
      });
    }

    const json = sub.toJSON();
    const { error } = await supabase.rpc('fn_save_push_subscription', {
      p_endpoint: json.endpoint,
      p_p256dh: json.keys.p256dh,
      p_auth: json.keys.auth,
      p_user_agent: navigator.userAgent,
    });
    if (error) return { ok: false, error: error.message };

    return { ok: true };
  } catch (e) {
    return { ok: false, error: e?.message || 'تعذر تفعيل الإشعارات.' };
  }
}

/** يُلغي الاشتراك محليًا وفي القاعدة. */
export async function disablePushNotifications() {
  try {
    const reg = await navigator.serviceWorker.getRegistration('./');
    const sub = await reg?.pushManager.getSubscription();
    if (sub) {
      await supabase.rpc('fn_remove_push_subscription', { p_endpoint: sub.endpoint });
      await sub.unsubscribe();
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e?.message || 'تعذر إلغاء التفعيل.' };
  }
}
