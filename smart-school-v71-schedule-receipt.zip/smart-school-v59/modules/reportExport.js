// ============================================================================
// modules/reportExport.js — Phase 63
// تصدير احترافي مشترك لكل التقارير: Excel حقيقي (SheetJS) + PDF عبر نافذة
// طباعة مستقلة بترويسة رسمية (شعار المؤسسة + عنوان + جدول + خلاصة + توقيع).
// اعتماد الطباعة بدل مكتبة PDF لأن دعم العربية RTL في jsPDF غير موثوق، بينما
// طباعة HTML حقيقية تدعم العربية بشكل كامل مضمون عبر المتصفح.
// ============================================================================

let sheetJsLoading = null;
function loadSheetJs() {
  if (window.XLSX) return Promise.resolve();
  if (sheetJsLoading) return sheetJsLoading;
  sheetJsLoading = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js';
    s.onload = resolve;
    s.onerror = () => reject(new Error('تعذر تحميل مكتبة Excel، تحقق من الاتصال.'));
    document.head.appendChild(s);
  });
  return sheetJsLoading;
}

/**
 * تصدير جدول (أو عدة جداول) إلى ملف Excel حقيقي (.xlsx).
 * sheets: [{ name, headers, rows }]  — إن مُرِّر جدول واحد فقط، يمكن تمرير
 * { headers, rows } مباشرة بدل مصفوفة.
 */
export async function exportToExcel(filename, sheets) {
  await loadSheetJs();
  const list = Array.isArray(sheets) ? sheets : [{ name: 'البيانات', ...sheets }];
  const wb = window.XLSX.utils.book_new();
  list.forEach((sheet) => {
    const aoa = [sheet.headers, ...sheet.rows];
    const ws = window.XLSX.utils.aoa_to_sheet(aoa);
    ws['!cols'] = sheet.headers.map(() => ({ wch: 18 }));
    window.XLSX.utils.book_append_sheet(wb, ws, (sheet.name || 'ورقة1').slice(0, 31));
  });
  window.XLSX.writeFile(wb, filename.endsWith('.xlsx') ? filename : filename + '.xlsx');
}

/**
 * يفتح نافذة مستقلة بترويسة رسمية احترافية (شعار + اسم المؤسسة + عنوان +
 * جدول + خلاصة + خط توقيع) ويشغّل نافذة الطباعة تلقائيًا — يحفظها المستخدم
 * كـ PDF عبر خيار "حفظ كـ PDF" في نافذة الطباعة (يدعم العربية بالكامل).
 */
export function printReport({
  schoolName = '', logoUrl = '', title = 'تقرير', meta = [],
  headers = [], rows = [], summary = [], footerNote = '',
}) {
  const win = window.open('', '_blank', 'width=900,height=1000');
  if (!win) { alert('يرجى السماح بالنوافذ المنبثقة لطباعة التقرير.'); return; }

  const escape = (v) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const metaHtml = meta.filter(([, v]) => v !== null && v !== undefined && v !== '')
    .map(([k, v]) => `<div class="meta-item"><span class="k">${escape(k)}</span><span class="v">${escape(v)}</span></div>`).join('');
  const rowsHtml = rows.length
    ? rows.map((r) => `<tr>${r.map((c) => `<td>${escape(c)}</td>`).join('')}</tr>`).join('')
    : `<tr><td colspan="${headers.length || 1}" style="text-align:center;padding:20px;color:#94a3b8;">لا توجد بيانات</td></tr>`;
  const summaryHtml = summary.length
    ? `<div class="summary-box">${summary.map(([k, v]) => `<div><b>${escape(k)}:</b> ${escape(v)}</div>`).join('')}</div>`
    : '';

  win.document.write(`<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${escape(title)}</title>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap" rel="stylesheet">
<style>
  :root{ --navy-900:#0b1f33; --navy-700:#16334e; --navy-600:#1d4265; --gold-500:#c9a227; --gold-400:#ddb84c;
    --ink:#14212e; --muted:#5b6b7c; --line:#e3e9f0; }
  @page { size: A4; margin: 16mm 14mm; }
  * { box-sizing: border-box; }
  body { font-family:'Tajawal','Segoe UI',Tahoma,Arial,sans-serif; color:var(--ink); margin:0; padding:24px; direction:rtl; }
  .letterhead { display:flex; align-items:center; gap:14px; border-bottom:3px solid var(--navy-700);
    padding-bottom:14px; margin-bottom:18px; position:relative; }
  .letterhead::after { content:''; position:absolute; inset-inline-start:0; bottom:-3px; width:120px; height:3px;
    background:linear-gradient(90deg,var(--gold-500),var(--gold-400)); }
  .letterhead img { width:64px; height:64px; object-fit:contain; border-radius:8px; }
  .letterhead h1 { margin:0; font-size:19px; color:var(--navy-700); font-weight:800; }
  .letterhead .sub { color:var(--muted); font-size:12px; margin-top:2px; }
  h2.title { text-align:center; font-size:17px; color:var(--navy-900); margin:14px 0 16px; font-weight:800; }
  h2.title::before, h2.title::after { content:'◆'; color:var(--gold-500); font-size:10px; margin:0 10px; vertical-align:middle; }
  .meta-row { display:flex; flex-wrap:wrap; gap:8px 24px; margin-bottom:16px; font-size:13px; }
  .meta-item { display:flex; gap:5px; }
  .meta-item .k { font-weight:700; color:var(--navy-700); }
  table { width:100%; border-collapse:collapse; font-size:12.5px; margin-bottom:16px; }
  th, td { border:1px solid var(--line); padding:7px 8px; text-align:center; }
  th { background:#eef2f7; color:var(--navy-700); font-weight:700; }
  tr:nth-child(even) td { background:#f8fafc; }
  .summary-box { border:1px solid var(--line); border-radius:12px; padding:12px 16px; background:#f8fafc;
    margin-bottom:24px; font-size:13.5px; line-height:2; border-inline-start:4px solid var(--gold-500); }
  .signatures { display:flex; justify-content:space-between; margin-top:50px; font-size:13px; color:var(--navy-700); }
  .signatures div { text-align:center; width:220px; }
  .signatures .line { border-top:1px solid var(--muted); margin-top:46px; padding-top:6px; }
  .footer-note { margin-top:30px; font-size:11px; color:var(--muted); text-align:center; }
  @media print { body { padding:0; } }
</style></head>
<body>
  <div class="letterhead">
    ${logoUrl ? `<img src="${escape(logoUrl)}" alt="">` : ''}
    <div><h1>${escape(schoolName || 'المؤسسة التعليمية')}</h1><div class="sub">وثيقة رسمية صادرة عن النظام</div></div>
  </div>
  <h2 class="title">${escape(title)}</h2>
  <div class="meta-row">${metaHtml}</div>
  <table><thead><tr>${headers.map((h) => `<th>${escape(h)}</th>`).join('')}</tr></thead><tbody>${rowsHtml}</tbody></table>
  ${summaryHtml}
  <div class="signatures">
    <div><div class="line">توقيع المسؤول</div></div>
    <div><div class="line">ختم المؤسسة</div></div>
  </div>
  ${footerNote ? `<div class="footer-note">${escape(footerNote)}</div>` : ''}
</body></html>`);
  win.document.close();
  let printed = false;
  const doPrint = () => { if (printed) return; printed = true; try { win.focus(); win.print(); } catch {} };
  win.onload = doPrint;
  // بعض المتصفحات لا تطلق onload لنوافذ document.write — احتياط:
  setTimeout(doPrint, 400);
}
