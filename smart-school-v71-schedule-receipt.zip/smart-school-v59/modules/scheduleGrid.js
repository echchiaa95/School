// ============================================================================
// modules/scheduleGrid.js — Phase 70
// منطق الجدول الزمني الأسبوعي (شبكة 8 حصص × 7 أيام + طباعة + تحميل PDF)،
// مُستخرَج من adminConsole.js ليُستعمل بنفس الشكل تمامًا في admin.html
// وguard.html — بدون أي تكرار للكود.
// ============================================================================
import { esc } from './ui.js';

export const WEEKDAYS_AR = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

export function addMinutes(hhmm, minutes) {
  const parts = String(hhmm).slice(0, 5).split(':').map(Number);
  const total = parts[0] * 60 + parts[1] + minutes;
  return String(Math.floor((total % 1440) / 60)).padStart(2, '0') + ':' + String(total % 60).padStart(2, '0');
}

export function periodTimeRange(period, cfg) {
  const n = Number(period);
  if (!cfg || n < 1 || n > 8) return { start: '—', end: '—' };
  const morning = n <= 4;
  const count = morning ? n : n - 4;
  const startBase = String(morning ? (cfg.morning_start || '08:00') : (cfg.afternoon_start || '14:00'));
  const mins = Number(morning ? (cfg.morning_lesson_minutes || 60) : (cfg.afternoon_lesson_minutes || 60));
  return { start: addMinutes(startBase, (count - 1) * mins), end: addMinutes(startBase, count * mins) };
}

function timetableCellHtml(row, weekday, period, canEdit) {
  if (!row) {
    return canEdit
      ? '<div class="schedule-cell-content schedule-empty-cell">'
        + '<button type="button" class="icon-btn schedule-add-btn" data-add-lesson="1" data-weekday="' + esc(weekday) + '" data-period="' + esc(period) + '" title="إضافة حصة">＋</button>'
        + '<span class="schedule-add-label">إضافة</span></div>'
      : '<div class="schedule-cell-content schedule-empty-cell"><span class="schedule-add-label">—</span></div>';
  }
  return '<div class="schedule-cell-content">'
    + '<strong>' + esc(row.subject_name || '—') + '</strong>'
    + '<span>' + esc(row.teacher_name || '—') + '</span>'
    + (canEdit ? '<div class="schedule-cell-actions">'
      + '<button type="button" class="icon-btn" data-edit-lesson="' + esc(row.id) + '" data-weekday="' + esc(row.weekday) + '" data-period="' + esc(row.period) + '" data-subject="' + esc(row.subject_id || '') + '" data-teacher="' + esc(row.teacher_id || '') + '" title="تعديل">✏️</button>'
      + '<button type="button" class="icon-btn" data-del-lesson="' + esc(row.id) + '" title="حذف">🗑️</button>'
      + '</div>' : '')
    + '</div>';
}

/** يبني HTML الجدول الأسبوعي الكامل (ترويسة + شبكة + خلاصة). */
export function buildWeeklyTimetable(rows, className, periodsCfg, canEdit = true) {
  const bySlot = new Map();
  (rows || []).forEach((r) => bySlot.set(Number(r.weekday) + '-' + Number(r.period), r));
  const days = [0, 1, 2, 3, 4, 5, 6];
  const html = [];
  html.push('<div class="schedule-toolbar"><div><strong>الجدول الأسبوعي</strong><span class="schedule-subtitle">' + esc(className || '') + '</span></div>');
  html.push('<div class="schedule-actions"><button type="button" class="quick-action-btn secondary" id="sc-print">🖨️ طباعة الجدول</button><button type="button" class="quick-action-btn" id="sc-pdf">⬇️ تحميل PDF</button></div></div>');
  html.push('<div class="schedule-scroll"><table class="weekly-schedule"><thead><tr><th class="period-head">الحصة</th>');
  days.forEach((d) => html.push('<th>' + WEEKDAYS_AR[d] + '</th>'));
  html.push('</tr></thead><tbody>');
  for (let period = 1; period <= 8; period++) {
    const tr = period <= 4 ? 'morning' : 'afternoon';
    const t = periodTimeRange(period, periodsCfg);
    html.push('<tr class="schedule-' + tr + '"><th class="period-head"><span>الحصة ' + period + '</span><small>' + t.start + ' – ' + t.end + '</small></th>');
    days.forEach((d) => html.push('<td>' + timetableCellHtml(bySlot.get(d + '-' + period), d, period, canEdit) + '</td>'));
    html.push('</tr>');
    if (period === 4) html.push('<tr class="schedule-break"><td colspan="8">☀️ فترة الزوال</td></tr>');
  }
  html.push('</tbody></table></div>');
  html.push('<div class="schedule-legend"><span>🌅 الصباح: 4 حصص</span><span>☀️ الزوال: 4 حصص</span><span>' + (rows || []).length + ' حصة مسجلة هذا الأسبوع</span></div>');
  return html.join('');
}

function extractWeeklyTable(rows, className, periodsCfg, canEdit) {
  const html = buildWeeklyTimetable(rows, className, periodsCfg, canEdit);
  const a = html.indexOf('<div class="schedule-scroll">');
  const b = html.indexOf('<div class="schedule-legend">');
  return a >= 0 && b > a ? html.slice(a, b) : html;
}

/** يفتح نافذة طباعة للجدول الأسبوعي بترويسة المؤسسة (شعار+اسم). */
export function printWeeklyTimetable(rows, className, schoolProfile, periodsCfg) {
  const school = schoolProfile || {};
  const grid = extractWeeklyTable(rows, className, periodsCfg, false);
  const win = window.open('', '_blank', 'width=1200,height=800');
  if (!win) { alert('يرجى السماح بالنوافذ المنبثقة لطباعة الجدول.'); return; }
  const css = '<style>body{font-family:Arial,Tahoma,sans-serif;color:#14212e;margin:24px;direction:rtl}.weekly-schedule{width:100%;border-collapse:collapse;table-layout:fixed}.weekly-schedule th,.weekly-schedule td{border:1px solid #cbd5e1;padding:7px;text-align:center;vertical-align:middle}.weekly-schedule th{background:#f8fafc}.period-head{width:125px}.period-head span,.period-head small{display:block}.schedule-cell-content strong,.schedule-cell-content span{display:block}.schedule-cell-content span{font-size:11px;color:#64748b;margin-top:4px}.schedule-cell-actions{display:none}.schedule-break td{background:#fffbeb;font-weight:700;padding:5px}@media print{body{margin:10mm}}</style>';
  const header = '<header style="text-align:center;margin-bottom:18px;">'
    + (school.logo_url ? '<img src="' + esc(school.logo_url) + '" crossorigin="anonymous" style="max-height:70px;max-width:180px" alt="الشعار"><br>' : '')
    + '<h1>' + esc(school.name || 'المؤسسة') + '</h1><h2>الجدول الدراسي — ' + esc(className || '') + '</h2></header>';
  win.document.write('<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>الجدول الدراسي</title>' + css + '</head><body>' + header + grid + '<script>window.onload=function(){setTimeout(function(){window.print()},300)};<\/script></body></html>');
  win.document.close();
}

function loadExternalScript(src, globalName) {
  return new Promise((resolve, reject) => {
    if (window[globalName]) return resolve(window[globalName]);
    const existing = document.querySelector('script[data-ss-lib="' + globalName + '"]');
    if (existing) { existing.addEventListener('load', () => resolve(window[globalName])); existing.addEventListener('error', reject); return; }
    const s = document.createElement('script');
    s.src = src; s.async = true; s.dataset.ssLib = globalName;
    s.onload = () => window[globalName] ? resolve(window[globalName]) : reject(new Error(globalName + ' unavailable'));
    s.onerror = reject; document.head.appendChild(s);
  });
}

/** يُنشئ ملف PDF حقيقي (عبر html2canvas+jsPDF) بدل الاعتماد فقط على الطباعة. */
export async function downloadWeeklyTimetablePdf(rows, className, schoolProfile, periodsCfg) {
  const school = schoolProfile || {};
  const wrap = document.createElement('div');
  wrap.dir = 'rtl';
  wrap.style.cssText = 'position:fixed;left:-100000px;top:0;width:1120px;padding:28px;background:#fff;color:#14212e;font-family:Arial,Tahoma,sans-serif;z-index:-1;';
  const title = document.createElement('div');
  title.style.cssText = 'text-align:center;margin-bottom:18px;';
  title.innerHTML = (school.logo_url ? '<img src="' + esc(school.logo_url) + '" crossorigin="anonymous" style="max-height:70px;max-width:180px;display:block;margin:0 auto 8px" alt="الشعار">' : '')
    + '<h1 style="margin:0;font-size:25px">' + esc(school.name || 'المؤسسة') + '</h1>'
    + '<h2 style="margin:6px 0;font-size:18px">الجدول الدراسي — ' + esc(className || '') + '</h2>';
  wrap.appendChild(title);
  const content = document.createElement('div');
  content.innerHTML = extractWeeklyTable(rows, className, periodsCfg, false);
  const pdfOnlyStyle = document.createElement('style');
  pdfOnlyStyle.textContent = '.schedule-cell-actions,.schedule-add-btn,.schedule-add-label,.schedule-actions{display:none!important;visibility:hidden!important;}';
  wrap.appendChild(pdfOnlyStyle);
  wrap.appendChild(content);
  document.body.appendChild(wrap);
  try {
    await loadExternalScript('https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js', 'html2canvas');
    await loadExternalScript('https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js', 'jspdf');
    const canvas = await window.html2canvas(wrap, { scale: 2, useCORS: true, backgroundColor: '#ffffff', logging: false });
    const Pdf = window.jspdf?.jsPDF || window.jsPDF;
    if (!Pdf) throw new Error('PDF library unavailable');
    const pdf = new Pdf({ orientation: 'landscape', unit: 'mm', format: 'a4' });
    const pageW = pdf.internal.pageSize.getWidth();
    const pageH = pdf.internal.pageSize.getHeight();
    const margin = 7;
    const ratio = Math.min((pageW - margin * 2) / canvas.width, (pageH - margin * 2) / canvas.height);
    const w = canvas.width * ratio, h = canvas.height * ratio;
    pdf.addImage(canvas.toDataURL('image/jpeg', 0.92), 'JPEG', (pageW - w) / 2, (pageH - h) / 2, w, h);
    pdf.save('الجدول-' + String(className || 'القسم').replace(/[^\u0600-\u06FF\w\-]+/g, '_') + '.pdf');
    return { ok: true };
  } catch (error) {
    console.error('schedule PDF error:', error);
    printWeeklyTimetable(rows, className, schoolProfile, periodsCfg);
    return { ok: false, fellBackToPrint: true };
  } finally { wrap.remove(); }
}
