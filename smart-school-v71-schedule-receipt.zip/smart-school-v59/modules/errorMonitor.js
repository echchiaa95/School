// ============================================================================
// modules/errorMonitor.js — Phase 67
// مراقبة أخطاء طرف العميل بدل الاعتماد فقط على تقارير المستخدمين.
//
// طبقتان مستقلتان:
// 1) تسجيل مجاني بالكامل في جدول client_error_logs (Supabase) — يعمل تلقائيًا
//    بدون أي إعداد إضافي، ويظهر في لوحة SuperAdmin مباشرة.
// 2) Sentry (اختياري تمامًا) — إن وضعت SENTRY_DSN أدناه، تُفعَّل تلقائيًا
//    وتحصل على تتبع أعمق (stack trace مُفكَّك، تنبيهات بريدية، إلخ) عبر لوحة
//    sentry.io الخاصة بحسابك. بدون DSN، هذا الجزء مُعطَّل بالكامل ولا يُحمَّل
//    أي سكريبت خارجي — الطبقة الأولى تبقى كافية للاستعمال اليومي ومجانية 100%.
// ============================================================================
import { armErrorBoundary } from './ui.js';
import { supabase } from './supabase.js';

// ضع DSN مشروعك من sentry.io هنا لتفعيل الطبقة الثانية (اختياري):
// مثال: 'https://xxxxxxxx@o000000.ingest.sentry.io/0000000'
const SENTRY_DSN = '';
const SENTRY_BUNDLE_URL = 'https://browser.sentry-cdn.com/7.120.3/bundle.min.js';

let sentryLoadAttempted = false;
function maybeLoadSentry() {
  if (!SENTRY_DSN || sentryLoadAttempted) return;
  sentryLoadAttempted = true;
  const script = document.createElement('script');
  script.src = SENTRY_BUNDLE_URL;
  script.crossOrigin = 'anonymous';
  script.onload = () => {
    try {
      window.Sentry?.init({ dsn: SENTRY_DSN, tracesSampleRate: 0 });
    } catch { /* Sentry اختياري — فشل تحميله لا يجب أن يؤثر على التطبيق */ }
  };
  document.head.appendChild(script);
}

/** يُسجِّل خطأً واحدًا — لا يرمي استثناءً أبدًا مهما حدث. */
export async function logClientError(page, message, stack, level = 'error') {
  try {
    await supabase.rpc('fn_log_client_error', {
      p_page: page,
      p_message: String(message || 'UNKNOWN_ERROR').slice(0, 2000),
      p_stack: stack ? String(stack).slice(0, 4000) : null,
      p_level: level,
      p_user_agent: navigator.userAgent,
      p_page_url: location.href,
    });
  } catch { /* تسجيل الخطأ نفسه يجب ألا يُسبب خطأً آخر أبدًا */ }
  if (window.Sentry?.captureException) {
    try { window.Sentry.captureException(new Error(message)); } catch { /* تجاهل */ }
  }
}

/**
 * نقطة الدخول الوحيدة — تُستدعى مرة واحدة في بداية كل صفحة بدل
 * armErrorBoundary() مباشرة. تُفعِّل حدود الأخطاء الموجودة أصلًا + تسجّل كل
 * خطأ غير مُلتقط تلقائيًا في قاعدة البيانات (ومنها إلى Sentry إن كان مُفعَّلًا).
 */
export function initErrorMonitor(pageName) {
  maybeLoadSentry();
  armErrorBoundary((info) => {
    logClientError(pageName, info.message, info.stack);
  });
}

/** تُستعمل مع showInitError(error, reportInitError('admin.html')) عند الحاجة. */
export function reportInitError(pageName) {
  return (info) => logClientError(pageName, info.message, info.stack, 'error');
}
