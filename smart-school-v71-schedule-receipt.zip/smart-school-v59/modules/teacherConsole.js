import { requireAuth, logout } from './auth.js';
import {
  el, esc, fmtDate, fmtDateTime, toast, statCard,
  loadingHtml, emptyHtml, errorHtml, initPageHeader, showView,
  armViewHistory, showInitError, openNotificationDetails,
} from './ui.js';
import { initErrorMonitor } from './errorMonitor.js';
import {
  teacherClasses, getClassAttendance, saveAttendance, addGrade,
  listStudentGradesForTeacher, listStudentAssessmentMarks, getClassSchedule, myTeacherSubjects, gradeSubjectCoefficients, reportIncident,
  createGradeAssessment, saveGradeMark, listGradeAssessments, updateGradeAssessmentCoefficient,
  listMyNotifications, markNotificationRead, unreadNotificationsCount, deleteMyNotification,
  getSchoolProfile, teacherClassRoster, getMyTeacherSchedule, isDebug,
} from './school.js';

// Debug-only logging (SMART_SCHOOL_DEBUG=1): ids only, never tokens/secrets.
const dbg = (...a) => { if (isDebug()) console.log(...a); };

const WEEKDAYS_AR = { 0: 'الأحد', 1: 'الاثنين', 2: 'الثلاثاء', 3: 'الأربعاء', 4: 'الخميس', 5: 'الجمعة', 6: 'السبت' };
const ATT_STATES = [
  ['present', 'حاضر', 'active-present'],
  ['absent', 'غائب', 'active-absent'],
  ['late', 'متأخر', 'active-late'],
  ['excused', 'مبرر', 'active-excused'],
];

let ctx = null;
let classes = [];
let subjects = [];
let coefficientRows = [];
let gradeRoster = [];
let roster = []; // current attendance roster: {student_id, full_name, status}
const attendanceMarks = new Map(); // student_id -> status

function classLabel(c) {
  return `${c.name || ''}${c.level ? ' — ' + c.level : ''}${c.year_name ? ' (' + c.year_name + ')' : ''}`;
}

function fillClassSelect(selectEl) {
  if (!selectEl) return;
  selectEl.innerHTML = classes.length
    ? classes.map((c) => `<option value="${c.class_id}">${esc(classLabel(c))}</option>`).join('')
    : '<option value="">لا توجد أقسام مسندة</option>';
}

// ---- Home -------------------------------------------------------------------
async function loadHome() {
  const stats = el('dash-stats');
  const list = el('my-classes');
  if (!stats || !list) throw new Error('TEACHER_HOME_ELEMENTS_MISSING');
  stats.innerHTML = loadingHtml();
  list.innerHTML = '';
  const res = await teacherClasses();
  if (!res.ok) {
    // FIX (Phase 23): a real error here now gets a retry button instead of
    // a dead end — per your instruction, no generic message should be a
    // trap with no way forward.
    stats.innerHTML = errorHtml(res.error);
    list.innerHTML = `<button type="button" class="quick-action-btn secondary" id="home-retry" style="width:100%;">🔄 إعادة المحاولة</button>`;
    el('home-retry')?.addEventListener('click', loadHome);
    return;
  }
  classes = res.data || [];
  const today = new Date().getDay();
  const studentsTotal = classes.reduce((sum, c) => sum + (c.student_count || 0), 0);
  stats.innerHTML = `<div class="stats-grid">${
    statCard(classes.length, 'الأقسام المسندة')
    + statCard(studentsTotal, 'التلاميذ')
    + statCard(WEEKDAYS_AR[today] || '', 'اليوم', 'tone-gold')
  }</div>`;

  if (!classes.length) {
    list.innerHTML = emptyHtml('لا توجد أقسام مسندة إليك حاليًا. تواصل مع إدارة المؤسسة.');
    return;
  }
  list.innerHTML = `<div class="modules-grid">${classes.map((c) => `
    <button type="button" class="module-card" data-open-class="${c.class_id}">
      <span class="module-icon">🏫</span>${esc(classLabel(c))}
      <span class="badge badge-blue">${c.student_count ?? 0} تلميذ</span>
    </button>`).join('')}</div>`;
  list.querySelectorAll('[data-open-class]').forEach((b) => {
    b.addEventListener('click', () => {
      el('att-class').value = b.dataset.openClass;
      showView('attendance');
      loadRoster();
    });
  });

  ['att-class', 'gr-class', 'inc-class'].forEach((id) => fillClassSelect(el(id)));
}

// ---- Attendance -------------------------------------------------------------
function renderRoster() {
  const host = el('att-roster');
  if (!roster.length) {
    host.innerHTML = emptyHtml('لا يوجد تلاميذ في هذا القسم.');
    return;
  }
  const counts = roster.reduce((a, s) => { const st = attendanceMarks.get(s.student_id) || s.status || ''; if (st) a[st] = (a[st]||0)+1; return a; }, {});
  host.innerHTML = `<div class="stats-grid" style="margin-bottom:10px;">${statCard(counts.present||0,'حاضر','tone-green')}${statCard(counts.absent||0,'غائب','tone-red')}${statCard(counts.late||0,'متأخر','tone-gold')}</div><div style="display:grid;gap:7px;">${roster.map((s, i) => {
    const current = attendanceMarks.get(s.student_id) || s.status || '';
    return `<div class="detail-row" style="display:grid;grid-template-columns:minmax(120px,1fr) auto;gap:8px;align-items:center;padding:9px 10px;border:1px solid #e5e7eb;border-radius:12px;">
      <div><strong>${i+1}. ${esc(s.full_name)}</strong><div class="time">#${esc(s.student_number||'—')}</div></div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end;">${ATT_STATES.map(([key, label, cls]) => `<button type="button" class="att-btn ${current === key ? cls : ''}" data-student="${s.student_id}" data-status="${key}">${label}</button>`).join('')}</div>
    </div>`;
  }).join('')}</div>`;
  host.querySelectorAll('.att-btn').forEach((b) => {
    b.addEventListener('click', () => {
      attendanceMarks.set(b.dataset.student, b.dataset.status);
      renderRoster();
    });
  });
}

async function loadRoster() {
  const classId = el('att-class').value;
  const date = el('att-date').value;
  if (!classId) { toast('لا توجد أقسام مسندة إليك حاليًا.', 'error'); return; }
  if (!date) { toast('اختر التاريخ', 'error'); return; }
  el('att-panel').hidden = false;
  el('att-roster').innerHTML = loadingHtml();
  const res = await getClassAttendance(classId, date);
  if (!res.ok) {
    el('att-roster').innerHTML = errorHtml(res.error)
      + `<button type="button" class="quick-action-btn secondary" id="att-retry" style="width:100%; margin-top:8px;">🔄 إعادة المحاولة</button>`;
    el('att-retry')?.addEventListener('click', loadRoster);
    return;
  }
  roster = res.data || [];
  dbg(`[TEACHER ROSTER] loaded ${roster.length} students`);
  attendanceMarks.clear();
  roster.forEach((s) => { if (s.status) attendanceMarks.set(s.student_id, s.status); });
  renderRoster();
}

async function saveRoster() {
  const classId = el('att-class').value;
  const date = el('att-date').value;
  if (!classId || !date) { toast('اختر القسم والتاريخ', 'error'); return; }
  const rows = roster
    .filter((s) => attendanceMarks.has(s.student_id))
    .map((s) => ({ student_id: s.student_id, status: attendanceMarks.get(s.student_id) }));
  if (!rows.length) { toast('لم يتم تحديد أي حالة بعد', 'error'); return; }
  dbg(`[TEACHER ATTENDANCE] saving ${rows.length} marks class=${classId} date=${date}`);
  const res = await saveAttendance(classId, date, rows);
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم حفظ الحضور بنجاح', 'success');
  loadRoster();
}

// ---- Grades -----------------------------------------------------------------
async function loadClassStudentsInto(selectEl, classId) {
  selectEl.innerHTML = '<option value="">جارٍ التحميل...</option>';
  if (!classId) { selectEl.innerHTML = '<option value="">اختر القسم أولاً</option>'; return; }
  // FIX (Phase 23): this used to reuse fn_get_class_attendance (a
  // date-scoped attendance query) purely to get a student list, coupling
  // Grades/Incidents to an unrelated feature. Now uses the dedicated,
  // simpler fn_teacher_class_roster.
  const res = await teacherClassRoster(classId);
  if (!res.ok) {
    selectEl.innerHTML = `<option value="">تعذر تحميل التلاميذ: ${esc(res.error || 'خطأ غير معروف')}</option>`;
    toast(res.error || 'تعذر تحميل تلاميذ القسم', 'error');
    return;
  }
  const students = res.data || [];
  gradeRoster = students;
  selectEl.innerHTML = students.length
    ? '<option value="">اختر التلميذ بالاسم</option>' + students.map((s) => `<option value="${s.student_id}">${esc(s.full_name)}${s.student_number ? ' — #' + esc(s.student_number) : ''}</option>`).join('')
    : '<option value="">لا يوجد تلاميذ في هذا القسم</option>';
  renderGradeStudentRoster();
  updateSelectedStudentInfo();
}

function renderGradeStudentRoster() {
  const host = el('gr-student-roster');
  if (!host) return;
  const q = (el('gr-student-search')?.value || '').trim().toLowerCase();
  const selected = el('gr-student')?.value || '';
  const rows = gradeRoster.filter(s => !q || `${s.full_name || ''} ${s.student_number || ''}`.toLowerCase().includes(q));
  host.innerHTML = rows.length ? rows.map((s, i) => `
    <button type="button" class="${String(s.student_id) === String(selected) ? 'active' : ''}" data-grade-student="${s.student_id}">
      <span><strong>${esc(s.full_name || '—')}</strong><small style="display:block;color:var(--muted);">${s.student_number ? 'رقم: ' + esc(s.student_number) : 'تلميذ'}</small></span>
      <span aria-hidden="true">${String(s.student_id) === String(selected) ? '✓' : '›'}</span>
    </button>`).join('') : '<div class="empty-state">لا يوجد تلميذ مطابق للبحث.</div>';
  host.querySelectorAll('[data-grade-student]').forEach(btn => btn.addEventListener('click', () => {
    const id = btn.dataset.gradeStudent;
    el('gr-student').value = id;
    renderGradeStudentRoster();
    updateSelectedStudentInfo();
    loadStudentGrades();
  }));
}

function updateSelectedStudentInfo() {
  const id = el('gr-student')?.value;
  const student = gradeRoster.find(s => String(s.student_id) === String(id));
  const host = el('gr-selected-student-info');
  if (host) host.textContent = student ? `التلميذ المختار: ${student.full_name}${student.student_number ? ' — رقم ' + student.student_number : ''}` : 'اختر تلميذاً من اللائحة لإدخال نقطته';
}

async function loadCoefficients(classId) {
  const subjectEl = el('gr-subject');
  const coeffEl = el('gr-coefficient');
  if (!subjectEl || !coeffEl) return;
  coeffEl.value = '—';
  if (!classId) return;
  const res = await gradeSubjectCoefficients(classId);
  if (!res.ok) { toast(res.error || 'تعذر تحميل معاملات المواد', 'error'); return; }
  coefficientRows = res.data || [];
  const selected = coefficientRows.find(r => String(r.subject_id) === String(subjectEl.value));
  coeffEl.value = selected?.coefficient ?? '1';
}
function refreshSelectedCoefficient() {
  const row = coefficientRows.find(r => String(r.subject_id) === String(el('gr-subject')?.value));
  if (el('gr-coefficient')) el('gr-coefficient').value = row?.coefficient ?? '1';
}

async function loadStudentGrades() {
  const studentId = el('gr-student')?.value;
  const subjectId = el('gr-subject')?.value;
  const classId = el('gr-class')?.value;
  const period = el('gr-period')?.value;
  const host = el('gr-list');
  if (!studentId) { host.innerHTML = emptyHtml('اختر تلميذًا لعرض نقاطه.'); return; }
  if (!subjectId || !classId) { host.innerHTML = emptyHtml('اختر القسم والمادة أولاً.'); return; }
  host.innerHTML = loadingHtml();
  const res = await listStudentAssessmentMarks(studentId, subjectId, classId, period);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) {
    if (el('gr-summary')) el('gr-summary').innerHTML = emptyHtml('لا توجد نقط مسجلة لهذا التلميذ في هذه المادة والفترة.');
    host.innerHTML = emptyHtml('لا توجد نقط مسجلة لهذا التلميذ في المادة المختارة.');
    return;
  }
  renderGradeSummary(rows);
  host.innerHTML = `<div class="data-table-wrap"><table class="data-table"><thead><tr>
    <th>التقييم</th><th>النوع</th><th>النقطة</th><th>المعامل</th><th>ملاحظة</th><th>التاريخ</th>
  </tr></thead><tbody>${rows.map((g) => `<tr>
    <td>${esc(g.title || '—')}</td><td>${esc(g.assessment_type || '—')}</td>
    <td>${g.score}/${g.max_score ?? 20}</td><td>${Number(g.coefficient || 1).toFixed(2)}</td>
    <td>${esc(g.teacher_note || '—')}</td><td>${fmtDate(g.assessment_date || g.created_at)}</td>
  </tr>`).join('')}</tbody></table></div>`;
}

function gradeScale() {
  const text = el('gr-class')?.selectedOptions?.[0]?.textContent || '';
  return /ابتدائي|الأول|الثاني|الثالث|الرابع|الخامس|السادس/.test(text) ? 10 : 20;
}

function renderGradeSummary(rows) {
  const host = el('gr-summary');
  if (!host) return;
  if (!rows?.length) { host.innerHTML = '<div class="empty-state">لا توجد نقط بعد.</div>'; return; }
  const scale = gradeScale();
  const weighted = rows.reduce((acc, g) => {
    const max = Number(g.max_score) || scale;
    const score = Number(g.score);
    const coefficient = Number(g.coefficient) || 1;
    if (!Number.isFinite(score) || !Number.isFinite(max)) return acc;
    acc.total += (score / max) * scale * coefficient;
    acc.coeff += coefficient;
    return acc;
  }, { total: 0, coeff: 0 });
  const avg = weighted.coeff ? weighted.total / weighted.coeff : 0;
  host.innerHTML = `<strong>معدل المادة في الفترة:</strong> ${avg.toFixed(2)} / ${scale}<br><small>يُحتسب حسب معاملات التقييمات المسجلة للمادة المختارة فقط.</small>`;
}

function printGrades() {
  const content = el('gr-list')?.innerHTML || '';
  const summary = el('gr-summary')?.innerHTML || '';
  const student = el('gr-student')?.selectedOptions?.[0]?.textContent || 'التلميذ';
  const w = window.open('', '_blank');
  if (!w) { toast('اسمح بالنوافذ المنبثقة للطباعة', 'error'); return; }
  w.document.write(`<html dir="rtl"><head><meta charset="utf-8"><title>كشف نقط ${student}</title><style>body{font-family:Arial;padding:24px}table{width:100%;border-collapse:collapse}td,th{border:1px solid #999;padding:8px;text-align:right}</style></head><body><h2>كشف نقط التلميذ: ${student}</h2><div>${summary}</div>${content}</body></html>`);
  w.document.close(); w.focus(); w.print();
}

let selectedAssessment = null;

async function loadAssessments() {
  const classId = el('gr-class').value;
  const subjectId = el('gr-subject').value;
  const period = el('gr-period').value;
  const host = el('gr-assessments');
  if (!classId || !subjectId) { host.innerHTML = emptyHtml('اختر القسم والمادة أولاً.'); return; }
  host.innerHTML = loadingHtml();
  const res = await listGradeAssessments(classId, subjectId, period);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد تقييمات بعد. أنشئ أول فرض أو امتحان.'); return; }
  host.innerHTML = rows.map(a => `<button type="button" class="detail-row" data-assessment="${a.id}" style="width:100%;text-align:right;display:flex;justify-content:space-between;gap:12px;align-items:center;border:1px solid var(--border,#e5e7eb);border-radius:12px;padding:12px;background:var(--surface,#fff);margin-bottom:8px;cursor:pointer;"><span><strong>${esc(a.title)}</strong><small style="display:block;color:var(--muted);">${esc(a.assessment_type)} · ${esc(a.period)}</small></span><span class="badge badge-blue">معامل ${Number(a.coefficient).toFixed(2)}</span></button>`).join('');
  host.querySelectorAll('[data-assessment]').forEach(b => b.addEventListener('click', () => selectAssessment(rows.find(a => a.id === b.dataset.assessment))));
}

function selectAssessment(a) {
  selectedAssessment = a;
  el('gr-entry-panel').hidden = false;
  if (el('gr-save')) el('gr-save').disabled = false;
  if (el('gr-score')) { el('gr-score').value = ''; el('gr-score').focus({ preventScroll: true }); }
  if (el('gr-note')) el('gr-note').value = '';
  el('gr-selected-assessment').innerHTML = `<strong>${esc(a.title)}</strong> — ${esc(a.assessment_type)} · معامل التقييم: <strong>${Number(a.coefficient).toFixed(2)}</strong> · النقطة القصوى: ${Number(a.max_score)}`;
  el('gr-score').max = a.max_score;
  updateSelectedStudentInfo();
  renderGradeStudentRoster();
  updateGradeSaveState();
}

async function createAssessment() {
  const classId = el('gr-class').value, subjectId = el('gr-subject').value;
  const title = el('gr-title').value.trim();
  const coefficient = Number(el('gr-assessment-coefficient').value);
  const maxScore = Number(el('gr-max').value);
  if (!classId || !subjectId) return toast('اختر القسم والمادة أولاً', 'error');
  if (!title) return toast('أدخل عنوان التقييم', 'error');
  if (!(coefficient > 0) || !(maxScore > 0)) return toast('تحقق من المعامل والنقطة القصوى', 'error');
  const res = await createGradeAssessment({ schoolId: ctx.schoolId, classId, subjectId, period: el('gr-period').value, title, assessmentType: el('gr-type').value, coefficient, maxScore, assessmentDate: el('gr-date').value || null });
  if (!res.ok) return toast(res.error, 'error');
  toast('تم إنشاء التقييم بنجاح', 'success');
  el('gr-title').value = '';
  await loadAssessments();
  selectAssessment(res.data);
}

function updateGradeSaveState() {
  const button = el('gr-save');
  if (!button) return;
  const studentId = el('gr-student')?.value || '';
  const scoreText = (el('gr-score')?.value || '').trim();
  const score = Number(scoreText);
  const max = Number(selectedAssessment?.max_score);

  // Keep the button usable so the teacher receives a clear validation message
  // when the assessment or student has not been selected yet. Previously the
  // button stayed disabled even after entering a score in some mobile browsers.
  const validScore = scoreText !== '' && Number.isFinite(score) &&
    (!selectedAssessment || !Number.isFinite(max) || (score >= 0 && score <= max));
  button.disabled = !(studentId && validScore);
}

async function saveGrade() {
  if (!selectedAssessment) return toast('اختر تقييماً أولاً', 'error');
  const studentId = el('gr-student').value;
  const scoreText = (el('gr-score')?.value || '').trim();
  const score = Number(scoreText);
  if (!studentId) return toast('اختر التلميذ', 'error');
  if (scoreText === '') return toast('أدخل نقطة التلميذ أولاً', 'error');
  if (!Number.isFinite(score) || score < 0 || score > Number(selectedAssessment.max_score)) return toast('النقطة خارج المجال المسموح', 'error');
  const res = await saveGradeMark({ assessmentId: selectedAssessment.id, studentId, score, teacherNote: el('gr-note').value.trim() || null });
  if (!res.ok) return toast(res.error, 'error');
  toast('تم حفظ النقطة بنجاح', 'success');
  el('gr-score').value = ''; el('gr-note').value = '';
  updateGradeSaveState();
  await loadStudentGrades();
  // Refresh the assessment list so the selected assessment remains current.
  await loadAssessments();
  const refreshed = (el('gr-assessments')?.querySelector(`[data-assessment=\"${selectedAssessment.id}\"]`));
  if (refreshed) refreshed.classList.add('active');
}

// ---- Schedule ---------------------------------------------------------------
async function loadSchedule() {
  const host = el('sc-table');
  const currentHost = el('sc-current');
  host.innerHTML = loadingHtml();
  currentHost.innerHTML = '';
  const res = await getMyTeacherSchedule();
  if (!res.ok) {
    host.innerHTML = errorHtml(res.error) + `<button type="button" class="quick-action-btn secondary" id="sc-retry" style="width:100%; margin-top:8px;">🔄 إعادة المحاولة</button>`;
    el('sc-retry')?.addEventListener('click', loadSchedule);
    return;
  }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد حصص مسندة إليك حاليًا.'); return; }
  const now = new Date();
  const jsDay = now.getDay();
  const mins = now.getHours() * 60 + now.getMinutes();
  const dayRows = rows.filter(r => Number(r.weekday) === jsDay);
  const active = dayRows.find(r => {
    const [sh, sm] = String(r.starts_at || '').slice(0,5).split(':').map(Number);
    const [eh, em] = String(r.ends_at || '').slice(0,5).split(':').map(Number);
    return mins >= sh*60+sm && mins < eh*60+em;
  });
  const next = dayRows.find(r => {
    const [sh, sm] = String(r.starts_at || '').slice(0,5).split(':').map(Number);
    return sh*60+sm > mins;
  });
  currentHost.innerHTML = active
    ? `<div class="panel" style="border:1px solid #16a34a55;background:#f0fdf4;"><strong>🟢 حصتك الآن</strong><div style="font-size:1.05em;margin-top:4px;">${esc(active.subject_name)} — ${esc(active.class_name)}</div><div class="time">${esc(String(active.starts_at).slice(0,5))} → ${esc(String(active.ends_at).slice(0,5))}</div></div>`
    : next
      ? `<div class="panel" style="border:1px solid #d4a72c55;background:#fffbeb;"><strong>⏭️ الحصة القادمة</strong><div style="font-size:1.05em;margin-top:4px;">${esc(next.subject_name)} — ${esc(next.class_name)}</div><div class="time">${esc(String(next.starts_at).slice(0,5))} → ${esc(String(next.ends_at).slice(0,5))}</div></div>`
      : `<div class="empty-state">لا توجد حصة جارية أو قادمة اليوم.</div>`;
  host.innerHTML = `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>اليوم</th><th>الوقت</th><th>الحصة</th><th>المادة</th></tr></thead><tbody>${rows.map(r => `<tr class="${Number(r.weekday)===jsDay ? 'today-row':''}"><td>${esc(WEEKDAYS_AR[r.weekday] || r.weekday)}</td><td><strong>${esc(String(r.starts_at||'').slice(0,5))} — ${esc(String(r.ends_at||'').slice(0,5))}</strong></td><td>${esc(r.class_name||'—')}</td><td>${esc(r.subject_name||'—')}</td></tr>`).join('')}</tbody></table></div>`;
}

// ---- Incidents --------------------------------------------------------------
async function saveIncident() {
  const studentId = el('inc-student').value;
  const desc = el('inc-desc').value.trim();
  if (!studentId) { toast('اختر التلميذ', 'error'); return; }
  const res = await reportIncident({
    studentId,
    type: el('inc-type').value,
    title: el('inc-type').value,
    description: desc || null,
    place: el('inc-place').value.trim() || null,
  });
  if (!res.ok) { toast(res.error, 'error'); return; }
  toast('تم إرسال البلاغ إلى الإدارة', 'success');
  el('inc-desc').value = '';
  el('inc-place').value = '';
}

// ---- Notifications ----------------------------------------------------------
async function loadNotifications() {
  const host = el('notif-list');
  host.innerHTML = loadingHtml();
  const res = await listMyNotifications(50);
  if (!res.ok) { host.innerHTML = errorHtml(res.error); return; }
  const rows = res.data || [];
  if (!rows.length) { host.innerHTML = emptyHtml('لا توجد إشعارات.'); refreshNotifBadge(); return; }
  const typeLabels = { announcement: 'إعلان', incident: 'بلاغ', attendance: 'حضور', grade: 'نقطة', transport: 'نقل', schedule: 'جدول', system: 'نظام' };
  host.innerHTML = rows.map((n) => `
    <div class="notif-swipe-wrap">
      <div class="notif-delete-zone">🗑 حذف</div>
      <div class="notif-card" data-notif="${n.notification_id}" style="${n.is_read ? 'opacity:.65;' : 'font-weight:600;'}">
        <div class="notif-head">
          <span>${esc(n.title)}</span>
          <span class="badge badge-blue">${esc(typeLabels[n.type] || n.type || 'إشعار')}</span>
        </div>
        ${n.body ? `<div class="notif-body">${esc(n.body)}</div>` : ''}
        ${n.image_url ? `<img src="${esc(n.image_url)}" alt="">` : ''}
        <div class="time">${fmtDateTime(n.created_at)}</div>
      </div>
    </div>`).join('');

  host.querySelectorAll('.notif-card').forEach((card) => {
    card.addEventListener('click', async () => {
      if (card.dataset.swiping === '1') return;
      await markNotificationRead(card.dataset.notif);
      card.style.opacity = '.65';
      card.style.fontWeight = '400';
      openNotificationDetails(rows.find((n) => n.notification_id === card.dataset.notif));
      refreshNotifBadge();
    });

    let startX = 0, dx = 0, dragging = false;
    card.addEventListener('touchstart', (e) => { startX = e.touches[0].clientX; dragging = true; card.style.transition = 'none'; }, { passive: true });
    card.addEventListener('touchmove', (e) => {
      if (!dragging) return;
      dx = e.touches[0].clientX - startX;
      if (dx < 0) card.style.transform = `translateX(${dx}px)`;
    }, { passive: true });
    card.addEventListener('touchend', async () => {
      dragging = false;
      card.style.transition = 'transform .2s';
      if (dx < -90) {
        card.dataset.swiping = '1';
        card.style.transform = 'translateX(-100%)';
        const res2 = await deleteMyNotification(card.dataset.notif);
        if (res2.ok) {
          setTimeout(() => { card.closest('.notif-swipe-wrap')?.remove(); refreshNotifBadge(); }, 180);
        } else {
          card.style.transform = 'translateX(0)';
          setTimeout(() => { card.dataset.swiping = '0'; }, 200);
        }
      } else {
        card.style.transform = 'translateX(0)';
      }
      dx = 0;
    });
  });
  refreshNotifBadge();
}

async function refreshNotifBadge() {
  const res = await unreadNotificationsCount();
  const badge = el('notif-count');
  if (!badge) return;
  const count = res.ok ? (res.data || 0) : 0;
  badge.hidden = !count;
  badge.textContent = count;
}

// ---- Init -------------------------------------------------------------------
(async () => {
  try {
    initErrorMonitor('teacher.html');
    ctx = await requireAuth('teacher.html');
    if (!ctx) return;
    armViewHistory('home');
    document.getElementById('app-body').hidden = false;

    // Header/profile lookup is non-fatal: a transient profile RPC failure must
    // never prevent a valid teacher session from opening the dashboard.
    let schoolName = null;
    try {
      const schoolRes = await getSchoolProfile(ctx.schoolId);
      schoolName = schoolRes.ok ? schoolRes.data?.name : null;
    } catch (e) {
      console.warn('teacher school profile lookup failed:', e);
    }
    await initPageHeader(ctx, schoolName, logout);

    const bind = (id, event, fn) => { const node = el(id); if (node) node.addEventListener(event, fn); };
    const dateEl = el('att-date');
    if (dateEl) dateEl.value = new Date().toISOString().slice(0, 10);

    document.querySelectorAll('[data-go]').forEach((b) => {
      b.addEventListener('click', () => {
        showView(b.dataset.go);
        if (b.dataset.go === 'notifications') loadNotifications();
        if (b.dataset.go === 'grades') { loadSubjectsInto().then(async () => { const cid = el('gr-class')?.value; if (cid) { await loadClassStudentsInto(el('gr-student'), cid); await loadCoefficients(cid); refreshSelectedCoefficient(); await loadAssessments(); } }); }
        if (b.dataset.go === 'schedule') loadSchedule();
      });
    });
    document.querySelectorAll('[data-back]').forEach((b) => b.addEventListener('click', () => showView('home')));
    bind('notif-btn', 'click', () => { showView('notifications'); loadNotifications(); });
    bind('att-load', 'click', loadRoster);
    bind('att-save', 'click', saveRoster);
    bind('gr-class', 'change', async () => { const cid = el('gr-class')?.value; selectedAssessment = null; if (el('gr-save')) el('gr-save').disabled = true; await loadClassStudentsInto(el('gr-student'), cid); updateSelectedStudentInfo(); await loadCoefficients(cid); refreshSelectedCoefficient(); await loadAssessments(); });
    bind('gr-student', 'change', () => { updateSelectedStudentInfo(); renderGradeStudentRoster(); loadStudentGrades(); });
    bind('gr-student-search', 'input', renderGradeStudentRoster);
    bind('gr-score', 'input', updateGradeSaveState);
    bind('gr-note', 'input', updateGradeSaveState);
    bind('gr-subject', 'change', async () => { refreshSelectedCoefficient(); await loadAssessments(); });
    bind('gr-period', 'change', loadAssessments);
    bind('gr-create-assessment', 'click', createAssessment);
    bind('gr-save', 'click', saveGrade);
    bind('gr-print', 'click', printGrades);
    bind('inc-class', 'change', () => loadClassStudentsInto(el('inc-student'), el('inc-class')?.value));
    bind('inc-save', 'click', saveIncident);

    // The shell is already visible; loadHome is isolated so a dashboard data
    // problem cannot turn into a fatal "تعذر تحميل اللوحة" screen.
    try { await loadHome(); }
    catch (e) {
      console.error('teacher home load error:', e);
      const host = el('dash-stats');
      if (host) host.innerHTML = errorHtml(e?.message || 'تعذر تحميل بيانات الأستاذ.');
    }
    refreshNotifBadge();
  } catch (error) {
    console.error('teacher console init error:', error);
    showInitError(error);
  }
})();

async function loadSubjectsInto() {
  if (subjects.length) return;
  // PHASE 14: a teacher only ever sees their ASSIGNED subjects (the server
  // independently enforces the same rule in fn_add_grade). fn_list_subjects
  // returns subject_id/subject_name — the old s.id/s.name keys produced
  // empty option values and server-side GRADE_SUBJECT_REQUIRED failures.
  const res = await myTeacherSubjects();
  if (res.ok) {
    subjects = res.data || [];
    el('gr-subject').innerHTML = subjects.length
      ? '<option value="">اختر المادة</option>' + subjects.map((s) => `<option value="${s.subject_id}">${esc(s.subject_name)}</option>`).join('')
      : '<option value="">لا توجد مواد مسندة — راجع الإدارة</option>';
  }
}
